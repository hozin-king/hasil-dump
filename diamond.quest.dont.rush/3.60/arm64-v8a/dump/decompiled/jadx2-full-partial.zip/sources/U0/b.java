package U0;

import com.fasterxml.jackson.core.c;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes3.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    private final b f1826a;

    /* renamed from: b, reason: collision with root package name */
    private final AtomicReference f1827b;

    /* renamed from: c, reason: collision with root package name */
    private final int f1828c;

    /* renamed from: d, reason: collision with root package name */
    private final int f1829d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f1830e;

    /* renamed from: f, reason: collision with root package name */
    private String[] f1831f;

    /* renamed from: g, reason: collision with root package name */
    private a[] f1832g;

    /* renamed from: h, reason: collision with root package name */
    private int f1833h;

    /* renamed from: i, reason: collision with root package name */
    private int f1834i;

    /* renamed from: j, reason: collision with root package name */
    private int f1835j;

    /* renamed from: k, reason: collision with root package name */
    private int f1836k;

    /* renamed from: l, reason: collision with root package name */
    private boolean f1837l;

    static final class a {
    }

    /* renamed from: U0.b$b, reason: collision with other inner class name */
    private static final class C0083b {

        /* renamed from: a, reason: collision with root package name */
        final int f1838a;

        /* renamed from: b, reason: collision with root package name */
        final int f1839b;

        /* renamed from: c, reason: collision with root package name */
        final String[] f1840c;

        /* renamed from: d, reason: collision with root package name */
        final a[] f1841d;

        public C0083b(int i5, int i6, String[] strArr, a[] aVarArr) {
            this.f1838a = i5;
            this.f1839b = i6;
            this.f1840c = strArr;
            this.f1841d = aVarArr;
        }

        public static C0083b a(int i5) {
            return new C0083b(0, 0, new String[i5], new a[i5 >> 1]);
        }
    }

    private b(int i5) {
        this.f1826a = null;
        this.f1828c = i5;
        this.f1830e = true;
        this.f1829d = -1;
        this.f1837l = false;
        this.f1836k = 0;
        this.f1827b = new AtomicReference(C0083b.a(64));
    }

    private static int a(int i5) {
        return i5 - (i5 >> 2);
    }

    public static b b() {
        long currentTimeMillis = System.currentTimeMillis();
        return c((((int) currentTimeMillis) + ((int) (currentTimeMillis >>> 32))) | 1);
    }

    protected static b c(int i5) {
        return new b(i5);
    }

    private b(b bVar, int i5, int i6, C0083b c0083b) {
        this.f1826a = bVar;
        this.f1828c = i6;
        this.f1827b = null;
        this.f1829d = i5;
        this.f1830e = c.a.CANONICALIZE_FIELD_NAMES.c(i5);
        String[] strArr = c0083b.f1840c;
        this.f1831f = strArr;
        this.f1832g = c0083b.f1841d;
        this.f1833h = c0083b.f1838a;
        this.f1836k = c0083b.f1839b;
        int length = strArr.length;
        this.f1834i = a(length);
        this.f1835j = length - 1;
        this.f1837l = true;
    }
}
