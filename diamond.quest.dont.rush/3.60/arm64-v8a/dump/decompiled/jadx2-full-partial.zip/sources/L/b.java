package L;

import androidx.lifecycle.K;
import androidx.lifecycle.L;
import androidx.lifecycle.M;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class b implements L.b {

    /* renamed from: a, reason: collision with root package name */
    private final f[] f1414a;

    public b(f... initializers) {
        C7150s.j(initializers, "initializers");
        this.f1414a = initializers;
    }

    @Override // androidx.lifecycle.L.b
    public K a(Class modelClass, a extras) {
        C7150s.j(modelClass, "modelClass");
        C7150s.j(extras, "extras");
        K k5 = null;
        for (f fVar : this.f1414a) {
            if (C7150s.e(fVar.a(), modelClass)) {
                Object invoke = fVar.b().invoke(extras);
                k5 = invoke instanceof K ? (K) invoke : null;
            }
        }
        if (k5 != null) {
            return k5;
        }
        throw new IllegalArgumentException("No initializer set for given class " + modelClass.getName());
    }

    @Override // androidx.lifecycle.L.b
    public /* synthetic */ K b(Class cls) {
        return M.a(this, cls);
    }
}
