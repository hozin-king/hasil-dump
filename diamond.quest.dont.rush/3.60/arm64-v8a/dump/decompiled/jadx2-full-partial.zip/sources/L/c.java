package L;

import U3.l;
import androidx.lifecycle.L;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    private final List f1415a = new ArrayList();

    public final void a(Z3.c clazz, l initializer) {
        C7150s.j(clazz, "clazz");
        C7150s.j(initializer, "initializer");
        this.f1415a.add(new f(T3.a.a(clazz), initializer));
    }

    public final L.b b() {
        f[] fVarArr = (f[]) this.f1415a.toArray(new f[0]);
        return new b((f[]) Arrays.copyOf(fVarArr, fVarArr.length));
    }
}
