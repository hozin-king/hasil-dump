package a4;

import Y3.l;
import a4.b;
import io.bidmachine.media3.common.PlaybackException;
import java.util.Collection;
import java.util.Iterator;
import kotlin.collections.I;
import kotlin.jvm.internal.C7150s;
import kotlin.text.o;

/* loaded from: classes8.dex */
public abstract class d {
    /* JADX INFO: Access modifiers changed from: private */
    public static final long i(long j5, int i5) {
        return b.j((j5 << 1) + i5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long j(long j5) {
        return b.j((j5 << 1) + 1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long k(long j5) {
        return new Y3.k(-4611686018426L, 4611686018426L).g(j5) ? l(n(j5)) : j(l.l(j5, -4611686018427387903L, 4611686018427387903L));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long l(long j5) {
        return b.j(j5 << 1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long m(long j5) {
        return new Y3.k(-4611686018426999999L, 4611686018426999999L).g(j5) ? l(j5) : j(o(j5));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long n(long j5) {
        return j5 * PlaybackException.CUSTOM_ERROR_CODE_BASE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long o(long j5) {
        return j5 / PlaybackException.CUSTOM_ERROR_CODE_BASE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final long p(String str, boolean z4) {
        int i5;
        boolean z5;
        int i6;
        boolean z6;
        int length = str.length();
        if (length == 0) {
            throw new IllegalArgumentException("The string is empty");
        }
        b.a aVar = b.f2244c;
        long c5 = aVar.c();
        char charAt = str.charAt(0);
        int i7 = (charAt == '+' || charAt == '-') ? 1 : 0;
        boolean z7 = i7 > 0;
        boolean z8 = z7 && o.M0(str, '-', false, 2, null);
        if (length <= i7) {
            throw new IllegalArgumentException("No components");
        }
        char c6 = '9';
        char c7 = '0';
        String str2 = "null cannot be cast to non-null type java.lang.String";
        if (str.charAt(i7) == 'P') {
            int i8 = i7 + 1;
            if (i8 == length) {
                throw new IllegalArgumentException();
            }
            boolean z9 = false;
            e eVar = null;
            while (i8 < length) {
                if (str.charAt(i8) != 'T') {
                    int i9 = i8;
                    while (true) {
                        if (i9 >= str.length()) {
                            i6 = length;
                            break;
                        }
                        char charAt2 = str.charAt(i9);
                        if (!new Y3.c(c7, c6).g(charAt2)) {
                            i6 = length;
                            if (!o.S("+-.", charAt2, false, 2, null)) {
                                break;
                            }
                        } else {
                            i6 = length;
                        }
                        i9++;
                        length = i6;
                        c7 = '0';
                        c6 = '9';
                    }
                    C7150s.h(str, "null cannot be cast to non-null type java.lang.String");
                    String substring = str.substring(i8, i9);
                    C7150s.i(substring, "substring(...)");
                    if (substring.length() == 0) {
                        throw new IllegalArgumentException();
                    }
                    int length2 = i8 + substring.length();
                    if (length2 < 0 || length2 > o.c0(str)) {
                        throw new IllegalArgumentException("Missing unit for value " + substring);
                    }
                    char charAt3 = str.charAt(length2);
                    i8 = length2 + 1;
                    e d5 = g.d(charAt3, z9);
                    if (eVar != null && eVar.compareTo(d5) <= 0) {
                        throw new IllegalArgumentException("Unexpected order of duration components");
                    }
                    int h02 = o.h0(substring, '.', 0, false, 6, null);
                    if (d5 != e.f2254f || h02 <= 0) {
                        z6 = z9;
                        c5 = b.E(c5, t(q(substring), d5));
                    } else {
                        C7150s.h(substring, "null cannot be cast to non-null type java.lang.String");
                        String substring2 = substring.substring(0, h02);
                        C7150s.i(substring2, "substring(...)");
                        z6 = z9;
                        long E4 = b.E(c5, t(q(substring2), d5));
                        C7150s.h(substring, "null cannot be cast to non-null type java.lang.String");
                        String substring3 = substring.substring(h02);
                        C7150s.i(substring3, "substring(...)");
                        c5 = b.E(E4, r(Double.parseDouble(substring3), d5));
                    }
                    z9 = z6;
                    eVar = d5;
                    length = i6;
                    c7 = '0';
                    c6 = '9';
                } else {
                    if (z9 || (i8 = i8 + 1) == length) {
                        throw new IllegalArgumentException();
                    }
                    z9 = true;
                }
            }
        } else {
            if (z4) {
                throw new IllegalArgumentException();
            }
            char c8 = '0';
            if (o.E(str, i7, "Infinity", 0, Math.max(length - i7, 8), true)) {
                c5 = aVar.a();
            } else {
                boolean z10 = !z7;
                if (z7 && str.charAt(i7) == '(' && o.m1(str) == ')') {
                    i7++;
                    int i10 = length - 1;
                    if (i7 == i10) {
                        throw new IllegalArgumentException("No components");
                    }
                    i5 = i10;
                    z10 = true;
                } else {
                    i5 = length;
                }
                boolean z11 = false;
                e eVar2 = null;
                while (i7 < i5) {
                    if (z11 && z10) {
                        while (i7 < str.length() && str.charAt(i7) == ' ') {
                            i7++;
                        }
                    }
                    int i11 = i7;
                    while (i11 < str.length()) {
                        char charAt4 = str.charAt(i11);
                        if (!new Y3.c(c8, '9').g(charAt4) && charAt4 != '.') {
                            break;
                        }
                        i11++;
                    }
                    C7150s.h(str, str2);
                    String substring4 = str.substring(i7, i11);
                    C7150s.i(substring4, "substring(...)");
                    if (substring4.length() == 0) {
                        throw new IllegalArgumentException();
                    }
                    int length3 = i7 + substring4.length();
                    int i12 = length3;
                    while (true) {
                        if (i12 >= str.length()) {
                            z5 = z10;
                            break;
                        }
                        z5 = z10;
                        if (!new Y3.c('a', 'z').g(str.charAt(i12))) {
                            break;
                        }
                        i12++;
                        z10 = z5;
                    }
                    C7150s.h(str, str2);
                    String substring5 = str.substring(length3, i12);
                    C7150s.i(substring5, "substring(...)");
                    i7 = length3 + substring5.length();
                    e e5 = g.e(substring5);
                    if (eVar2 != null && eVar2.compareTo(e5) <= 0) {
                        throw new IllegalArgumentException("Unexpected order of duration components");
                    }
                    int h03 = o.h0(substring4, '.', 0, false, 6, null);
                    if (h03 > 0) {
                        C7150s.h(substring4, str2);
                        String substring6 = substring4.substring(0, h03);
                        C7150s.i(substring6, "substring(...)");
                        String str3 = str2;
                        long E5 = b.E(c5, t(Long.parseLong(substring6), e5));
                        C7150s.h(substring4, str3);
                        String substring7 = substring4.substring(h03);
                        C7150s.i(substring7, "substring(...)");
                        c5 = b.E(E5, r(Double.parseDouble(substring7), e5));
                        if (i7 < i5) {
                            throw new IllegalArgumentException("Fractional component must be last");
                        }
                        eVar2 = e5;
                        str2 = str3;
                    } else {
                        c5 = b.E(c5, t(Long.parseLong(substring4), e5));
                        eVar2 = e5;
                    }
                    z11 = true;
                    c8 = '0';
                    z10 = z5;
                }
            }
        }
        return z8 ? b.K(c5) : c5;
    }

    private static final long q(String str) {
        int length = str.length();
        int i5 = (length <= 0 || !o.S("+-", str.charAt(0), false, 2, null)) ? 0 : 1;
        if (length - i5 > 16) {
            Iterable hVar = new Y3.h(i5, o.c0(str));
            if (!(hVar instanceof Collection) || !((Collection) hVar).isEmpty()) {
                Iterator it = hVar.iterator();
                while (it.hasNext()) {
                    if (!new Y3.c('0', '9').g(str.charAt(((I) it).nextInt()))) {
                    }
                }
            }
            return str.charAt(0) == '-' ? Long.MIN_VALUE : Long.MAX_VALUE;
        }
        return o.O(str, "+", false, 2, null) ? Long.parseLong(o.j1(str, 1)) : Long.parseLong(str);
    }

    public static final long r(double d5, e unit) {
        C7150s.j(unit, "unit");
        double a5 = f.a(d5, unit, e.f2251c);
        if (Double.isNaN(a5)) {
            throw new IllegalArgumentException("Duration value cannot be NaN.");
        }
        long d6 = W3.a.d(a5);
        return new Y3.k(-4611686018426999999L, 4611686018426999999L).g(d6) ? l(d6) : k(W3.a.d(f.a(d5, unit, e.f2253e)));
    }

    public static final long s(int i5, e unit) {
        C7150s.j(unit, "unit");
        return unit.compareTo(e.f2254f) <= 0 ? l(f.c(i5, unit, e.f2251c)) : t(i5, unit);
    }

    public static final long t(long j5, e unit) {
        C7150s.j(unit, "unit");
        e eVar = e.f2251c;
        long c5 = f.c(4611686018426999999L, eVar, unit);
        return new Y3.k(-c5, c5).g(j5) ? l(f.c(j5, unit, eVar)) : j(l.l(f.b(j5, unit, e.f2253e), -4611686018427387903L, 4611686018427387903L));
    }
}
