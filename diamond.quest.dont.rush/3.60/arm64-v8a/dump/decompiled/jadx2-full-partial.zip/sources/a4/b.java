package a4;

import Y3.l;
import io.bidmachine.media3.common.PlaybackException;
import io.bidmachine.media3.exoplayer.upstream.CmcdData;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.text.o;

/* loaded from: classes8.dex */
public final class b implements Comparable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f2244c = new a(null);

    /* renamed from: d, reason: collision with root package name */
    private static final long f2245d = j(0);

    /* renamed from: e, reason: collision with root package name */
    private static final long f2246e;

    /* renamed from: f, reason: collision with root package name */
    private static final long f2247f;

    /* renamed from: b, reason: collision with root package name */
    private final long f2248b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final long a() {
            return b.f2246e;
        }

        public final long b() {
            return b.f2247f;
        }

        public final long c() {
            return b.f2245d;
        }

        public final long d(String value) {
            long p5;
            C7150s.j(value, "value");
            try {
                p5 = d.p(value, true);
                return p5;
            } catch (IllegalArgumentException e5) {
                throw new IllegalArgumentException("Invalid ISO duration string format: '" + value + "'.", e5);
            }
        }

        private a() {
        }
    }

    static {
        long j5;
        long j6;
        j5 = d.j(4611686018427387903L);
        f2246e = j5;
        j6 = d.j(-4611686018427387903L);
        f2247f = j6;
    }

    private /* synthetic */ b(long j5) {
        this.f2248b = j5;
    }

    private static final boolean A(long j5) {
        return (((int) j5) & 1) == 0;
    }

    public static final boolean B(long j5) {
        return j5 == f2246e || j5 == f2247f;
    }

    public static final boolean C(long j5) {
        return j5 < 0;
    }

    public static final boolean D(long j5) {
        return j5 > 0;
    }

    public static final long E(long j5, long j6) {
        long k5;
        long m5;
        if (B(j5)) {
            if (y(j6) || (j6 ^ j5) >= 0) {
                return j5;
            }
            throw new IllegalArgumentException("Summing infinite durations of different signs yields an undefined result.");
        }
        if (B(j6)) {
            return j6;
        }
        if ((((int) j5) & 1) != (((int) j6) & 1)) {
            return z(j5) ? e(j5, w(j5), w(j6)) : e(j5, w(j6), w(j5));
        }
        long w5 = w(j5) + w(j6);
        if (A(j5)) {
            m5 = d.m(w5);
            return m5;
        }
        k5 = d.k(w5);
        return k5;
    }

    public static final double F(long j5, e unit) {
        C7150s.j(unit, "unit");
        if (j5 == f2246e) {
            return Double.POSITIVE_INFINITY;
        }
        if (j5 == f2247f) {
            return Double.NEGATIVE_INFINITY;
        }
        return f.a(w(j5), v(j5), unit);
    }

    public static final int G(long j5, e unit) {
        C7150s.j(unit, "unit");
        return (int) l.l(I(j5, unit), -2147483648L, 2147483647L);
    }

    public static final String H(long j5) {
        StringBuilder sb = new StringBuilder();
        if (C(j5)) {
            sb.append('-');
        }
        sb.append("PT");
        long l5 = l(j5);
        long o5 = o(l5);
        int s5 = s(l5);
        int u5 = u(l5);
        int t5 = t(l5);
        long j6 = B(j5) ? 9999999999999L : o5;
        boolean z4 = false;
        boolean z5 = j6 != 0;
        boolean z6 = (u5 == 0 && t5 == 0) ? false : true;
        if (s5 != 0 || (z6 && z5)) {
            z4 = true;
        }
        if (z5) {
            sb.append(j6);
            sb.append('H');
        }
        if (z4) {
            sb.append(s5);
            sb.append('M');
        }
        if (z6 || (!z5 && !z4)) {
            f(j5, sb, u5, t5, 9, "S", true);
        }
        String sb2 = sb.toString();
        C7150s.i(sb2, "toString(...)");
        return sb2;
    }

    public static final long I(long j5, e unit) {
        C7150s.j(unit, "unit");
        if (j5 == f2246e) {
            return Long.MAX_VALUE;
        }
        if (j5 == f2247f) {
            return Long.MIN_VALUE;
        }
        return f.b(w(j5), v(j5), unit);
    }

    public static String J(long j5) {
        if (j5 == 0) {
            return "0s";
        }
        if (j5 == f2246e) {
            return "Infinity";
        }
        if (j5 == f2247f) {
            return "-Infinity";
        }
        boolean C4 = C(j5);
        StringBuilder sb = new StringBuilder();
        if (C4) {
            sb.append('-');
        }
        long l5 = l(j5);
        long n5 = n(l5);
        int m5 = m(l5);
        int s5 = s(l5);
        int u5 = u(l5);
        int t5 = t(l5);
        int i5 = 0;
        boolean z4 = n5 != 0;
        boolean z5 = m5 != 0;
        boolean z6 = s5 != 0;
        boolean z7 = (u5 == 0 && t5 == 0) ? false : true;
        if (z4) {
            sb.append(n5);
            sb.append('d');
            i5 = 1;
        }
        if (z5 || (z4 && (z6 || z7))) {
            int i6 = i5 + 1;
            if (i5 > 0) {
                sb.append(' ');
            }
            sb.append(m5);
            sb.append('h');
            i5 = i6;
        }
        if (z6 || (z7 && (z5 || z4))) {
            int i7 = i5 + 1;
            if (i5 > 0) {
                sb.append(' ');
            }
            sb.append(s5);
            sb.append('m');
            i5 = i7;
        }
        if (z7) {
            int i8 = i5 + 1;
            if (i5 > 0) {
                sb.append(' ');
            }
            if (u5 != 0 || z4 || z5 || z6) {
                f(j5, sb, u5, t5, 9, CmcdData.Factory.STREAMING_FORMAT_SS, false);
            } else if (t5 >= 1000000) {
                f(j5, sb, t5 / PlaybackException.CUSTOM_ERROR_CODE_BASE, t5 % PlaybackException.CUSTOM_ERROR_CODE_BASE, 6, "ms", false);
            } else if (t5 >= 1000) {
                f(j5, sb, t5 / 1000, t5 % 1000, 3, "us", false);
            } else {
                sb.append(t5);
                sb.append("ns");
            }
            i5 = i8;
        }
        if (C4 && i5 > 1) {
            sb.insert(1, '(').append(')');
        }
        String sb2 = sb.toString();
        C7150s.i(sb2, "toString(...)");
        return sb2;
    }

    public static final long K(long j5) {
        long i5;
        i5 = d.i(-w(j5), ((int) j5) & 1);
        return i5;
    }

    private static final long e(long j5, long j6, long j7) {
        long o5;
        long j8;
        long n5;
        long n6;
        long l5;
        o5 = d.o(j7);
        long j9 = j6 + o5;
        if (!new Y3.k(-4611686018426L, 4611686018426L).g(j9)) {
            j8 = d.j(l.l(j9, -4611686018427387903L, 4611686018427387903L));
            return j8;
        }
        n5 = d.n(o5);
        long j10 = j7 - n5;
        n6 = d.n(j9);
        l5 = d.l(n6 + j10);
        return l5;
    }

    private static final void f(long j5, StringBuilder sb, int i5, int i6, int i7, String str, boolean z4) {
        sb.append(i5);
        if (i6 != 0) {
            sb.append('.');
            String s02 = o.s0(String.valueOf(i6), i7, '0');
            int i8 = -1;
            int length = s02.length() - 1;
            if (length >= 0) {
                while (true) {
                    int i9 = length - 1;
                    if (s02.charAt(length) != '0') {
                        i8 = length;
                        break;
                    } else if (i9 < 0) {
                        break;
                    } else {
                        length = i9;
                    }
                }
            }
            int i10 = i8 + 1;
            if (z4 || i10 >= 3) {
                sb.append((CharSequence) s02, 0, ((i8 + 3) / 3) * 3);
                C7150s.i(sb, "append(...)");
            } else {
                sb.append((CharSequence) s02, 0, i10);
                C7150s.i(sb, "append(...)");
            }
        }
        sb.append(str);
    }

    public static final /* synthetic */ b g(long j5) {
        return new b(j5);
    }

    public static int i(long j5, long j6) {
        long j7 = j5 ^ j6;
        if (j7 < 0 || (((int) j7) & 1) == 0) {
            return C7150s.l(j5, j6);
        }
        int i5 = (((int) j5) & 1) - (((int) j6) & 1);
        return C(j5) ? -i5 : i5;
    }

    public static long j(long j5) {
        if (c.a()) {
            if (A(j5)) {
                if (!new Y3.k(-4611686018426999999L, 4611686018426999999L).g(w(j5))) {
                    throw new AssertionError(w(j5) + " ns is out of nanoseconds range");
                }
            } else {
                if (!new Y3.k(-4611686018427387903L, 4611686018427387903L).g(w(j5))) {
                    throw new AssertionError(w(j5) + " ms is out of milliseconds range");
                }
                if (new Y3.k(-4611686018426L, 4611686018426L).g(w(j5))) {
                    throw new AssertionError(w(j5) + " ms is denormalized");
                }
            }
        }
        return j5;
    }

    public static boolean k(long j5, Object obj) {
        return (obj instanceof b) && j5 == ((b) obj).L();
    }

    public static final long l(long j5) {
        return C(j5) ? K(j5) : j5;
    }

    public static final int m(long j5) {
        if (B(j5)) {
            return 0;
        }
        return (int) (o(j5) % 24);
    }

    public static final long n(long j5) {
        return I(j5, e.f2257i);
    }

    public static final long o(long j5) {
        return I(j5, e.f2256h);
    }

    public static final long p(long j5) {
        return (z(j5) && y(j5)) ? w(j5) : I(j5, e.f2253e);
    }

    public static final long q(long j5) {
        return I(j5, e.f2255g);
    }

    public static final long r(long j5) {
        return I(j5, e.f2254f);
    }

    public static final int s(long j5) {
        if (B(j5)) {
            return 0;
        }
        return (int) (q(j5) % 60);
    }

    public static final int t(long j5) {
        if (B(j5)) {
            return 0;
        }
        return (int) (z(j5) ? d.n(w(j5) % 1000) : w(j5) % 1000000000);
    }

    public static final int u(long j5) {
        if (B(j5)) {
            return 0;
        }
        return (int) (r(j5) % 60);
    }

    private static final e v(long j5) {
        return A(j5) ? e.f2251c : e.f2253e;
    }

    private static final long w(long j5) {
        return j5 >> 1;
    }

    public static int x(long j5) {
        return androidx.privacysandbox.ads.adservices.topics.j.a(j5);
    }

    public static final boolean y(long j5) {
        return !B(j5);
    }

    private static final boolean z(long j5) {
        return (((int) j5) & 1) == 1;
    }

    public final /* synthetic */ long L() {
        return this.f2248b;
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return h(((b) obj).L());
    }

    public boolean equals(Object obj) {
        return k(this.f2248b, obj);
    }

    public int h(long j5) {
        return i(this.f2248b, j5);
    }

    public int hashCode() {
        return x(this.f2248b);
    }

    public String toString() {
        return J(this.f2248b);
    }
}
