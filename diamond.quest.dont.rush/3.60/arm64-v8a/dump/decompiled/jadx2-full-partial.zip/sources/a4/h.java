package a4;

import a4.b;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public abstract class h {
    private static final long a(long j5) {
        return j5 < 0 ? b.f2244c.b() : b.f2244c.a();
    }

    public static final long b(long j5, long j6, e unit) {
        C7150s.j(unit, "unit");
        return (1 | (j6 - 1)) == Long.MAX_VALUE ? b.K(a(j6)) : c(j5, j6, unit);
    }

    private static final long c(long j5, long j6, e eVar) {
        long j7 = j5 - j6;
        if (((j7 ^ j5) & (~(j7 ^ j6))) >= 0) {
            return d.t(j7, eVar);
        }
        e eVar2 = e.f2253e;
        if (eVar.compareTo(eVar2) >= 0) {
            return b.K(a(j7));
        }
        long b5 = f.b(1L, eVar2, eVar);
        long j8 = (j5 / b5) - (j6 / b5);
        long j9 = (j5 % b5) - (j6 % b5);
        b.a aVar = b.f2244c;
        return b.E(d.t(j8, eVar2), d.t(j9, eVar));
    }

    public static final long d(long j5, long j6, e unit) {
        C7150s.j(unit, "unit");
        return ((j6 - 1) | 1) == Long.MAX_VALUE ? j5 == j6 ? b.f2244c.c() : b.K(a(j6)) : (1 | (j5 - 1)) == Long.MAX_VALUE ? a(j5) : c(j5, j6, unit);
    }
}
