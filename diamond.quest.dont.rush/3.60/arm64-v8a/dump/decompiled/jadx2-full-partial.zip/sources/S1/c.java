package S1;

import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;
import g2.C5013a;

/* loaded from: classes4.dex */
public class c extends C5013a {

    /* renamed from: e, reason: collision with root package name */
    public long f1778e;

    @Override // g2.b, com.badlogic.gdx.utils.Json.Serializable
    public void read(Json json, JsonValue jsonValue) {
        super.read(json, jsonValue);
        this.f1778e = ((Long) json.readValue("lastInterstitial", (Class<Class>) Long.TYPE, (Class) 0L, jsonValue)).longValue();
    }

    @Override // g2.b, com.badlogic.gdx.utils.Json.Serializable
    public void write(Json json) {
        super.write(json);
        json.writeValue("lastInterstitial", Long.valueOf(this.f1778e));
    }
}
