package S1;

import com.badlogic.gdx.Gdx;

/* loaded from: classes4.dex */
public class d implements e, Runnable {

    /* renamed from: b, reason: collision with root package name */
    private e f1779b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f1780c = false;

    public d(e eVar) {
        this.f1779b = eVar;
    }

    @Override // S1.e
    public void a(boolean z4) {
        if (this.f1779b != null) {
            this.f1780c = z4;
            Gdx.app.postRunnable(this);
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        e eVar = this.f1779b;
        if (eVar != null) {
            eVar.a(this.f1780c);
        }
    }
}
