package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.m;
import androidx.core.view.C1052x;
import f.C4993a;
import f.C4996d;

/* loaded from: classes.dex */
public class l {

    /* renamed from: a, reason: collision with root package name */
    private final Context f3183a;

    /* renamed from: b, reason: collision with root package name */
    private final g f3184b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f3185c;

    /* renamed from: d, reason: collision with root package name */
    private final int f3186d;

    /* renamed from: e, reason: collision with root package name */
    private final int f3187e;

    /* renamed from: f, reason: collision with root package name */
    private View f3188f;

    /* renamed from: g, reason: collision with root package name */
    private int f3189g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f3190h;

    /* renamed from: i, reason: collision with root package name */
    private m.a f3191i;

    /* renamed from: j, reason: collision with root package name */
    private k f3192j;

    /* renamed from: k, reason: collision with root package name */
    private PopupWindow.OnDismissListener f3193k;

    /* renamed from: l, reason: collision with root package name */
    private final PopupWindow.OnDismissListener f3194l;

    class a implements PopupWindow.OnDismissListener {
        a() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            l.this.e();
        }
    }

    public l(@NonNull Context context, @NonNull g gVar) {
        this(context, gVar, null, false, C4993a.f53687H, 0);
    }

    private k a() {
        Display defaultDisplay = ((WindowManager) this.f3183a.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getRealSize(point);
        k dVar = Math.min(point.x, point.y) >= this.f3183a.getResources().getDimensionPixelSize(C4996d.f53734c) ? new d(this.f3183a, this.f3188f, this.f3186d, this.f3187e, this.f3185c) : new q(this.f3183a, this.f3184b, this.f3188f, this.f3186d, this.f3187e, this.f3185c);
        dVar.i(this.f3184b);
        dVar.r(this.f3194l);
        dVar.m(this.f3188f);
        dVar.g(this.f3191i);
        dVar.o(this.f3190h);
        dVar.p(this.f3189g);
        return dVar;
    }

    private void l(int i5, int i6, boolean z4, boolean z5) {
        k c5 = c();
        c5.s(z5);
        if (z4) {
            if ((C1052x.a(this.f3189g, this.f3188f.getLayoutDirection()) & 7) == 5) {
                i5 -= this.f3188f.getWidth();
            }
            c5.q(i5);
            c5.t(i6);
            int i7 = (int) ((this.f3183a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            c5.n(new Rect(i5 - i7, i6 - i7, i5 + i7, i6 + i7));
        }
        c5.show();
    }

    public void b() {
        if (d()) {
            this.f3192j.dismiss();
        }
    }

    public k c() {
        if (this.f3192j == null) {
            this.f3192j = a();
        }
        return this.f3192j;
    }

    public boolean d() {
        k kVar = this.f3192j;
        return kVar != null && kVar.isShowing();
    }

    protected void e() {
        this.f3192j = null;
        PopupWindow.OnDismissListener onDismissListener = this.f3193k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void f(View view) {
        this.f3188f = view;
    }

    public void g(boolean z4) {
        this.f3190h = z4;
        k kVar = this.f3192j;
        if (kVar != null) {
            kVar.o(z4);
        }
    }

    public void h(int i5) {
        this.f3189g = i5;
    }

    public void i(PopupWindow.OnDismissListener onDismissListener) {
        this.f3193k = onDismissListener;
    }

    public void j(m.a aVar) {
        this.f3191i = aVar;
        k kVar = this.f3192j;
        if (kVar != null) {
            kVar.g(aVar);
        }
    }

    public void k() {
        if (!m()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    public boolean m() {
        if (d()) {
            return true;
        }
        if (this.f3188f == null) {
            return false;
        }
        l(0, 0, false, false);
        return true;
    }

    public boolean n(int i5, int i6) {
        if (d()) {
            return true;
        }
        if (this.f3188f == null) {
            return false;
        }
        l(i5, i6, true, true);
        return true;
    }

    public l(@NonNull Context context, @NonNull g gVar, @NonNull View view) {
        this(context, gVar, view, false, C4993a.f53687H, 0);
    }

    public l(@NonNull Context context, @NonNull g gVar, @NonNull View view, boolean z4, int i5) {
        this(context, gVar, view, z4, i5, 0);
    }

    public l(@NonNull Context context, @NonNull g gVar, @NonNull View view, boolean z4, int i5, int i6) {
        this.f3189g = 8388611;
        this.f3194l = new a();
        this.f3183a = context;
        this.f3184b = gVar;
        this.f3188f = view;
        this.f3185c = z4;
        this.f3186d = i5;
        this.f3187e = i6;
    }
}
