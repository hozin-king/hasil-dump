package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class b implements m {

    /* renamed from: b, reason: collision with root package name */
    protected Context f3042b;

    /* renamed from: c, reason: collision with root package name */
    protected Context f3043c;

    /* renamed from: d, reason: collision with root package name */
    protected g f3044d;

    /* renamed from: e, reason: collision with root package name */
    protected LayoutInflater f3045e;

    /* renamed from: f, reason: collision with root package name */
    protected LayoutInflater f3046f;

    /* renamed from: g, reason: collision with root package name */
    private m.a f3047g;

    /* renamed from: h, reason: collision with root package name */
    private int f3048h;

    /* renamed from: i, reason: collision with root package name */
    private int f3049i;

    /* renamed from: j, reason: collision with root package name */
    protected n f3050j;

    /* renamed from: k, reason: collision with root package name */
    private int f3051k;

    public b(Context context, int i5, int i6) {
        this.f3042b = context;
        this.f3045e = LayoutInflater.from(context);
        this.f3048h = i5;
        this.f3049i = i6;
    }

    @Override // androidx.appcompat.view.menu.m
    public void a(g gVar, boolean z4) {
        m.a aVar = this.f3047g;
        if (aVar != null) {
            aVar.a(gVar, z4);
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean b(g gVar, i iVar) {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.appcompat.view.menu.m
    public void c(boolean z4) {
        ViewGroup viewGroup = (ViewGroup) this.f3050j;
        if (viewGroup == null) {
            return;
        }
        g gVar = this.f3044d;
        int i5 = 0;
        if (gVar != null) {
            gVar.r();
            ArrayList E4 = this.f3044d.E();
            int size = E4.size();
            int i6 = 0;
            for (int i7 = 0; i7 < size; i7++) {
                i iVar = (i) E4.get(i7);
                if (q(i6, iVar)) {
                    View childAt = viewGroup.getChildAt(i6);
                    i itemData = childAt instanceof n.a ? ((n.a) childAt).getItemData() : null;
                    View n5 = n(iVar, childAt, viewGroup);
                    if (iVar != itemData) {
                        n5.setPressed(false);
                        n5.jumpDrawablesToCurrentState();
                    }
                    if (n5 != childAt) {
                        i(n5, i6);
                    }
                    i6++;
                }
            }
            i5 = i6;
        }
        while (i5 < viewGroup.getChildCount()) {
            if (!l(viewGroup, i5)) {
                i5++;
            }
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean e(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void f(Context context, g gVar) {
        this.f3043c = context;
        this.f3046f = LayoutInflater.from(context);
        this.f3044d = gVar;
    }

    @Override // androidx.appcompat.view.menu.m
    public void g(m.a aVar) {
        this.f3047g = aVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v4, types: [androidx.appcompat.view.menu.g] */
    @Override // androidx.appcompat.view.menu.m
    public boolean h(r rVar) {
        m.a aVar = this.f3047g;
        r rVar2 = rVar;
        if (aVar == null) {
            return false;
        }
        if (rVar == null) {
            rVar2 = this.f3044d;
        }
        return aVar.b(rVar2);
    }

    protected void i(View view, int i5) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.f3050j).addView(view, i5);
    }

    public abstract void j(i iVar, n.a aVar);

    public n.a k(ViewGroup viewGroup) {
        return (n.a) this.f3045e.inflate(this.f3049i, viewGroup, false);
    }

    protected boolean l(ViewGroup viewGroup, int i5) {
        viewGroup.removeViewAt(i5);
        return true;
    }

    public m.a m() {
        return this.f3047g;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View n(i iVar, View view, ViewGroup viewGroup) {
        n.a k5 = view instanceof n.a ? (n.a) view : k(viewGroup);
        j(iVar, k5);
        return (View) k5;
    }

    public n o(ViewGroup viewGroup) {
        if (this.f3050j == null) {
            n nVar = (n) this.f3045e.inflate(this.f3048h, viewGroup, false);
            this.f3050j = nVar;
            nVar.a(this.f3044d);
            c(true);
        }
        return this.f3050j;
    }

    public void p(int i5) {
        this.f3051k = i5;
    }

    public boolean q(int i5, i iVar) {
        return true;
    }
}
