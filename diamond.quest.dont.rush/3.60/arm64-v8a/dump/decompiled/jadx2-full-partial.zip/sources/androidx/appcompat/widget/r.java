package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;
import g.C5008a;

/* loaded from: classes.dex */
public class r extends MultiAutoCompleteTextView implements androidx.core.widget.l {

    /* renamed from: e, reason: collision with root package name */
    private static final int[] f3869e = {R.attr.popupBackground};

    /* renamed from: b, reason: collision with root package name */
    private final C0986e f3870b;

    /* renamed from: c, reason: collision with root package name */
    private final A f3871c;

    /* renamed from: d, reason: collision with root package name */
    private final C0994m f3872d;

    public r(@NonNull Context context) {
        this(context, null);
    }

    void a(C0994m c0994m) {
        KeyListener keyListener = getKeyListener();
        if (c0994m.b(keyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a5 = c0994m.a(keyListener);
            if (a5 == keyListener) {
                return;
            }
            super.setKeyListener(a5);
            super.setRawInputType(inputType);
            super.setFocusable(isFocusable);
            super.setClickable(isClickable);
            super.setLongClickable(isLongClickable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            c0986e.b();
        }
        A a5 = this.f3871c;
        if (a5 != null) {
            a5.b();
        }
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f3871c.j();
    }

    @Nullable
    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f3871c.k();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return this.f3872d.d(AbstractC0996o.a(super.onCreateInputConnection(editorInfo), editorInfo, this), editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        A a5 = this.f3871c;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        A a5 = this.f3871c;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i5) {
        setDropDownBackgroundDrawable(C5008a.b(getContext(), i5));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        this.f3872d.e(z4);
    }

    @Override // android.widget.TextView
    public void setKeyListener(@Nullable KeyListener keyListener) {
        super.setKeyListener(this.f3872d.a(keyListener));
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.f3870b;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList colorStateList) {
        this.f3871c.w(colorStateList);
        this.f3871c.b();
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode mode) {
        this.f3871c.x(mode);
        this.f3871c.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i5) {
        super.setTextAppearance(context, i5);
        A a5 = this.f3871c;
        if (a5 != null) {
            a5.q(context, i5);
        }
    }

    public r(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53713q);
    }

    public r(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        c0.a(this, getContext());
        g0 u5 = g0.u(getContext(), attributeSet, f3869e, i5, 0);
        if (u5.r(0)) {
            setDropDownBackgroundDrawable(u5.f(0));
        }
        u5.w();
        C0986e c0986e = new C0986e(this);
        this.f3870b = c0986e;
        c0986e.e(attributeSet, i5);
        A a5 = new A(this);
        this.f3871c = a5;
        a5.m(attributeSet, i5);
        a5.b();
        C0994m c0994m = new C0994m(this);
        this.f3872d = c0994m;
        c0994m.c(attributeSet, i5);
        a(c0994m);
    }
}
