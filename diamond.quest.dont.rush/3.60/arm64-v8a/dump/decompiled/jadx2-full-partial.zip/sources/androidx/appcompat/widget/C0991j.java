package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

/* renamed from: androidx.appcompat.widget.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0991j {

    /* renamed from: a, reason: collision with root package name */
    private final CompoundButton f3795a;

    /* renamed from: b, reason: collision with root package name */
    private ColorStateList f3796b = null;

    /* renamed from: c, reason: collision with root package name */
    private PorterDuff.Mode f3797c = null;

    /* renamed from: d, reason: collision with root package name */
    private boolean f3798d = false;

    /* renamed from: e, reason: collision with root package name */
    private boolean f3799e = false;

    /* renamed from: f, reason: collision with root package name */
    private boolean f3800f;

    C0991j(CompoundButton compoundButton) {
        this.f3795a = compoundButton;
    }

    void a() {
        Drawable a5 = androidx.core.widget.c.a(this.f3795a);
        if (a5 != null) {
            if (this.f3798d || this.f3799e) {
                Drawable mutate = androidx.core.graphics.drawable.a.q(a5).mutate();
                if (this.f3798d) {
                    androidx.core.graphics.drawable.a.n(mutate, this.f3796b);
                }
                if (this.f3799e) {
                    androidx.core.graphics.drawable.a.o(mutate, this.f3797c);
                }
                if (mutate.isStateful()) {
                    mutate.setState(this.f3795a.getDrawableState());
                }
                this.f3795a.setButtonDrawable(mutate);
            }
        }
    }

    ColorStateList b() {
        return this.f3796b;
    }

    PorterDuff.Mode c() {
        return this.f3797c;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0065 A[Catch: all -> 0x003d, TryCatch #1 {all -> 0x003d, blocks: (B:3:0x001f, B:5:0x0027, B:8:0x002f, B:9:0x005d, B:11:0x0065, B:12:0x0070, B:14:0x0078, B:21:0x0040, B:23:0x0048, B:25:0x0050), top: B:2:0x001f }] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0078 A[Catch: all -> 0x003d, TRY_LEAVE, TryCatch #1 {all -> 0x003d, blocks: (B:3:0x001f, B:5:0x0027, B:8:0x002f, B:9:0x005d, B:11:0x0065, B:12:0x0070, B:14:0x0078, B:21:0x0040, B:23:0x0048, B:25:0x0050), top: B:2:0x001f }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void d(android.util.AttributeSet r11, int r12) {
        /*
            r10 = this;
            android.widget.CompoundButton r0 = r10.f3795a
            android.content.Context r0 = r0.getContext()
            int[] r1 = f.j.f53971U0
            r2 = 0
            androidx.appcompat.widget.g0 r1 = androidx.appcompat.widget.g0.u(r0, r11, r1, r12, r2)
            android.widget.CompoundButton r3 = r10.f3795a
            android.content.Context r4 = r3.getContext()
            int[] r5 = f.j.f53971U0
            android.content.res.TypedArray r7 = r1.q()
            r9 = 0
            r6 = r11
            r8 = r12
            androidx.core.view.C1015b0.b0(r3, r4, r5, r6, r7, r8, r9)
            int r11 = f.j.f53979W0     // Catch: java.lang.Throwable -> L3d
            boolean r11 = r1.r(r11)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L40
            int r11 = f.j.f53979W0     // Catch: java.lang.Throwable -> L3d
            int r11 = r1.m(r11, r2)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L40
            android.widget.CompoundButton r12 = r10.f3795a     // Catch: java.lang.Throwable -> L3d android.content.res.Resources.NotFoundException -> L40
            android.content.Context r0 = r12.getContext()     // Catch: java.lang.Throwable -> L3d android.content.res.Resources.NotFoundException -> L40
            android.graphics.drawable.Drawable r11 = g.C5008a.b(r0, r11)     // Catch: java.lang.Throwable -> L3d android.content.res.Resources.NotFoundException -> L40
            r12.setButtonDrawable(r11)     // Catch: java.lang.Throwable -> L3d android.content.res.Resources.NotFoundException -> L40
            goto L5d
        L3d:
            r0 = move-exception
            r11 = r0
            goto L8d
        L40:
            int r11 = f.j.f53975V0     // Catch: java.lang.Throwable -> L3d
            boolean r11 = r1.r(r11)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L5d
            int r11 = f.j.f53975V0     // Catch: java.lang.Throwable -> L3d
            int r11 = r1.m(r11, r2)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L5d
            android.widget.CompoundButton r12 = r10.f3795a     // Catch: java.lang.Throwable -> L3d
            android.content.Context r0 = r12.getContext()     // Catch: java.lang.Throwable -> L3d
            android.graphics.drawable.Drawable r11 = g.C5008a.b(r0, r11)     // Catch: java.lang.Throwable -> L3d
            r12.setButtonDrawable(r11)     // Catch: java.lang.Throwable -> L3d
        L5d:
            int r11 = f.j.f53983X0     // Catch: java.lang.Throwable -> L3d
            boolean r11 = r1.r(r11)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L70
            android.widget.CompoundButton r11 = r10.f3795a     // Catch: java.lang.Throwable -> L3d
            int r12 = f.j.f53983X0     // Catch: java.lang.Throwable -> L3d
            android.content.res.ColorStateList r12 = r1.c(r12)     // Catch: java.lang.Throwable -> L3d
            androidx.core.widget.c.b(r11, r12)     // Catch: java.lang.Throwable -> L3d
        L70:
            int r11 = f.j.f53987Y0     // Catch: java.lang.Throwable -> L3d
            boolean r11 = r1.r(r11)     // Catch: java.lang.Throwable -> L3d
            if (r11 == 0) goto L89
            android.widget.CompoundButton r11 = r10.f3795a     // Catch: java.lang.Throwable -> L3d
            int r12 = f.j.f53987Y0     // Catch: java.lang.Throwable -> L3d
            r0 = -1
            int r12 = r1.j(r12, r0)     // Catch: java.lang.Throwable -> L3d
            r0 = 0
            android.graphics.PorterDuff$Mode r12 = androidx.appcompat.widget.M.d(r12, r0)     // Catch: java.lang.Throwable -> L3d
            androidx.core.widget.c.c(r11, r12)     // Catch: java.lang.Throwable -> L3d
        L89:
            r1.w()
            return
        L8d:
            r1.w()
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0991j.d(android.util.AttributeSet, int):void");
    }

    void e() {
        if (this.f3800f) {
            this.f3800f = false;
        } else {
            this.f3800f = true;
            a();
        }
    }

    void f(ColorStateList colorStateList) {
        this.f3796b = colorStateList;
        this.f3798d = true;
        a();
    }

    void g(PorterDuff.Mode mode) {
        this.f3797c = mode;
        this.f3799e = true;
        a();
    }
}
