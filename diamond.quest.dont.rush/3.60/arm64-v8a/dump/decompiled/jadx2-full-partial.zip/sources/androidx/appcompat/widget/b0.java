package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import androidx.emoji2.text.f;
import f.C4993a;
import f.C5000h;
import g.C5008a;
import i.C5047a;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class b0 extends CompoundButton {

    /* renamed from: T, reason: collision with root package name */
    private static final Property f3668T = new a(Float.class, "thumbPos");

    /* renamed from: U, reason: collision with root package name */
    private static final int[] f3669U = {R.attr.state_checked};

    /* renamed from: A, reason: collision with root package name */
    float f3670A;

    /* renamed from: B, reason: collision with root package name */
    private int f3671B;

    /* renamed from: C, reason: collision with root package name */
    private int f3672C;

    /* renamed from: D, reason: collision with root package name */
    private int f3673D;

    /* renamed from: E, reason: collision with root package name */
    private int f3674E;

    /* renamed from: F, reason: collision with root package name */
    private int f3675F;

    /* renamed from: G, reason: collision with root package name */
    private int f3676G;

    /* renamed from: H, reason: collision with root package name */
    private int f3677H;

    /* renamed from: I, reason: collision with root package name */
    private boolean f3678I;

    /* renamed from: J, reason: collision with root package name */
    private final TextPaint f3679J;

    /* renamed from: K, reason: collision with root package name */
    private ColorStateList f3680K;

    /* renamed from: L, reason: collision with root package name */
    private Layout f3681L;

    /* renamed from: M, reason: collision with root package name */
    private Layout f3682M;

    /* renamed from: N, reason: collision with root package name */
    private TransformationMethod f3683N;

    /* renamed from: O, reason: collision with root package name */
    ObjectAnimator f3684O;

    /* renamed from: P, reason: collision with root package name */
    private final A f3685P;

    /* renamed from: Q, reason: collision with root package name */
    private C0995n f3686Q;

    /* renamed from: R, reason: collision with root package name */
    private b f3687R;

    /* renamed from: S, reason: collision with root package name */
    private final Rect f3688S;

    /* renamed from: b, reason: collision with root package name */
    private Drawable f3689b;

    /* renamed from: c, reason: collision with root package name */
    private ColorStateList f3690c;

    /* renamed from: d, reason: collision with root package name */
    private PorterDuff.Mode f3691d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f3692e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f3693f;

    /* renamed from: g, reason: collision with root package name */
    private Drawable f3694g;

    /* renamed from: h, reason: collision with root package name */
    private ColorStateList f3695h;

    /* renamed from: i, reason: collision with root package name */
    private PorterDuff.Mode f3696i;

    /* renamed from: j, reason: collision with root package name */
    private boolean f3697j;

    /* renamed from: k, reason: collision with root package name */
    private boolean f3698k;

    /* renamed from: l, reason: collision with root package name */
    private int f3699l;

    /* renamed from: m, reason: collision with root package name */
    private int f3700m;

    /* renamed from: n, reason: collision with root package name */
    private int f3701n;

    /* renamed from: o, reason: collision with root package name */
    private boolean f3702o;

    /* renamed from: p, reason: collision with root package name */
    private CharSequence f3703p;

    /* renamed from: q, reason: collision with root package name */
    private CharSequence f3704q;

    /* renamed from: r, reason: collision with root package name */
    private CharSequence f3705r;

    /* renamed from: s, reason: collision with root package name */
    private CharSequence f3706s;

    /* renamed from: t, reason: collision with root package name */
    private boolean f3707t;

    /* renamed from: u, reason: collision with root package name */
    private int f3708u;

    /* renamed from: v, reason: collision with root package name */
    private int f3709v;

    /* renamed from: w, reason: collision with root package name */
    private float f3710w;

    /* renamed from: x, reason: collision with root package name */
    private float f3711x;

    /* renamed from: y, reason: collision with root package name */
    private VelocityTracker f3712y;

    /* renamed from: z, reason: collision with root package name */
    private int f3713z;

    class a extends Property {
        a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(b0 b0Var) {
            return Float.valueOf(b0Var.f3670A);
        }

        @Override // android.util.Property
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(b0 b0Var, Float f5) {
            b0Var.setThumbPosition(f5.floatValue());
        }
    }

    static class b extends f.AbstractC0147f {

        /* renamed from: a, reason: collision with root package name */
        private final Reference f3714a;

        b(b0 b0Var) {
            this.f3714a = new WeakReference(b0Var);
        }

        @Override // androidx.emoji2.text.f.AbstractC0147f
        public void a(Throwable th) {
            b0 b0Var = (b0) this.f3714a.get();
            if (b0Var != null) {
                b0Var.j();
            }
        }

        @Override // androidx.emoji2.text.f.AbstractC0147f
        public void b() {
            b0 b0Var = (b0) this.f3714a.get();
            if (b0Var != null) {
                b0Var.j();
            }
        }
    }

    public b0(@NonNull Context context) {
        this(context, null);
    }

    private void a(boolean z4) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, (Property<b0, Float>) f3668T, z4 ? 1.0f : 0.0f);
        this.f3684O = ofFloat;
        ofFloat.setDuration(250L);
        this.f3684O.setAutoCancel(true);
        this.f3684O.start();
    }

    private void b() {
        Drawable drawable = this.f3689b;
        if (drawable != null) {
            if (this.f3692e || this.f3693f) {
                Drawable mutate = androidx.core.graphics.drawable.a.q(drawable).mutate();
                this.f3689b = mutate;
                if (this.f3692e) {
                    androidx.core.graphics.drawable.a.n(mutate, this.f3690c);
                }
                if (this.f3693f) {
                    androidx.core.graphics.drawable.a.o(this.f3689b, this.f3691d);
                }
                if (this.f3689b.isStateful()) {
                    this.f3689b.setState(getDrawableState());
                }
            }
        }
    }

    private void c() {
        Drawable drawable = this.f3694g;
        if (drawable != null) {
            if (this.f3697j || this.f3698k) {
                Drawable mutate = androidx.core.graphics.drawable.a.q(drawable).mutate();
                this.f3694g = mutate;
                if (this.f3697j) {
                    androidx.core.graphics.drawable.a.n(mutate, this.f3695h);
                }
                if (this.f3698k) {
                    androidx.core.graphics.drawable.a.o(this.f3694g, this.f3696i);
                }
                if (this.f3694g.isStateful()) {
                    this.f3694g.setState(getDrawableState());
                }
            }
        }
    }

    private void d() {
        ObjectAnimator objectAnimator = this.f3684O;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    private void e(MotionEvent motionEvent) {
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        obtain.setAction(3);
        super.onTouchEvent(obtain);
        obtain.recycle();
    }

    private static float f(float f5, float f6, float f7) {
        return f5 < f6 ? f6 : f5 > f7 ? f7 : f5;
    }

    private CharSequence g(CharSequence charSequence) {
        TransformationMethod f5 = getEmojiTextViewHelper().f(this.f3683N);
        return f5 != null ? f5.getTransformation(charSequence, this) : charSequence;
    }

    @NonNull
    private C0995n getEmojiTextViewHelper() {
        if (this.f3686Q == null) {
            this.f3686Q = new C0995n(this);
        }
        return this.f3686Q;
    }

    private boolean getTargetCheckedState() {
        return this.f3670A > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((r0.b(this) ? 1.0f - this.f3670A : this.f3670A) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f3694g;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.f3688S;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f3689b;
        Rect c5 = drawable2 != null ? M.c(drawable2) : M.f3388c;
        return ((((this.f3671B - this.f3673D) - rect.left) - rect.right) - c5.left) - c5.right;
    }

    private boolean h(float f5, float f6) {
        if (this.f3689b == null) {
            return false;
        }
        int thumbOffset = getThumbOffset();
        this.f3689b.getPadding(this.f3688S);
        int i5 = this.f3675F;
        int i6 = this.f3709v;
        int i7 = i5 - i6;
        int i8 = (this.f3674E + thumbOffset) - i6;
        int i9 = this.f3673D + i8;
        Rect rect = this.f3688S;
        return f5 > ((float) i8) && f5 < ((float) (((i9 + rect.left) + rect.right) + i6)) && f6 > ((float) i7) && f6 < ((float) (this.f3677H + i6));
    }

    private Layout i(CharSequence charSequence) {
        return new StaticLayout(charSequence, this.f3679J, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, r2)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    private void k() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence charSequence = this.f3705r;
            if (charSequence == null) {
                charSequence = getResources().getString(C5000h.f53855b);
            }
            C1015b0.v0(this, charSequence);
        }
    }

    private void l() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence charSequence = this.f3703p;
            if (charSequence == null) {
                charSequence = getResources().getString(C5000h.f53856c);
            }
            C1015b0.v0(this, charSequence);
        }
    }

    private void o(int i5, int i6) {
        n(i5 != 1 ? i5 != 2 ? i5 != 3 ? null : Typeface.MONOSPACE : Typeface.SERIF : Typeface.SANS_SERIF, i6);
    }

    private void p() {
        if (this.f3687R == null && this.f3686Q.b() && androidx.emoji2.text.f.i()) {
            androidx.emoji2.text.f c5 = androidx.emoji2.text.f.c();
            int e5 = c5.e();
            if (e5 == 3 || e5 == 0) {
                b bVar = new b(this);
                this.f3687R = bVar;
                c5.t(bVar);
            }
        }
    }

    private void q(MotionEvent motionEvent) {
        this.f3708u = 0;
        boolean z4 = true;
        boolean z5 = motionEvent.getAction() == 1 && isEnabled();
        boolean isChecked = isChecked();
        if (z5) {
            this.f3712y.computeCurrentVelocity(1000);
            float xVelocity = this.f3712y.getXVelocity();
            if (Math.abs(xVelocity) <= this.f3713z) {
                z4 = getTargetCheckedState();
            } else if (!r0.b(this) ? xVelocity <= 0.0f : xVelocity >= 0.0f) {
                z4 = false;
            }
        } else {
            z4 = isChecked;
        }
        if (z4 != isChecked) {
            playSoundEffect(0);
        }
        setChecked(z4);
        e(motionEvent);
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f3705r = charSequence;
        this.f3706s = g(charSequence);
        this.f3682M = null;
        if (this.f3707t) {
            p();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f3703p = charSequence;
        this.f3704q = g(charSequence);
        this.f3681L = null;
        if (this.f3707t) {
            p();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i5;
        int i6;
        Rect rect = this.f3688S;
        int i7 = this.f3674E;
        int i8 = this.f3675F;
        int i9 = this.f3676G;
        int i10 = this.f3677H;
        int thumbOffset = getThumbOffset() + i7;
        Drawable drawable = this.f3689b;
        Rect c5 = drawable != null ? M.c(drawable) : M.f3388c;
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i11 = rect.left;
            thumbOffset += i11;
            if (c5 != null) {
                int i12 = c5.left;
                if (i12 > i11) {
                    i7 += i12 - i11;
                }
                int i13 = c5.top;
                int i14 = rect.top;
                i5 = i13 > i14 ? (i13 - i14) + i8 : i8;
                int i15 = c5.right;
                int i16 = rect.right;
                if (i15 > i16) {
                    i9 -= i15 - i16;
                }
                int i17 = c5.bottom;
                int i18 = rect.bottom;
                if (i17 > i18) {
                    i6 = i10 - (i17 - i18);
                    this.f3694g.setBounds(i7, i5, i9, i6);
                }
            } else {
                i5 = i8;
            }
            i6 = i10;
            this.f3694g.setBounds(i7, i5, i9, i6);
        }
        Drawable drawable3 = this.f3689b;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i19 = thumbOffset - rect.left;
            int i20 = thumbOffset + this.f3673D + rect.right;
            this.f3689b.setBounds(i19, i8, i20, i10);
            Drawable background = getBackground();
            if (background != null) {
                androidx.core.graphics.drawable.a.k(background, i19, i8, i20, i10);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableHotspotChanged(float f5, float f6) {
        super.drawableHotspotChanged(f5, f6);
        Drawable drawable = this.f3689b;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.j(drawable, f5, f6);
        }
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null) {
            androidx.core.graphics.drawable.a.j(drawable2, f5, f6);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f3689b;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        if (!r0.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.f3671B;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f3701n : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        if (r0.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.f3671B;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f3701n : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    @Nullable
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return androidx.core.widget.j.n(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f3707t;
    }

    public boolean getSplitTrack() {
        return this.f3702o;
    }

    public int getSwitchMinWidth() {
        return this.f3700m;
    }

    public int getSwitchPadding() {
        return this.f3701n;
    }

    public CharSequence getTextOff() {
        return this.f3705r;
    }

    public CharSequence getTextOn() {
        return this.f3703p;
    }

    public Drawable getThumbDrawable() {
        return this.f3689b;
    }

    protected final float getThumbPosition() {
        return this.f3670A;
    }

    public int getThumbTextPadding() {
        return this.f3699l;
    }

    @Nullable
    public ColorStateList getThumbTintList() {
        return this.f3690c;
    }

    @Nullable
    public PorterDuff.Mode getThumbTintMode() {
        return this.f3691d;
    }

    public Drawable getTrackDrawable() {
        return this.f3694g;
    }

    @Nullable
    public ColorStateList getTrackTintList() {
        return this.f3695h;
    }

    @Nullable
    public PorterDuff.Mode getTrackTintMode() {
        return this.f3696i;
    }

    void j() {
        setTextOnInternal(this.f3703p);
        setTextOffInternal(this.f3705r);
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f3689b;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.f3684O;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.f3684O.end();
        this.f3684O = null;
    }

    public void m(Context context, int i5) {
        g0 s5 = g0.s(context, i5, f.j.f53965S2);
        ColorStateList c5 = s5.c(f.j.f53981W2);
        if (c5 != null) {
            this.f3680K = c5;
        } else {
            this.f3680K = getTextColors();
        }
        int e5 = s5.e(f.j.f53969T2, 0);
        if (e5 != 0) {
            float f5 = e5;
            if (f5 != this.f3679J.getTextSize()) {
                this.f3679J.setTextSize(f5);
                requestLayout();
            }
        }
        o(s5.j(f.j.f53973U2, -1), s5.j(f.j.f53977V2, -1));
        if (s5.a(f.j.f54003b3, false)) {
            this.f3683N = new C5047a(getContext());
        } else {
            this.f3683N = null;
        }
        setTextOnInternal(this.f3703p);
        setTextOffInternal(this.f3705r);
        s5.w();
    }

    public void n(Typeface typeface, int i5) {
        if (i5 <= 0) {
            this.f3679J.setFakeBoldText(false);
            this.f3679J.setTextSkewX(0.0f);
            setSwitchTypeface(typeface);
        } else {
            Typeface defaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i5) : Typeface.create(typeface, i5);
            setSwitchTypeface(defaultFromStyle);
            int i6 = (~(defaultFromStyle != null ? defaultFromStyle.getStyle() : 0)) & i5;
            this.f3679J.setFakeBoldText((i6 & 1) != 0);
            this.f3679J.setTextSkewX((i6 & 2) != 0 ? -0.25f : 0.0f);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected int[] onCreateDrawableState(int i5) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i5 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, f3669U);
        }
        return onCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Rect rect = this.f3688S;
        Drawable drawable = this.f3694g;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i5 = this.f3675F;
        int i6 = this.f3677H;
        int i7 = i5 + rect.top;
        int i8 = i6 - rect.bottom;
        Drawable drawable2 = this.f3689b;
        if (drawable != null) {
            if (!this.f3702o || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect c5 = M.c(drawable2);
                drawable2.copyBounds(rect);
                rect.left += c5.left;
                rect.right -= c5.right;
                int save = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(save);
            }
        }
        int save2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.f3681L : this.f3682M;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.f3680K;
            if (colorStateList != null) {
                this.f3679J.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.f3679J.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i7 + i8) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(save2);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f3703p : this.f3705r;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        int i9;
        int width;
        int i10;
        int i11;
        int i12;
        int i13;
        super.onLayout(z4, i5, i6, i7, i8);
        int i14 = 0;
        if (this.f3689b != null) {
            Rect rect = this.f3688S;
            Drawable drawable = this.f3694g;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect c5 = M.c(this.f3689b);
            i9 = Math.max(0, c5.left - rect.left);
            i14 = Math.max(0, c5.right - rect.right);
        } else {
            i9 = 0;
        }
        if (r0.b(this)) {
            i10 = getPaddingLeft() + i9;
            width = ((this.f3671B + i10) - i9) - i14;
        } else {
            width = (getWidth() - getPaddingRight()) - i14;
            i10 = (width - this.f3671B) + i9 + i14;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int paddingTop = ((getPaddingTop() + getHeight()) - getPaddingBottom()) / 2;
            i11 = this.f3672C;
            i12 = paddingTop - (i11 / 2);
        } else {
            if (gravity == 80) {
                i13 = getHeight() - getPaddingBottom();
                i12 = i13 - this.f3672C;
                this.f3674E = i10;
                this.f3675F = i12;
                this.f3677H = i13;
                this.f3676G = width;
            }
            i12 = getPaddingTop();
            i11 = this.f3672C;
        }
        i13 = i11 + i12;
        this.f3674E = i10;
        this.f3675F = i12;
        this.f3677H = i13;
        this.f3676G = width;
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i5, int i6) {
        int i7;
        int i8;
        if (this.f3707t) {
            if (this.f3681L == null) {
                this.f3681L = i(this.f3704q);
            }
            if (this.f3682M == null) {
                this.f3682M = i(this.f3706s);
            }
        }
        Rect rect = this.f3688S;
        Drawable drawable = this.f3689b;
        int i9 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            i7 = (this.f3689b.getIntrinsicWidth() - rect.left) - rect.right;
            i8 = this.f3689b.getIntrinsicHeight();
        } else {
            i7 = 0;
            i8 = 0;
        }
        this.f3673D = Math.max(this.f3707t ? Math.max(this.f3681L.getWidth(), this.f3682M.getWidth()) + (this.f3699l * 2) : 0, i7);
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            i9 = this.f3694g.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int i10 = rect.left;
        int i11 = rect.right;
        Drawable drawable3 = this.f3689b;
        if (drawable3 != null) {
            Rect c5 = M.c(drawable3);
            i10 = Math.max(i10, c5.left);
            i11 = Math.max(i11, c5.right);
        }
        int max = this.f3678I ? Math.max(this.f3700m, (this.f3673D * 2) + i10 + i11) : this.f3700m;
        int max2 = Math.max(i9, i8);
        this.f3671B = max;
        this.f3672C = max2;
        super.onMeasure(i5, i6);
        if (getMeasuredHeight() < max2) {
            setMeasuredDimension(getMeasuredWidthAndState(), max2);
        }
    }

    @Override // android.view.View
    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f3703p : this.f3705r;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0012, code lost:
    
        if (r0 != 3) goto L44;
     */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onTouchEvent(android.view.MotionEvent r7) {
        /*
            r6 = this;
            android.view.VelocityTracker r0 = r6.f3712y
            r0.addMovement(r7)
            int r0 = r7.getActionMasked()
            r1 = 1
            if (r0 == 0) goto L9d
            r2 = 2
            if (r0 == r1) goto L89
            if (r0 == r2) goto L16
            r3 = 3
            if (r0 == r3) goto L89
            goto Lb7
        L16:
            int r0 = r6.f3708u
            if (r0 == r1) goto L55
            if (r0 == r2) goto L1e
            goto Lb7
        L1e:
            float r7 = r7.getX()
            int r0 = r6.getThumbScrollRange()
            float r2 = r6.f3710w
            float r2 = r7 - r2
            r3 = 1065353216(0x3f800000, float:1.0)
            r4 = 0
            if (r0 == 0) goto L32
            float r0 = (float) r0
            float r2 = r2 / r0
            goto L3b
        L32:
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 <= 0) goto L38
            r2 = r3
            goto L3b
        L38:
            r0 = -1082130432(0xffffffffbf800000, float:-1.0)
            r2 = r0
        L3b:
            boolean r0 = androidx.appcompat.widget.r0.b(r6)
            if (r0 == 0) goto L42
            float r2 = -r2
        L42:
            float r0 = r6.f3670A
            float r0 = r0 + r2
            float r0 = f(r0, r4, r3)
            float r2 = r6.f3670A
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 == 0) goto L54
            r6.f3710w = r7
            r6.setThumbPosition(r0)
        L54:
            return r1
        L55:
            float r0 = r7.getX()
            float r3 = r7.getY()
            float r4 = r6.f3710w
            float r4 = r0 - r4
            float r4 = java.lang.Math.abs(r4)
            int r5 = r6.f3709v
            float r5 = (float) r5
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 > 0) goto L7b
            float r4 = r6.f3711x
            float r4 = r3 - r4
            float r4 = java.lang.Math.abs(r4)
            int r5 = r6.f3709v
            float r5 = (float) r5
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 <= 0) goto Lb7
        L7b:
            r6.f3708u = r2
            android.view.ViewParent r7 = r6.getParent()
            r7.requestDisallowInterceptTouchEvent(r1)
            r6.f3710w = r0
            r6.f3711x = r3
            return r1
        L89:
            int r0 = r6.f3708u
            if (r0 != r2) goto L94
            r6.q(r7)
            super.onTouchEvent(r7)
            return r1
        L94:
            r0 = 0
            r6.f3708u = r0
            android.view.VelocityTracker r0 = r6.f3712y
            r0.clear()
            goto Lb7
        L9d:
            float r0 = r7.getX()
            float r2 = r7.getY()
            boolean r3 = r6.isEnabled()
            if (r3 == 0) goto Lb7
            boolean r3 = r6.h(r0, r2)
            if (r3 == 0) goto Lb7
            r6.f3708u = r1
            r6.f3710w = r0
            r6.f3711x = r2
        Lb7:
            boolean r7 = super.onTouchEvent(r7)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.b0.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().d(z4);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z4) {
        super.setChecked(z4);
        boolean isChecked = isChecked();
        if (isChecked) {
            l();
        } else {
            k();
        }
        if (getWindowToken() != null && isLaidOut()) {
            a(isChecked);
        } else {
            d();
            setThumbPosition(isChecked ? 1.0f : 0.0f);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(@Nullable ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(androidx.core.widget.j.o(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().e(z4);
        setTextOnInternal(this.f3703p);
        setTextOffInternal(this.f3705r);
        requestLayout();
    }

    protected final void setEnforceSwitchWidth(boolean z4) {
        this.f3678I = z4;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(@NonNull InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z4) {
        if (this.f3707t != z4) {
            this.f3707t = z4;
            requestLayout();
            if (z4) {
                p();
            }
        }
    }

    public void setSplitTrack(boolean z4) {
        this.f3702o = z4;
        invalidate();
    }

    public void setSwitchMinWidth(int i5) {
        this.f3700m = i5;
        requestLayout();
    }

    public void setSwitchPadding(int i5) {
        this.f3701n = i5;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.f3679J.getTypeface() == null || this.f3679J.getTypeface().equals(typeface)) && (this.f3679J.getTypeface() != null || typeface == null)) {
            return;
        }
        this.f3679J.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            return;
        }
        k();
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            l();
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f3689b;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f3689b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    void setThumbPosition(float f5) {
        this.f3670A = f5;
        invalidate();
    }

    public void setThumbResource(int i5) {
        setThumbDrawable(C5008a.b(getContext(), i5));
    }

    public void setThumbTextPadding(int i5) {
        this.f3699l = i5;
        requestLayout();
    }

    public void setThumbTintList(@Nullable ColorStateList colorStateList) {
        this.f3690c = colorStateList;
        this.f3692e = true;
        b();
    }

    public void setThumbTintMode(@Nullable PorterDuff.Mode mode) {
        this.f3691d = mode;
        this.f3693f = true;
        b();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f3694g;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f3694g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i5) {
        setTrackDrawable(C5008a.b(getContext(), i5));
    }

    public void setTrackTintList(@Nullable ColorStateList colorStateList) {
        this.f3695h = colorStateList;
        this.f3697j = true;
        c();
    }

    public void setTrackTintMode(@Nullable PorterDuff.Mode mode) {
        this.f3696i = mode;
        this.f3698k = true;
        c();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f3689b || drawable == this.f3694g;
    }

    public b0(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53693N);
    }

    public b0(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        this.f3690c = null;
        this.f3691d = null;
        this.f3692e = false;
        this.f3693f = false;
        this.f3695h = null;
        this.f3696i = null;
        this.f3697j = false;
        this.f3698k = false;
        this.f3712y = VelocityTracker.obtain();
        this.f3678I = true;
        this.f3688S = new Rect();
        c0.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.f3679J = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        g0 u5 = g0.u(context, attributeSet, f.j.f53890D2, i5, 0);
        C1015b0.b0(this, context, f.j.f53890D2, attributeSet, u5.q(), i5, 0);
        Drawable f5 = u5.f(f.j.f53905G2);
        this.f3689b = f5;
        if (f5 != null) {
            f5.setCallback(this);
        }
        Drawable f6 = u5.f(f.j.f53950P2);
        this.f3694g = f6;
        if (f6 != null) {
            f6.setCallback(this);
        }
        setTextOnInternal(u5.o(f.j.f53895E2));
        setTextOffInternal(u5.o(f.j.f53900F2));
        this.f3707t = u5.a(f.j.f53910H2, true);
        this.f3699l = u5.e(f.j.f53935M2, 0);
        this.f3700m = u5.e(f.j.f53920J2, 0);
        this.f3701n = u5.e(f.j.f53925K2, 0);
        this.f3702o = u5.a(f.j.f53915I2, false);
        ColorStateList c5 = u5.c(f.j.f53940N2);
        if (c5 != null) {
            this.f3690c = c5;
            this.f3692e = true;
        }
        PorterDuff.Mode d5 = M.d(u5.j(f.j.f53945O2, -1), null);
        if (this.f3691d != d5) {
            this.f3691d = d5;
            this.f3693f = true;
        }
        if (this.f3692e || this.f3693f) {
            b();
        }
        ColorStateList c6 = u5.c(f.j.f53955Q2);
        if (c6 != null) {
            this.f3695h = c6;
            this.f3697j = true;
        }
        PorterDuff.Mode d6 = M.d(u5.j(f.j.f53960R2, -1), null);
        if (this.f3696i != d6) {
            this.f3696i = d6;
            this.f3698k = true;
        }
        if (this.f3697j || this.f3698k) {
            c();
        }
        int m5 = u5.m(f.j.f53930L2, 0);
        if (m5 != 0) {
            m(context, m5);
        }
        A a5 = new A(this);
        this.f3685P = a5;
        a5.m(attributeSet, i5);
        u5.w();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f3709v = viewConfiguration.getScaledTouchSlop();
        this.f3713z = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().c(attributeSet, i5);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
