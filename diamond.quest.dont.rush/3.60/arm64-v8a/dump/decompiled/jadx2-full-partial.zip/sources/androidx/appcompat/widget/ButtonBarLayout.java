package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import f.C4998f;

/* loaded from: classes.dex */
public class ButtonBarLayout extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    private boolean f3357b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f3358c;

    /* renamed from: d, reason: collision with root package name */
    private int f3359d;

    public ButtonBarLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3359d = -1;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f.j.f53938N0);
        C1015b0.b0(this, context, f.j.f53938N0, attributeSet, obtainStyledAttributes, 0, 0);
        this.f3357b = obtainStyledAttributes.getBoolean(f.j.f53943O0, true);
        obtainStyledAttributes.recycle();
        if (getOrientation() == 1) {
            setStacked(this.f3357b);
        }
    }

    private int a(int i5) {
        int childCount = getChildCount();
        while (i5 < childCount) {
            if (getChildAt(i5).getVisibility() == 0) {
                return i5;
            }
            i5++;
        }
        return -1;
    }

    private boolean b() {
        return this.f3358c;
    }

    private void setStacked(boolean z4) {
        if (this.f3358c != z4) {
            if (!z4 || this.f3357b) {
                this.f3358c = z4;
                setOrientation(z4 ? 1 : 0);
                setGravity(z4 ? 8388613 : 80);
                View findViewById = findViewById(C4998f.f53798G);
                if (findViewById != null) {
                    findViewById.setVisibility(z4 ? 8 : 4);
                }
                for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
                    bringChildToFront(getChildAt(childCount));
                }
            }
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i5, int i6) {
        int i7;
        boolean z4;
        int size = View.MeasureSpec.getSize(i5);
        int i8 = 0;
        if (this.f3357b) {
            if (size > this.f3359d && b()) {
                setStacked(false);
            }
            this.f3359d = size;
        }
        if (b() || View.MeasureSpec.getMode(i5) != 1073741824) {
            i7 = i5;
            z4 = false;
        } else {
            i7 = View.MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE);
            z4 = true;
        }
        super.onMeasure(i7, i6);
        if (this.f3357b && !b() && (getMeasuredWidthAndState() & (-16777216)) == 16777216) {
            setStacked(true);
            z4 = true;
        }
        if (z4) {
            super.onMeasure(i5, i6);
        }
        int a5 = a(0);
        if (a5 >= 0) {
            View childAt = getChildAt(a5);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
            int paddingTop = getPaddingTop() + childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (b()) {
                int a6 = a(a5 + 1);
                if (a6 >= 0) {
                    paddingTop += getChildAt(a6).getPaddingTop() + ((int) (getResources().getDisplayMetrics().density * 16.0f));
                }
                i8 = paddingTop;
            } else {
                i8 = paddingTop + getPaddingBottom();
            }
        }
        if (C1015b0.z(this) != i8) {
            setMinimumHeight(i8);
            if (i6 == 0) {
                super.onMeasure(i5, i6);
            }
        }
    }

    public void setAllowStacking(boolean z4) {
        if (this.f3357b != z4) {
            this.f3357b = z4;
            if (!z4 && b()) {
                setStacked(false);
            }
            requestLayout();
        }
    }
}
