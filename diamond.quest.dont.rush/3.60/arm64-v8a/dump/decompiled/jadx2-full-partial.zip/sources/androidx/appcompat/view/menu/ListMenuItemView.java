package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.view.menu.n;
import androidx.appcompat.widget.g0;
import f.C4993a;
import f.C4998f;
import f.C4999g;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: b, reason: collision with root package name */
    private i f3005b;

    /* renamed from: c, reason: collision with root package name */
    private ImageView f3006c;

    /* renamed from: d, reason: collision with root package name */
    private RadioButton f3007d;

    /* renamed from: e, reason: collision with root package name */
    private TextView f3008e;

    /* renamed from: f, reason: collision with root package name */
    private CheckBox f3009f;

    /* renamed from: g, reason: collision with root package name */
    private TextView f3010g;

    /* renamed from: h, reason: collision with root package name */
    private ImageView f3011h;

    /* renamed from: i, reason: collision with root package name */
    private ImageView f3012i;

    /* renamed from: j, reason: collision with root package name */
    private LinearLayout f3013j;

    /* renamed from: k, reason: collision with root package name */
    private Drawable f3014k;

    /* renamed from: l, reason: collision with root package name */
    private int f3015l;

    /* renamed from: m, reason: collision with root package name */
    private Context f3016m;

    /* renamed from: n, reason: collision with root package name */
    private boolean f3017n;

    /* renamed from: o, reason: collision with root package name */
    private Drawable f3018o;

    /* renamed from: p, reason: collision with root package name */
    private boolean f3019p;

    /* renamed from: q, reason: collision with root package name */
    private LayoutInflater f3020q;

    /* renamed from: r, reason: collision with root package name */
    private boolean f3021r;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53684E);
    }

    private void a(View view) {
        b(view, -1);
    }

    private void b(View view, int i5) {
        LinearLayout linearLayout = this.f3013j;
        if (linearLayout != null) {
            linearLayout.addView(view, i5);
        } else {
            addView(view, i5);
        }
    }

    private void e() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(C4999g.f53841h, (ViewGroup) this, false);
        this.f3009f = checkBox;
        a(checkBox);
    }

    private void f() {
        ImageView imageView = (ImageView) getInflater().inflate(C4999g.f53842i, (ViewGroup) this, false);
        this.f3006c = imageView;
        b(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(C4999g.f53844k, (ViewGroup) this, false);
        this.f3007d = radioButton;
        a(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.f3020q == null) {
            this.f3020q = LayoutInflater.from(getContext());
        }
        return this.f3020q;
    }

    private void setSubMenuArrowVisible(boolean z4) {
        ImageView imageView = this.f3011h;
        if (imageView != null) {
            imageView.setVisibility(z4 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f3012i;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f3012i.getLayoutParams();
        rect.top += this.f3012i.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.n.a
    public boolean c() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.n.a
    public void d(i iVar, int i5) {
        this.f3005b = iVar;
        setVisibility(iVar.isVisible() ? 0 : 8);
        setTitle(iVar.i(this));
        setCheckable(iVar.isCheckable());
        h(iVar.A(), iVar.g());
        setIcon(iVar.getIcon());
        setEnabled(iVar.isEnabled());
        setSubMenuArrowVisible(iVar.hasSubMenu());
        setContentDescription(iVar.getContentDescription());
    }

    @Override // androidx.appcompat.view.menu.n.a
    public i getItemData() {
        return this.f3005b;
    }

    public void h(boolean z4, char c5) {
        int i5 = (z4 && this.f3005b.A()) ? 0 : 8;
        if (i5 == 0) {
            this.f3010g.setText(this.f3005b.h());
        }
        if (this.f3010g.getVisibility() != i5) {
            this.f3010g.setVisibility(i5);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f3014k);
        TextView textView = (TextView) findViewById(C4998f.f53804M);
        this.f3008e = textView;
        int i5 = this.f3015l;
        if (i5 != -1) {
            textView.setTextAppearance(this.f3016m, i5);
        }
        this.f3010g = (TextView) findViewById(C4998f.f53797F);
        ImageView imageView = (ImageView) findViewById(C4998f.f53800I);
        this.f3011h = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f3018o);
        }
        this.f3012i = (ImageView) findViewById(C4998f.f53825r);
        this.f3013j = (LinearLayout) findViewById(C4998f.f53819l);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i5, int i6) {
        if (this.f3006c != null && this.f3017n) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f3006c.getLayoutParams();
            int i7 = layoutParams.height;
            if (i7 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i7;
            }
        }
        super.onMeasure(i5, i6);
    }

    public void setCheckable(boolean z4) {
        CompoundButton compoundButton;
        View view;
        if (!z4 && this.f3007d == null && this.f3009f == null) {
            return;
        }
        if (this.f3005b.m()) {
            if (this.f3007d == null) {
                g();
            }
            compoundButton = this.f3007d;
            view = this.f3009f;
        } else {
            if (this.f3009f == null) {
                e();
            }
            compoundButton = this.f3009f;
            view = this.f3007d;
        }
        if (z4) {
            compoundButton.setChecked(this.f3005b.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.f3009f;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.f3007d;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z4) {
        CompoundButton compoundButton;
        if (this.f3005b.m()) {
            if (this.f3007d == null) {
                g();
            }
            compoundButton = this.f3007d;
        } else {
            if (this.f3009f == null) {
                e();
            }
            compoundButton = this.f3009f;
        }
        compoundButton.setChecked(z4);
    }

    public void setForceShowIcon(boolean z4) {
        this.f3021r = z4;
        this.f3017n = z4;
    }

    public void setGroupDividerEnabled(boolean z4) {
        ImageView imageView = this.f3012i;
        if (imageView != null) {
            imageView.setVisibility((this.f3019p || !z4) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z4 = this.f3005b.z() || this.f3021r;
        if (z4 || this.f3017n) {
            ImageView imageView = this.f3006c;
            if (imageView == null && drawable == null && !this.f3017n) {
                return;
            }
            if (imageView == null) {
                f();
            }
            if (drawable == null && !this.f3017n) {
                this.f3006c.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.f3006c;
            if (!z4) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.f3006c.getVisibility() != 0) {
                this.f3006c.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f3008e.getVisibility() != 8) {
                this.f3008e.setVisibility(8);
            }
        } else {
            this.f3008e.setText(charSequence);
            if (this.f3008e.getVisibility() != 0) {
                this.f3008e.setVisibility(0);
            }
        }
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i5) {
        super(context, attributeSet);
        g0 u5 = g0.u(getContext(), attributeSet, f.j.f53968T1, i5, 0);
        this.f3014k = u5.f(f.j.f53976V1);
        this.f3015l = u5.m(f.j.f53972U1, -1);
        this.f3017n = u5.a(f.j.f53980W1, false);
        this.f3016m = context;
        this.f3018o = u5.f(f.j.f53984X1);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, C4993a.f53681B, 0);
        this.f3019p = obtainStyledAttributes.hasValue(0);
        u5.w();
        obtainStyledAttributes.recycle();
    }
}
