package androidx.core.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings;
import android.util.Log;
import androidx.annotation.NonNull;
import c.InterfaceC1228a;
import com.gdx.diamond.remote.event.Events;
import com.ironsource.b9;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class u {

    /* renamed from: d, reason: collision with root package name */
    private static String f4261d;

    /* renamed from: g, reason: collision with root package name */
    private static d f4264g;

    /* renamed from: a, reason: collision with root package name */
    private final Context f4265a;

    /* renamed from: b, reason: collision with root package name */
    private final NotificationManager f4266b;

    /* renamed from: c, reason: collision with root package name */
    private static final Object f4260c = new Object();

    /* renamed from: e, reason: collision with root package name */
    private static Set f4262e = new HashSet();

    /* renamed from: f, reason: collision with root package name */
    private static final Object f4263f = new Object();

    static class a {
        static boolean a(NotificationManager notificationManager) {
            return notificationManager.areNotificationsEnabled();
        }

        static int b(NotificationManager notificationManager) {
            return notificationManager.getImportance();
        }
    }

    private static class b implements e {

        /* renamed from: a, reason: collision with root package name */
        final String f4267a;

        /* renamed from: b, reason: collision with root package name */
        final int f4268b;

        /* renamed from: c, reason: collision with root package name */
        final String f4269c;

        /* renamed from: d, reason: collision with root package name */
        final Notification f4270d;

        b(String str, int i5, String str2, Notification notification) {
            this.f4267a = str;
            this.f4268b = i5;
            this.f4269c = str2;
            this.f4270d = notification;
        }

        @Override // androidx.core.app.u.e
        public void a(InterfaceC1228a interfaceC1228a) {
            interfaceC1228a.l(this.f4267a, this.f4268b, this.f4269c, this.f4270d);
        }

        public String toString() {
            return "NotifyTask[packageName:" + this.f4267a + ", id:" + this.f4268b + ", tag:" + this.f4269c + b9.i.f26270e;
        }
    }

    private static class c {

        /* renamed from: a, reason: collision with root package name */
        final ComponentName f4271a;

        /* renamed from: b, reason: collision with root package name */
        final IBinder f4272b;

        c(ComponentName componentName, IBinder iBinder) {
            this.f4271a = componentName;
            this.f4272b = iBinder;
        }
    }

    private static class d implements Handler.Callback, ServiceConnection {

        /* renamed from: b, reason: collision with root package name */
        private final Context f4273b;

        /* renamed from: c, reason: collision with root package name */
        private final HandlerThread f4274c;

        /* renamed from: d, reason: collision with root package name */
        private final Handler f4275d;

        /* renamed from: e, reason: collision with root package name */
        private final Map f4276e = new HashMap();

        /* renamed from: f, reason: collision with root package name */
        private Set f4277f = new HashSet();

        private static class a {

            /* renamed from: a, reason: collision with root package name */
            final ComponentName f4278a;

            /* renamed from: c, reason: collision with root package name */
            InterfaceC1228a f4280c;

            /* renamed from: b, reason: collision with root package name */
            boolean f4279b = false;

            /* renamed from: d, reason: collision with root package name */
            ArrayDeque f4281d = new ArrayDeque();

            /* renamed from: e, reason: collision with root package name */
            int f4282e = 0;

            a(ComponentName componentName) {
                this.f4278a = componentName;
            }
        }

        d(Context context) {
            this.f4273b = context;
            HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
            this.f4274c = handlerThread;
            handlerThread.start();
            this.f4275d = new Handler(handlerThread.getLooper(), this);
        }

        private boolean d(a aVar) {
            if (aVar.f4279b) {
                return true;
            }
            boolean bindService = this.f4273b.bindService(new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(aVar.f4278a), this, 33);
            aVar.f4279b = bindService;
            if (bindService) {
                aVar.f4282e = 0;
            } else {
                Log.w("NotifManCompat", "Unable to bind to listener " + aVar.f4278a);
                this.f4273b.unbindService(this);
            }
            return aVar.f4279b;
        }

        private void e(a aVar) {
            if (aVar.f4279b) {
                this.f4273b.unbindService(this);
                aVar.f4279b = false;
            }
            aVar.f4280c = null;
        }

        private void f(e eVar) {
            m();
            for (a aVar : this.f4276e.values()) {
                aVar.f4281d.add(eVar);
                j(aVar);
            }
        }

        private void g(ComponentName componentName) {
            a aVar = (a) this.f4276e.get(componentName);
            if (aVar != null) {
                j(aVar);
            }
        }

        private void h(ComponentName componentName, IBinder iBinder) {
            a aVar = (a) this.f4276e.get(componentName);
            if (aVar != null) {
                aVar.f4280c = InterfaceC1228a.AbstractBinderC0195a.C0(iBinder);
                aVar.f4282e = 0;
                j(aVar);
            }
        }

        private void i(ComponentName componentName) {
            a aVar = (a) this.f4276e.get(componentName);
            if (aVar != null) {
                e(aVar);
            }
        }

        private void j(a aVar) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Processing component " + aVar.f4278a + ", " + aVar.f4281d.size() + " queued tasks");
            }
            if (aVar.f4281d.isEmpty()) {
                return;
            }
            if (!d(aVar) || aVar.f4280c == null) {
                l(aVar);
                return;
            }
            while (true) {
                e eVar = (e) aVar.f4281d.peek();
                if (eVar == null) {
                    break;
                }
                try {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        Log.d("NotifManCompat", "Sending task " + eVar);
                    }
                    eVar.a(aVar.f4280c);
                    aVar.f4281d.remove();
                } catch (DeadObjectException unused) {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        Log.d("NotifManCompat", "Remote service has died: " + aVar.f4278a);
                    }
                } catch (RemoteException e5) {
                    Log.w("NotifManCompat", "RemoteException communicating with " + aVar.f4278a, e5);
                }
            }
            if (aVar.f4281d.isEmpty()) {
                return;
            }
            l(aVar);
        }

        private void l(a aVar) {
            if (this.f4275d.hasMessages(3, aVar.f4278a)) {
                return;
            }
            int i5 = aVar.f4282e;
            int i6 = i5 + 1;
            aVar.f4282e = i6;
            if (i6 <= 6) {
                int i7 = (1 << i5) * 1000;
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Log.d("NotifManCompat", "Scheduling retry for " + i7 + " ms");
                }
                this.f4275d.sendMessageDelayed(this.f4275d.obtainMessage(3, aVar.f4278a), i7);
                return;
            }
            Log.w("NotifManCompat", "Giving up on delivering " + aVar.f4281d.size() + " tasks to " + aVar.f4278a + " after " + aVar.f4282e + " retries");
            aVar.f4281d.clear();
        }

        private void m() {
            Set e5 = u.e(this.f4273b);
            if (e5.equals(this.f4277f)) {
                return;
            }
            this.f4277f = e5;
            List<ResolveInfo> queryIntentServices = this.f4273b.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
            HashSet<ComponentName> hashSet = new HashSet();
            for (ResolveInfo resolveInfo : queryIntentServices) {
                if (e5.contains(resolveInfo.serviceInfo.packageName)) {
                    ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                    ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                    if (resolveInfo.serviceInfo.permission != null) {
                        Log.w("NotifManCompat", "Permission present on component " + componentName + ", not adding listener record.");
                    } else {
                        hashSet.add(componentName);
                    }
                }
            }
            for (ComponentName componentName2 : hashSet) {
                if (!this.f4276e.containsKey(componentName2)) {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        Log.d("NotifManCompat", "Adding listener record for " + componentName2);
                    }
                    this.f4276e.put(componentName2, new a(componentName2));
                }
            }
            Iterator it = this.f4276e.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry entry = (Map.Entry) it.next();
                if (!hashSet.contains(entry.getKey())) {
                    if (Log.isLoggable("NotifManCompat", 3)) {
                        Log.d("NotifManCompat", "Removing listener record for " + entry.getKey());
                    }
                    e((a) entry.getValue());
                    it.remove();
                }
            }
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            int i5 = message.what;
            if (i5 == 0) {
                f((e) message.obj);
                return true;
            }
            if (i5 == 1) {
                c cVar = (c) message.obj;
                h(cVar.f4271a, cVar.f4272b);
                return true;
            }
            if (i5 == 2) {
                i((ComponentName) message.obj);
                return true;
            }
            if (i5 != 3) {
                return false;
            }
            g((ComponentName) message.obj);
            return true;
        }

        public void k(e eVar) {
            this.f4275d.obtainMessage(0, eVar).sendToTarget();
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Connected to service " + componentName);
            }
            this.f4275d.obtainMessage(1, new c(componentName, iBinder)).sendToTarget();
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Disconnected from service " + componentName);
            }
            this.f4275d.obtainMessage(2, componentName).sendToTarget();
        }
    }

    private interface e {
        void a(InterfaceC1228a interfaceC1228a);
    }

    private u(Context context) {
        this.f4265a = context;
        this.f4266b = (NotificationManager) context.getSystemService(Events.NOTIFICATION);
    }

    public static u d(Context context) {
        return new u(context);
    }

    public static Set e(Context context) {
        Set set;
        String string = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        synchronized (f4260c) {
            if (string != null) {
                try {
                    if (!string.equals(f4261d)) {
                        String[] split = string.split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1);
                        HashSet hashSet = new HashSet(split.length);
                        for (String str : split) {
                            ComponentName unflattenFromString = ComponentName.unflattenFromString(str);
                            if (unflattenFromString != null) {
                                hashSet.add(unflattenFromString.getPackageName());
                            }
                        }
                        f4262e = hashSet;
                        f4261d = string;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            set = f4262e;
        }
        return set;
    }

    private void h(e eVar) {
        synchronized (f4263f) {
            try {
                if (f4264g == null) {
                    f4264g = new d(this.f4265a.getApplicationContext());
                }
                f4264g.k(eVar);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static boolean i(Notification notification) {
        Bundle extras = NotificationCompat.getExtras(notification);
        return extras != null && extras.getBoolean("android.support.useSideChannel");
    }

    public boolean a() {
        if (Build.VERSION.SDK_INT >= 24) {
            return a.a(this.f4266b);
        }
        AppOpsManager appOpsManager = (AppOpsManager) this.f4265a.getSystemService("appops");
        ApplicationInfo applicationInfo = this.f4265a.getApplicationInfo();
        String packageName = this.f4265a.getApplicationContext().getPackageName();
        int i5 = applicationInfo.uid;
        try {
            Class<?> cls = Class.forName(AppOpsManager.class.getName());
            Class<?> cls2 = Integer.TYPE;
            Method method = cls.getMethod("checkOpNoThrow", cls2, cls2, String.class);
            Integer num = (Integer) cls.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class);
            num.intValue();
            return ((Integer) method.invoke(appOpsManager, num, Integer.valueOf(i5), packageName)).intValue() == 0;
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | RuntimeException | InvocationTargetException unused) {
            return true;
        }
    }

    public void b(int i5) {
        c(null, i5);
    }

    public void c(String str, int i5) {
        this.f4266b.cancel(str, i5);
    }

    public void f(int i5, Notification notification) {
        g(null, i5, notification);
    }

    public void g(String str, int i5, Notification notification) {
        if (!i(notification)) {
            this.f4266b.notify(str, i5, notification);
        } else {
            h(new b(this.f4265a.getPackageName(), i5, str, notification));
            this.f4266b.cancel(str, i5);
        }
    }

    u(@NonNull NotificationManager notificationManager, @NonNull Context context) {
        this.f4265a = context;
        this.f4266b = notificationManager;
    }
}
