package androidx.activity;

import K3.InterfaceC0950j;
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.AbstractC1108h;
import androidx.lifecycle.InterfaceC1112l;
import androidx.lifecycle.InterfaceC1116p;
import java.lang.reflect.Field;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes.dex */
public final class ImmLeaksCleaner implements InterfaceC1112l {

    /* renamed from: c, reason: collision with root package name */
    public static final c f2435c = new c(null);

    /* renamed from: d, reason: collision with root package name */
    private static final InterfaceC0950j f2436d = K3.k.b(b.f2438g);

    /* renamed from: b, reason: collision with root package name */
    private final Activity f2437b;

    public static abstract class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public abstract boolean a(InputMethodManager inputMethodManager);

        public abstract Object b(InputMethodManager inputMethodManager);

        public abstract View c(InputMethodManager inputMethodManager);

        private a() {
        }
    }

    static final class b extends kotlin.jvm.internal.t implements U3.a {

        /* renamed from: g, reason: collision with root package name */
        public static final b f2438g = new b();

        b() {
            super(0);
        }

        @Override // U3.a
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final a invoke() {
            try {
                Field servedViewField = InputMethodManager.class.getDeclaredField("mServedView");
                servedViewField.setAccessible(true);
                Field nextServedViewField = InputMethodManager.class.getDeclaredField("mNextServedView");
                nextServedViewField.setAccessible(true);
                Field hField = InputMethodManager.class.getDeclaredField("mH");
                hField.setAccessible(true);
                C7150s.i(hField, "hField");
                C7150s.i(servedViewField, "servedViewField");
                C7150s.i(nextServedViewField, "nextServedViewField");
                return new e(hField, servedViewField, nextServedViewField);
            } catch (NoSuchFieldException unused) {
                return d.f2439a;
            }
        }
    }

    public static final class c {
        public /* synthetic */ c(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final a a() {
            return (a) ImmLeaksCleaner.f2436d.getValue();
        }

        private c() {
        }
    }

    public static final class d extends a {

        /* renamed from: a, reason: collision with root package name */
        public static final d f2439a = new d();

        private d() {
            super(null);
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public boolean a(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            return false;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public Object b(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            return null;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public View c(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            return null;
        }
    }

    public static final class e extends a {

        /* renamed from: a, reason: collision with root package name */
        private final Field f2440a;

        /* renamed from: b, reason: collision with root package name */
        private final Field f2441b;

        /* renamed from: c, reason: collision with root package name */
        private final Field f2442c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(Field hField, Field servedViewField, Field nextServedViewField) {
            super(null);
            C7150s.j(hField, "hField");
            C7150s.j(servedViewField, "servedViewField");
            C7150s.j(nextServedViewField, "nextServedViewField");
            this.f2440a = hField;
            this.f2441b = servedViewField;
            this.f2442c = nextServedViewField;
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public boolean a(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            try {
                this.f2442c.set(inputMethodManager, null);
                return true;
            } catch (IllegalAccessException unused) {
                return false;
            }
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public Object b(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            try {
                return this.f2440a.get(inputMethodManager);
            } catch (IllegalAccessException unused) {
                return null;
            }
        }

        @Override // androidx.activity.ImmLeaksCleaner.a
        public View c(InputMethodManager inputMethodManager) {
            C7150s.j(inputMethodManager, "<this>");
            try {
                return (View) this.f2441b.get(inputMethodManager);
            } catch (ClassCastException | IllegalAccessException unused) {
                return null;
            }
        }
    }

    public ImmLeaksCleaner(Activity activity) {
        C7150s.j(activity, "activity");
        this.f2437b = activity;
    }

    @Override // androidx.lifecycle.InterfaceC1112l
    public void onStateChanged(InterfaceC1116p source, AbstractC1108h.a event) {
        C7150s.j(source, "source");
        C7150s.j(event, "event");
        if (event != AbstractC1108h.a.ON_DESTROY) {
            return;
        }
        Object systemService = this.f2437b.getSystemService("input_method");
        C7150s.h(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
        InputMethodManager inputMethodManager = (InputMethodManager) systemService;
        a a5 = f2435c.a();
        Object b5 = a5.b(inputMethodManager);
        if (b5 == null) {
            return;
        }
        synchronized (b5) {
            View c5 = a5.c(inputMethodManager);
            if (c5 == null) {
                return;
            }
            if (c5.isAttachedToWindow()) {
                return;
            }
            boolean a6 = a5.a(inputMethodManager);
            if (a6) {
                inputMethodManager.isActive();
            }
        }
    }
}
