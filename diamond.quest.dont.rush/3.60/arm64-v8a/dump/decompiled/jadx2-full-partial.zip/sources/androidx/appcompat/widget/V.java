package androidx.appcompat.widget;

import android.content.Context;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.g;
import f.C4993a;

/* loaded from: classes.dex */
public class V {

    /* renamed from: a, reason: collision with root package name */
    private final Context f3583a;

    /* renamed from: b, reason: collision with root package name */
    private final androidx.appcompat.view.menu.g f3584b;

    /* renamed from: c, reason: collision with root package name */
    private final View f3585c;

    /* renamed from: d, reason: collision with root package name */
    final androidx.appcompat.view.menu.l f3586d;

    class a implements g.a {
        a() {
        }

        @Override // androidx.appcompat.view.menu.g.a
        public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
            V.this.getClass();
            return false;
        }

        @Override // androidx.appcompat.view.menu.g.a
        public void b(androidx.appcompat.view.menu.g gVar) {
        }
    }

    class b implements PopupWindow.OnDismissListener {
        b() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            V.this.getClass();
        }
    }

    public V(@NonNull Context context, @NonNull View view) {
        this(context, view, 0);
    }

    public Menu a() {
        return this.f3584b;
    }

    public void b() {
        this.f3586d.k();
    }

    public V(@NonNull Context context, @NonNull View view, int i5) {
        this(context, view, i5, C4993a.f53687H, 0);
    }

    public V(@NonNull Context context, @NonNull View view, int i5, int i6, int i7) {
        this.f3583a = context;
        this.f3585c = view;
        androidx.appcompat.view.menu.g gVar = new androidx.appcompat.view.menu.g(context);
        this.f3584b = gVar;
        gVar.S(new a());
        androidx.appcompat.view.menu.l lVar = new androidx.appcompat.view.menu.l(context, gVar, view, false, i6, i7);
        this.f3586d = lVar;
        lVar.h(i5);
        lVar.i(new b());
    }
}
