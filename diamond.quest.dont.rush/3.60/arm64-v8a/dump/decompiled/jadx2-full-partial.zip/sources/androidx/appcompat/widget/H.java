package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.C1035l0;

/* loaded from: classes.dex */
public interface H {
    boolean a();

    boolean b();

    boolean c();

    void collapseActionView();

    boolean d();

    void e(Menu menu, m.a aVar);

    void f();

    boolean g();

    Context getContext();

    CharSequence getTitle();

    boolean h();

    void i(int i5);

    int j();

    void k();

    void l(boolean z4);

    void m();

    int n();

    void o();

    Menu p();

    C1035l0 q(int i5, long j5);

    ViewGroup r();

    void s(boolean z4);

    void setIcon(int i5);

    void setIcon(Drawable drawable);

    void setVisibility(int i5);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    void t(Z z4);

    void u(int i5);

    void v(m.a aVar, g.a aVar2);
}
