package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;

/* renamed from: androidx.appcompat.widget.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0997p extends ImageButton {

    /* renamed from: b, reason: collision with root package name */
    private final C0986e f3852b;

    /* renamed from: c, reason: collision with root package name */
    private final C0998q f3853c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f3854d;

    public C0997p(@NonNull Context context) {
        this(context, null);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            c0986e.b();
        }
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportImageTintList() {
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            return c0998q.d();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportImageTintMode() {
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            return c0998q.e();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.f3853c.f() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(@Nullable Drawable drawable) {
        C0998q c0998q = this.f3853c;
        if (c0998q != null && drawable != null && !this.f3854d) {
            c0998q.h(drawable);
        }
        super.setImageDrawable(drawable);
        C0998q c0998q2 = this.f3853c;
        if (c0998q2 != null) {
            c0998q2.c();
            if (this.f3854d) {
                return;
            }
            this.f3853c.b();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i5) {
        super.setImageLevel(i5);
        this.f3854d = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i5) {
        this.f3853c.i(i5);
    }

    @Override // android.widget.ImageView
    public void setImageURI(@Nullable Uri uri) {
        super.setImageURI(uri);
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.f3852b;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    public void setSupportImageTintList(@Nullable ColorStateList colorStateList) {
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            c0998q.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(@Nullable PorterDuff.Mode mode) {
        C0998q c0998q = this.f3853c;
        if (c0998q != null) {
            c0998q.k(mode);
        }
    }

    public C0997p(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53683D);
    }

    public C0997p(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        this.f3854d = false;
        c0.a(this, getContext());
        C0986e c0986e = new C0986e(this);
        this.f3852b = c0986e;
        c0986e.e(attributeSet, i5);
        C0998q c0998q = new C0998q(this);
        this.f3853c = c0998q;
        c0998q.g(attributeSet, i5);
    }
}
