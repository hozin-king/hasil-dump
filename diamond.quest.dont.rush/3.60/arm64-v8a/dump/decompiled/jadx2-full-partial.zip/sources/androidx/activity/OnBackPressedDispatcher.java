package androidx.activity;

import K3.H;
import android.os.Build;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.OnBackPressedDispatcher;
import androidx.lifecycle.AbstractC1108h;
import androidx.lifecycle.InterfaceC1112l;
import androidx.lifecycle.InterfaceC1116p;
import java.util.Iterator;
import java.util.ListIterator;
import kotlin.collections.C7115h;
import kotlin.jvm.internal.C7148p;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes.dex */
public final class OnBackPressedDispatcher {

    /* renamed from: a, reason: collision with root package name */
    private final Runnable f2443a;

    /* renamed from: b, reason: collision with root package name */
    private final t.b f2444b;

    /* renamed from: c, reason: collision with root package name */
    private final C7115h f2445c;

    /* renamed from: d, reason: collision with root package name */
    private u f2446d;

    /* renamed from: e, reason: collision with root package name */
    private OnBackInvokedCallback f2447e;

    /* renamed from: f, reason: collision with root package name */
    private OnBackInvokedDispatcher f2448f;

    /* renamed from: g, reason: collision with root package name */
    private boolean f2449g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f2450h;

    private final class LifecycleOnBackPressedCancellable implements InterfaceC1112l, androidx.activity.c {

        /* renamed from: b, reason: collision with root package name */
        private final AbstractC1108h f2451b;

        /* renamed from: c, reason: collision with root package name */
        private final u f2452c;

        /* renamed from: d, reason: collision with root package name */
        private androidx.activity.c f2453d;

        /* renamed from: e, reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f2454e;

        public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher onBackPressedDispatcher, AbstractC1108h lifecycle, u onBackPressedCallback) {
            C7150s.j(lifecycle, "lifecycle");
            C7150s.j(onBackPressedCallback, "onBackPressedCallback");
            this.f2454e = onBackPressedDispatcher;
            this.f2451b = lifecycle;
            this.f2452c = onBackPressedCallback;
            lifecycle.addObserver(this);
        }

        @Override // androidx.activity.c
        public void cancel() {
            this.f2451b.removeObserver(this);
            this.f2452c.removeCancellable(this);
            androidx.activity.c cVar = this.f2453d;
            if (cVar != null) {
                cVar.cancel();
            }
            this.f2453d = null;
        }

        @Override // androidx.lifecycle.InterfaceC1112l
        public void onStateChanged(InterfaceC1116p source, AbstractC1108h.a event) {
            C7150s.j(source, "source");
            C7150s.j(event, "event");
            if (event == AbstractC1108h.a.ON_START) {
                this.f2453d = this.f2454e.j(this.f2452c);
                return;
            }
            if (event != AbstractC1108h.a.ON_STOP) {
                if (event == AbstractC1108h.a.ON_DESTROY) {
                    cancel();
                }
            } else {
                androidx.activity.c cVar = this.f2453d;
                if (cVar != null) {
                    cVar.cancel();
                }
            }
        }
    }

    static final class a extends kotlin.jvm.internal.t implements U3.l {
        a() {
            super(1);
        }

        public final void a(androidx.activity.b backEvent) {
            C7150s.j(backEvent, "backEvent");
            OnBackPressedDispatcher.this.n(backEvent);
        }

        @Override // U3.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.activity.b) obj);
            return H.f1374a;
        }
    }

    static final class b extends kotlin.jvm.internal.t implements U3.l {
        b() {
            super(1);
        }

        public final void a(androidx.activity.b backEvent) {
            C7150s.j(backEvent, "backEvent");
            OnBackPressedDispatcher.this.m(backEvent);
        }

        @Override // U3.l
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((androidx.activity.b) obj);
            return H.f1374a;
        }
    }

    static final class c extends kotlin.jvm.internal.t implements U3.a {
        c() {
            super(0);
        }

        @Override // U3.a
        public /* bridge */ /* synthetic */ Object invoke() {
            m3invoke();
            return H.f1374a;
        }

        /* renamed from: invoke, reason: collision with other method in class */
        public final void m3invoke() {
            OnBackPressedDispatcher.this.l();
        }
    }

    static final class d extends kotlin.jvm.internal.t implements U3.a {
        d() {
            super(0);
        }

        @Override // U3.a
        public /* bridge */ /* synthetic */ Object invoke() {
            m4invoke();
            return H.f1374a;
        }

        /* renamed from: invoke, reason: collision with other method in class */
        public final void m4invoke() {
            OnBackPressedDispatcher.this.k();
        }
    }

    static final class e extends kotlin.jvm.internal.t implements U3.a {
        e() {
            super(0);
        }

        @Override // U3.a
        public /* bridge */ /* synthetic */ Object invoke() {
            m5invoke();
            return H.f1374a;
        }

        /* renamed from: invoke, reason: collision with other method in class */
        public final void m5invoke() {
            OnBackPressedDispatcher.this.l();
        }
    }

    public static final class f {

        /* renamed from: a, reason: collision with root package name */
        public static final f f2460a = new f();

        private f() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(U3.a onBackInvoked) {
            C7150s.j(onBackInvoked, "$onBackInvoked");
            onBackInvoked.invoke();
        }

        public final OnBackInvokedCallback b(final U3.a onBackInvoked) {
            C7150s.j(onBackInvoked, "onBackInvoked");
            return new OnBackInvokedCallback() { // from class: androidx.activity.w
                public final void onBackInvoked() {
                    OnBackPressedDispatcher.f.c(U3.a.this);
                }
            };
        }

        public final void d(Object dispatcher, int i5, Object callback) {
            C7150s.j(dispatcher, "dispatcher");
            C7150s.j(callback, "callback");
            ((OnBackInvokedDispatcher) dispatcher).registerOnBackInvokedCallback(i5, (OnBackInvokedCallback) callback);
        }

        public final void e(Object dispatcher, Object callback) {
            C7150s.j(dispatcher, "dispatcher");
            C7150s.j(callback, "callback");
            ((OnBackInvokedDispatcher) dispatcher).unregisterOnBackInvokedCallback((OnBackInvokedCallback) callback);
        }
    }

    public static final class g {

        /* renamed from: a, reason: collision with root package name */
        public static final g f2461a = new g();

        public static final class a implements OnBackAnimationCallback {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ U3.l f2462a;

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ U3.l f2463b;

            /* renamed from: c, reason: collision with root package name */
            final /* synthetic */ U3.a f2464c;

            /* renamed from: d, reason: collision with root package name */
            final /* synthetic */ U3.a f2465d;

            a(U3.l lVar, U3.l lVar2, U3.a aVar, U3.a aVar2) {
                this.f2462a = lVar;
                this.f2463b = lVar2;
                this.f2464c = aVar;
                this.f2465d = aVar2;
            }

            public void onBackCancelled() {
                this.f2465d.invoke();
            }

            public void onBackInvoked() {
                this.f2464c.invoke();
            }

            public void onBackProgressed(BackEvent backEvent) {
                C7150s.j(backEvent, "backEvent");
                this.f2463b.invoke(new androidx.activity.b(backEvent));
            }

            public void onBackStarted(BackEvent backEvent) {
                C7150s.j(backEvent, "backEvent");
                this.f2462a.invoke(new androidx.activity.b(backEvent));
            }
        }

        private g() {
        }

        public final OnBackInvokedCallback a(U3.l onBackStarted, U3.l onBackProgressed, U3.a onBackInvoked, U3.a onBackCancelled) {
            C7150s.j(onBackStarted, "onBackStarted");
            C7150s.j(onBackProgressed, "onBackProgressed");
            C7150s.j(onBackInvoked, "onBackInvoked");
            C7150s.j(onBackCancelled, "onBackCancelled");
            return new a(onBackStarted, onBackProgressed, onBackInvoked, onBackCancelled);
        }
    }

    private final class h implements androidx.activity.c {

        /* renamed from: b, reason: collision with root package name */
        private final u f2466b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f2467c;

        public h(OnBackPressedDispatcher onBackPressedDispatcher, u onBackPressedCallback) {
            C7150s.j(onBackPressedCallback, "onBackPressedCallback");
            this.f2467c = onBackPressedDispatcher;
            this.f2466b = onBackPressedCallback;
        }

        @Override // androidx.activity.c
        public void cancel() {
            this.f2467c.f2445c.remove(this.f2466b);
            if (C7150s.e(this.f2467c.f2446d, this.f2466b)) {
                this.f2466b.handleOnBackCancelled();
                this.f2467c.f2446d = null;
            }
            this.f2466b.removeCancellable(this);
            U3.a enabledChangedCallback$activity_release = this.f2466b.getEnabledChangedCallback$activity_release();
            if (enabledChangedCallback$activity_release != null) {
                enabledChangedCallback$activity_release.invoke();
            }
            this.f2466b.setEnabledChangedCallback$activity_release(null);
        }
    }

    /* synthetic */ class i extends C7148p implements U3.a {
        i(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        public final void h() {
            ((OnBackPressedDispatcher) this.receiver).q();
        }

        @Override // U3.a
        public /* bridge */ /* synthetic */ Object invoke() {
            h();
            return H.f1374a;
        }
    }

    /* synthetic */ class j extends C7148p implements U3.a {
        j(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        public final void h() {
            ((OnBackPressedDispatcher) this.receiver).q();
        }

        @Override // U3.a
        public /* bridge */ /* synthetic */ Object invoke() {
            h();
            return H.f1374a;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OnBackPressedDispatcher() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object] */
    public final void k() {
        u uVar;
        u uVar2 = this.f2446d;
        if (uVar2 == null) {
            C7115h c7115h = this.f2445c;
            ListIterator listIterator = c7115h.listIterator(c7115h.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    uVar = 0;
                    break;
                } else {
                    uVar = listIterator.previous();
                    if (((u) uVar).isEnabled()) {
                        break;
                    }
                }
            }
            uVar2 = uVar;
        }
        this.f2446d = null;
        if (uVar2 != null) {
            uVar2.handleOnBackCancelled();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4, types: [java.lang.Object] */
    public final void m(androidx.activity.b bVar) {
        u uVar;
        u uVar2 = this.f2446d;
        if (uVar2 == null) {
            C7115h c7115h = this.f2445c;
            ListIterator listIterator = c7115h.listIterator(c7115h.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    uVar = 0;
                    break;
                } else {
                    uVar = listIterator.previous();
                    if (((u) uVar).isEnabled()) {
                        break;
                    }
                }
            }
            uVar2 = uVar;
        }
        if (uVar2 != null) {
            uVar2.handleOnBackProgressed(bVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void n(androidx.activity.b bVar) {
        Object obj;
        C7115h c7115h = this.f2445c;
        ListIterator<E> listIterator = c7115h.listIterator(c7115h.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            } else {
                obj = listIterator.previous();
                if (((u) obj).isEnabled()) {
                    break;
                }
            }
        }
        u uVar = (u) obj;
        if (this.f2446d != null) {
            k();
        }
        this.f2446d = uVar;
        if (uVar != null) {
            uVar.handleOnBackStarted(bVar);
        }
    }

    private final void p(boolean z4) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f2448f;
        OnBackInvokedCallback onBackInvokedCallback = this.f2447e;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        if (z4 && !this.f2449g) {
            f.f2460a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f2449g = true;
        } else {
            if (z4 || !this.f2449g) {
                return;
            }
            f.f2460a.e(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f2449g = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void q() {
        boolean z4 = this.f2450h;
        C7115h c7115h = this.f2445c;
        boolean z5 = false;
        if (!v.a(c7115h) || !c7115h.isEmpty()) {
            Iterator<E> it = c7115h.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (((u) it.next()).isEnabled()) {
                    z5 = true;
                    break;
                }
            }
        }
        this.f2450h = z5;
        if (z5 != z4) {
            t.b bVar = this.f2444b;
            if (bVar != null) {
                bVar.accept(Boolean.valueOf(z5));
            }
            if (Build.VERSION.SDK_INT >= 33) {
                p(z5);
            }
        }
    }

    public final void h(u onBackPressedCallback) {
        C7150s.j(onBackPressedCallback, "onBackPressedCallback");
        j(onBackPressedCallback);
    }

    public final void i(InterfaceC1116p owner, u onBackPressedCallback) {
        C7150s.j(owner, "owner");
        C7150s.j(onBackPressedCallback, "onBackPressedCallback");
        AbstractC1108h lifecycle = owner.getLifecycle();
        if (lifecycle.getCurrentState() == AbstractC1108h.b.DESTROYED) {
            return;
        }
        onBackPressedCallback.addCancellable(new LifecycleOnBackPressedCancellable(this, lifecycle, onBackPressedCallback));
        q();
        onBackPressedCallback.setEnabledChangedCallback$activity_release(new i(this));
    }

    public final androidx.activity.c j(u onBackPressedCallback) {
        C7150s.j(onBackPressedCallback, "onBackPressedCallback");
        this.f2445c.add(onBackPressedCallback);
        h hVar = new h(this, onBackPressedCallback);
        onBackPressedCallback.addCancellable(hVar);
        q();
        onBackPressedCallback.setEnabledChangedCallback$activity_release(new j(this));
        return hVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object] */
    public final void l() {
        u uVar;
        u uVar2 = this.f2446d;
        if (uVar2 == null) {
            C7115h c7115h = this.f2445c;
            ListIterator listIterator = c7115h.listIterator(c7115h.size());
            while (true) {
                if (!listIterator.hasPrevious()) {
                    uVar = 0;
                    break;
                } else {
                    uVar = listIterator.previous();
                    if (((u) uVar).isEnabled()) {
                        break;
                    }
                }
            }
            uVar2 = uVar;
        }
        this.f2446d = null;
        if (uVar2 != null) {
            uVar2.handleOnBackPressed();
            return;
        }
        Runnable runnable = this.f2443a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void o(OnBackInvokedDispatcher invoker) {
        C7150s.j(invoker, "invoker");
        this.f2448f = invoker;
        p(this.f2450h);
    }

    public OnBackPressedDispatcher(Runnable runnable, t.b bVar) {
        this.f2443a = runnable;
        this.f2444b = bVar;
        this.f2445c = new C7115h();
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 33) {
            this.f2447e = i5 >= 34 ? g.f2461a.a(new a(), new b(), new c(), new d()) : f.f2460a.b(new e());
        }
    }

    public /* synthetic */ OnBackPressedDispatcher(Runnable runnable, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this((i5 & 1) != 0 ? null : runnable);
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this(runnable, null);
    }
}
