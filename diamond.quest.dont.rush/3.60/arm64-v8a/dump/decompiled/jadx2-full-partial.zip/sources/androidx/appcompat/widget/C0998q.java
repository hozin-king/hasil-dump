package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.core.view.C1015b0;
import g.C5008a;

/* renamed from: androidx.appcompat.widget.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0998q {

    /* renamed from: a, reason: collision with root package name */
    private final ImageView f3862a;

    /* renamed from: b, reason: collision with root package name */
    private e0 f3863b;

    /* renamed from: c, reason: collision with root package name */
    private e0 f3864c;

    /* renamed from: d, reason: collision with root package name */
    private e0 f3865d;

    /* renamed from: e, reason: collision with root package name */
    private int f3866e = 0;

    public C0998q(@NonNull ImageView imageView) {
        this.f3862a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.f3865d == null) {
            this.f3865d = new e0();
        }
        e0 e0Var = this.f3865d;
        e0Var.a();
        ColorStateList a5 = androidx.core.widget.g.a(this.f3862a);
        if (a5 != null) {
            e0Var.f3771d = true;
            e0Var.f3768a = a5;
        }
        PorterDuff.Mode b5 = androidx.core.widget.g.b(this.f3862a);
        if (b5 != null) {
            e0Var.f3770c = true;
            e0Var.f3769b = b5;
        }
        if (!e0Var.f3771d && !e0Var.f3770c) {
            return false;
        }
        C0992k.i(drawable, e0Var, this.f3862a.getDrawableState());
        return true;
    }

    private boolean l() {
        return this.f3863b != null;
    }

    void b() {
        if (this.f3862a.getDrawable() != null) {
            this.f3862a.getDrawable().setLevel(this.f3866e);
        }
    }

    void c() {
        Drawable drawable = this.f3862a.getDrawable();
        if (drawable != null) {
            M.a(drawable);
        }
        if (drawable != null) {
            if (l() && a(drawable)) {
                return;
            }
            e0 e0Var = this.f3864c;
            if (e0Var != null) {
                C0992k.i(drawable, e0Var, this.f3862a.getDrawableState());
                return;
            }
            e0 e0Var2 = this.f3863b;
            if (e0Var2 != null) {
                C0992k.i(drawable, e0Var2, this.f3862a.getDrawableState());
            }
        }
    }

    ColorStateList d() {
        e0 e0Var = this.f3864c;
        if (e0Var != null) {
            return e0Var.f3768a;
        }
        return null;
    }

    PorterDuff.Mode e() {
        e0 e0Var = this.f3864c;
        if (e0Var != null) {
            return e0Var.f3769b;
        }
        return null;
    }

    boolean f() {
        return !(this.f3862a.getBackground() instanceof RippleDrawable);
    }

    public void g(AttributeSet attributeSet, int i5) {
        int m5;
        g0 u5 = g0.u(this.f3862a.getContext(), attributeSet, f.j.f53947P, i5, 0);
        ImageView imageView = this.f3862a;
        C1015b0.b0(imageView, imageView.getContext(), f.j.f53947P, attributeSet, u5.q(), i5, 0);
        try {
            Drawable drawable = this.f3862a.getDrawable();
            if (drawable == null && (m5 = u5.m(f.j.f53952Q, -1)) != -1 && (drawable = C5008a.b(this.f3862a.getContext(), m5)) != null) {
                this.f3862a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                M.a(drawable);
            }
            if (u5.r(f.j.f53957R)) {
                androidx.core.widget.g.c(this.f3862a, u5.c(f.j.f53957R));
            }
            if (u5.r(f.j.f53962S)) {
                androidx.core.widget.g.d(this.f3862a, M.d(u5.j(f.j.f53962S, -1), null));
            }
            u5.w();
        } catch (Throwable th) {
            u5.w();
            throw th;
        }
    }

    void h(Drawable drawable) {
        this.f3866e = drawable.getLevel();
    }

    public void i(int i5) {
        if (i5 != 0) {
            Drawable b5 = C5008a.b(this.f3862a.getContext(), i5);
            if (b5 != null) {
                M.a(b5);
            }
            this.f3862a.setImageDrawable(b5);
        } else {
            this.f3862a.setImageDrawable(null);
        }
        c();
    }

    void j(ColorStateList colorStateList) {
        if (this.f3864c == null) {
            this.f3864c = new e0();
        }
        e0 e0Var = this.f3864c;
        e0Var.f3768a = colorStateList;
        e0Var.f3771d = true;
        c();
    }

    void k(PorterDuff.Mode mode) {
        if (this.f3864c == null) {
            this.f3864c = new e0();
        }
        e0 e0Var = this.f3864c;
        e0Var.f3769b = mode;
        e0Var.f3770c = true;
        c();
    }
}
