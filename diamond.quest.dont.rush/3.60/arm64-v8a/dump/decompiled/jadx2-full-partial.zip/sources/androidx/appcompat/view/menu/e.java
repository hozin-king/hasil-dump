package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;
import f.C4999g;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class e implements m, AdapterView.OnItemClickListener {

    /* renamed from: b, reason: collision with root package name */
    Context f3092b;

    /* renamed from: c, reason: collision with root package name */
    LayoutInflater f3093c;

    /* renamed from: d, reason: collision with root package name */
    g f3094d;

    /* renamed from: e, reason: collision with root package name */
    ExpandedMenuView f3095e;

    /* renamed from: f, reason: collision with root package name */
    int f3096f;

    /* renamed from: g, reason: collision with root package name */
    int f3097g;

    /* renamed from: h, reason: collision with root package name */
    int f3098h;

    /* renamed from: i, reason: collision with root package name */
    private m.a f3099i;

    /* renamed from: j, reason: collision with root package name */
    a f3100j;

    private class a extends BaseAdapter {

        /* renamed from: b, reason: collision with root package name */
        private int f3101b = -1;

        public a() {
            a();
        }

        void a() {
            i v5 = e.this.f3094d.v();
            if (v5 != null) {
                ArrayList z4 = e.this.f3094d.z();
                int size = z4.size();
                for (int i5 = 0; i5 < size; i5++) {
                    if (((i) z4.get(i5)) == v5) {
                        this.f3101b = i5;
                        return;
                    }
                }
            }
            this.f3101b = -1;
        }

        @Override // android.widget.Adapter
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public i getItem(int i5) {
            ArrayList z4 = e.this.f3094d.z();
            int i6 = i5 + e.this.f3096f;
            int i7 = this.f3101b;
            if (i7 >= 0 && i6 >= i7) {
                i6++;
            }
            return (i) z4.get(i6);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            int size = e.this.f3094d.z().size() - e.this.f3096f;
            return this.f3101b < 0 ? size : size - 1;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i5) {
            return i5;
        }

        @Override // android.widget.Adapter
        public View getView(int i5, View view, ViewGroup viewGroup) {
            if (view == null) {
                e eVar = e.this;
                view = eVar.f3093c.inflate(eVar.f3098h, viewGroup, false);
            }
            ((n.a) view).d(getItem(i5), 0);
            return view;
        }

        @Override // android.widget.BaseAdapter
        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public e(Context context, int i5) {
        this(i5, 0);
        this.f3092b = context;
        this.f3093c = LayoutInflater.from(context);
    }

    @Override // androidx.appcompat.view.menu.m
    public void a(g gVar, boolean z4) {
        m.a aVar = this.f3099i;
        if (aVar != null) {
            aVar.a(gVar, z4);
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean b(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void c(boolean z4) {
        a aVar = this.f3100j;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean e(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void f(Context context, g gVar) {
        if (this.f3097g != 0) {
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, this.f3097g);
            this.f3092b = contextThemeWrapper;
            this.f3093c = LayoutInflater.from(contextThemeWrapper);
        } else if (this.f3092b != null) {
            this.f3092b = context;
            if (this.f3093c == null) {
                this.f3093c = LayoutInflater.from(context);
            }
        }
        this.f3094d = gVar;
        a aVar = this.f3100j;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public void g(m.a aVar) {
        this.f3099i = aVar;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean h(r rVar) {
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        new h(rVar).d(null);
        m.a aVar = this.f3099i;
        if (aVar == null) {
            return true;
        }
        aVar.b(rVar);
        return true;
    }

    public ListAdapter i() {
        if (this.f3100j == null) {
            this.f3100j = new a();
        }
        return this.f3100j;
    }

    public n j(ViewGroup viewGroup) {
        if (this.f3095e == null) {
            this.f3095e = (ExpandedMenuView) this.f3093c.inflate(C4999g.f53840g, viewGroup, false);
            if (this.f3100j == null) {
                this.f3100j = new a();
            }
            this.f3095e.setAdapter((ListAdapter) this.f3100j);
            this.f3095e.setOnItemClickListener(this);
        }
        return this.f3095e;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i5, long j5) {
        this.f3094d.N(this.f3100j.getItem(i5), this, 0);
    }

    public e(int i5, int i6) {
        this.f3098h = i5;
        this.f3097g = i6;
    }
}
