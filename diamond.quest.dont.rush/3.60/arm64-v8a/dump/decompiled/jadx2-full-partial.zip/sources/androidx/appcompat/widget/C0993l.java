package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import androidx.core.view.C1018d;
import f.C4993a;
import w.C7504c;
import w.C7506e;

/* renamed from: androidx.appcompat.widget.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0993l extends EditText implements androidx.core.view.N, androidx.core.widget.l {

    @NonNull
    private final C0994m mAppCompatEmojiEditTextHelper;
    private final C0986e mBackgroundTintHelper;
    private final androidx.core.widget.k mDefaultOnReceiveContentListener;

    @Nullable
    private a mSuperCaller;
    private final C1006z mTextClassifierHelper;
    private final A mTextHelper;

    /* renamed from: androidx.appcompat.widget.l$a */
    class a {
        a() {
        }

        public TextClassifier a() {
            return C0993l.super.getTextClassifier();
        }

        public void b(TextClassifier textClassifier) {
            C0993l.super.setTextClassifier(textClassifier);
        }
    }

    public C0993l(@NonNull Context context) {
        this(context, null);
    }

    @NonNull
    private a getSuperCaller() {
        if (this.mSuperCaller == null) {
            this.mSuperCaller = new a();
        }
        return this.mSuperCaller;
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.b();
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.b();
        }
    }

    @Override // android.widget.TextView
    @Nullable
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return androidx.core.widget.j.n(super.getCustomSelectionActionModeCallback());
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.mTextHelper.j();
    }

    @Nullable
    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.mTextHelper.k();
    }

    @Override // android.widget.TextView
    @NonNull
    public TextClassifier getTextClassifier() {
        C1006z c1006z;
        return (Build.VERSION.SDK_INT >= 28 || (c1006z = this.mTextClassifierHelper) == null) ? getSuperCaller().a() : c1006z.a();
    }

    void initEmojiKeyListener(C0994m c0994m) {
        KeyListener keyListener = getKeyListener();
        if (c0994m.b(keyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a5 = c0994m.a(keyListener);
            if (a5 == keyListener) {
                return;
            }
            super.setKeyListener(a5);
            super.setRawInputType(inputType);
            super.setFocusable(isFocusable);
            super.setClickable(isClickable);
            super.setLongClickable(isLongClickable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    @Nullable
    public InputConnection onCreateInputConnection(@NonNull EditorInfo editorInfo) {
        String[] B4;
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.mTextHelper.r(this, onCreateInputConnection, editorInfo);
        InputConnection a5 = AbstractC0996o.a(onCreateInputConnection, editorInfo, this);
        if (a5 != null && Build.VERSION.SDK_INT <= 30 && (B4 = C1015b0.B(this)) != null) {
            C7504c.d(editorInfo, B4);
            a5 = C7506e.c(this, a5, editorInfo);
        }
        return this.mAppCompatEmojiEditTextHelper.d(a5, editorInfo);
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i5 = Build.VERSION.SDK_INT;
        if (i5 < 30 || i5 >= 33) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onDragEvent(DragEvent dragEvent) {
        if (AbstractC1003w.a(this, dragEvent)) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // androidx.core.view.N
    @Nullable
    public C1018d onReceiveContent(@NonNull C1018d c1018d) {
        return this.mDefaultOnReceiveContentListener.a(this, c1018d);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public boolean onTextContextMenuItem(int i5) {
        if (AbstractC1003w.b(this, i5)) {
            return true;
        }
        return super.onTextContextMenuItem(i5);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(@Nullable ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(androidx.core.widget.j.o(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        this.mAppCompatEmojiEditTextHelper.e(z4);
    }

    @Override // android.widget.TextView
    public void setKeyListener(@Nullable KeyListener keyListener) {
        super.setKeyListener(this.mAppCompatEmojiEditTextHelper.a(keyListener));
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList colorStateList) {
        this.mTextHelper.w(colorStateList);
        this.mTextHelper.b();
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode mode) {
        this.mTextHelper.x(mode);
        this.mTextHelper.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i5) {
        super.setTextAppearance(context, i5);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.q(context, i5);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(@Nullable TextClassifier textClassifier) {
        C1006z c1006z;
        if (Build.VERSION.SDK_INT >= 28 || (c1006z = this.mTextClassifierHelper) == null) {
            getSuperCaller().b(textClassifier);
        } else {
            c1006z.b(textClassifier);
        }
    }

    public C0993l(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53682C);
    }

    @Override // android.widget.EditText, android.widget.TextView
    @Nullable
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    public C0993l(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        c0.a(this, getContext());
        C0986e c0986e = new C0986e(this);
        this.mBackgroundTintHelper = c0986e;
        c0986e.e(attributeSet, i5);
        A a5 = new A(this);
        this.mTextHelper = a5;
        a5.m(attributeSet, i5);
        a5.b();
        this.mTextClassifierHelper = new C1006z(this);
        this.mDefaultOnReceiveContentListener = new androidx.core.widget.k();
        C0994m c0994m = new C0994m(this);
        this.mAppCompatEmojiEditTextHelper = c0994m;
        c0994m.c(attributeSet, i5);
        initEmojiKeyListener(c0994m);
    }
}
