package androidx.activity;

import androidx.lifecycle.InterfaceC1116p;

/* loaded from: classes.dex */
public interface x extends InterfaceC1116p {
    OnBackPressedDispatcher getOnBackPressedDispatcher();
}
