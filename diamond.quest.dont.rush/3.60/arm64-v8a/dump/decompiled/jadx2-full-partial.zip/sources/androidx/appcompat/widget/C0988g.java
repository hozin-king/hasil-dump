package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;
import g.C5008a;

/* renamed from: androidx.appcompat.widget.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0988g extends CheckBox implements androidx.core.widget.l {

    /* renamed from: b, reason: collision with root package name */
    private final C0991j f3776b;

    /* renamed from: c, reason: collision with root package name */
    private final C0986e f3777c;

    /* renamed from: d, reason: collision with root package name */
    private final A f3778d;

    /* renamed from: e, reason: collision with root package name */
    private C0995n f3779e;

    public C0988g(@NonNull Context context) {
        this(context, null);
    }

    @NonNull
    private C0995n getEmojiTextViewHelper() {
        if (this.f3779e == null) {
            this.f3779e = new C0995n(this);
        }
        return this.f3779e;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            c0986e.b();
        }
        A a5 = this.f3778d;
        if (a5 != null) {
            a5.b();
        }
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportButtonTintList() {
        C0991j c0991j = this.f3776b;
        if (c0991j != null) {
            return c0991j.b();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportButtonTintMode() {
        C0991j c0991j = this.f3776b;
        if (c0991j != null) {
            return c0991j.c();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f3778d.j();
    }

    @Nullable
    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f3778d.k();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().d(z4);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0991j c0991j = this.f3776b;
        if (c0991j != null) {
            c0991j.e();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        A a5 = this.f3778d;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        A a5 = this.f3778d;
        if (a5 != null) {
            a5.p();
        }
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().e(z4);
    }

    @Override // android.widget.TextView
    public void setFilters(@NonNull InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.f3777c;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    public void setSupportButtonTintList(@Nullable ColorStateList colorStateList) {
        C0991j c0991j = this.f3776b;
        if (c0991j != null) {
            c0991j.f(colorStateList);
        }
    }

    public void setSupportButtonTintMode(@Nullable PorterDuff.Mode mode) {
        C0991j c0991j = this.f3776b;
        if (c0991j != null) {
            c0991j.g(mode);
        }
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList colorStateList) {
        this.f3778d.w(colorStateList);
        this.f3778d.b();
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode mode) {
        this.f3778d.x(mode);
        this.f3778d.b();
    }

    public C0988g(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53715s);
    }

    public C0988g(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        c0.a(this, getContext());
        C0991j c0991j = new C0991j(this);
        this.f3776b = c0991j;
        c0991j.d(attributeSet, i5);
        C0986e c0986e = new C0986e(this);
        this.f3777c = c0986e;
        c0986e.e(attributeSet, i5);
        A a5 = new A(this);
        this.f3778d = a5;
        a5.m(attributeSet, i5);
        getEmojiTextViewHelper().c(attributeSet, i5);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i5) {
        setButtonDrawable(C5008a.b(getContext(), i5));
    }
}
