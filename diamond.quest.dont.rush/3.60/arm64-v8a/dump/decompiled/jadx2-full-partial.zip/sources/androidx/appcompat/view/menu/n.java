package androidx.appcompat.view.menu;

/* loaded from: classes.dex */
public interface n {

    public interface a {
        boolean c();

        void d(i iVar, int i5);

        i getItemData();
    }

    void a(g gVar);
}
