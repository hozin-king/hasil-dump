package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.n;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class f extends BaseAdapter {

    /* renamed from: b, reason: collision with root package name */
    g f3103b;

    /* renamed from: c, reason: collision with root package name */
    private int f3104c = -1;

    /* renamed from: d, reason: collision with root package name */
    private boolean f3105d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f3106e;

    /* renamed from: f, reason: collision with root package name */
    private final LayoutInflater f3107f;

    /* renamed from: g, reason: collision with root package name */
    private final int f3108g;

    public f(g gVar, LayoutInflater layoutInflater, boolean z4, int i5) {
        this.f3106e = z4;
        this.f3107f = layoutInflater;
        this.f3103b = gVar;
        this.f3108g = i5;
        a();
    }

    void a() {
        i v5 = this.f3103b.v();
        if (v5 != null) {
            ArrayList z4 = this.f3103b.z();
            int size = z4.size();
            for (int i5 = 0; i5 < size; i5++) {
                if (((i) z4.get(i5)) == v5) {
                    this.f3104c = i5;
                    return;
                }
            }
        }
        this.f3104c = -1;
    }

    public g b() {
        return this.f3103b;
    }

    @Override // android.widget.Adapter
    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public i getItem(int i5) {
        ArrayList z4 = this.f3106e ? this.f3103b.z() : this.f3103b.E();
        int i6 = this.f3104c;
        if (i6 >= 0 && i5 >= i6) {
            i5++;
        }
        return (i) z4.get(i5);
    }

    public void d(boolean z4) {
        this.f3105d = z4;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.f3104c < 0 ? (this.f3106e ? this.f3103b.z() : this.f3103b.E()).size() : r0.size() - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i5) {
        return i5;
    }

    @Override // android.widget.Adapter
    public View getView(int i5, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f3107f.inflate(this.f3108g, viewGroup, false);
        }
        int groupId = getItem(i5).getGroupId();
        int i6 = i5 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f3103b.G() && groupId != (i6 >= 0 ? getItem(i6).getGroupId() : groupId));
        n.a aVar = (n.a) view;
        if (this.f3105d) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.d(getItem(i5), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
