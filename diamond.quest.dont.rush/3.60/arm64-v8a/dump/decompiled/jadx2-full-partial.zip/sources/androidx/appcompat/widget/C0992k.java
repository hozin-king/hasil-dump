package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import androidx.appcompat.widget.W;
import f.C4993a;
import f.C4995c;
import f.C4996d;
import f.C4997e;
import g.C5008a;

/* renamed from: androidx.appcompat.widget.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0992k {

    /* renamed from: b, reason: collision with root package name */
    private static final PorterDuff.Mode f3802b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    private static C0992k f3803c;

    /* renamed from: a, reason: collision with root package name */
    private W f3804a;

    /* renamed from: androidx.appcompat.widget.k$a */
    class a implements W.f {

        /* renamed from: a, reason: collision with root package name */
        private final int[] f3805a = {C4997e.f53764R, C4997e.f53762P, C4997e.f53766a};

        /* renamed from: b, reason: collision with root package name */
        private final int[] f3806b = {C4997e.f53780o, C4997e.f53748B, C4997e.f53785t, C4997e.f53781p, C4997e.f53782q, C4997e.f53784s, C4997e.f53783r};

        /* renamed from: c, reason: collision with root package name */
        private final int[] f3807c = {C4997e.f53761O, C4997e.f53763Q, C4997e.f53776k, C4997e.f53757K, C4997e.f53758L, C4997e.f53759M, C4997e.f53760N};

        /* renamed from: d, reason: collision with root package name */
        private final int[] f3808d = {C4997e.f53788w, C4997e.f53774i, C4997e.f53787v};

        /* renamed from: e, reason: collision with root package name */
        private final int[] f3809e = {C4997e.f53756J, C4997e.f53765S};

        /* renamed from: f, reason: collision with root package name */
        private final int[] f3810f = {C4997e.f53768c, C4997e.f53772g, C4997e.f53769d, C4997e.f53773h};

        a() {
        }

        private boolean f(int[] iArr, int i5) {
            for (int i6 : iArr) {
                if (i6 == i5) {
                    return true;
                }
            }
            return false;
        }

        private ColorStateList g(Context context) {
            return h(context, 0);
        }

        private ColorStateList h(Context context, int i5) {
            int c5 = c0.c(context, C4993a.f53720x);
            return new ColorStateList(new int[][]{c0.f3745b, c0.f3748e, c0.f3746c, c0.f3752i}, new int[]{c0.b(context, C4993a.f53718v), androidx.core.graphics.a.d(c5, i5), androidx.core.graphics.a.d(c5, i5), i5});
        }

        private ColorStateList i(Context context) {
            return h(context, c0.c(context, C4993a.f53717u));
        }

        private ColorStateList j(Context context) {
            return h(context, c0.c(context, C4993a.f53718v));
        }

        private ColorStateList k(Context context) {
            int[][] iArr = new int[3][];
            int[] iArr2 = new int[3];
            ColorStateList e5 = c0.e(context, C4993a.f53722z);
            if (e5 == null || !e5.isStateful()) {
                iArr[0] = c0.f3745b;
                iArr2[0] = c0.b(context, C4993a.f53722z);
                iArr[1] = c0.f3749f;
                iArr2[1] = c0.c(context, C4993a.f53719w);
                iArr[2] = c0.f3752i;
                iArr2[2] = c0.c(context, C4993a.f53722z);
            } else {
                int[] iArr3 = c0.f3745b;
                iArr[0] = iArr3;
                iArr2[0] = e5.getColorForState(iArr3, 0);
                iArr[1] = c0.f3749f;
                iArr2[1] = c0.c(context, C4993a.f53719w);
                iArr[2] = c0.f3752i;
                iArr2[2] = e5.getDefaultColor();
            }
            return new ColorStateList(iArr, iArr2);
        }

        private LayerDrawable l(W w5, Context context, int i5) {
            BitmapDrawable bitmapDrawable;
            BitmapDrawable bitmapDrawable2;
            BitmapDrawable bitmapDrawable3;
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(i5);
            Drawable j5 = w5.j(context, C4997e.f53752F);
            Drawable j6 = w5.j(context, C4997e.f53753G);
            if ((j5 instanceof BitmapDrawable) && j5.getIntrinsicWidth() == dimensionPixelSize && j5.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable = (BitmapDrawable) j5;
                bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
            } else {
                Bitmap createBitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                j5.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                j5.draw(canvas);
                bitmapDrawable = new BitmapDrawable(createBitmap);
                bitmapDrawable2 = new BitmapDrawable(createBitmap);
            }
            bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
            if ((j6 instanceof BitmapDrawable) && j6.getIntrinsicWidth() == dimensionPixelSize && j6.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable3 = (BitmapDrawable) j6;
            } else {
                Bitmap createBitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas2 = new Canvas(createBitmap2);
                j6.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                j6.draw(canvas2);
                bitmapDrawable3 = new BitmapDrawable(createBitmap2);
            }
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable, bitmapDrawable3, bitmapDrawable2});
            layerDrawable.setId(0, R.id.background);
            layerDrawable.setId(1, R.id.secondaryProgress);
            layerDrawable.setId(2, R.id.progress);
            return layerDrawable;
        }

        private void m(Drawable drawable, int i5, PorterDuff.Mode mode) {
            Drawable mutate = drawable.mutate();
            if (mode == null) {
                mode = C0992k.f3802b;
            }
            mutate.setColorFilter(C0992k.e(i5, mode));
        }

        @Override // androidx.appcompat.widget.W.f
        public Drawable a(W w5, Context context, int i5) {
            if (i5 == C4997e.f53775j) {
                return new LayerDrawable(new Drawable[]{w5.j(context, C4997e.f53774i), w5.j(context, C4997e.f53776k)});
            }
            if (i5 == C4997e.f53790y) {
                return l(w5, context, C4996d.f53740i);
            }
            if (i5 == C4997e.f53789x) {
                return l(w5, context, C4996d.f53741j);
            }
            if (i5 == C4997e.f53791z) {
                return l(w5, context, C4996d.f53742k);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.W.f
        public ColorStateList b(Context context, int i5) {
            if (i5 == C4997e.f53778m) {
                return C5008a.a(context, C4995c.f53728e);
            }
            if (i5 == C4997e.f53755I) {
                return C5008a.a(context, C4995c.f53731h);
            }
            if (i5 == C4997e.f53754H) {
                return k(context);
            }
            if (i5 == C4997e.f53771f) {
                return j(context);
            }
            if (i5 == C4997e.f53767b) {
                return g(context);
            }
            if (i5 == C4997e.f53770e) {
                return i(context);
            }
            if (i5 == C4997e.f53750D || i5 == C4997e.f53751E) {
                return C5008a.a(context, C4995c.f53730g);
            }
            if (f(this.f3806b, i5)) {
                return c0.e(context, C4993a.f53721y);
            }
            if (f(this.f3809e, i5)) {
                return C5008a.a(context, C4995c.f53727d);
            }
            if (f(this.f3810f, i5)) {
                return C5008a.a(context, C4995c.f53726c);
            }
            if (i5 == C4997e.f53747A) {
                return C5008a.a(context, C4995c.f53729f);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.W.f
        public PorterDuff.Mode c(int i5) {
            if (i5 == C4997e.f53754H) {
                return PorterDuff.Mode.MULTIPLY;
            }
            return null;
        }

        @Override // androidx.appcompat.widget.W.f
        public boolean d(Context context, int i5, Drawable drawable) {
            if (i5 == C4997e.f53749C) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                m(layerDrawable.findDrawableByLayerId(R.id.background), c0.c(context, C4993a.f53721y), C0992k.f3802b);
                m(layerDrawable.findDrawableByLayerId(R.id.secondaryProgress), c0.c(context, C4993a.f53721y), C0992k.f3802b);
                m(layerDrawable.findDrawableByLayerId(R.id.progress), c0.c(context, C4993a.f53719w), C0992k.f3802b);
                return true;
            }
            if (i5 != C4997e.f53790y && i5 != C4997e.f53789x && i5 != C4997e.f53791z) {
                return false;
            }
            LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
            m(layerDrawable2.findDrawableByLayerId(R.id.background), c0.b(context, C4993a.f53721y), C0992k.f3802b);
            m(layerDrawable2.findDrawableByLayerId(R.id.secondaryProgress), c0.c(context, C4993a.f53719w), C0992k.f3802b);
            m(layerDrawable2.findDrawableByLayerId(R.id.progress), c0.c(context, C4993a.f53719w), C0992k.f3802b);
            return true;
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0065 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:7:0x0050  */
        @Override // androidx.appcompat.widget.W.f
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean e(android.content.Context r7, int r8, android.graphics.drawable.Drawable r9) {
            /*
                r6 = this;
                android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.C0992k.a()
                int[] r1 = r6.f3805a
                boolean r1 = r6.f(r1, r8)
                r2 = 1
                r3 = 0
                r4 = -1
                if (r1 == 0) goto L15
                int r8 = f.C4993a.f53721y
            L11:
                r1 = r0
                r5 = r2
            L13:
                r0 = r4
                goto L4e
            L15:
                int[] r1 = r6.f3807c
                boolean r1 = r6.f(r1, r8)
                if (r1 == 0) goto L20
                int r8 = f.C4993a.f53719w
                goto L11
            L20:
                int[] r1 = r6.f3808d
                boolean r1 = r6.f(r1, r8)
                r5 = 16842801(0x1010031, float:2.3693695E-38)
                if (r1 == 0) goto L32
                android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
            L2d:
                r1 = r0
                r0 = r4
                r8 = r5
            L30:
                r5 = r2
                goto L4e
            L32:
                int r1 = f.C4997e.f53786u
                if (r8 != r1) goto L45
                r8 = 1109603123(0x42233333, float:40.8)
                int r8 = java.lang.Math.round(r8)
                r1 = 16842800(0x1010030, float:2.3693693E-38)
                r5 = r0
                r0 = r8
                r8 = r1
                r1 = r5
                goto L30
            L45:
                int r1 = f.C4997e.f53777l
                if (r8 != r1) goto L4a
                goto L2d
            L4a:
                r1 = r0
                r8 = r3
                r5 = r8
                goto L13
            L4e:
                if (r5 == 0) goto L65
                android.graphics.drawable.Drawable r9 = r9.mutate()
                int r7 = androidx.appcompat.widget.c0.c(r7, r8)
                android.graphics.PorterDuffColorFilter r7 = androidx.appcompat.widget.C0992k.e(r7, r1)
                r9.setColorFilter(r7)
                if (r0 == r4) goto L64
                r9.setAlpha(r0)
            L64:
                return r2
            L65:
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0992k.a.e(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
        }
    }

    public static synchronized C0992k b() {
        C0992k c0992k;
        synchronized (C0992k.class) {
            try {
                if (f3803c == null) {
                    h();
                }
                c0992k = f3803c;
            } catch (Throwable th) {
                throw th;
            }
        }
        return c0992k;
    }

    public static synchronized PorterDuffColorFilter e(int i5, PorterDuff.Mode mode) {
        PorterDuffColorFilter l5;
        synchronized (C0992k.class) {
            l5 = W.l(i5, mode);
        }
        return l5;
    }

    public static synchronized void h() {
        synchronized (C0992k.class) {
            if (f3803c == null) {
                C0992k c0992k = new C0992k();
                f3803c = c0992k;
                c0992k.f3804a = W.h();
                f3803c.f3804a.u(new a());
            }
        }
    }

    static void i(Drawable drawable, e0 e0Var, int[] iArr) {
        W.w(drawable, e0Var, iArr);
    }

    public synchronized Drawable c(Context context, int i5) {
        return this.f3804a.j(context, i5);
    }

    synchronized Drawable d(Context context, int i5, boolean z4) {
        return this.f3804a.k(context, i5, z4);
    }

    synchronized ColorStateList f(Context context, int i5) {
        return this.f3804a.m(context, i5);
    }

    public synchronized void g(Context context) {
        this.f3804a.s(context);
    }
}
