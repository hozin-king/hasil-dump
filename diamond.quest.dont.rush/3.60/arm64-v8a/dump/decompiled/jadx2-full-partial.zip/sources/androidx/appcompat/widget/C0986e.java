package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.C1015b0;

/* renamed from: androidx.appcompat.widget.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0986e {

    /* renamed from: a, reason: collision with root package name */
    private final View f3762a;

    /* renamed from: d, reason: collision with root package name */
    private e0 f3765d;

    /* renamed from: e, reason: collision with root package name */
    private e0 f3766e;

    /* renamed from: f, reason: collision with root package name */
    private e0 f3767f;

    /* renamed from: c, reason: collision with root package name */
    private int f3764c = -1;

    /* renamed from: b, reason: collision with root package name */
    private final C0992k f3763b = C0992k.b();

    C0986e(View view) {
        this.f3762a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f3767f == null) {
            this.f3767f = new e0();
        }
        e0 e0Var = this.f3767f;
        e0Var.a();
        ColorStateList r5 = C1015b0.r(this.f3762a);
        if (r5 != null) {
            e0Var.f3771d = true;
            e0Var.f3768a = r5;
        }
        PorterDuff.Mode s5 = C1015b0.s(this.f3762a);
        if (s5 != null) {
            e0Var.f3770c = true;
            e0Var.f3769b = s5;
        }
        if (!e0Var.f3771d && !e0Var.f3770c) {
            return false;
        }
        C0992k.i(drawable, e0Var, this.f3762a.getDrawableState());
        return true;
    }

    private boolean k() {
        return this.f3765d != null;
    }

    void b() {
        Drawable background = this.f3762a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            e0 e0Var = this.f3766e;
            if (e0Var != null) {
                C0992k.i(background, e0Var, this.f3762a.getDrawableState());
                return;
            }
            e0 e0Var2 = this.f3765d;
            if (e0Var2 != null) {
                C0992k.i(background, e0Var2, this.f3762a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        e0 e0Var = this.f3766e;
        if (e0Var != null) {
            return e0Var.f3768a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        e0 e0Var = this.f3766e;
        if (e0Var != null) {
            return e0Var.f3769b;
        }
        return null;
    }

    void e(AttributeSet attributeSet, int i5) {
        g0 u5 = g0.u(this.f3762a.getContext(), attributeSet, f.j.f53926K3, i5, 0);
        View view = this.f3762a;
        C1015b0.b0(view, view.getContext(), f.j.f53926K3, attributeSet, u5.q(), i5, 0);
        try {
            if (u5.r(f.j.f53931L3)) {
                this.f3764c = u5.m(f.j.f53931L3, -1);
                ColorStateList f5 = this.f3763b.f(this.f3762a.getContext(), this.f3764c);
                if (f5 != null) {
                    h(f5);
                }
            }
            if (u5.r(f.j.f53936M3)) {
                C1015b0.h0(this.f3762a, u5.c(f.j.f53936M3));
            }
            if (u5.r(f.j.f53941N3)) {
                C1015b0.i0(this.f3762a, M.d(u5.j(f.j.f53941N3, -1), null));
            }
            u5.w();
        } catch (Throwable th) {
            u5.w();
            throw th;
        }
    }

    void f(Drawable drawable) {
        this.f3764c = -1;
        h(null);
        b();
    }

    void g(int i5) {
        this.f3764c = i5;
        C0992k c0992k = this.f3763b;
        h(c0992k != null ? c0992k.f(this.f3762a.getContext(), i5) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f3765d == null) {
                this.f3765d = new e0();
            }
            e0 e0Var = this.f3765d;
            e0Var.f3768a = colorStateList;
            e0Var.f3771d = true;
        } else {
            this.f3765d = null;
        }
        b();
    }

    void i(ColorStateList colorStateList) {
        if (this.f3766e == null) {
            this.f3766e = new e0();
        }
        e0 e0Var = this.f3766e;
        e0Var.f3768a = colorStateList;
        e0Var.f3771d = true;
        b();
    }

    void j(PorterDuff.Mode mode) {
        if (this.f3766e == null) {
            this.f3766e = new e0();
        }
        e0 e0Var = this.f3766e;
        e0Var.f3769b = mode;
        e0Var.f3770c = true;
        b();
    }
}
