package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.Q;
import androidx.core.view.C1015b0;
import androidx.core.widget.NestedScrollView;
import f.C4993a;
import f.C4998f;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
class AlertController {

    /* renamed from: A, reason: collision with root package name */
    NestedScrollView f2543A;

    /* renamed from: C, reason: collision with root package name */
    private Drawable f2545C;

    /* renamed from: D, reason: collision with root package name */
    private ImageView f2546D;

    /* renamed from: E, reason: collision with root package name */
    private TextView f2547E;

    /* renamed from: F, reason: collision with root package name */
    private TextView f2548F;

    /* renamed from: G, reason: collision with root package name */
    private View f2549G;

    /* renamed from: H, reason: collision with root package name */
    ListAdapter f2550H;

    /* renamed from: J, reason: collision with root package name */
    private int f2552J;

    /* renamed from: K, reason: collision with root package name */
    private int f2553K;

    /* renamed from: L, reason: collision with root package name */
    int f2554L;

    /* renamed from: M, reason: collision with root package name */
    int f2555M;

    /* renamed from: N, reason: collision with root package name */
    int f2556N;

    /* renamed from: O, reason: collision with root package name */
    int f2557O;

    /* renamed from: P, reason: collision with root package name */
    private boolean f2558P;

    /* renamed from: R, reason: collision with root package name */
    Handler f2560R;

    /* renamed from: a, reason: collision with root package name */
    private final Context f2562a;

    /* renamed from: b, reason: collision with root package name */
    final x f2563b;

    /* renamed from: c, reason: collision with root package name */
    private final Window f2564c;

    /* renamed from: d, reason: collision with root package name */
    private final int f2565d;

    /* renamed from: e, reason: collision with root package name */
    private CharSequence f2566e;

    /* renamed from: f, reason: collision with root package name */
    private CharSequence f2567f;

    /* renamed from: g, reason: collision with root package name */
    ListView f2568g;

    /* renamed from: h, reason: collision with root package name */
    private View f2569h;

    /* renamed from: i, reason: collision with root package name */
    private int f2570i;

    /* renamed from: j, reason: collision with root package name */
    private int f2571j;

    /* renamed from: k, reason: collision with root package name */
    private int f2572k;

    /* renamed from: l, reason: collision with root package name */
    private int f2573l;

    /* renamed from: m, reason: collision with root package name */
    private int f2574m;

    /* renamed from: o, reason: collision with root package name */
    Button f2576o;

    /* renamed from: p, reason: collision with root package name */
    private CharSequence f2577p;

    /* renamed from: q, reason: collision with root package name */
    Message f2578q;

    /* renamed from: r, reason: collision with root package name */
    private Drawable f2579r;

    /* renamed from: s, reason: collision with root package name */
    Button f2580s;

    /* renamed from: t, reason: collision with root package name */
    private CharSequence f2581t;

    /* renamed from: u, reason: collision with root package name */
    Message f2582u;

    /* renamed from: v, reason: collision with root package name */
    private Drawable f2583v;

    /* renamed from: w, reason: collision with root package name */
    Button f2584w;

    /* renamed from: x, reason: collision with root package name */
    private CharSequence f2585x;

    /* renamed from: y, reason: collision with root package name */
    Message f2586y;

    /* renamed from: z, reason: collision with root package name */
    private Drawable f2587z;

    /* renamed from: n, reason: collision with root package name */
    private boolean f2575n = false;

    /* renamed from: B, reason: collision with root package name */
    private int f2544B = 0;

    /* renamed from: I, reason: collision with root package name */
    int f2551I = -1;

    /* renamed from: Q, reason: collision with root package name */
    private int f2559Q = 0;

    /* renamed from: S, reason: collision with root package name */
    private final View.OnClickListener f2561S = new a();

    public static class RecycleListView extends ListView {

        /* renamed from: b, reason: collision with root package name */
        private final int f2588b;

        /* renamed from: c, reason: collision with root package name */
        private final int f2589c;

        public RecycleListView(Context context) {
            this(context, null);
        }

        public void a(boolean z4, boolean z5) {
            if (z5 && z4) {
                return;
            }
            setPadding(getPaddingLeft(), z4 ? getPaddingTop() : this.f2588b, getPaddingRight(), z5 ? getPaddingBottom() : this.f2589c);
        }

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f.j.f54007c2);
            this.f2589c = obtainStyledAttributes.getDimensionPixelOffset(f.j.f54012d2, -1);
            this.f2588b = obtainStyledAttributes.getDimensionPixelOffset(f.j.f54017e2, -1);
        }
    }

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Message message;
            Message message2;
            Message message3;
            AlertController alertController = AlertController.this;
            Message obtain = (view != alertController.f2576o || (message3 = alertController.f2578q) == null) ? (view != alertController.f2580s || (message2 = alertController.f2582u) == null) ? (view != alertController.f2584w || (message = alertController.f2586y) == null) ? null : Message.obtain(message) : Message.obtain(message2) : Message.obtain(message3);
            if (obtain != null) {
                obtain.sendToTarget();
            }
            AlertController alertController2 = AlertController.this;
            alertController2.f2560R.obtainMessage(1, alertController2.f2563b).sendToTarget();
        }
    }

    public static class b {

        /* renamed from: A, reason: collision with root package name */
        public int f2591A;

        /* renamed from: B, reason: collision with root package name */
        public int f2592B;

        /* renamed from: C, reason: collision with root package name */
        public int f2593C;

        /* renamed from: D, reason: collision with root package name */
        public int f2594D;

        /* renamed from: F, reason: collision with root package name */
        public boolean[] f2596F;

        /* renamed from: G, reason: collision with root package name */
        public boolean f2597G;

        /* renamed from: H, reason: collision with root package name */
        public boolean f2598H;

        /* renamed from: J, reason: collision with root package name */
        public DialogInterface.OnMultiChoiceClickListener f2600J;

        /* renamed from: K, reason: collision with root package name */
        public Cursor f2601K;

        /* renamed from: L, reason: collision with root package name */
        public String f2602L;

        /* renamed from: M, reason: collision with root package name */
        public String f2603M;

        /* renamed from: N, reason: collision with root package name */
        public AdapterView.OnItemSelectedListener f2604N;

        /* renamed from: a, reason: collision with root package name */
        public final Context f2606a;

        /* renamed from: b, reason: collision with root package name */
        public final LayoutInflater f2607b;

        /* renamed from: d, reason: collision with root package name */
        public Drawable f2609d;

        /* renamed from: f, reason: collision with root package name */
        public CharSequence f2611f;

        /* renamed from: g, reason: collision with root package name */
        public View f2612g;

        /* renamed from: h, reason: collision with root package name */
        public CharSequence f2613h;

        /* renamed from: i, reason: collision with root package name */
        public CharSequence f2614i;

        /* renamed from: j, reason: collision with root package name */
        public Drawable f2615j;

        /* renamed from: k, reason: collision with root package name */
        public DialogInterface.OnClickListener f2616k;

        /* renamed from: l, reason: collision with root package name */
        public CharSequence f2617l;

        /* renamed from: m, reason: collision with root package name */
        public Drawable f2618m;

        /* renamed from: n, reason: collision with root package name */
        public DialogInterface.OnClickListener f2619n;

        /* renamed from: o, reason: collision with root package name */
        public CharSequence f2620o;

        /* renamed from: p, reason: collision with root package name */
        public Drawable f2621p;

        /* renamed from: q, reason: collision with root package name */
        public DialogInterface.OnClickListener f2622q;

        /* renamed from: s, reason: collision with root package name */
        public DialogInterface.OnCancelListener f2624s;

        /* renamed from: t, reason: collision with root package name */
        public DialogInterface.OnDismissListener f2625t;

        /* renamed from: u, reason: collision with root package name */
        public DialogInterface.OnKeyListener f2626u;

        /* renamed from: v, reason: collision with root package name */
        public CharSequence[] f2627v;

        /* renamed from: w, reason: collision with root package name */
        public ListAdapter f2628w;

        /* renamed from: x, reason: collision with root package name */
        public DialogInterface.OnClickListener f2629x;

        /* renamed from: y, reason: collision with root package name */
        public int f2630y;

        /* renamed from: z, reason: collision with root package name */
        public View f2631z;

        /* renamed from: c, reason: collision with root package name */
        public int f2608c = 0;

        /* renamed from: e, reason: collision with root package name */
        public int f2610e = 0;

        /* renamed from: E, reason: collision with root package name */
        public boolean f2595E = false;

        /* renamed from: I, reason: collision with root package name */
        public int f2599I = -1;

        /* renamed from: O, reason: collision with root package name */
        public boolean f2605O = true;

        /* renamed from: r, reason: collision with root package name */
        public boolean f2623r = true;

        class a extends ArrayAdapter {

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ RecycleListView f2632b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(Context context, int i5, int i6, CharSequence[] charSequenceArr, RecycleListView recycleListView) {
                super(context, i5, i6, charSequenceArr);
                this.f2632b = recycleListView;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i5, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i5, view, viewGroup);
                boolean[] zArr = b.this.f2596F;
                if (zArr != null && zArr[i5]) {
                    this.f2632b.setItemChecked(i5, true);
                }
                return view2;
            }
        }

        /* renamed from: androidx.appcompat.app.AlertController$b$b, reason: collision with other inner class name */
        class C0105b extends CursorAdapter {

            /* renamed from: b, reason: collision with root package name */
            private final int f2634b;

            /* renamed from: c, reason: collision with root package name */
            private final int f2635c;

            /* renamed from: d, reason: collision with root package name */
            final /* synthetic */ RecycleListView f2636d;

            /* renamed from: e, reason: collision with root package name */
            final /* synthetic */ AlertController f2637e;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C0105b(Context context, Cursor cursor, boolean z4, RecycleListView recycleListView, AlertController alertController) {
                super(context, cursor, z4);
                this.f2636d = recycleListView;
                this.f2637e = alertController;
                Cursor cursor2 = getCursor();
                this.f2634b = cursor2.getColumnIndexOrThrow(b.this.f2602L);
                this.f2635c = cursor2.getColumnIndexOrThrow(b.this.f2603M);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                ((CheckedTextView) view.findViewById(R.id.text1)).setText(cursor.getString(this.f2634b));
                this.f2636d.setItemChecked(cursor.getPosition(), cursor.getInt(this.f2635c) == 1);
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return b.this.f2607b.inflate(this.f2637e.f2555M, viewGroup, false);
            }
        }

        class c implements AdapterView.OnItemClickListener {

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ AlertController f2639b;

            c(AlertController alertController) {
                this.f2639b = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i5, long j5) {
                b.this.f2629x.onClick(this.f2639b.f2563b, i5);
                if (b.this.f2598H) {
                    return;
                }
                this.f2639b.f2563b.dismiss();
            }
        }

        class d implements AdapterView.OnItemClickListener {

            /* renamed from: b, reason: collision with root package name */
            final /* synthetic */ RecycleListView f2641b;

            /* renamed from: c, reason: collision with root package name */
            final /* synthetic */ AlertController f2642c;

            d(RecycleListView recycleListView, AlertController alertController) {
                this.f2641b = recycleListView;
                this.f2642c = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView adapterView, View view, int i5, long j5) {
                boolean[] zArr = b.this.f2596F;
                if (zArr != null) {
                    zArr[i5] = this.f2641b.isItemChecked(i5);
                }
                b.this.f2600J.onClick(this.f2642c.f2563b, i5, this.f2641b.isItemChecked(i5));
            }
        }

        public b(Context context) {
            this.f2606a = context;
            this.f2607b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        private void b(AlertController alertController) {
            b bVar;
            AlertController alertController2;
            ListAdapter listAdapter;
            RecycleListView recycleListView = (RecycleListView) this.f2607b.inflate(alertController.f2554L, (ViewGroup) null);
            if (!this.f2597G) {
                bVar = this;
                alertController2 = alertController;
                int i5 = bVar.f2598H ? alertController2.f2556N : alertController2.f2557O;
                if (bVar.f2601K != null) {
                    listAdapter = new SimpleCursorAdapter(bVar.f2606a, i5, bVar.f2601K, new String[]{bVar.f2602L}, new int[]{R.id.text1});
                } else {
                    listAdapter = bVar.f2628w;
                    if (listAdapter == null) {
                        listAdapter = new d(bVar.f2606a, i5, R.id.text1, bVar.f2627v);
                    }
                }
            } else if (this.f2601K == null) {
                bVar = this;
                listAdapter = bVar.new a(this.f2606a, alertController.f2555M, R.id.text1, this.f2627v, recycleListView);
                recycleListView = recycleListView;
                alertController2 = alertController;
            } else {
                bVar = this;
                alertController2 = alertController;
                listAdapter = bVar.new C0105b(bVar.f2606a, bVar.f2601K, false, recycleListView, alertController2);
            }
            alertController2.f2550H = listAdapter;
            alertController2.f2551I = bVar.f2599I;
            if (bVar.f2629x != null) {
                recycleListView.setOnItemClickListener(new c(alertController2));
            } else if (bVar.f2600J != null) {
                recycleListView.setOnItemClickListener(new d(recycleListView, alertController2));
            }
            AdapterView.OnItemSelectedListener onItemSelectedListener = bVar.f2604N;
            if (onItemSelectedListener != null) {
                recycleListView.setOnItemSelectedListener(onItemSelectedListener);
            }
            if (bVar.f2598H) {
                recycleListView.setChoiceMode(1);
            } else if (bVar.f2597G) {
                recycleListView.setChoiceMode(2);
            }
            alertController2.f2568g = recycleListView;
        }

        public void a(AlertController alertController) {
            AlertController alertController2;
            View view = this.f2612g;
            if (view != null) {
                alertController.k(view);
            } else {
                CharSequence charSequence = this.f2611f;
                if (charSequence != null) {
                    alertController.p(charSequence);
                }
                Drawable drawable = this.f2609d;
                if (drawable != null) {
                    alertController.m(drawable);
                }
                int i5 = this.f2608c;
                if (i5 != 0) {
                    alertController.l(i5);
                }
                int i6 = this.f2610e;
                if (i6 != 0) {
                    alertController.l(alertController.c(i6));
                }
            }
            CharSequence charSequence2 = this.f2613h;
            if (charSequence2 != null) {
                alertController.n(charSequence2);
            }
            CharSequence charSequence3 = this.f2614i;
            if (charSequence3 == null && this.f2615j == null) {
                alertController2 = alertController;
            } else {
                alertController.j(-1, charSequence3, this.f2616k, null, this.f2615j);
                alertController2 = alertController;
            }
            CharSequence charSequence4 = this.f2617l;
            if (charSequence4 != null || this.f2618m != null) {
                alertController2.j(-2, charSequence4, this.f2619n, null, this.f2618m);
            }
            CharSequence charSequence5 = this.f2620o;
            if (charSequence5 != null || this.f2621p != null) {
                alertController2.j(-3, charSequence5, this.f2622q, null, this.f2621p);
            }
            if (this.f2627v != null || this.f2601K != null || this.f2628w != null) {
                b(alertController2);
            }
            View view2 = this.f2631z;
            if (view2 != null) {
                if (this.f2595E) {
                    alertController2.s(view2, this.f2591A, this.f2592B, this.f2593C, this.f2594D);
                    return;
                } else {
                    alertController2.r(view2);
                    return;
                }
            }
            int i7 = this.f2630y;
            if (i7 != 0) {
                alertController2.q(i7);
            }
        }
    }

    private static final class c extends Handler {

        /* renamed from: a, reason: collision with root package name */
        private WeakReference f2644a;

        public c(DialogInterface dialogInterface) {
            this.f2644a = new WeakReference(dialogInterface);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i5 = message.what;
            if (i5 == -3 || i5 == -2 || i5 == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f2644a.get(), message.what);
            } else {
                if (i5 != 1) {
                    return;
                }
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    private static class d extends ArrayAdapter {
        public d(Context context, int i5, int i6, CharSequence[] charSequenceArr) {
            super(context, i5, i6, charSequenceArr);
        }

        @Override // android.widget.ArrayAdapter, android.widget.Adapter
        public long getItemId(int i5) {
            return i5;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, x xVar, Window window) {
        this.f2562a = context;
        this.f2563b = xVar;
        this.f2564c = window;
        this.f2560R = new c(xVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, f.j.f53897F, C4993a.f53711o, 0);
        this.f2552J = obtainStyledAttributes.getResourceId(f.j.f53902G, 0);
        this.f2553K = obtainStyledAttributes.getResourceId(f.j.f53912I, 0);
        this.f2554L = obtainStyledAttributes.getResourceId(f.j.f53922K, 0);
        this.f2555M = obtainStyledAttributes.getResourceId(f.j.f53927L, 0);
        this.f2556N = obtainStyledAttributes.getResourceId(f.j.f53937N, 0);
        this.f2557O = obtainStyledAttributes.getResourceId(f.j.f53917J, 0);
        this.f2558P = obtainStyledAttributes.getBoolean(f.j.f53932M, true);
        this.f2565d = obtainStyledAttributes.getDimensionPixelSize(f.j.f53907H, 0);
        obtainStyledAttributes.recycle();
        xVar.h(1);
    }

    static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    private void b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    private ViewGroup h(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    private int i() {
        int i5 = this.f2553K;
        return i5 == 0 ? this.f2552J : this.f2559Q == 1 ? i5 : this.f2552J;
    }

    private void o(ViewGroup viewGroup, View view, int i5, int i6) {
        View findViewById = this.f2564c.findViewById(C4998f.f53829v);
        View findViewById2 = this.f2564c.findViewById(C4998f.f53828u);
        C1015b0.u0(view, i5, i6);
        if (findViewById != null) {
            viewGroup.removeView(findViewById);
        }
        if (findViewById2 != null) {
            viewGroup.removeView(findViewById2);
        }
    }

    private void t(ViewGroup viewGroup) {
        int i5;
        Button button = (Button) viewGroup.findViewById(R.id.button1);
        this.f2576o = button;
        button.setOnClickListener(this.f2561S);
        if (TextUtils.isEmpty(this.f2577p) && this.f2579r == null) {
            this.f2576o.setVisibility(8);
            i5 = 0;
        } else {
            this.f2576o.setText(this.f2577p);
            Drawable drawable = this.f2579r;
            if (drawable != null) {
                int i6 = this.f2565d;
                drawable.setBounds(0, 0, i6, i6);
                this.f2576o.setCompoundDrawables(this.f2579r, null, null, null);
            }
            this.f2576o.setVisibility(0);
            i5 = 1;
        }
        Button button2 = (Button) viewGroup.findViewById(R.id.button2);
        this.f2580s = button2;
        button2.setOnClickListener(this.f2561S);
        if (TextUtils.isEmpty(this.f2581t) && this.f2583v == null) {
            this.f2580s.setVisibility(8);
        } else {
            this.f2580s.setText(this.f2581t);
            Drawable drawable2 = this.f2583v;
            if (drawable2 != null) {
                int i7 = this.f2565d;
                drawable2.setBounds(0, 0, i7, i7);
                this.f2580s.setCompoundDrawables(this.f2583v, null, null, null);
            }
            this.f2580s.setVisibility(0);
            i5 |= 2;
        }
        Button button3 = (Button) viewGroup.findViewById(R.id.button3);
        this.f2584w = button3;
        button3.setOnClickListener(this.f2561S);
        if (TextUtils.isEmpty(this.f2585x) && this.f2587z == null) {
            this.f2584w.setVisibility(8);
        } else {
            this.f2584w.setText(this.f2585x);
            Drawable drawable3 = this.f2587z;
            if (drawable3 != null) {
                int i8 = this.f2565d;
                drawable3.setBounds(0, 0, i8, i8);
                this.f2584w.setCompoundDrawables(this.f2587z, null, null, null);
            }
            this.f2584w.setVisibility(0);
            i5 |= 4;
        }
        if (y(this.f2562a)) {
            if (i5 == 1) {
                b(this.f2576o);
            } else if (i5 == 2) {
                b(this.f2580s);
            } else if (i5 == 4) {
                b(this.f2584w);
            }
        }
        if (i5 != 0) {
            return;
        }
        viewGroup.setVisibility(8);
    }

    private void u(ViewGroup viewGroup) {
        NestedScrollView nestedScrollView = (NestedScrollView) this.f2564c.findViewById(C4998f.f53830w);
        this.f2543A = nestedScrollView;
        nestedScrollView.setFocusable(false);
        this.f2543A.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroup.findViewById(R.id.message);
        this.f2548F = textView;
        if (textView == null) {
            return;
        }
        CharSequence charSequence = this.f2567f;
        if (charSequence != null) {
            textView.setText(charSequence);
            return;
        }
        textView.setVisibility(8);
        this.f2543A.removeView(this.f2548F);
        if (this.f2568g == null) {
            viewGroup.setVisibility(8);
            return;
        }
        ViewGroup viewGroup2 = (ViewGroup) this.f2543A.getParent();
        int indexOfChild = viewGroup2.indexOfChild(this.f2543A);
        viewGroup2.removeViewAt(indexOfChild);
        viewGroup2.addView(this.f2568g, indexOfChild, new ViewGroup.LayoutParams(-1, -1));
    }

    private void v(ViewGroup viewGroup) {
        View view = this.f2569h;
        if (view == null) {
            view = this.f2570i != 0 ? LayoutInflater.from(this.f2562a).inflate(this.f2570i, viewGroup, false) : null;
        }
        boolean z4 = view != null;
        if (!z4 || !a(view)) {
            this.f2564c.setFlags(131072, 131072);
        }
        if (!z4) {
            viewGroup.setVisibility(8);
            return;
        }
        FrameLayout frameLayout = (FrameLayout) this.f2564c.findViewById(C4998f.f53821n);
        frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
        if (this.f2575n) {
            frameLayout.setPadding(this.f2571j, this.f2572k, this.f2573l, this.f2574m);
        }
        if (this.f2568g != null) {
            ((LinearLayout.LayoutParams) ((Q.a) viewGroup.getLayoutParams())).weight = 0.0f;
        }
    }

    private void w(ViewGroup viewGroup) {
        if (this.f2549G != null) {
            viewGroup.addView(this.f2549G, 0, new ViewGroup.LayoutParams(-1, -2));
            this.f2564c.findViewById(C4998f.f53806O).setVisibility(8);
            return;
        }
        this.f2546D = (ImageView) this.f2564c.findViewById(R.id.icon);
        if (TextUtils.isEmpty(this.f2566e) || !this.f2558P) {
            this.f2564c.findViewById(C4998f.f53806O).setVisibility(8);
            this.f2546D.setVisibility(8);
            viewGroup.setVisibility(8);
            return;
        }
        TextView textView = (TextView) this.f2564c.findViewById(C4998f.f53817j);
        this.f2547E = textView;
        textView.setText(this.f2566e);
        int i5 = this.f2544B;
        if (i5 != 0) {
            this.f2546D.setImageResource(i5);
            return;
        }
        Drawable drawable = this.f2545C;
        if (drawable != null) {
            this.f2546D.setImageDrawable(drawable);
        } else {
            this.f2547E.setPadding(this.f2546D.getPaddingLeft(), this.f2546D.getPaddingTop(), this.f2546D.getPaddingRight(), this.f2546D.getPaddingBottom());
            this.f2546D.setVisibility(8);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void x() {
        View findViewById;
        ListAdapter listAdapter;
        View findViewById2;
        View findViewById3 = this.f2564c.findViewById(C4998f.f53827t);
        View findViewById4 = findViewById3.findViewById(C4998f.f53807P);
        View findViewById5 = findViewById3.findViewById(C4998f.f53820m);
        View findViewById6 = findViewById3.findViewById(C4998f.f53818k);
        ViewGroup viewGroup = (ViewGroup) findViewById3.findViewById(C4998f.f53822o);
        v(viewGroup);
        View findViewById7 = viewGroup.findViewById(C4998f.f53807P);
        View findViewById8 = viewGroup.findViewById(C4998f.f53820m);
        View findViewById9 = viewGroup.findViewById(C4998f.f53818k);
        ViewGroup h5 = h(findViewById7, findViewById4);
        ViewGroup h6 = h(findViewById8, findViewById5);
        ViewGroup h7 = h(findViewById9, findViewById6);
        u(h6);
        t(h7);
        w(h5);
        boolean z4 = viewGroup.getVisibility() != 8;
        boolean z5 = (h5 == null || h5.getVisibility() == 8) ? 0 : 1;
        boolean z6 = (h7 == null || h7.getVisibility() == 8) ? false : true;
        if (!z6 && h6 != null && (findViewById2 = h6.findViewById(C4998f.f53802K)) != null) {
            findViewById2.setVisibility(0);
        }
        if (z5 != 0) {
            NestedScrollView nestedScrollView = this.f2543A;
            if (nestedScrollView != null) {
                nestedScrollView.setClipToPadding(true);
            }
            View findViewById10 = (this.f2567f == null && this.f2568g == null) ? null : h5.findViewById(C4998f.f53805N);
            if (findViewById10 != null) {
                findViewById10.setVisibility(0);
            }
        } else if (h6 != null && (findViewById = h6.findViewById(C4998f.f53803L)) != null) {
            findViewById.setVisibility(0);
        }
        ListView listView = this.f2568g;
        if (listView instanceof RecycleListView) {
            ((RecycleListView) listView).a(z5, z6);
        }
        if (!z4) {
            View view = this.f2568g;
            if (view == null) {
                view = this.f2543A;
            }
            if (view != null) {
                o(h6, view, z5 | (z6 ? 2 : 0), 3);
            }
        }
        ListView listView2 = this.f2568g;
        if (listView2 == null || (listAdapter = this.f2550H) == null) {
            return;
        }
        listView2.setAdapter(listAdapter);
        int i5 = this.f2551I;
        if (i5 > -1) {
            listView2.setItemChecked(i5, true);
            listView2.setSelection(i5);
        }
    }

    private static boolean y(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C4993a.f53710n, typedValue, true);
        return typedValue.data != 0;
    }

    public int c(int i5) {
        TypedValue typedValue = new TypedValue();
        this.f2562a.getTheme().resolveAttribute(i5, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView d() {
        return this.f2568g;
    }

    public void e() {
        this.f2563b.setContentView(i());
        x();
    }

    public boolean f(int i5, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f2543A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public boolean g(int i5, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f2543A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public void j(int i5, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f2560R.obtainMessage(i5, onClickListener);
        }
        if (i5 == -3) {
            this.f2585x = charSequence;
            this.f2586y = message;
            this.f2587z = drawable;
        } else if (i5 == -2) {
            this.f2581t = charSequence;
            this.f2582u = message;
            this.f2583v = drawable;
        } else {
            if (i5 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f2577p = charSequence;
            this.f2578q = message;
            this.f2579r = drawable;
        }
    }

    public void k(View view) {
        this.f2549G = view;
    }

    public void l(int i5) {
        this.f2545C = null;
        this.f2544B = i5;
        ImageView imageView = this.f2546D;
        if (imageView != null) {
            if (i5 == 0) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f2546D.setImageResource(this.f2544B);
            }
        }
    }

    public void m(Drawable drawable) {
        this.f2545C = drawable;
        this.f2544B = 0;
        ImageView imageView = this.f2546D;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f2546D.setImageDrawable(drawable);
            }
        }
    }

    public void n(CharSequence charSequence) {
        this.f2567f = charSequence;
        TextView textView = this.f2548F;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void p(CharSequence charSequence) {
        this.f2566e = charSequence;
        TextView textView = this.f2547E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void q(int i5) {
        this.f2569h = null;
        this.f2570i = i5;
        this.f2575n = false;
    }

    public void r(View view) {
        this.f2569h = view;
        this.f2570i = 0;
        this.f2575n = false;
    }

    public void s(View view, int i5, int i6, int i7, int i8) {
        this.f2569h = view;
        this.f2570i = 0;
        this.f2575n = true;
        this.f2571j = i5;
        this.f2572k = i6;
        this.f2573l = i7;
        this.f2574m = i8;
    }
}
