package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AbstractC0975a;
import androidx.appcompat.widget.Q;
import f.C4993a;

/* loaded from: classes.dex */
public class Z extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {

    /* renamed from: m, reason: collision with root package name */
    private static final Interpolator f3612m = new DecelerateInterpolator();

    /* renamed from: b, reason: collision with root package name */
    Runnable f3613b;

    /* renamed from: c, reason: collision with root package name */
    private c f3614c;

    /* renamed from: d, reason: collision with root package name */
    Q f3615d;

    /* renamed from: e, reason: collision with root package name */
    private Spinner f3616e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f3617f;

    /* renamed from: g, reason: collision with root package name */
    int f3618g;

    /* renamed from: h, reason: collision with root package name */
    int f3619h;

    /* renamed from: i, reason: collision with root package name */
    private int f3620i;

    /* renamed from: j, reason: collision with root package name */
    private int f3621j;

    /* renamed from: k, reason: collision with root package name */
    protected ViewPropertyAnimator f3622k;

    /* renamed from: l, reason: collision with root package name */
    protected final e f3623l;

    class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f3624b;

        a(View view) {
            this.f3624b = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            Z.this.smoothScrollTo(this.f3624b.getLeft() - ((Z.this.getWidth() - this.f3624b.getWidth()) / 2), 0);
            Z.this.f3613b = null;
        }
    }

    private class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return Z.this.f3615d.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i5) {
            return ((d) Z.this.f3615d.getChildAt(i5)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i5) {
            return i5;
        }

        @Override // android.widget.Adapter
        public View getView(int i5, View view, ViewGroup viewGroup) {
            if (view == null) {
                return Z.this.d((AbstractC0975a.b) getItem(i5), true);
            }
            ((d) view).a((AbstractC0975a.b) getItem(i5));
            return view;
        }
    }

    private class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = Z.this.f3615d.getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                View childAt = Z.this.f3615d.getChildAt(i5);
                childAt.setSelected(childAt == view);
            }
        }
    }

    private class d extends LinearLayout {

        /* renamed from: b, reason: collision with root package name */
        private final int[] f3628b;

        /* renamed from: c, reason: collision with root package name */
        private AbstractC0975a.b f3629c;

        /* renamed from: d, reason: collision with root package name */
        private TextView f3630d;

        /* renamed from: e, reason: collision with root package name */
        private ImageView f3631e;

        /* renamed from: f, reason: collision with root package name */
        private View f3632f;

        public d(Context context, AbstractC0975a.b bVar, boolean z4) {
            super(context, null, C4993a.f53701e);
            int[] iArr = {R.attr.background};
            this.f3628b = iArr;
            this.f3629c = bVar;
            g0 u5 = g0.u(context, null, iArr, C4993a.f53701e, 0);
            if (u5.r(0)) {
                setBackgroundDrawable(u5.f(0));
            }
            u5.w();
            if (z4) {
                setGravity(8388627);
            }
            c();
        }

        public void a(AbstractC0975a.b bVar) {
            this.f3629c = bVar;
            c();
        }

        public AbstractC0975a.b b() {
            return this.f3629c;
        }

        public void c() {
            AbstractC0975a.b bVar = this.f3629c;
            View b5 = bVar.b();
            if (b5 != null) {
                ViewParent parent = b5.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(b5);
                    }
                    addView(b5);
                }
                this.f3632f = b5;
                TextView textView = this.f3630d;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f3631e;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f3631e.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.f3632f;
            if (view != null) {
                removeView(view);
                this.f3632f = null;
            }
            Drawable c5 = bVar.c();
            CharSequence d5 = bVar.d();
            if (c5 != null) {
                if (this.f3631e == null) {
                    AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    appCompatImageView.setLayoutParams(layoutParams);
                    addView(appCompatImageView, 0);
                    this.f3631e = appCompatImageView;
                }
                this.f3631e.setImageDrawable(c5);
                this.f3631e.setVisibility(0);
            } else {
                ImageView imageView2 = this.f3631e;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f3631e.setImageDrawable(null);
                }
            }
            boolean isEmpty = TextUtils.isEmpty(d5);
            if (isEmpty) {
                TextView textView2 = this.f3630d;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.f3630d.setText((CharSequence) null);
                }
            } else {
                if (this.f3630d == null) {
                    B b6 = new B(getContext(), null, C4993a.f53702f);
                    b6.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    b6.setLayoutParams(layoutParams2);
                    addView(b6);
                    this.f3630d = b6;
                }
                this.f3630d.setText(d5);
                this.f3630d.setVisibility(0);
            }
            ImageView imageView3 = this.f3631e;
            if (imageView3 != null) {
                imageView3.setContentDescription(bVar.a());
            }
            l0.a(this, isEmpty ? bVar.a() : null);
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i5, int i6) {
            super.onMeasure(i5, i6);
            if (Z.this.f3618g > 0) {
                int measuredWidth = getMeasuredWidth();
                int i7 = Z.this.f3618g;
                if (measuredWidth > i7) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i7, 1073741824), i6);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z4) {
            boolean z5 = isSelected() != z4;
            super.setSelected(z4);
            if (z5 && z4) {
                sendAccessibilityEvent(4);
            }
        }
    }

    protected class e extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        private boolean f3634a = false;

        /* renamed from: b, reason: collision with root package name */
        private int f3635b;

        protected e() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f3634a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f3634a) {
                return;
            }
            Z z4 = Z.this;
            z4.f3622k = null;
            z4.setVisibility(this.f3635b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            Z.this.setVisibility(0);
            this.f3634a = false;
        }
    }

    public Z(@NonNull Context context) {
        super(context);
        this.f3623l = new e();
        setHorizontalScrollBarEnabled(false);
        androidx.appcompat.view.a b5 = androidx.appcompat.view.a.b(context);
        setContentHeight(b5.f());
        this.f3619h = b5.e();
        Q c5 = c();
        this.f3615d = c5;
        addView(c5, new ViewGroup.LayoutParams(-2, -1));
    }

    private Spinner b() {
        AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, C4993a.f53705i);
        appCompatSpinner.setLayoutParams(new Q.a(-2, -1));
        appCompatSpinner.setOnItemSelectedListener(this);
        return appCompatSpinner;
    }

    private Q c() {
        Q q5 = new Q(getContext(), null, C4993a.f53700d);
        q5.setMeasureWithLargestChildEnabled(true);
        q5.setGravity(17);
        q5.setLayoutParams(new Q.a(-2, -1));
        return q5;
    }

    private boolean e() {
        Spinner spinner = this.f3616e;
        return spinner != null && spinner.getParent() == this;
    }

    private void f() {
        if (e()) {
            return;
        }
        if (this.f3616e == null) {
            this.f3616e = b();
        }
        removeView(this.f3615d);
        addView(this.f3616e, new ViewGroup.LayoutParams(-2, -1));
        if (this.f3616e.getAdapter() == null) {
            this.f3616e.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.f3613b;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.f3613b = null;
        }
        this.f3616e.setSelection(this.f3621j);
    }

    private boolean g() {
        if (!e()) {
            return false;
        }
        removeView(this.f3616e);
        addView(this.f3615d, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.f3616e.getSelectedItemPosition());
        return false;
    }

    public void a(int i5) {
        View childAt = this.f3615d.getChildAt(i5);
        Runnable runnable = this.f3613b;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.f3613b = aVar;
        post(aVar);
    }

    d d(AbstractC0975a.b bVar, boolean z4) {
        d dVar = new d(getContext(), bVar, z4);
        if (z4) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.f3620i));
            return dVar;
        }
        dVar.setFocusable(true);
        if (this.f3614c == null) {
            this.f3614c = new c();
        }
        dVar.setOnClickListener(this.f3614c);
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.f3613b;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        androidx.appcompat.view.a b5 = androidx.appcompat.view.a.b(getContext());
        setContentHeight(b5.f());
        this.f3619h = b5.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.f3613b;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView adapterView, View view, int i5, long j5) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i5, int i6) {
        int mode = View.MeasureSpec.getMode(i5);
        boolean z4 = mode == 1073741824;
        setFillViewport(z4);
        int childCount = this.f3615d.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            this.f3618g = -1;
        } else {
            if (childCount > 2) {
                this.f3618g = (int) (View.MeasureSpec.getSize(i5) * 0.4f);
            } else {
                this.f3618g = View.MeasureSpec.getSize(i5) / 2;
            }
            this.f3618g = Math.min(this.f3618g, this.f3619h);
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.f3620i, 1073741824);
        if (z4 || !this.f3617f) {
            g();
        } else {
            this.f3615d.measure(0, makeMeasureSpec);
            if (this.f3615d.getMeasuredWidth() > View.MeasureSpec.getSize(i5)) {
                f();
            } else {
                g();
            }
        }
        int measuredWidth = getMeasuredWidth();
        super.onMeasure(i5, makeMeasureSpec);
        int measuredWidth2 = getMeasuredWidth();
        if (!z4 || measuredWidth == measuredWidth2) {
            return;
        }
        setTabSelected(this.f3621j);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView adapterView) {
    }

    public void setAllowCollapse(boolean z4) {
        this.f3617f = z4;
    }

    public void setContentHeight(int i5) {
        this.f3620i = i5;
        requestLayout();
    }

    public void setTabSelected(int i5) {
        this.f3621j = i5;
        int childCount = this.f3615d.getChildCount();
        int i6 = 0;
        while (i6 < childCount) {
            View childAt = this.f3615d.getChildAt(i6);
            boolean z4 = i6 == i5;
            childAt.setSelected(z4);
            if (z4) {
                a(i5);
            }
            i6++;
        }
        Spinner spinner = this.f3616e;
        if (spinner == null || i5 < 0) {
            return;
        }
        spinner.setSelection(i5);
    }
}
