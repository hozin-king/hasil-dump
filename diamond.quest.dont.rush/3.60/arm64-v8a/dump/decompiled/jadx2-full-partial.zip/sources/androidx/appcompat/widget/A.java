package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.core.content.res.h;
import androidx.core.view.C1015b0;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.lang.ref.WeakReference;
import java.util.Locale;
import w.C7504c;

/* loaded from: classes.dex */
class A {

    /* renamed from: a, reason: collision with root package name */
    private final TextView f3222a;

    /* renamed from: b, reason: collision with root package name */
    private e0 f3223b;

    /* renamed from: c, reason: collision with root package name */
    private e0 f3224c;

    /* renamed from: d, reason: collision with root package name */
    private e0 f3225d;

    /* renamed from: e, reason: collision with root package name */
    private e0 f3226e;

    /* renamed from: f, reason: collision with root package name */
    private e0 f3227f;

    /* renamed from: g, reason: collision with root package name */
    private e0 f3228g;

    /* renamed from: h, reason: collision with root package name */
    private e0 f3229h;

    /* renamed from: i, reason: collision with root package name */
    private final C f3230i;

    /* renamed from: j, reason: collision with root package name */
    private int f3231j = 0;

    /* renamed from: k, reason: collision with root package name */
    private int f3232k = -1;

    /* renamed from: l, reason: collision with root package name */
    private Typeface f3233l;

    /* renamed from: m, reason: collision with root package name */
    private boolean f3234m;

    class a extends h.e {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f3235a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f3236b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ WeakReference f3237c;

        a(int i5, int i6, WeakReference weakReference) {
            this.f3235a = i5;
            this.f3236b = i6;
            this.f3237c = weakReference;
        }

        @Override // androidx.core.content.res.h.e
        public void f(int i5) {
        }

        @Override // androidx.core.content.res.h.e
        public void g(Typeface typeface) {
            int i5;
            if (Build.VERSION.SDK_INT >= 28 && (i5 = this.f3235a) != -1) {
                typeface = f.a(typeface, i5, (this.f3236b & 2) != 0);
            }
            A.this.n(this.f3237c, typeface);
        }
    }

    class b implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ TextView f3239b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ Typeface f3240c;

        /* renamed from: d, reason: collision with root package name */
        final /* synthetic */ int f3241d;

        b(TextView textView, Typeface typeface, int i5) {
            this.f3239b = textView;
            this.f3240c = typeface;
            this.f3241d = i5;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f3239b.setTypeface(this.f3240c, this.f3241d);
        }
    }

    static class c {
        static Locale a(String str) {
            return Locale.forLanguageTag(str);
        }
    }

    static class d {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }

        static void b(TextView textView, LocaleList localeList) {
            textView.setTextLocales(localeList);
        }
    }

    static class e {
        static int a(TextView textView) {
            return textView.getAutoSizeStepGranularity();
        }

        static void b(TextView textView, int i5, int i6, int i7, int i8) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(i5, i6, i7, i8);
        }

        static void c(TextView textView, int[] iArr, int i5) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i5);
        }

        static boolean d(TextView textView, String str) {
            return textView.setFontVariationSettings(str);
        }
    }

    static class f {
        static Typeface a(Typeface typeface, int i5, boolean z4) {
            return Typeface.create(typeface, i5, z4);
        }
    }

    A(TextView textView) {
        this.f3222a = textView;
        this.f3230i = new C(textView);
    }

    private void B(int i5, float f5) {
        this.f3230i.t(i5, f5);
    }

    private void C(Context context, g0 g0Var) {
        String n5;
        this.f3231j = g0Var.j(f.j.f53977V2, this.f3231j);
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 28) {
            int j5 = g0Var.j(f.j.f53989Y2, -1);
            this.f3232k = j5;
            if (j5 != -1) {
                this.f3231j &= 2;
            }
        }
        if (!g0Var.r(f.j.f53985X2) && !g0Var.r(f.j.f53993Z2)) {
            if (g0Var.r(f.j.f53973U2)) {
                this.f3234m = false;
                int j6 = g0Var.j(f.j.f53973U2, 1);
                if (j6 == 1) {
                    this.f3233l = Typeface.SANS_SERIF;
                    return;
                } else if (j6 == 2) {
                    this.f3233l = Typeface.SERIF;
                    return;
                } else {
                    if (j6 != 3) {
                        return;
                    }
                    this.f3233l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.f3233l = null;
        int i6 = g0Var.r(f.j.f53993Z2) ? f.j.f53993Z2 : f.j.f53985X2;
        int i7 = this.f3232k;
        int i8 = this.f3231j;
        if (!context.isRestricted()) {
            try {
                Typeface i9 = g0Var.i(i6, this.f3231j, new a(i7, i8, new WeakReference(this.f3222a)));
                if (i9 != null) {
                    if (i5 < 28 || this.f3232k == -1) {
                        this.f3233l = i9;
                    } else {
                        this.f3233l = f.a(Typeface.create(i9, 0), this.f3232k, (this.f3231j & 2) != 0);
                    }
                }
                this.f3234m = this.f3233l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f3233l != null || (n5 = g0Var.n(i6)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.f3232k == -1) {
            this.f3233l = Typeface.create(n5, this.f3231j);
        } else {
            this.f3233l = f.a(Typeface.create(n5, 0), this.f3232k, (this.f3231j & 2) != 0);
        }
    }

    private void a(Drawable drawable, e0 e0Var) {
        if (drawable == null || e0Var == null) {
            return;
        }
        C0992k.i(drawable, e0Var, this.f3222a.getDrawableState());
    }

    private static e0 d(Context context, C0992k c0992k, int i5) {
        ColorStateList f5 = c0992k.f(context, i5);
        if (f5 == null) {
            return null;
        }
        e0 e0Var = new e0();
        e0Var.f3771d = true;
        e0Var.f3768a = f5;
        return e0Var;
    }

    private void y(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] compoundDrawablesRelative = this.f3222a.getCompoundDrawablesRelative();
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            TextView textView = this.f3222a;
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
            return;
        }
        if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative2 = this.f3222a.getCompoundDrawablesRelative();
        Drawable drawable7 = compoundDrawablesRelative2[0];
        if (drawable7 != null || compoundDrawablesRelative2[2] != null) {
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative2[1];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative2[3];
            }
            this.f3222a.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, compoundDrawablesRelative2[2], drawable4);
            return;
        }
        Drawable[] compoundDrawables = this.f3222a.getCompoundDrawables();
        TextView textView2 = this.f3222a;
        if (drawable == null) {
            drawable = compoundDrawables[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawables[1];
        }
        if (drawable3 == null) {
            drawable3 = compoundDrawables[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawables[3];
        }
        textView2.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    private void z() {
        e0 e0Var = this.f3229h;
        this.f3223b = e0Var;
        this.f3224c = e0Var;
        this.f3225d = e0Var;
        this.f3226e = e0Var;
        this.f3227f = e0Var;
        this.f3228g = e0Var;
    }

    void A(int i5, float f5) {
        if (r0.f3875c || l()) {
            return;
        }
        B(i5, f5);
    }

    void b() {
        if (this.f3223b != null || this.f3224c != null || this.f3225d != null || this.f3226e != null) {
            Drawable[] compoundDrawables = this.f3222a.getCompoundDrawables();
            a(compoundDrawables[0], this.f3223b);
            a(compoundDrawables[1], this.f3224c);
            a(compoundDrawables[2], this.f3225d);
            a(compoundDrawables[3], this.f3226e);
        }
        if (this.f3227f == null && this.f3228g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = this.f3222a.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f3227f);
        a(compoundDrawablesRelative[2], this.f3228g);
    }

    void c() {
        this.f3230i.a();
    }

    int e() {
        return this.f3230i.f();
    }

    int f() {
        return this.f3230i.g();
    }

    int g() {
        return this.f3230i.h();
    }

    int[] h() {
        return this.f3230i.i();
    }

    int i() {
        return this.f3230i.j();
    }

    ColorStateList j() {
        e0 e0Var = this.f3229h;
        if (e0Var != null) {
            return e0Var.f3768a;
        }
        return null;
    }

    PorterDuff.Mode k() {
        e0 e0Var = this.f3229h;
        if (e0Var != null) {
            return e0Var.f3769b;
        }
        return null;
    }

    boolean l() {
        return this.f3230i.n();
    }

    void m(AttributeSet attributeSet, int i5) {
        boolean z4;
        boolean z5;
        String str;
        String str2;
        boolean z6;
        int i6;
        float f5;
        Context context = this.f3222a.getContext();
        C0992k b5 = C0992k.b();
        g0 u5 = g0.u(context, attributeSet, f.j.f53986Y, i5, 0);
        TextView textView = this.f3222a;
        C1015b0.b0(textView, textView.getContext(), f.j.f53986Y, attributeSet, u5.q(), i5, 0);
        int m5 = u5.m(f.j.f53990Z, -1);
        if (u5.r(f.j.f54005c0)) {
            this.f3223b = d(context, b5, u5.m(f.j.f54005c0, 0));
        }
        if (u5.r(f.j.f53995a0)) {
            this.f3224c = d(context, b5, u5.m(f.j.f53995a0, 0));
        }
        if (u5.r(f.j.f54010d0)) {
            this.f3225d = d(context, b5, u5.m(f.j.f54010d0, 0));
        }
        if (u5.r(f.j.f54000b0)) {
            this.f3226e = d(context, b5, u5.m(f.j.f54000b0, 0));
        }
        if (u5.r(f.j.f54015e0)) {
            this.f3227f = d(context, b5, u5.m(f.j.f54015e0, 0));
        }
        if (u5.r(f.j.f54020f0)) {
            this.f3228g = d(context, b5, u5.m(f.j.f54020f0, 0));
        }
        u5.w();
        boolean z7 = this.f3222a.getTransformationMethod() instanceof PasswordTransformationMethod;
        if (m5 != -1) {
            g0 s5 = g0.s(context, m5, f.j.f53965S2);
            if (z7 || !s5.r(f.j.f54003b3)) {
                z4 = false;
                z5 = false;
            } else {
                z4 = s5.a(f.j.f54003b3, false);
                z5 = true;
            }
            C(context, s5);
            int i7 = Build.VERSION.SDK_INT;
            str2 = s5.r(f.j.f54008c3) ? s5.n(f.j.f54008c3) : null;
            str = (i7 < 26 || !s5.r(f.j.f53998a3)) ? null : s5.n(f.j.f53998a3);
            s5.w();
        } else {
            z4 = false;
            z5 = false;
            str = null;
            str2 = null;
        }
        g0 u6 = g0.u(context, attributeSet, f.j.f53965S2, i5, 0);
        if (z7 || !u6.r(f.j.f54003b3)) {
            z6 = z5;
        } else {
            z4 = u6.a(f.j.f54003b3, false);
            z6 = true;
        }
        int i8 = Build.VERSION.SDK_INT;
        if (u6.r(f.j.f54008c3)) {
            str2 = u6.n(f.j.f54008c3);
        }
        if (i8 >= 26 && u6.r(f.j.f53998a3)) {
            str = u6.n(f.j.f53998a3);
        }
        if (i8 >= 28 && u6.r(f.j.f53969T2) && u6.e(f.j.f53969T2, -1) == 0) {
            this.f3222a.setTextSize(0, 0.0f);
        }
        C(context, u6);
        u6.w();
        if (!z7 && z6) {
            s(z4);
        }
        Typeface typeface = this.f3233l;
        if (typeface != null) {
            if (this.f3232k == -1) {
                this.f3222a.setTypeface(typeface, this.f3231j);
            } else {
                this.f3222a.setTypeface(typeface);
            }
        }
        if (str != null) {
            e.d(this.f3222a, str);
        }
        if (str2 != null) {
            if (i8 >= 24) {
                d.b(this.f3222a, d.a(str2));
            } else {
                this.f3222a.setTextLocale(c.a(str2.split(StringUtils.COMMA)[0]));
            }
        }
        this.f3230i.o(attributeSet, i5);
        if (r0.f3875c && this.f3230i.j() != 0) {
            int[] i9 = this.f3230i.i();
            if (i9.length > 0) {
                if (e.a(this.f3222a) != -1.0f) {
                    e.b(this.f3222a, this.f3230i.g(), this.f3230i.f(), this.f3230i.h(), 0);
                } else {
                    e.c(this.f3222a, i9, 0);
                }
            }
        }
        g0 t5 = g0.t(context, attributeSet, f.j.f54025g0);
        int m6 = t5.m(f.j.f54065o0, -1);
        Drawable c5 = m6 != -1 ? b5.c(context, m6) : null;
        int m7 = t5.m(f.j.f54090t0, -1);
        Drawable c6 = m7 != -1 ? b5.c(context, m7) : null;
        int m8 = t5.m(f.j.f54070p0, -1);
        Drawable c7 = m8 != -1 ? b5.c(context, m8) : null;
        int m9 = t5.m(f.j.f54055m0, -1);
        Drawable c8 = m9 != -1 ? b5.c(context, m9) : null;
        int m10 = t5.m(f.j.f54075q0, -1);
        Drawable c9 = m10 != -1 ? b5.c(context, m10) : null;
        int m11 = t5.m(f.j.f54060n0, -1);
        y(c5, c6, c7, c8, c9, m11 != -1 ? b5.c(context, m11) : null);
        if (t5.r(f.j.f54080r0)) {
            androidx.core.widget.j.f(this.f3222a, t5.c(f.j.f54080r0));
        }
        if (t5.r(f.j.f54085s0)) {
            androidx.core.widget.j.g(this.f3222a, M.d(t5.j(f.j.f54085s0, -1), null));
        }
        int e5 = t5.e(f.j.f54100v0, -1);
        int e6 = t5.e(f.j.f54105w0, -1);
        if (t5.r(f.j.f54110x0)) {
            TypedValue v5 = t5.v(f.j.f54110x0);
            if (v5 == null || v5.type != 5) {
                f5 = t5.e(f.j.f54110x0, -1);
                i6 = -1;
            } else {
                i6 = t.k.a(v5.data);
                f5 = TypedValue.complexToFloat(v5.data);
            }
        } else {
            i6 = -1;
            f5 = -1.0f;
        }
        t5.w();
        if (e5 != -1) {
            androidx.core.widget.j.h(this.f3222a, e5);
        }
        if (e6 != -1) {
            androidx.core.widget.j.i(this.f3222a, e6);
        }
        if (f5 != -1.0f) {
            if (i6 == -1) {
                androidx.core.widget.j.j(this.f3222a, (int) f5);
            } else {
                androidx.core.widget.j.k(this.f3222a, i6, f5);
            }
        }
    }

    void n(WeakReference weakReference, Typeface typeface) {
        if (this.f3234m) {
            this.f3233l = typeface;
            TextView textView = (TextView) weakReference.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new b(textView, typeface, this.f3231j));
                } else {
                    textView.setTypeface(typeface, this.f3231j);
                }
            }
        }
    }

    void o(boolean z4, int i5, int i6, int i7, int i8) {
        if (r0.f3875c) {
            return;
        }
        c();
    }

    void p() {
        b();
    }

    void q(Context context, int i5) {
        String n5;
        g0 s5 = g0.s(context, i5, f.j.f53965S2);
        if (s5.r(f.j.f54003b3)) {
            s(s5.a(f.j.f54003b3, false));
        }
        int i6 = Build.VERSION.SDK_INT;
        if (s5.r(f.j.f53969T2) && s5.e(f.j.f53969T2, -1) == 0) {
            this.f3222a.setTextSize(0, 0.0f);
        }
        C(context, s5);
        if (i6 >= 26 && s5.r(f.j.f53998a3) && (n5 = s5.n(f.j.f53998a3)) != null) {
            e.d(this.f3222a, n5);
        }
        s5.w();
        Typeface typeface = this.f3233l;
        if (typeface != null) {
            this.f3222a.setTypeface(typeface, this.f3231j);
        }
    }

    void r(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
        if (Build.VERSION.SDK_INT >= 30 || inputConnection == null) {
            return;
        }
        C7504c.f(editorInfo, textView.getText());
    }

    void s(boolean z4) {
        this.f3222a.setAllCaps(z4);
    }

    void t(int i5, int i6, int i7, int i8) {
        this.f3230i.p(i5, i6, i7, i8);
    }

    void u(int[] iArr, int i5) {
        this.f3230i.q(iArr, i5);
    }

    void v(int i5) {
        this.f3230i.r(i5);
    }

    void w(ColorStateList colorStateList) {
        if (this.f3229h == null) {
            this.f3229h = new e0();
        }
        e0 e0Var = this.f3229h;
        e0Var.f3768a = colorStateList;
        e0Var.f3771d = colorStateList != null;
        z();
    }

    void x(PorterDuff.Mode mode) {
        if (this.f3229h == null) {
            this.f3229h = new e0();
        }
        e0 e0Var = this.f3229h;
        e0Var.f3769b = mode;
        e0Var.f3770c = mode != null;
        z();
    }
}
