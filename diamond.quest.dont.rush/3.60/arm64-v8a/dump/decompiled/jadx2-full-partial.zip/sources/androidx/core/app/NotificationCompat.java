package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.widget.RemoteViews;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.y;
import androidx.core.graphics.drawable.IconCompat;
import com.badlogic.gdx.graphics.GL20;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class NotificationCompat {
    public static final int BADGE_ICON_LARGE = 2;
    public static final int BADGE_ICON_NONE = 0;
    public static final int BADGE_ICON_SMALL = 1;
    public static final String CATEGORY_ALARM = "alarm";
    public static final String CATEGORY_CALL = "call";
    public static final String CATEGORY_EMAIL = "email";
    public static final String CATEGORY_ERROR = "err";
    public static final String CATEGORY_EVENT = "event";
    public static final String CATEGORY_LOCATION_SHARING = "location_sharing";
    public static final String CATEGORY_MESSAGE = "msg";
    public static final String CATEGORY_MISSED_CALL = "missed_call";
    public static final String CATEGORY_NAVIGATION = "navigation";
    public static final String CATEGORY_PROGRESS = "progress";
    public static final String CATEGORY_PROMO = "promo";
    public static final String CATEGORY_RECOMMENDATION = "recommendation";
    public static final String CATEGORY_REMINDER = "reminder";
    public static final String CATEGORY_SERVICE = "service";
    public static final String CATEGORY_SOCIAL = "social";
    public static final String CATEGORY_STATUS = "status";
    public static final String CATEGORY_STOPWATCH = "stopwatch";
    public static final String CATEGORY_SYSTEM = "sys";
    public static final String CATEGORY_TRANSPORT = "transport";
    public static final String CATEGORY_WORKOUT = "workout";
    public static final int COLOR_DEFAULT = 0;
    public static final int DEFAULT_ALL = -1;
    public static final int DEFAULT_LIGHTS = 4;
    public static final int DEFAULT_SOUND = 1;
    public static final int DEFAULT_VIBRATE = 2;

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_ANSWER_COLOR = "android.answerColor";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_ANSWER_INTENT = "android.answerIntent";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_AUDIO_CONTENTS_URI = "android.audioContents";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_BACKGROUND_IMAGE_URI = "android.backgroundImageUri";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_BIG_TEXT = "android.bigText";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CALL_IS_VIDEO = "android.callIsVideo";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CALL_PERSON = "android.callPerson";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CALL_PERSON_COMPAT = "android.callPersonCompat";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CALL_TYPE = "android.callType";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CHANNEL_GROUP_ID = "android.intent.extra.CHANNEL_GROUP_ID";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CHANNEL_ID = "android.intent.extra.CHANNEL_ID";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CHRONOMETER_COUNT_DOWN = "android.chronometerCountDown";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_COLORIZED = "android.colorized";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_COMPACT_ACTIONS = "android.compactActions";
    public static final String EXTRA_COMPAT_TEMPLATE = "androidx.core.app.extra.COMPAT_TEMPLATE";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_CONVERSATION_TITLE = "android.conversationTitle";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_DECLINE_COLOR = "android.declineColor";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_DECLINE_INTENT = "android.declineIntent";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_HANG_UP_INTENT = "android.hangUpIntent";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_HIDDEN_CONVERSATION_TITLE = "android.hiddenConversationTitle";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_HISTORIC_MESSAGES = "android.messages.historic";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_INFO_TEXT = "android.infoText";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_IS_GROUP_CONVERSATION = "android.isGroupConversation";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_LARGE_ICON = "android.largeIcon";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_LARGE_ICON_BIG = "android.largeIcon.big";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_MEDIA_SESSION = "android.mediaSession";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_MESSAGES = "android.messages";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_MESSAGING_STYLE_USER = "android.messagingStyleUser";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_NOTIFICATION_ID = "android.intent.extra.NOTIFICATION_ID";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_NOTIFICATION_TAG = "android.intent.extra.NOTIFICATION_TAG";

    @SuppressLint({"ActionValue"})
    @Deprecated
    public static final String EXTRA_PEOPLE = "android.people";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PEOPLE_LIST = "android.people.list";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PICTURE = "android.picture";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PICTURE_CONTENT_DESCRIPTION = "android.pictureContentDescription";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PICTURE_ICON = "android.pictureIcon";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PROGRESS = "android.progress";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PROGRESS_INDETERMINATE = "android.progressIndeterminate";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_PROGRESS_MAX = "android.progressMax";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_REMOTE_INPUT_HISTORY = "android.remoteInputHistory";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SELF_DISPLAY_NAME = "android.selfDisplayName";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SHOW_BIG_PICTURE_WHEN_COLLAPSED = "android.showBigPictureWhenCollapsed";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SHOW_CHRONOMETER = "android.showChronometer";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SHOW_WHEN = "android.showWhen";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SMALL_ICON = "android.icon";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SUB_TEXT = "android.subText";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_SUMMARY_TEXT = "android.summaryText";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_TEMPLATE = "android.template";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_TEXT = "android.text";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_TEXT_LINES = "android.textLines";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_TITLE = "android.title";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_TITLE_BIG = "android.title.big";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_VERIFICATION_ICON = "android.verificationIcon";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_VERIFICATION_ICON_COMPAT = "android.verificationIconCompat";

    @SuppressLint({"ActionValue"})
    public static final String EXTRA_VERIFICATION_TEXT = "android.verificationText";
    public static final int FLAG_AUTO_CANCEL = 16;
    public static final int FLAG_BUBBLE = 4096;
    public static final int FLAG_FOREGROUND_SERVICE = 64;
    public static final int FLAG_GROUP_SUMMARY = 512;

    @Deprecated
    public static final int FLAG_HIGH_PRIORITY = 128;
    public static final int FLAG_INSISTENT = 4;
    public static final int FLAG_LOCAL_ONLY = 256;
    public static final int FLAG_NO_CLEAR = 32;
    public static final int FLAG_ONGOING_EVENT = 2;
    public static final int FLAG_ONLY_ALERT_ONCE = 8;
    public static final int FLAG_SHOW_LIGHTS = 1;
    public static final int FOREGROUND_SERVICE_DEFAULT = 0;
    public static final int FOREGROUND_SERVICE_DEFERRED = 2;
    public static final int FOREGROUND_SERVICE_IMMEDIATE = 1;
    public static final int GROUP_ALERT_ALL = 0;
    public static final int GROUP_ALERT_CHILDREN = 2;
    public static final int GROUP_ALERT_SUMMARY = 1;
    public static final String GROUP_KEY_SILENT = "silent";

    @SuppressLint({"ActionValue"})
    public static final String INTENT_CATEGORY_NOTIFICATION_PREFERENCES = "android.intent.category.NOTIFICATION_PREFERENCES";
    public static final int MAX_ACTION_BUTTONS = 3;
    public static final int PRIORITY_DEFAULT = 0;
    public static final int PRIORITY_HIGH = 1;
    public static final int PRIORITY_LOW = -1;
    public static final int PRIORITY_MAX = 2;
    public static final int PRIORITY_MIN = -2;
    public static final int STREAM_DEFAULT = -1;
    private static final String TAG = "NotifCompat";
    public static final int VISIBILITY_PRIVATE = 0;
    public static final int VISIBILITY_PUBLIC = 1;
    public static final int VISIBILITY_SECRET = -1;

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        final Bundle f4103a;

        /* renamed from: b, reason: collision with root package name */
        private IconCompat f4104b;

        /* renamed from: c, reason: collision with root package name */
        private final A[] f4105c;

        /* renamed from: d, reason: collision with root package name */
        private final A[] f4106d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f4107e;

        /* renamed from: f, reason: collision with root package name */
        boolean f4108f;

        /* renamed from: g, reason: collision with root package name */
        private final int f4109g;

        /* renamed from: h, reason: collision with root package name */
        private final boolean f4110h;

        /* renamed from: i, reason: collision with root package name */
        public int f4111i;

        /* renamed from: j, reason: collision with root package name */
        public CharSequence f4112j;

        /* renamed from: k, reason: collision with root package name */
        public PendingIntent f4113k;

        /* renamed from: l, reason: collision with root package name */
        private boolean f4114l;

        public static final class a {

            /* renamed from: a, reason: collision with root package name */
            private final IconCompat f4115a;

            /* renamed from: b, reason: collision with root package name */
            private final CharSequence f4116b;

            /* renamed from: c, reason: collision with root package name */
            private final PendingIntent f4117c;

            /* renamed from: d, reason: collision with root package name */
            private boolean f4118d;

            /* renamed from: e, reason: collision with root package name */
            private final Bundle f4119e;

            /* renamed from: f, reason: collision with root package name */
            private ArrayList f4120f;

            /* renamed from: g, reason: collision with root package name */
            private int f4121g;

            /* renamed from: h, reason: collision with root package name */
            private boolean f4122h;

            /* renamed from: i, reason: collision with root package name */
            private boolean f4123i;

            /* renamed from: j, reason: collision with root package name */
            private boolean f4124j;

            /* renamed from: androidx.core.app.NotificationCompat$b$a$a, reason: collision with other inner class name */
            static class C0120a {
                static Bundle a(Notification.Action action) {
                    return action.getExtras();
                }

                static RemoteInput[] b(Notification.Action action) {
                    return action.getRemoteInputs();
                }
            }

            /* renamed from: androidx.core.app.NotificationCompat$b$a$b, reason: collision with other inner class name */
            static class C0121b {
                static Icon a(Notification.Action action) {
                    return action.getIcon();
                }
            }

            static class c {
                static boolean a(Notification.Action action) {
                    return action.getAllowGeneratedReplies();
                }
            }

            static class d {
                static int a(Notification.Action action) {
                    return action.getSemanticAction();
                }
            }

            static class e {
                static boolean a(Notification.Action action) {
                    return action.isContextual();
                }
            }

            static class f {
                static boolean a(Notification.Action action) {
                    return action.isAuthenticationRequired();
                }
            }

            public a(@Nullable IconCompat iconCompat, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent) {
                this(iconCompat, charSequence, pendingIntent, new Bundle(), null, true, 0, true, false, false);
            }

            private void d() {
                if (this.f4123i && this.f4117c == null) {
                    throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
                }
            }

            public static a e(Notification.Action action) {
                a aVar = C0121b.a(action) != null ? new a(IconCompat.g(C0121b.a(action)), action.title, action.actionIntent) : new a(action.icon, action.title, action.actionIntent);
                RemoteInput[] b5 = C0120a.b(action);
                if (b5 != null && b5.length != 0) {
                    for (RemoteInput remoteInput : b5) {
                        aVar.b(A.c(remoteInput));
                    }
                }
                int i5 = Build.VERSION.SDK_INT;
                if (i5 >= 24) {
                    aVar.f4118d = c.a(action);
                }
                if (i5 >= 28) {
                    aVar.h(d.a(action));
                }
                if (i5 >= 29) {
                    aVar.g(e.a(action));
                }
                if (i5 >= 31) {
                    aVar.f(f.a(action));
                }
                aVar.a(C0120a.a(action));
                return aVar;
            }

            public a a(Bundle bundle) {
                if (bundle != null) {
                    this.f4119e.putAll(bundle);
                }
                return this;
            }

            public a b(A a5) {
                if (this.f4120f == null) {
                    this.f4120f = new ArrayList();
                }
                if (a5 != null) {
                    this.f4120f.add(a5);
                }
                return this;
            }

            public b c() {
                d();
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                ArrayList arrayList3 = this.f4120f;
                if (arrayList3 != null) {
                    int size = arrayList3.size();
                    int i5 = 0;
                    while (i5 < size) {
                        Object obj = arrayList3.get(i5);
                        i5++;
                        A a5 = (A) obj;
                        if (a5.k()) {
                            arrayList.add(a5);
                        } else {
                            arrayList2.add(a5);
                        }
                    }
                }
                return new b(this.f4115a, this.f4116b, this.f4117c, this.f4119e, arrayList2.isEmpty() ? null : (A[]) arrayList2.toArray(new A[arrayList2.size()]), arrayList.isEmpty() ? null : (A[]) arrayList.toArray(new A[arrayList.size()]), this.f4118d, this.f4121g, this.f4122h, this.f4123i, this.f4124j);
            }

            public a f(boolean z4) {
                this.f4124j = z4;
                return this;
            }

            public a g(boolean z4) {
                this.f4123i = z4;
                return this;
            }

            public a h(int i5) {
                this.f4121g = i5;
                return this;
            }

            public a(int i5, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent) {
                this(i5 != 0 ? IconCompat.o(null, "", i5) : null, charSequence, pendingIntent, new Bundle(), null, true, 0, true, false, false);
            }

            public a(@NonNull b bVar) {
                this(bVar.d(), bVar.f4112j, bVar.f4113k, new Bundle(bVar.f4103a), bVar.e(), bVar.b(), bVar.f(), bVar.f4108f, bVar.j(), bVar.i());
            }

            private a(@Nullable IconCompat iconCompat, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent, @NonNull Bundle bundle, @Nullable A[] aArr, boolean z4, int i5, boolean z5, boolean z6, boolean z7) {
                this.f4118d = true;
                this.f4122h = true;
                this.f4115a = iconCompat;
                this.f4116b = m.p(charSequence);
                this.f4117c = pendingIntent;
                this.f4119e = bundle;
                this.f4120f = aArr == null ? null : new ArrayList(Arrays.asList(aArr));
                this.f4118d = z4;
                this.f4121g = i5;
                this.f4122h = z5;
                this.f4123i = z6;
                this.f4124j = z7;
            }
        }

        public b(int i5, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent) {
            this(i5 != 0 ? IconCompat.o(null, "", i5) : null, charSequence, pendingIntent);
        }

        public PendingIntent a() {
            return this.f4113k;
        }

        public boolean b() {
            return this.f4107e;
        }

        public Bundle c() {
            return this.f4103a;
        }

        public IconCompat d() {
            int i5;
            if (this.f4104b == null && (i5 = this.f4111i) != 0) {
                this.f4104b = IconCompat.o(null, "", i5);
            }
            return this.f4104b;
        }

        public A[] e() {
            return this.f4105c;
        }

        public int f() {
            return this.f4109g;
        }

        public boolean g() {
            return this.f4108f;
        }

        public CharSequence h() {
            return this.f4112j;
        }

        public boolean i() {
            return this.f4114l;
        }

        public boolean j() {
            return this.f4110h;
        }

        public b(@Nullable IconCompat iconCompat, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent) {
            this(iconCompat, charSequence, pendingIntent, new Bundle(), (A[]) null, (A[]) null, true, 0, true, false, false);
        }

        b(int i5, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent, @Nullable Bundle bundle, @Nullable A[] aArr, @Nullable A[] aArr2, boolean z4, int i6, boolean z5, boolean z6, boolean z7) {
            this(i5 != 0 ? IconCompat.o(null, "", i5) : null, charSequence, pendingIntent, bundle, aArr, aArr2, z4, i6, z5, z6, z7);
        }

        b(@Nullable IconCompat iconCompat, @Nullable CharSequence charSequence, @Nullable PendingIntent pendingIntent, @Nullable Bundle bundle, @Nullable A[] aArr, @Nullable A[] aArr2, boolean z4, int i5, boolean z5, boolean z6, boolean z7) {
            this.f4108f = true;
            this.f4104b = iconCompat;
            if (iconCompat != null && iconCompat.u() == 2) {
                this.f4111i = iconCompat.r();
            }
            this.f4112j = m.p(charSequence);
            this.f4113k = pendingIntent;
            this.f4103a = bundle == null ? new Bundle() : bundle;
            this.f4105c = aArr;
            this.f4106d = aArr2;
            this.f4107e = z4;
            this.f4109g = i5;
            this.f4108f = z5;
            this.f4110h = z6;
            this.f4114l = z7;
        }
    }

    static class c {
        static boolean a(RemoteInput remoteInput) {
            return remoteInput.getAllowFreeFormInput();
        }

        static CharSequence[] b(RemoteInput remoteInput) {
            return remoteInput.getChoices();
        }

        static Bundle c(Notification.Action action) {
            return action.getExtras();
        }

        static Bundle d(RemoteInput remoteInput) {
            return remoteInput.getExtras();
        }

        static String e(Notification notification) {
            return notification.getGroup();
        }

        static CharSequence f(RemoteInput remoteInput) {
            return remoteInput.getLabel();
        }

        static RemoteInput[] g(Notification.Action action) {
            return action.getRemoteInputs();
        }

        static String h(RemoteInput remoteInput) {
            return remoteInput.getResultKey();
        }

        static String i(Notification notification) {
            return notification.getSortKey();
        }
    }

    static class d {
        static Icon a(Notification.Action action) {
            return action.getIcon();
        }
    }

    static class e {
        static boolean a(Notification.Action action) {
            return action.getAllowGeneratedReplies();
        }
    }

    static class f {
        static int a(Notification notification) {
            return notification.getBadgeIconType();
        }

        static String b(Notification notification) {
            return notification.getChannelId();
        }

        static int c(Notification notification) {
            return notification.getGroupAlertBehavior();
        }

        static CharSequence d(Notification notification) {
            return notification.getSettingsText();
        }

        static String e(Notification notification) {
            return notification.getShortcutId();
        }

        static long f(Notification notification) {
            return notification.getTimeoutAfter();
        }
    }

    static class g {
        static int a(Notification.Action action) {
            return action.getSemanticAction();
        }
    }

    static class h {
        static boolean a(Notification notification) {
            return notification.getAllowSystemGeneratedContextualActions();
        }

        static Notification.BubbleMetadata b(Notification notification) {
            return notification.getBubbleMetadata();
        }

        static int c(RemoteInput remoteInput) {
            return remoteInput.getEditChoicesBeforeSending();
        }

        static LocusId d(Notification notification) {
            return notification.getLocusId();
        }

        static boolean e(Notification.Action action) {
            return action.isContextual();
        }
    }

    static class i {
        static boolean a(Notification.Action action) {
            return action.isAuthenticationRequired();
        }
    }

    public static class j extends r {

        /* renamed from: a, reason: collision with root package name */
        private IconCompat f4125a;

        /* renamed from: b, reason: collision with root package name */
        private IconCompat f4126b;

        /* renamed from: c, reason: collision with root package name */
        private boolean f4127c;

        /* renamed from: d, reason: collision with root package name */
        private CharSequence f4128d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f4129e;

        private static class a {
            static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
                bigPictureStyle.bigLargeIcon(icon);
            }
        }

        private static class b {
            static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
                bigPictureStyle.bigPicture(icon);
            }

            static void b(Notification.BigPictureStyle bigPictureStyle, CharSequence charSequence) {
                bigPictureStyle.setContentDescription(charSequence);
            }

            static void c(Notification.BigPictureStyle bigPictureStyle, boolean z4) {
                bigPictureStyle.showBigPictureWhenCollapsed(z4);
            }
        }

        public j() {
        }

        private static IconCompat h(Parcelable parcelable) {
            if (parcelable == null) {
                return null;
            }
            if (parcelable instanceof Icon) {
                return IconCompat.f((Icon) parcelable);
            }
            if (parcelable instanceof Bitmap) {
                return IconCompat.k((Bitmap) parcelable);
            }
            return null;
        }

        public static IconCompat k(Bundle bundle) {
            if (bundle == null) {
                return null;
            }
            Parcelable parcelable = bundle.getParcelable(NotificationCompat.EXTRA_PICTURE);
            return parcelable != null ? h(parcelable) : h(bundle.getParcelable(NotificationCompat.EXTRA_PICTURE_ICON));
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            Notification.BigPictureStyle bigContentTitle = new Notification.BigPictureStyle(mVar.a()).setBigContentTitle(this.mBigContentTitle);
            IconCompat iconCompat = this.f4125a;
            if (iconCompat != null) {
                if (Build.VERSION.SDK_INT >= 31) {
                    b.a(bigContentTitle, this.f4125a.C(mVar instanceof s ? ((s) mVar).f() : null));
                } else if (iconCompat.u() == 1) {
                    bigContentTitle = bigContentTitle.bigPicture(this.f4125a.q());
                }
            }
            if (this.f4127c) {
                if (this.f4126b == null) {
                    bigContentTitle.bigLargeIcon((Bitmap) null);
                } else {
                    a.a(bigContentTitle, this.f4126b.C(mVar instanceof s ? ((s) mVar).f() : null));
                }
            }
            if (this.mSummaryTextSet) {
                bigContentTitle.setSummaryText(this.mSummaryText);
            }
            if (Build.VERSION.SDK_INT >= 31) {
                b.c(bigContentTitle, this.f4129e);
                b.b(bigContentTitle, this.f4128d);
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void clearCompatExtraKeys(Bundle bundle) {
            super.clearCompatExtraKeys(bundle);
            bundle.remove(NotificationCompat.EXTRA_LARGE_ICON_BIG);
            bundle.remove(NotificationCompat.EXTRA_PICTURE);
            bundle.remove(NotificationCompat.EXTRA_PICTURE_ICON);
            bundle.remove(NotificationCompat.EXTRA_SHOW_BIG_PICTURE_WHEN_COLLAPSED);
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$BigPictureStyle";
        }

        public j i(Bitmap bitmap) {
            this.f4126b = bitmap == null ? null : IconCompat.k(bitmap);
            this.f4127c = true;
            return this;
        }

        public j j(Bitmap bitmap) {
            this.f4125a = bitmap == null ? null : IconCompat.k(bitmap);
            return this;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void restoreFromCompatExtras(Bundle bundle) {
            super.restoreFromCompatExtras(bundle);
            if (bundle.containsKey(NotificationCompat.EXTRA_LARGE_ICON_BIG)) {
                this.f4126b = h(bundle.getParcelable(NotificationCompat.EXTRA_LARGE_ICON_BIG));
                this.f4127c = true;
            }
            this.f4125a = k(bundle);
            this.f4129e = bundle.getBoolean(NotificationCompat.EXTRA_SHOW_BIG_PICTURE_WHEN_COLLAPSED);
        }

        public j(@Nullable m mVar) {
            setBuilder(mVar);
        }
    }

    public static class k extends r {

        /* renamed from: a, reason: collision with root package name */
        private CharSequence f4130a;

        public k() {
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void addCompatExtras(Bundle bundle) {
            super.addCompatExtras(bundle);
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            Notification.BigTextStyle bigText = new Notification.BigTextStyle(mVar.a()).setBigContentTitle(this.mBigContentTitle).bigText(this.f4130a);
            if (this.mSummaryTextSet) {
                bigText.setSummaryText(this.mSummaryText);
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void clearCompatExtraKeys(Bundle bundle) {
            super.clearCompatExtraKeys(bundle);
            bundle.remove(NotificationCompat.EXTRA_BIG_TEXT);
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$BigTextStyle";
        }

        public k h(CharSequence charSequence) {
            this.f4130a = m.p(charSequence);
            return this;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void restoreFromCompatExtras(Bundle bundle) {
            super.restoreFromCompatExtras(bundle);
            this.f4130a = bundle.getCharSequence(NotificationCompat.EXTRA_BIG_TEXT);
        }

        public k(@Nullable m mVar) {
            setBuilder(mVar);
        }
    }

    public static final class l {

        /* renamed from: a, reason: collision with root package name */
        private PendingIntent f4131a;

        /* renamed from: b, reason: collision with root package name */
        private PendingIntent f4132b;

        /* renamed from: c, reason: collision with root package name */
        private IconCompat f4133c;

        /* renamed from: d, reason: collision with root package name */
        private int f4134d;

        /* renamed from: e, reason: collision with root package name */
        private int f4135e;

        /* renamed from: f, reason: collision with root package name */
        private int f4136f;

        /* renamed from: g, reason: collision with root package name */
        private String f4137g;

        private static class a {
            @Nullable
            static l a(@Nullable Notification.BubbleMetadata bubbleMetadata) {
                if (bubbleMetadata == null || bubbleMetadata.getIntent() == null) {
                    return null;
                }
                c g5 = new c(bubbleMetadata.getIntent(), IconCompat.f(bubbleMetadata.getIcon())).b(bubbleMetadata.getAutoExpandBubble()).c(bubbleMetadata.getDeleteIntent()).g(bubbleMetadata.isNotificationSuppressed());
                if (bubbleMetadata.getDesiredHeight() != 0) {
                    g5.d(bubbleMetadata.getDesiredHeight());
                }
                if (bubbleMetadata.getDesiredHeightResId() != 0) {
                    g5.e(bubbleMetadata.getDesiredHeightResId());
                }
                return g5.a();
            }

            @Nullable
            static Notification.BubbleMetadata b(@Nullable l lVar) {
                if (lVar == null || lVar.g() == null) {
                    return null;
                }
                Notification.BubbleMetadata.Builder suppressNotification = new Notification.BubbleMetadata.Builder().setIcon(lVar.f().B()).setIntent(lVar.g()).setDeleteIntent(lVar.c()).setAutoExpandBubble(lVar.b()).setSuppressNotification(lVar.i());
                if (lVar.d() != 0) {
                    suppressNotification.setDesiredHeight(lVar.d());
                }
                if (lVar.e() != 0) {
                    suppressNotification.setDesiredHeightResId(lVar.e());
                }
                return suppressNotification.build();
            }
        }

        private static class b {
            @Nullable
            static l a(@Nullable Notification.BubbleMetadata bubbleMetadata) {
                if (bubbleMetadata == null) {
                    return null;
                }
                c cVar = bubbleMetadata.getShortcutId() != null ? new c(bubbleMetadata.getShortcutId()) : new c(bubbleMetadata.getIntent(), IconCompat.f(bubbleMetadata.getIcon()));
                cVar.b(bubbleMetadata.getAutoExpandBubble()).c(bubbleMetadata.getDeleteIntent()).g(bubbleMetadata.isNotificationSuppressed());
                if (bubbleMetadata.getDesiredHeight() != 0) {
                    cVar.d(bubbleMetadata.getDesiredHeight());
                }
                if (bubbleMetadata.getDesiredHeightResId() != 0) {
                    cVar.e(bubbleMetadata.getDesiredHeightResId());
                }
                return cVar.a();
            }

            @Nullable
            static Notification.BubbleMetadata b(@Nullable l lVar) {
                if (lVar == null) {
                    return null;
                }
                Notification.BubbleMetadata.Builder builder = lVar.h() != null ? new Notification.BubbleMetadata.Builder(lVar.h()) : new Notification.BubbleMetadata.Builder(lVar.g(), lVar.f().B());
                builder.setDeleteIntent(lVar.c()).setAutoExpandBubble(lVar.b()).setSuppressNotification(lVar.i());
                if (lVar.d() != 0) {
                    builder.setDesiredHeight(lVar.d());
                }
                if (lVar.e() != 0) {
                    builder.setDesiredHeightResId(lVar.e());
                }
                return builder.build();
            }
        }

        public static final class c {

            /* renamed from: a, reason: collision with root package name */
            private PendingIntent f4138a;

            /* renamed from: b, reason: collision with root package name */
            private IconCompat f4139b;

            /* renamed from: c, reason: collision with root package name */
            private int f4140c;

            /* renamed from: d, reason: collision with root package name */
            private int f4141d;

            /* renamed from: e, reason: collision with root package name */
            private int f4142e;

            /* renamed from: f, reason: collision with root package name */
            private PendingIntent f4143f;

            /* renamed from: g, reason: collision with root package name */
            private String f4144g;

            @Deprecated
            public c() {
            }

            private c f(int i5, boolean z4) {
                if (z4) {
                    this.f4142e = i5 | this.f4142e;
                    return this;
                }
                this.f4142e = (~i5) & this.f4142e;
                return this;
            }

            public l a() {
                String str = this.f4144g;
                if (str == null && this.f4138a == null) {
                    throw new NullPointerException("Must supply pending intent or shortcut to bubble");
                }
                if (str == null && this.f4139b == null) {
                    throw new NullPointerException("Must supply an icon or shortcut for the bubble");
                }
                l lVar = new l(this.f4138a, this.f4143f, this.f4139b, this.f4140c, this.f4141d, this.f4142e, str);
                lVar.j(this.f4142e);
                return lVar;
            }

            public c b(boolean z4) {
                f(1, z4);
                return this;
            }

            public c c(PendingIntent pendingIntent) {
                this.f4143f = pendingIntent;
                return this;
            }

            public c d(int i5) {
                this.f4140c = Math.max(i5, 0);
                this.f4141d = 0;
                return this;
            }

            public c e(int i5) {
                this.f4141d = i5;
                this.f4140c = 0;
                return this;
            }

            public c g(boolean z4) {
                f(2, z4);
                return this;
            }

            public c(@NonNull String str) {
                if (TextUtils.isEmpty(str)) {
                    throw new NullPointerException("Bubble requires a non-null shortcut id");
                }
                this.f4144g = str;
            }

            public c(@NonNull PendingIntent pendingIntent, @NonNull IconCompat iconCompat) {
                if (pendingIntent == null) {
                    throw new NullPointerException("Bubble requires non-null pending intent");
                }
                if (iconCompat != null) {
                    this.f4138a = pendingIntent;
                    this.f4139b = iconCompat;
                    return;
                }
                throw new NullPointerException("Bubbles require non-null icon");
            }
        }

        public static l a(Notification.BubbleMetadata bubbleMetadata) {
            if (bubbleMetadata == null) {
                return null;
            }
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 30) {
                return b.a(bubbleMetadata);
            }
            if (i5 == 29) {
                return a.a(bubbleMetadata);
            }
            return null;
        }

        public static Notification.BubbleMetadata k(l lVar) {
            if (lVar == null) {
                return null;
            }
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 30) {
                return b.b(lVar);
            }
            if (i5 == 29) {
                return a.b(lVar);
            }
            return null;
        }

        public boolean b() {
            return (this.f4136f & 1) != 0;
        }

        public PendingIntent c() {
            return this.f4132b;
        }

        public int d() {
            return this.f4134d;
        }

        public int e() {
            return this.f4135e;
        }

        public IconCompat f() {
            return this.f4133c;
        }

        public PendingIntent g() {
            return this.f4131a;
        }

        public String h() {
            return this.f4137g;
        }

        public boolean i() {
            return (this.f4136f & 2) != 0;
        }

        public void j(int i5) {
            this.f4136f = i5;
        }

        private l(@Nullable PendingIntent pendingIntent, @Nullable PendingIntent pendingIntent2, @Nullable IconCompat iconCompat, int i5, int i6, int i7, @Nullable String str) {
            this.f4131a = pendingIntent;
            this.f4133c = iconCompat;
            this.f4134d = i5;
            this.f4135e = i6;
            this.f4132b = pendingIntent2;
            this.f4136f = i7;
            this.f4137g = str;
        }
    }

    public static class n extends r {

        /* renamed from: a, reason: collision with root package name */
        private int f4195a;

        /* renamed from: b, reason: collision with root package name */
        private y f4196b;

        /* renamed from: c, reason: collision with root package name */
        private PendingIntent f4197c;

        /* renamed from: d, reason: collision with root package name */
        private PendingIntent f4198d;

        /* renamed from: e, reason: collision with root package name */
        private PendingIntent f4199e;

        /* renamed from: f, reason: collision with root package name */
        private boolean f4200f;

        /* renamed from: g, reason: collision with root package name */
        private Integer f4201g;

        /* renamed from: h, reason: collision with root package name */
        private Integer f4202h;

        /* renamed from: i, reason: collision with root package name */
        private IconCompat f4203i;

        /* renamed from: j, reason: collision with root package name */
        private CharSequence f4204j;

        static class a {
            static Notification.Builder a(Notification.Builder builder, String str) {
                return builder.addPerson(str);
            }

            static Notification.Builder b(Notification.Builder builder, String str) {
                return builder.setCategory(str);
            }
        }

        static class b {
            static Parcelable a(Icon icon) {
                return icon;
            }

            static Notification.Action.Builder b(Icon icon, CharSequence charSequence, PendingIntent pendingIntent) {
                return new Notification.Action.Builder(icon, charSequence, pendingIntent);
            }

            static void c(Notification.Builder builder, Icon icon) {
                builder.setLargeIcon(icon);
            }
        }

        static class c {
            static Notification.Builder a(Notification.Builder builder, Person person) {
                return builder.addPerson(person);
            }

            static Parcelable b(Person person) {
                return person;
            }
        }

        static class d {
            static Notification.CallStyle a(@NonNull Person person, @NonNull PendingIntent pendingIntent, @NonNull PendingIntent pendingIntent2) {
                return Notification.CallStyle.forIncomingCall(person, pendingIntent, pendingIntent2);
            }

            static Notification.CallStyle b(@NonNull Person person, @NonNull PendingIntent pendingIntent) {
                return Notification.CallStyle.forOngoingCall(person, pendingIntent);
            }

            static Notification.CallStyle c(@NonNull Person person, @NonNull PendingIntent pendingIntent, @NonNull PendingIntent pendingIntent2) {
                return Notification.CallStyle.forScreeningCall(person, pendingIntent, pendingIntent2);
            }

            static Notification.CallStyle d(Notification.CallStyle callStyle, int i5) {
                return callStyle.setAnswerButtonColorHint(i5);
            }

            static Notification.Action.Builder e(Notification.Action.Builder builder, boolean z4) {
                return builder.setAuthenticationRequired(z4);
            }

            static Notification.CallStyle f(Notification.CallStyle callStyle, int i5) {
                return callStyle.setDeclineButtonColorHint(i5);
            }

            static Notification.CallStyle g(Notification.CallStyle callStyle, boolean z4) {
                return callStyle.setIsVideo(z4);
            }

            static Notification.CallStyle h(Notification.CallStyle callStyle, @Nullable Icon icon) {
                return callStyle.setVerificationIcon(icon);
            }

            static Notification.CallStyle i(Notification.CallStyle callStyle, @Nullable CharSequence charSequence) {
                return callStyle.setVerificationText(charSequence);
            }
        }

        public n() {
        }

        private String i() {
            int i5 = this.f4195a;
            if (i5 == 1) {
                return this.mBuilder.f4169a.getResources().getString(o.h.f73285e);
            }
            if (i5 == 2) {
                return this.mBuilder.f4169a.getResources().getString(o.h.f73286f);
            }
            if (i5 != 3) {
                return null;
            }
            return this.mBuilder.f4169a.getResources().getString(o.h.f73287g);
        }

        private boolean j(b bVar) {
            return bVar != null && bVar.c().getBoolean("key_action_priority");
        }

        private b k(int i5, int i6, Integer num, int i7, PendingIntent pendingIntent) {
            if (num == null) {
                num = Integer.valueOf(androidx.core.content.a.getColor(this.mBuilder.f4169a, i7));
            }
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            spannableStringBuilder.append((CharSequence) this.mBuilder.f4169a.getResources().getString(i6));
            spannableStringBuilder.setSpan(new ForegroundColorSpan(num.intValue()), 0, spannableStringBuilder.length(), 18);
            b c5 = new b.a(IconCompat.n(this.mBuilder.f4169a, i5), spannableStringBuilder, pendingIntent).c();
            c5.c().putBoolean("key_action_priority", true);
            return c5;
        }

        private b l() {
            int i5 = o.d.f73211b;
            int i6 = o.d.f73210a;
            PendingIntent pendingIntent = this.f4197c;
            if (pendingIntent == null) {
                return null;
            }
            boolean z4 = this.f4200f;
            return k(z4 ? i5 : i6, z4 ? o.h.f73282b : o.h.f73281a, this.f4201g, o.b.f73197a, pendingIntent);
        }

        private b m() {
            int i5 = o.d.f73212c;
            PendingIntent pendingIntent = this.f4198d;
            return pendingIntent == null ? k(i5, o.h.f73284d, this.f4202h, o.b.f73198b, this.f4199e) : k(i5, o.h.f73283c, this.f4202h, o.b.f73198b, pendingIntent);
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void addCompatExtras(Bundle bundle) {
            super.addCompatExtras(bundle);
            bundle.putInt(NotificationCompat.EXTRA_CALL_TYPE, this.f4195a);
            bundle.putBoolean(NotificationCompat.EXTRA_CALL_IS_VIDEO, this.f4200f);
            y yVar = this.f4196b;
            if (yVar != null) {
                if (Build.VERSION.SDK_INT >= 28) {
                    bundle.putParcelable(NotificationCompat.EXTRA_CALL_PERSON, c.b(yVar.j()));
                } else {
                    bundle.putParcelable(NotificationCompat.EXTRA_CALL_PERSON_COMPAT, yVar.k());
                }
            }
            IconCompat iconCompat = this.f4203i;
            if (iconCompat != null) {
                bundle.putParcelable(NotificationCompat.EXTRA_VERIFICATION_ICON, b.a(iconCompat.C(this.mBuilder.f4169a)));
            }
            bundle.putCharSequence(NotificationCompat.EXTRA_VERIFICATION_TEXT, this.f4204j);
            bundle.putParcelable(NotificationCompat.EXTRA_ANSWER_INTENT, this.f4197c);
            bundle.putParcelable(NotificationCompat.EXTRA_DECLINE_INTENT, this.f4198d);
            bundle.putParcelable(NotificationCompat.EXTRA_HANG_UP_INTENT, this.f4199e);
            Integer num = this.f4201g;
            if (num != null) {
                bundle.putInt(NotificationCompat.EXTRA_ANSWER_COLOR, num.intValue());
            }
            Integer num2 = this.f4202h;
            if (num2 != null) {
                bundle.putInt(NotificationCompat.EXTRA_DECLINE_COLOR, num2.intValue());
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            int i5 = Build.VERSION.SDK_INT;
            CharSequence charSequence = null;
            r2 = null;
            Notification.CallStyle a5 = null;
            charSequence = null;
            if (i5 < 31) {
                Notification.Builder a6 = mVar.a();
                y yVar = this.f4196b;
                a6.setContentTitle(yVar != null ? yVar.e() : null);
                Bundle bundle = this.mBuilder.f4149E;
                if (bundle != null && bundle.containsKey(NotificationCompat.EXTRA_TEXT)) {
                    charSequence = this.mBuilder.f4149E.getCharSequence(NotificationCompat.EXTRA_TEXT);
                }
                if (charSequence == null) {
                    charSequence = i();
                }
                a6.setContentText(charSequence);
                y yVar2 = this.f4196b;
                if (yVar2 != null) {
                    if (yVar2.c() != null) {
                        b.c(a6, this.f4196b.c().C(this.mBuilder.f4169a));
                    }
                    if (i5 >= 28) {
                        c.a(a6, this.f4196b.j());
                    } else {
                        a.a(a6, this.f4196b.f());
                    }
                }
                a.b(a6, NotificationCompat.CATEGORY_CALL);
                return;
            }
            int i6 = this.f4195a;
            if (i6 == 1) {
                a5 = d.a(this.f4196b.j(), this.f4198d, this.f4197c);
            } else if (i6 == 2) {
                a5 = d.b(this.f4196b.j(), this.f4199e);
            } else if (i6 == 3) {
                a5 = d.c(this.f4196b.j(), this.f4199e, this.f4197c);
            } else if (Log.isLoggable(NotificationCompat.TAG, 3)) {
                Log.d(NotificationCompat.TAG, "Unrecognized call type in CallStyle: " + String.valueOf(this.f4195a));
            }
            if (a5 != null) {
                a5.setBuilder(mVar.a());
                Integer num = this.f4201g;
                if (num != null) {
                    d.d(a5, num.intValue());
                }
                Integer num2 = this.f4202h;
                if (num2 != null) {
                    d.f(a5, num2.intValue());
                }
                d.i(a5, this.f4204j);
                IconCompat iconCompat = this.f4203i;
                if (iconCompat != null) {
                    d.h(a5, iconCompat.C(this.mBuilder.f4169a));
                }
                d.g(a5, this.f4200f);
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        public boolean displayCustomViewInline() {
            return true;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$CallStyle";
        }

        public ArrayList h() {
            b m5 = m();
            b l5 = l();
            ArrayList arrayList = new ArrayList(3);
            arrayList.add(m5);
            ArrayList arrayList2 = this.mBuilder.f4170b;
            int i5 = 2;
            if (arrayList2 != null) {
                int size = arrayList2.size();
                int i6 = 0;
                while (i6 < size) {
                    Object obj = arrayList2.get(i6);
                    i6++;
                    b bVar = (b) obj;
                    if (bVar.j()) {
                        arrayList.add(bVar);
                    } else if (!j(bVar) && i5 > 1) {
                        arrayList.add(bVar);
                        i5--;
                    }
                    if (l5 != null && i5 == 1) {
                        arrayList.add(l5);
                        i5--;
                    }
                }
            }
            if (l5 != null && i5 >= 1) {
                arrayList.add(l5);
            }
            return arrayList;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void restoreFromCompatExtras(Bundle bundle) {
            super.restoreFromCompatExtras(bundle);
            this.f4195a = bundle.getInt(NotificationCompat.EXTRA_CALL_TYPE);
            this.f4200f = bundle.getBoolean(NotificationCompat.EXTRA_CALL_IS_VIDEO);
            if (Build.VERSION.SDK_INT >= 28 && bundle.containsKey(NotificationCompat.EXTRA_CALL_PERSON)) {
                this.f4196b = y.a(androidx.core.app.n.a(bundle.getParcelable(NotificationCompat.EXTRA_CALL_PERSON)));
            } else if (bundle.containsKey(NotificationCompat.EXTRA_CALL_PERSON_COMPAT)) {
                this.f4196b = y.b(bundle.getBundle(NotificationCompat.EXTRA_CALL_PERSON_COMPAT));
            }
            if (bundle.containsKey(NotificationCompat.EXTRA_VERIFICATION_ICON)) {
                this.f4203i = IconCompat.f((Icon) bundle.getParcelable(NotificationCompat.EXTRA_VERIFICATION_ICON));
            } else if (bundle.containsKey(NotificationCompat.EXTRA_VERIFICATION_ICON_COMPAT)) {
                this.f4203i = IconCompat.e(bundle.getBundle(NotificationCompat.EXTRA_VERIFICATION_ICON_COMPAT));
            }
            this.f4204j = bundle.getCharSequence(NotificationCompat.EXTRA_VERIFICATION_TEXT);
            this.f4197c = (PendingIntent) bundle.getParcelable(NotificationCompat.EXTRA_ANSWER_INTENT);
            this.f4198d = (PendingIntent) bundle.getParcelable(NotificationCompat.EXTRA_DECLINE_INTENT);
            this.f4199e = (PendingIntent) bundle.getParcelable(NotificationCompat.EXTRA_HANG_UP_INTENT);
            this.f4201g = bundle.containsKey(NotificationCompat.EXTRA_ANSWER_COLOR) ? Integer.valueOf(bundle.getInt(NotificationCompat.EXTRA_ANSWER_COLOR)) : null;
            this.f4202h = bundle.containsKey(NotificationCompat.EXTRA_DECLINE_COLOR) ? Integer.valueOf(bundle.getInt(NotificationCompat.EXTRA_DECLINE_COLOR)) : null;
        }

        public n(@Nullable m mVar) {
            setBuilder(mVar);
        }

        private n(int i5, @NonNull y yVar, @Nullable PendingIntent pendingIntent, @Nullable PendingIntent pendingIntent2, @Nullable PendingIntent pendingIntent3) {
            if (yVar != null && !TextUtils.isEmpty(yVar.e())) {
                this.f4195a = i5;
                this.f4196b = yVar;
                this.f4197c = pendingIntent3;
                this.f4198d = pendingIntent2;
                this.f4199e = pendingIntent;
                return;
            }
            throw new IllegalArgumentException("person must have a non-empty a name");
        }
    }

    public static class o extends r {

        static class a {
            static Notification.Style a() {
                return new Notification.DecoratedCustomViewStyle();
            }
        }

        private RemoteViews h(RemoteViews remoteViews, boolean z4) {
            int min;
            int i5 = 0;
            RemoteViews applyStandardTemplate = applyStandardTemplate(true, o.g.f73280c, false);
            applyStandardTemplate.removeAllViews(o.e.f73225L);
            List j5 = j(this.mBuilder.f4170b);
            if (!z4 || j5 == null || (min = Math.min(j5.size(), 3)) <= 0) {
                i5 = 8;
            } else {
                for (int i6 = 0; i6 < min; i6++) {
                    applyStandardTemplate.addView(o.e.f73225L, i((b) j5.get(i6)));
                }
            }
            applyStandardTemplate.setViewVisibility(o.e.f73225L, i5);
            applyStandardTemplate.setViewVisibility(o.e.f73222I, i5);
            buildIntoRemoteViews(applyStandardTemplate, remoteViews);
            return applyStandardTemplate;
        }

        private RemoteViews i(b bVar) {
            boolean z4 = bVar.f4113k == null;
            RemoteViews remoteViews = new RemoteViews(this.mBuilder.f4169a.getPackageName(), z4 ? o.g.f73279b : o.g.f73278a);
            IconCompat d5 = bVar.d();
            if (d5 != null) {
                remoteViews.setImageViewBitmap(o.e.f73223J, createColoredBitmap(d5, o.b.f73199c));
            }
            remoteViews.setTextViewText(o.e.f73224K, bVar.f4112j);
            if (!z4) {
                remoteViews.setOnClickPendingIntent(o.e.f73221H, bVar.f4113k);
            }
            remoteViews.setContentDescription(o.e.f73221H, bVar.f4112j);
            return remoteViews;
        }

        private static List j(List list) {
            if (list == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            Iterator it = list.iterator();
            while (it.hasNext()) {
                b bVar = (b) it.next();
                if (!bVar.j()) {
                    arrayList.add(bVar);
                }
            }
            return arrayList;
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            if (Build.VERSION.SDK_INT >= 24) {
                mVar.a().setStyle(a.a());
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        public boolean displayCustomViewInline() {
            return true;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
        }

        @Override // androidx.core.app.NotificationCompat.r
        public RemoteViews makeBigContentView(androidx.core.app.m mVar) {
            if (Build.VERSION.SDK_INT >= 24) {
                return null;
            }
            RemoteViews h5 = this.mBuilder.h();
            if (h5 == null) {
                h5 = this.mBuilder.j();
            }
            if (h5 == null) {
                return null;
            }
            return h(h5, true);
        }

        @Override // androidx.core.app.NotificationCompat.r
        public RemoteViews makeContentView(androidx.core.app.m mVar) {
            if (Build.VERSION.SDK_INT < 24 && this.mBuilder.j() != null) {
                return h(this.mBuilder.j(), false);
            }
            return null;
        }

        @Override // androidx.core.app.NotificationCompat.r
        public RemoteViews makeHeadsUpContentView(androidx.core.app.m mVar) {
            if (Build.VERSION.SDK_INT >= 24) {
                return null;
            }
            RemoteViews m5 = this.mBuilder.m();
            RemoteViews j5 = m5 != null ? m5 : this.mBuilder.j();
            if (m5 == null) {
                return null;
            }
            return h(j5, true);
        }
    }

    public static abstract class r {
        CharSequence mBigContentTitle;
        protected m mBuilder;
        CharSequence mSummaryText;
        boolean mSummaryTextSet = false;

        static class a {
            static void a(RemoteViews remoteViews, int i5, boolean z4) {
                remoteViews.setChronometerCountDown(i5, z4);
            }
        }

        private int a() {
            Resources resources = this.mBuilder.f4169a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(o.c.f73208i);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(o.c.f73209j);
            float b5 = (b(resources.getConfiguration().fontScale, 1.0f, 1.3f) - 1.0f) / 0.29999995f;
            return Math.round(((1.0f - b5) * dimensionPixelSize) + (b5 * dimensionPixelSize2));
        }

        private static float b(float f5, float f6, float f7) {
            return f5 < f6 ? f6 : f5 > f7 ? f7 : f5;
        }

        private static r c(String str) {
            if (str == null) {
                return null;
            }
            if (str.equals(Notification.BigPictureStyle.class.getName())) {
                return new j();
            }
            if (str.equals(Notification.BigTextStyle.class.getName())) {
                return new k();
            }
            if (str.equals(Notification.InboxStyle.class.getName())) {
                return new p();
            }
            if (Build.VERSION.SDK_INT >= 24) {
                if (str.equals(androidx.core.app.q.a().getName())) {
                    return new q();
                }
                if (str.equals(androidx.core.app.r.a().getName())) {
                    return new o();
                }
            }
            return null;
        }

        @Nullable
        static r constructCompatStyleByName(@Nullable String str) {
            if (str == null) {
                return null;
            }
            switch (str) {
                case "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle":
                    return new o();
                case "androidx.core.app.NotificationCompat$BigPictureStyle":
                    return new j();
                case "androidx.core.app.NotificationCompat$CallStyle":
                    return new n();
                case "androidx.core.app.NotificationCompat$InboxStyle":
                    return new p();
                case "androidx.core.app.NotificationCompat$BigTextStyle":
                    return new k();
                case "androidx.core.app.NotificationCompat$MessagingStyle":
                    return new q();
                default:
                    return null;
            }
        }

        @Nullable
        static r constructCompatStyleForBundle(@NonNull Bundle bundle) {
            r constructCompatStyleByName = constructCompatStyleByName(bundle.getString(NotificationCompat.EXTRA_COMPAT_TEMPLATE));
            return constructCompatStyleByName != null ? constructCompatStyleByName : (bundle.containsKey(NotificationCompat.EXTRA_SELF_DISPLAY_NAME) || bundle.containsKey(NotificationCompat.EXTRA_MESSAGING_STYLE_USER)) ? new q() : (bundle.containsKey(NotificationCompat.EXTRA_PICTURE) || bundle.containsKey(NotificationCompat.EXTRA_PICTURE_ICON)) ? new j() : bundle.containsKey(NotificationCompat.EXTRA_BIG_TEXT) ? new k() : bundle.containsKey(NotificationCompat.EXTRA_TEXT_LINES) ? new p() : bundle.containsKey(NotificationCompat.EXTRA_CALL_TYPE) ? new n() : c(bundle.getString(NotificationCompat.EXTRA_TEMPLATE));
        }

        @Nullable
        static r constructStyleForExtras(@NonNull Bundle bundle) {
            r constructCompatStyleForBundle = constructCompatStyleForBundle(bundle);
            if (constructCompatStyleForBundle == null) {
                return null;
            }
            try {
                constructCompatStyleForBundle.restoreFromCompatExtras(bundle);
                return constructCompatStyleForBundle;
            } catch (ClassCastException unused) {
                return null;
            }
        }

        private Bitmap d(int i5, int i6, int i7) {
            return e(IconCompat.n(this.mBuilder.f4169a, i5), i6, i7);
        }

        private Bitmap e(IconCompat iconCompat, int i5, int i6) {
            Drawable x5 = iconCompat.x(this.mBuilder.f4169a);
            int intrinsicWidth = i6 == 0 ? x5.getIntrinsicWidth() : i6;
            if (i6 == 0) {
                i6 = x5.getIntrinsicHeight();
            }
            Bitmap createBitmap = Bitmap.createBitmap(intrinsicWidth, i6, Bitmap.Config.ARGB_8888);
            x5.setBounds(0, 0, intrinsicWidth, i6);
            if (i5 != 0) {
                x5.mutate().setColorFilter(new PorterDuffColorFilter(i5, PorterDuff.Mode.SRC_IN));
            }
            x5.draw(new Canvas(createBitmap));
            return createBitmap;
        }

        @Nullable
        public static r extractStyleFromNotification(@NonNull Notification notification) {
            Bundle extras = NotificationCompat.getExtras(notification);
            if (extras == null) {
                return null;
            }
            return constructStyleForExtras(extras);
        }

        private Bitmap f(int i5, int i6, int i7, int i8) {
            int i9 = o.d.f73213d;
            if (i8 == 0) {
                i8 = 0;
            }
            Bitmap d5 = d(i9, i8, i6);
            Canvas canvas = new Canvas(d5);
            Drawable mutate = this.mBuilder.f4169a.getResources().getDrawable(i5).mutate();
            mutate.setFilterBitmap(true);
            int i10 = (i6 - i7) / 2;
            int i11 = i7 + i10;
            mutate.setBounds(i10, i10, i11, i11);
            mutate.setColorFilter(new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
            mutate.draw(canvas);
            return d5;
        }

        private void g(RemoteViews remoteViews) {
            remoteViews.setViewVisibility(o.e.f73261k0, 8);
            remoteViews.setViewVisibility(o.e.f73257i0, 8);
            remoteViews.setViewVisibility(o.e.f73255h0, 8);
        }

        public void addCompatExtras(@NonNull Bundle bundle) {
            if (this.mSummaryTextSet) {
                bundle.putCharSequence(NotificationCompat.EXTRA_SUMMARY_TEXT, this.mSummaryText);
            }
            CharSequence charSequence = this.mBigContentTitle;
            if (charSequence != null) {
                bundle.putCharSequence(NotificationCompat.EXTRA_TITLE_BIG, charSequence);
            }
            String className = getClassName();
            if (className != null) {
                bundle.putString(NotificationCompat.EXTRA_COMPAT_TEMPLATE, className);
            }
        }

        public void apply(androidx.core.app.m mVar) {
        }

        /* JADX WARN: Removed duplicated region for block: B:20:0x010a  */
        /* JADX WARN: Removed duplicated region for block: B:29:0x0148  */
        /* JADX WARN: Removed duplicated region for block: B:38:0x0199  */
        /* JADX WARN: Removed duplicated region for block: B:41:0x01a4  */
        /* JADX WARN: Removed duplicated region for block: B:45:0x019b  */
        /* JADX WARN: Removed duplicated region for block: B:47:0x0194  */
        @androidx.annotation.NonNull
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public android.widget.RemoteViews applyStandardTemplate(boolean r13, int r14, boolean r15) {
            /*
                Method dump skipped, instructions count: 425
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.core.app.NotificationCompat.r.applyStandardTemplate(boolean, int, boolean):android.widget.RemoteViews");
        }

        @Nullable
        public Notification build() {
            m mVar = this.mBuilder;
            if (mVar != null) {
                return mVar.g();
            }
            return null;
        }

        public void buildIntoRemoteViews(RemoteViews remoteViews, RemoteViews remoteViews2) {
            g(remoteViews);
            remoteViews.removeAllViews(o.e.f73231R);
            remoteViews.addView(o.e.f73231R, remoteViews2.clone());
            remoteViews.setViewVisibility(o.e.f73231R, 0);
            remoteViews.setViewPadding(o.e.f73232S, 0, a(), 0, 0);
        }

        protected void clearCompatExtraKeys(@NonNull Bundle bundle) {
            bundle.remove(NotificationCompat.EXTRA_SUMMARY_TEXT);
            bundle.remove(NotificationCompat.EXTRA_TITLE_BIG);
            bundle.remove(NotificationCompat.EXTRA_COMPAT_TEMPLATE);
        }

        public Bitmap createColoredBitmap(int i5, int i6) {
            return d(i5, i6, 0);
        }

        public boolean displayCustomViewInline() {
            return false;
        }

        @Nullable
        protected String getClassName() {
            return null;
        }

        public RemoteViews makeBigContentView(androidx.core.app.m mVar) {
            return null;
        }

        public RemoteViews makeContentView(androidx.core.app.m mVar) {
            return null;
        }

        public RemoteViews makeHeadsUpContentView(androidx.core.app.m mVar) {
            return null;
        }

        protected void restoreFromCompatExtras(@NonNull Bundle bundle) {
            if (bundle.containsKey(NotificationCompat.EXTRA_SUMMARY_TEXT)) {
                this.mSummaryText = bundle.getCharSequence(NotificationCompat.EXTRA_SUMMARY_TEXT);
                this.mSummaryTextSet = true;
            }
            this.mBigContentTitle = bundle.getCharSequence(NotificationCompat.EXTRA_TITLE_BIG);
        }

        public void setBuilder(@Nullable m mVar) {
            if (this.mBuilder != mVar) {
                this.mBuilder = mVar;
                if (mVar != null) {
                    mVar.c0(this);
                }
            }
        }

        Bitmap createColoredBitmap(@NonNull IconCompat iconCompat, int i5) {
            return e(iconCompat, i5, 0);
        }
    }

    @Deprecated
    public NotificationCompat() {
    }

    @Nullable
    public static b getAction(@NonNull Notification notification, int i5) {
        return getActionCompatFromAction(notification.actions[i5]);
    }

    @NonNull
    static b getActionCompatFromAction(@NonNull Notification.Action action) {
        A[] aArr;
        int i5;
        RemoteInput[] g5 = c.g(action);
        if (g5 == null) {
            aArr = null;
        } else {
            A[] aArr2 = new A[g5.length];
            for (int i6 = 0; i6 < g5.length; i6++) {
                RemoteInput remoteInput = g5[i6];
                aArr2[i6] = new A(c.h(remoteInput), c.f(remoteInput), c.b(remoteInput), c.a(remoteInput), Build.VERSION.SDK_INT >= 29 ? h.c(remoteInput) : 0, c.d(remoteInput), null);
            }
            aArr = aArr2;
        }
        int i7 = Build.VERSION.SDK_INT;
        boolean z4 = i7 >= 24 ? c.c(action).getBoolean("android.support.allowGeneratedReplies") || e.a(action) : c.c(action).getBoolean("android.support.allowGeneratedReplies");
        boolean z5 = c.c(action).getBoolean("android.support.action.showsUserInterface", true);
        int a5 = i7 >= 28 ? g.a(action) : c.c(action).getInt("android.support.action.semanticAction", 0);
        boolean e5 = i7 >= 29 ? h.e(action) : false;
        boolean a6 = i7 >= 31 ? i.a(action) : false;
        if (d.a(action) != null || (i5 = action.icon) == 0) {
            return new b(d.a(action) != null ? IconCompat.g(d.a(action)) : null, action.title, action.actionIntent, c.c(action), aArr, (A[]) null, z4, a5, z5, e5, a6);
        }
        return new b(i5, action.title, action.actionIntent, c.c(action), aArr, (A[]) null, z4, a5, z5, e5, a6);
    }

    public static int getActionCount(@NonNull Notification notification) {
        Notification.Action[] actionArr = notification.actions;
        if (actionArr != null) {
            return actionArr.length;
        }
        return 0;
    }

    public static boolean getAllowSystemGeneratedContextualActions(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            return h.a(notification);
        }
        return false;
    }

    public static boolean getAutoCancel(@NonNull Notification notification) {
        return (notification.flags & 16) != 0;
    }

    public static int getBadgeIconType(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.a(notification);
        }
        return 0;
    }

    @Nullable
    public static l getBubbleMetadata(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            return l.a(h.b(notification));
        }
        return null;
    }

    @Nullable
    public static String getCategory(@NonNull Notification notification) {
        return notification.category;
    }

    @Nullable
    public static String getChannelId(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.b(notification);
        }
        return null;
    }

    public static int getColor(@NonNull Notification notification) {
        return notification.color;
    }

    @Nullable
    public static CharSequence getContentInfo(@NonNull Notification notification) {
        return notification.extras.getCharSequence(EXTRA_INFO_TEXT);
    }

    @Nullable
    public static CharSequence getContentText(@NonNull Notification notification) {
        return notification.extras.getCharSequence(EXTRA_TEXT);
    }

    @Nullable
    public static CharSequence getContentTitle(@NonNull Notification notification) {
        return notification.extras.getCharSequence(EXTRA_TITLE);
    }

    @Nullable
    public static Bundle getExtras(@NonNull Notification notification) {
        return notification.extras;
    }

    @Nullable
    public static String getGroup(@NonNull Notification notification) {
        return c.e(notification);
    }

    public static int getGroupAlertBehavior(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.c(notification);
        }
        return 0;
    }

    static boolean getHighPriority(@NonNull Notification notification) {
        return (notification.flags & 128) != 0;
    }

    @NonNull
    public static List<b> getInvisibleActions(@NonNull Notification notification) {
        Bundle bundle;
        ArrayList arrayList = new ArrayList();
        Bundle bundle2 = notification.extras.getBundle("android.car.EXTENSIONS");
        if (bundle2 != null && (bundle = bundle2.getBundle("invisible_actions")) != null) {
            for (int i5 = 0; i5 < bundle.size(); i5++) {
                arrayList.add(t.c(bundle.getBundle(Integer.toString(i5))));
            }
        }
        return arrayList;
    }

    public static boolean getLocalOnly(@NonNull Notification notification) {
        return (notification.flags & 256) != 0;
    }

    @Nullable
    public static androidx.core.content.b getLocusId(@NonNull Notification notification) {
        LocusId d5;
        if (Build.VERSION.SDK_INT < 29 || (d5 = h.d(notification)) == null) {
            return null;
        }
        return androidx.core.content.b.c(d5);
    }

    @NonNull
    static Notification[] getNotificationArrayFromBundle(@NonNull Bundle bundle, @NonNull String str) {
        Parcelable[] parcelableArray = bundle.getParcelableArray(str);
        if ((parcelableArray instanceof Notification[]) || parcelableArray == null) {
            return (Notification[]) parcelableArray;
        }
        Notification[] notificationArr = new Notification[parcelableArray.length];
        for (int i5 = 0; i5 < parcelableArray.length; i5++) {
            notificationArr[i5] = (Notification) parcelableArray[i5];
        }
        bundle.putParcelableArray(str, notificationArr);
        return notificationArr;
    }

    public static boolean getOngoing(@NonNull Notification notification) {
        return (notification.flags & 2) != 0;
    }

    public static boolean getOnlyAlertOnce(@NonNull Notification notification) {
        return (notification.flags & 8) != 0;
    }

    @NonNull
    public static List<y> getPeople(@NonNull Notification notification) {
        ArrayList arrayList = new ArrayList();
        int i5 = 0;
        if (Build.VERSION.SDK_INT >= 28) {
            ArrayList parcelableArrayList = notification.extras.getParcelableArrayList(EXTRA_PEOPLE_LIST);
            if (parcelableArrayList != null && !parcelableArrayList.isEmpty()) {
                int size = parcelableArrayList.size();
                while (i5 < size) {
                    Object obj = parcelableArrayList.get(i5);
                    i5++;
                    arrayList.add(y.a(androidx.core.app.n.a(obj)));
                }
            }
        } else {
            String[] stringArray = notification.extras.getStringArray(EXTRA_PEOPLE);
            if (stringArray != null && stringArray.length != 0) {
                int length = stringArray.length;
                while (i5 < length) {
                    arrayList.add(new y.b().g(stringArray[i5]).a());
                    i5++;
                }
            }
        }
        return arrayList;
    }

    @Nullable
    public static Notification getPublicVersion(@NonNull Notification notification) {
        return notification.publicVersion;
    }

    @Nullable
    public static CharSequence getSettingsText(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.d(notification);
        }
        return null;
    }

    @Nullable
    public static String getShortcutId(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.e(notification);
        }
        return null;
    }

    public static boolean getShowWhen(@NonNull Notification notification) {
        return notification.extras.getBoolean(EXTRA_SHOW_WHEN);
    }

    @Nullable
    public static String getSortKey(@NonNull Notification notification) {
        return c.i(notification);
    }

    @Nullable
    public static CharSequence getSubText(@NonNull Notification notification) {
        return notification.extras.getCharSequence(EXTRA_SUB_TEXT);
    }

    public static long getTimeoutAfter(@NonNull Notification notification) {
        if (Build.VERSION.SDK_INT >= 26) {
            return f.f(notification);
        }
        return 0L;
    }

    public static boolean getUsesChronometer(@NonNull Notification notification) {
        return notification.extras.getBoolean(EXTRA_SHOW_CHRONOMETER);
    }

    public static int getVisibility(@NonNull Notification notification) {
        return notification.visibility;
    }

    public static boolean isGroupSummary(@NonNull Notification notification) {
        return (notification.flags & 512) != 0;
    }

    @Nullable
    public static Bitmap reduceLargeIconSize(@NonNull Context context, @Nullable Bitmap bitmap) {
        if (bitmap == null || Build.VERSION.SDK_INT >= 27) {
            return bitmap;
        }
        Resources resources = context.getResources();
        int dimensionPixelSize = resources.getDimensionPixelSize(o.c.f73201b);
        int dimensionPixelSize2 = resources.getDimensionPixelSize(o.c.f73200a);
        if (bitmap.getWidth() <= dimensionPixelSize && bitmap.getHeight() <= dimensionPixelSize2) {
            return bitmap;
        }
        double min = Math.min(dimensionPixelSize / Math.max(1, bitmap.getWidth()), dimensionPixelSize2 / Math.max(1, bitmap.getHeight()));
        return Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(bitmap.getWidth() * min), (int) Math.ceil(bitmap.getHeight() * min), true);
    }

    public static class p extends r {

        /* renamed from: a, reason: collision with root package name */
        private ArrayList f4205a = new ArrayList();

        public p() {
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            Notification.InboxStyle bigContentTitle = new Notification.InboxStyle(mVar.a()).setBigContentTitle(this.mBigContentTitle);
            if (this.mSummaryTextSet) {
                bigContentTitle.setSummaryText(this.mSummaryText);
            }
            ArrayList arrayList = this.f4205a;
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                bigContentTitle.addLine((CharSequence) obj);
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void clearCompatExtraKeys(Bundle bundle) {
            super.clearCompatExtraKeys(bundle);
            bundle.remove(NotificationCompat.EXTRA_TEXT_LINES);
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$InboxStyle";
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void restoreFromCompatExtras(Bundle bundle) {
            super.restoreFromCompatExtras(bundle);
            this.f4205a.clear();
            if (bundle.containsKey(NotificationCompat.EXTRA_TEXT_LINES)) {
                Collections.addAll(this.f4205a, bundle.getCharSequenceArray(NotificationCompat.EXTRA_TEXT_LINES));
            }
        }

        public p(@Nullable m mVar) {
            setBuilder(mVar);
        }
    }

    public static class q extends r {

        /* renamed from: a, reason: collision with root package name */
        private final List f4206a = new ArrayList();

        /* renamed from: b, reason: collision with root package name */
        private final List f4207b = new ArrayList();

        /* renamed from: c, reason: collision with root package name */
        private y f4208c;

        /* renamed from: d, reason: collision with root package name */
        private CharSequence f4209d;

        /* renamed from: e, reason: collision with root package name */
        private Boolean f4210e;

        static class a {
            static Notification.MessagingStyle a(Notification.MessagingStyle messagingStyle, Notification.MessagingStyle.Message message) {
                return messagingStyle.addMessage(message);
            }

            static Notification.MessagingStyle b(CharSequence charSequence) {
                return new Notification.MessagingStyle(charSequence);
            }

            static Notification.MessagingStyle c(Notification.MessagingStyle messagingStyle, CharSequence charSequence) {
                return messagingStyle.setConversationTitle(charSequence);
            }
        }

        static class b {
            static Notification.MessagingStyle a(Notification.MessagingStyle messagingStyle, Notification.MessagingStyle.Message message) {
                return messagingStyle.addHistoricMessage(message);
            }
        }

        static class c {
            static Notification.MessagingStyle a(Person person) {
                return new Notification.MessagingStyle(person);
            }

            static Notification.MessagingStyle b(Notification.MessagingStyle messagingStyle, boolean z4) {
                return messagingStyle.setGroupConversation(z4);
            }
        }

        q() {
        }

        private d h() {
            for (int size = this.f4206a.size() - 1; size >= 0; size--) {
                d dVar = (d) this.f4206a.get(size);
                if (dVar.g() != null && !TextUtils.isEmpty(dVar.g().e())) {
                    return dVar;
                }
            }
            if (this.f4206a.isEmpty()) {
                return null;
            }
            return (d) this.f4206a.get(r0.size() - 1);
        }

        private boolean i() {
            for (int size = this.f4206a.size() - 1; size >= 0; size--) {
                d dVar = (d) this.f4206a.get(size);
                if (dVar.g() != null && dVar.g().e() == null) {
                    return true;
                }
            }
            return false;
        }

        private TextAppearanceSpan k(int i5) {
            return new TextAppearanceSpan(null, 0, 0, ColorStateList.valueOf(i5), null);
        }

        private CharSequence l(d dVar) {
            androidx.core.text.a c5 = androidx.core.text.a.c();
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            CharSequence e5 = dVar.g() == null ? "" : dVar.g().e();
            int i5 = -16777216;
            if (TextUtils.isEmpty(e5)) {
                e5 = this.f4208c.e();
                if (this.mBuilder.i() != 0) {
                    i5 = this.mBuilder.i();
                }
            }
            CharSequence h5 = c5.h(e5);
            spannableStringBuilder.append(h5);
            spannableStringBuilder.setSpan(k(i5), spannableStringBuilder.length() - h5.length(), spannableStringBuilder.length(), 33);
            spannableStringBuilder.append((CharSequence) "  ").append(c5.h(dVar.h() != null ? dVar.h() : ""));
            return spannableStringBuilder;
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void addCompatExtras(Bundle bundle) {
            super.addCompatExtras(bundle);
            bundle.putCharSequence(NotificationCompat.EXTRA_SELF_DISPLAY_NAME, this.f4208c.e());
            bundle.putBundle(NotificationCompat.EXTRA_MESSAGING_STYLE_USER, this.f4208c.k());
            bundle.putCharSequence(NotificationCompat.EXTRA_HIDDEN_CONVERSATION_TITLE, this.f4209d);
            if (this.f4209d != null && this.f4210e.booleanValue()) {
                bundle.putCharSequence(NotificationCompat.EXTRA_CONVERSATION_TITLE, this.f4209d);
            }
            if (!this.f4206a.isEmpty()) {
                bundle.putParcelableArray(NotificationCompat.EXTRA_MESSAGES, d.a(this.f4206a));
            }
            if (!this.f4207b.isEmpty()) {
                bundle.putParcelableArray(NotificationCompat.EXTRA_HISTORIC_MESSAGES, d.a(this.f4207b));
            }
            Boolean bool = this.f4210e;
            if (bool != null) {
                bundle.putBoolean(NotificationCompat.EXTRA_IS_GROUP_CONVERSATION, bool.booleanValue());
            }
        }

        @Override // androidx.core.app.NotificationCompat.r
        public void apply(androidx.core.app.m mVar) {
            m(j());
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 24) {
                Notification.MessagingStyle a5 = i5 >= 28 ? c.a(this.f4208c.j()) : a.b(this.f4208c.e());
                Iterator it = this.f4206a.iterator();
                while (it.hasNext()) {
                    a.a(androidx.core.app.p.a(a5), ((d) it.next()).k());
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    Iterator it2 = this.f4207b.iterator();
                    while (it2.hasNext()) {
                        b.a(androidx.core.app.p.a(a5), ((d) it2.next()).k());
                    }
                }
                if (this.f4210e.booleanValue() || Build.VERSION.SDK_INT >= 28) {
                    a.c(androidx.core.app.p.a(a5), this.f4209d);
                }
                if (Build.VERSION.SDK_INT >= 28) {
                    c.b(androidx.core.app.p.a(a5), this.f4210e.booleanValue());
                }
                a5.setBuilder(mVar.a());
                return;
            }
            d h5 = h();
            if (this.f4209d != null && this.f4210e.booleanValue()) {
                mVar.a().setContentTitle(this.f4209d);
            } else if (h5 != null) {
                mVar.a().setContentTitle("");
                if (h5.g() != null) {
                    mVar.a().setContentTitle(h5.g().e());
                }
            }
            if (h5 != null) {
                mVar.a().setContentText(this.f4209d != null ? l(h5) : h5.h());
            }
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            boolean z4 = this.f4209d != null || i();
            for (int size = this.f4206a.size() - 1; size >= 0; size--) {
                d dVar = (d) this.f4206a.get(size);
                CharSequence l5 = z4 ? l(dVar) : dVar.h();
                if (size != this.f4206a.size() - 1) {
                    spannableStringBuilder.insert(0, (CharSequence) "\n");
                }
                spannableStringBuilder.insert(0, l5);
            }
            new Notification.BigTextStyle(mVar.a()).setBigContentTitle(null).bigText(spannableStringBuilder);
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void clearCompatExtraKeys(Bundle bundle) {
            super.clearCompatExtraKeys(bundle);
            bundle.remove(NotificationCompat.EXTRA_MESSAGING_STYLE_USER);
            bundle.remove(NotificationCompat.EXTRA_SELF_DISPLAY_NAME);
            bundle.remove(NotificationCompat.EXTRA_CONVERSATION_TITLE);
            bundle.remove(NotificationCompat.EXTRA_HIDDEN_CONVERSATION_TITLE);
            bundle.remove(NotificationCompat.EXTRA_MESSAGES);
            bundle.remove(NotificationCompat.EXTRA_HISTORIC_MESSAGES);
            bundle.remove(NotificationCompat.EXTRA_IS_GROUP_CONVERSATION);
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected String getClassName() {
            return "androidx.core.app.NotificationCompat$MessagingStyle";
        }

        public boolean j() {
            m mVar = this.mBuilder;
            if (mVar != null && mVar.f4169a.getApplicationInfo().targetSdkVersion < 28 && this.f4210e == null) {
                return this.f4209d != null;
            }
            Boolean bool = this.f4210e;
            if (bool != null) {
                return bool.booleanValue();
            }
            return false;
        }

        public q m(boolean z4) {
            this.f4210e = Boolean.valueOf(z4);
            return this;
        }

        @Override // androidx.core.app.NotificationCompat.r
        protected void restoreFromCompatExtras(Bundle bundle) {
            super.restoreFromCompatExtras(bundle);
            this.f4206a.clear();
            if (bundle.containsKey(NotificationCompat.EXTRA_MESSAGING_STYLE_USER)) {
                this.f4208c = y.b(bundle.getBundle(NotificationCompat.EXTRA_MESSAGING_STYLE_USER));
            } else {
                this.f4208c = new y.b().f(bundle.getString(NotificationCompat.EXTRA_SELF_DISPLAY_NAME)).a();
            }
            CharSequence charSequence = bundle.getCharSequence(NotificationCompat.EXTRA_CONVERSATION_TITLE);
            this.f4209d = charSequence;
            if (charSequence == null) {
                this.f4209d = bundle.getCharSequence(NotificationCompat.EXTRA_HIDDEN_CONVERSATION_TITLE);
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray(NotificationCompat.EXTRA_MESSAGES);
            if (parcelableArray != null) {
                this.f4206a.addAll(d.f(parcelableArray));
            }
            Parcelable[] parcelableArray2 = bundle.getParcelableArray(NotificationCompat.EXTRA_HISTORIC_MESSAGES);
            if (parcelableArray2 != null) {
                this.f4207b.addAll(d.f(parcelableArray2));
            }
            if (bundle.containsKey(NotificationCompat.EXTRA_IS_GROUP_CONVERSATION)) {
                this.f4210e = Boolean.valueOf(bundle.getBoolean(NotificationCompat.EXTRA_IS_GROUP_CONVERSATION));
            }
        }

        @Deprecated
        public q(@NonNull CharSequence charSequence) {
            this.f4208c = new y.b().f(charSequence).a();
        }

        public static final class d {

            /* renamed from: a, reason: collision with root package name */
            private final CharSequence f4211a;

            /* renamed from: b, reason: collision with root package name */
            private final long f4212b;

            /* renamed from: c, reason: collision with root package name */
            private final y f4213c;

            /* renamed from: d, reason: collision with root package name */
            private Bundle f4214d;

            /* renamed from: e, reason: collision with root package name */
            private String f4215e;

            /* renamed from: f, reason: collision with root package name */
            private Uri f4216f;

            static class a {
                static Notification.MessagingStyle.Message a(CharSequence charSequence, long j5, CharSequence charSequence2) {
                    return new Notification.MessagingStyle.Message(charSequence, j5, charSequence2);
                }

                static Notification.MessagingStyle.Message b(Notification.MessagingStyle.Message message, String str, Uri uri) {
                    return message.setData(str, uri);
                }
            }

            static class b {
                static Parcelable a(Person person) {
                    return person;
                }

                static Notification.MessagingStyle.Message b(CharSequence charSequence, long j5, Person person) {
                    return new Notification.MessagingStyle.Message(charSequence, j5, person);
                }
            }

            public d(@Nullable CharSequence charSequence, long j5, @Nullable y yVar) {
                this.f4214d = new Bundle();
                this.f4211a = charSequence;
                this.f4212b = j5;
                this.f4213c = yVar;
            }

            static Bundle[] a(List list) {
                Bundle[] bundleArr = new Bundle[list.size()];
                int size = list.size();
                for (int i5 = 0; i5 < size; i5++) {
                    bundleArr[i5] = ((d) list.get(i5)).l();
                }
                return bundleArr;
            }

            static d e(Bundle bundle) {
                try {
                    if (bundle.containsKey("text") && bundle.containsKey("time")) {
                        d dVar = new d(bundle.getCharSequence("text"), bundle.getLong("time"), bundle.containsKey("person") ? y.b(bundle.getBundle("person")) : (!bundle.containsKey("sender_person") || Build.VERSION.SDK_INT < 28) ? bundle.containsKey("sender") ? new y.b().f(bundle.getCharSequence("sender")).a() : null : y.a(androidx.core.app.n.a(bundle.getParcelable("sender_person"))));
                        if (bundle.containsKey("type") && bundle.containsKey("uri")) {
                            dVar.j(bundle.getString("type"), (Uri) bundle.getParcelable("uri"));
                        }
                        if (bundle.containsKey("extras")) {
                            dVar.d().putAll(bundle.getBundle("extras"));
                        }
                        return dVar;
                    }
                } catch (ClassCastException unused) {
                }
                return null;
            }

            static List f(Parcelable[] parcelableArr) {
                d e5;
                ArrayList arrayList = new ArrayList(parcelableArr.length);
                for (Parcelable parcelable : parcelableArr) {
                    if ((parcelable instanceof Bundle) && (e5 = e((Bundle) parcelable)) != null) {
                        arrayList.add(e5);
                    }
                }
                return arrayList;
            }

            private Bundle l() {
                Bundle bundle = new Bundle();
                CharSequence charSequence = this.f4211a;
                if (charSequence != null) {
                    bundle.putCharSequence("text", charSequence);
                }
                bundle.putLong("time", this.f4212b);
                y yVar = this.f4213c;
                if (yVar != null) {
                    bundle.putCharSequence("sender", yVar.e());
                    if (Build.VERSION.SDK_INT >= 28) {
                        bundle.putParcelable("sender_person", b.a(this.f4213c.j()));
                    } else {
                        bundle.putBundle("person", this.f4213c.k());
                    }
                }
                String str = this.f4215e;
                if (str != null) {
                    bundle.putString("type", str);
                }
                Uri uri = this.f4216f;
                if (uri != null) {
                    bundle.putParcelable("uri", uri);
                }
                Bundle bundle2 = this.f4214d;
                if (bundle2 != null) {
                    bundle.putBundle("extras", bundle2);
                }
                return bundle;
            }

            public String b() {
                return this.f4215e;
            }

            public Uri c() {
                return this.f4216f;
            }

            public Bundle d() {
                return this.f4214d;
            }

            public y g() {
                return this.f4213c;
            }

            public CharSequence h() {
                return this.f4211a;
            }

            public long i() {
                return this.f4212b;
            }

            public d j(String str, Uri uri) {
                this.f4215e = str;
                this.f4216f = uri;
                return this;
            }

            Notification.MessagingStyle.Message k() {
                Notification.MessagingStyle.Message a5;
                y g5 = g();
                if (Build.VERSION.SDK_INT >= 28) {
                    a5 = b.b(h(), i(), g5 != null ? g5.j() : null);
                } else {
                    a5 = a.a(h(), i(), g5 != null ? g5.e() : null);
                }
                if (b() != null) {
                    a.b(a5, b(), c());
                }
                return a5;
            }

            @Deprecated
            public d(@Nullable CharSequence charSequence, long j5, @Nullable CharSequence charSequence2) {
                this(charSequence, j5, new y.b().f(charSequence2).a());
            }
        }

        public q(@NonNull y yVar) {
            if (!TextUtils.isEmpty(yVar.e())) {
                this.f4208c = yVar;
                return;
            }
            throw new IllegalArgumentException("User's name must not be empty.");
        }
    }

    public static class m {

        /* renamed from: A, reason: collision with root package name */
        boolean f4145A;

        /* renamed from: B, reason: collision with root package name */
        boolean f4146B;

        /* renamed from: C, reason: collision with root package name */
        boolean f4147C;

        /* renamed from: D, reason: collision with root package name */
        String f4148D;

        /* renamed from: E, reason: collision with root package name */
        Bundle f4149E;

        /* renamed from: F, reason: collision with root package name */
        int f4150F;

        /* renamed from: G, reason: collision with root package name */
        int f4151G;

        /* renamed from: H, reason: collision with root package name */
        Notification f4152H;

        /* renamed from: I, reason: collision with root package name */
        RemoteViews f4153I;

        /* renamed from: J, reason: collision with root package name */
        RemoteViews f4154J;

        /* renamed from: K, reason: collision with root package name */
        RemoteViews f4155K;

        /* renamed from: L, reason: collision with root package name */
        String f4156L;

        /* renamed from: M, reason: collision with root package name */
        int f4157M;

        /* renamed from: N, reason: collision with root package name */
        String f4158N;

        /* renamed from: O, reason: collision with root package name */
        androidx.core.content.b f4159O;

        /* renamed from: P, reason: collision with root package name */
        long f4160P;

        /* renamed from: Q, reason: collision with root package name */
        int f4161Q;

        /* renamed from: R, reason: collision with root package name */
        int f4162R;

        /* renamed from: S, reason: collision with root package name */
        boolean f4163S;

        /* renamed from: T, reason: collision with root package name */
        l f4164T;

        /* renamed from: U, reason: collision with root package name */
        Notification f4165U;

        /* renamed from: V, reason: collision with root package name */
        boolean f4166V;

        /* renamed from: W, reason: collision with root package name */
        Object f4167W;

        /* renamed from: X, reason: collision with root package name */
        public ArrayList f4168X;

        /* renamed from: a, reason: collision with root package name */
        public Context f4169a;

        /* renamed from: b, reason: collision with root package name */
        public ArrayList f4170b;

        /* renamed from: c, reason: collision with root package name */
        public ArrayList f4171c;

        /* renamed from: d, reason: collision with root package name */
        ArrayList f4172d;

        /* renamed from: e, reason: collision with root package name */
        CharSequence f4173e;

        /* renamed from: f, reason: collision with root package name */
        CharSequence f4174f;

        /* renamed from: g, reason: collision with root package name */
        PendingIntent f4175g;

        /* renamed from: h, reason: collision with root package name */
        PendingIntent f4176h;

        /* renamed from: i, reason: collision with root package name */
        RemoteViews f4177i;

        /* renamed from: j, reason: collision with root package name */
        IconCompat f4178j;

        /* renamed from: k, reason: collision with root package name */
        CharSequence f4179k;

        /* renamed from: l, reason: collision with root package name */
        int f4180l;

        /* renamed from: m, reason: collision with root package name */
        int f4181m;

        /* renamed from: n, reason: collision with root package name */
        boolean f4182n;

        /* renamed from: o, reason: collision with root package name */
        boolean f4183o;

        /* renamed from: p, reason: collision with root package name */
        boolean f4184p;

        /* renamed from: q, reason: collision with root package name */
        r f4185q;

        /* renamed from: r, reason: collision with root package name */
        CharSequence f4186r;

        /* renamed from: s, reason: collision with root package name */
        CharSequence f4187s;

        /* renamed from: t, reason: collision with root package name */
        CharSequence[] f4188t;

        /* renamed from: u, reason: collision with root package name */
        int f4189u;

        /* renamed from: v, reason: collision with root package name */
        int f4190v;

        /* renamed from: w, reason: collision with root package name */
        boolean f4191w;

        /* renamed from: x, reason: collision with root package name */
        String f4192x;

        /* renamed from: y, reason: collision with root package name */
        boolean f4193y;

        /* renamed from: z, reason: collision with root package name */
        String f4194z;

        static class a {
            static AudioAttributes a(AudioAttributes.Builder builder) {
                return builder.build();
            }

            static AudioAttributes.Builder b() {
                return new AudioAttributes.Builder();
            }

            static AudioAttributes.Builder c(AudioAttributes.Builder builder, int i5) {
                return builder.setContentType(i5);
            }

            static AudioAttributes.Builder d(AudioAttributes.Builder builder, int i5) {
                return builder.setLegacyStreamType(i5);
            }

            static AudioAttributes.Builder e(AudioAttributes.Builder builder, int i5) {
                return builder.setUsage(i5);
            }
        }

        static class b {
            static Icon a(Notification notification) {
                return notification.getLargeIcon();
            }

            static Icon b(Notification notification) {
                return notification.getSmallIcon();
            }
        }

        public m(@NonNull Context context, @NonNull Notification notification) {
            this(context, NotificationCompat.getChannelId(notification));
            ArrayList parcelableArrayList;
            Bundle bundle = notification.extras;
            r extractStyleFromNotification = r.extractStyleFromNotification(notification);
            C(NotificationCompat.getContentTitle(notification)).B(NotificationCompat.getContentText(notification)).z(NotificationCompat.getContentInfo(notification)).d0(NotificationCompat.getSubText(notification)).U(NotificationCompat.getSettingsText(notification)).c0(extractStyleFromNotification).I(NotificationCompat.getGroup(notification)).J(NotificationCompat.isGroupSummary(notification)).N(NotificationCompat.getLocusId(notification)).j0(notification.when).W(NotificationCompat.getShowWhen(notification)).g0(NotificationCompat.getUsesChronometer(notification)).r(NotificationCompat.getAutoCancel(notification)).Q(NotificationCompat.getOnlyAlertOnce(notification)).P(NotificationCompat.getOngoing(notification)).M(NotificationCompat.getLocalOnly(notification)).K(notification.largeIcon).s(NotificationCompat.getBadgeIconType(notification)).u(NotificationCompat.getCategory(notification)).t(NotificationCompat.getBubbleMetadata(notification)).O(notification.number).e0(notification.tickerText).A(notification.contentIntent).E(notification.deleteIntent).H(notification.fullScreenIntent, NotificationCompat.getHighPriority(notification)).b0(notification.sound, notification.audioStreamType).h0(notification.vibrate).L(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).D(notification.defaults).R(notification.priority).x(NotificationCompat.getColor(notification)).i0(NotificationCompat.getVisibility(notification)).T(NotificationCompat.getPublicVersion(notification)).Z(NotificationCompat.getSortKey(notification)).f0(NotificationCompat.getTimeoutAfter(notification)).V(NotificationCompat.getShortcutId(notification)).S(bundle.getInt(NotificationCompat.EXTRA_PROGRESS_MAX), bundle.getInt(NotificationCompat.EXTRA_PROGRESS), bundle.getBoolean(NotificationCompat.EXTRA_PROGRESS_INDETERMINATE)).q(NotificationCompat.getAllowSystemGeneratedContextualActions(notification)).Y(notification.icon, notification.iconLevel).c(l(notification, extractStyleFromNotification));
            this.f4167W = b.b(notification);
            Icon a5 = b.a(notification);
            if (a5 != null) {
                this.f4178j = IconCompat.f(a5);
            }
            Notification.Action[] actionArr = notification.actions;
            int i5 = 0;
            if (actionArr != null && actionArr.length != 0) {
                for (Notification.Action action : actionArr) {
                    b(b.a.e(action).c());
                }
            }
            List<b> invisibleActions = NotificationCompat.getInvisibleActions(notification);
            if (!invisibleActions.isEmpty()) {
                Iterator<b> it = invisibleActions.iterator();
                while (it.hasNext()) {
                    d(it.next());
                }
            }
            String[] stringArray = notification.extras.getStringArray(NotificationCompat.EXTRA_PEOPLE);
            if (stringArray != null && stringArray.length != 0) {
                for (String str : stringArray) {
                    f(str);
                }
            }
            if (Build.VERSION.SDK_INT >= 28 && (parcelableArrayList = notification.extras.getParcelableArrayList(NotificationCompat.EXTRA_PEOPLE_LIST)) != null && !parcelableArrayList.isEmpty()) {
                int size = parcelableArrayList.size();
                while (i5 < size) {
                    Object obj = parcelableArrayList.get(i5);
                    i5++;
                    e(y.a(androidx.core.app.n.a(obj)));
                }
            }
            int i6 = Build.VERSION.SDK_INT;
            if (i6 >= 24 && bundle.containsKey(NotificationCompat.EXTRA_CHRONOMETER_COUNT_DOWN)) {
                w(bundle.getBoolean(NotificationCompat.EXTRA_CHRONOMETER_COUNT_DOWN));
            }
            if (i6 < 26 || !bundle.containsKey(NotificationCompat.EXTRA_COLORIZED)) {
                return;
            }
            y(bundle.getBoolean(NotificationCompat.EXTRA_COLORIZED));
        }

        private void F(int i5, boolean z4) {
            if (z4) {
                Notification notification = this.f4165U;
                notification.flags = i5 | notification.flags;
            } else {
                Notification notification2 = this.f4165U;
                notification2.flags = (~i5) & notification2.flags;
            }
        }

        private static Bundle l(Notification notification, r rVar) {
            if (notification.extras == null) {
                return null;
            }
            Bundle bundle = new Bundle(notification.extras);
            bundle.remove(NotificationCompat.EXTRA_TITLE);
            bundle.remove(NotificationCompat.EXTRA_TEXT);
            bundle.remove(NotificationCompat.EXTRA_INFO_TEXT);
            bundle.remove(NotificationCompat.EXTRA_SUB_TEXT);
            bundle.remove(NotificationCompat.EXTRA_CHANNEL_ID);
            bundle.remove(NotificationCompat.EXTRA_CHANNEL_GROUP_ID);
            bundle.remove(NotificationCompat.EXTRA_SHOW_WHEN);
            bundle.remove(NotificationCompat.EXTRA_PROGRESS);
            bundle.remove(NotificationCompat.EXTRA_PROGRESS_MAX);
            bundle.remove(NotificationCompat.EXTRA_PROGRESS_INDETERMINATE);
            bundle.remove(NotificationCompat.EXTRA_CHRONOMETER_COUNT_DOWN);
            bundle.remove(NotificationCompat.EXTRA_COLORIZED);
            bundle.remove(NotificationCompat.EXTRA_PEOPLE_LIST);
            bundle.remove(NotificationCompat.EXTRA_PEOPLE);
            bundle.remove("android.support.sortKey");
            bundle.remove("android.support.groupKey");
            bundle.remove("android.support.isGroupSummary");
            bundle.remove("android.support.localOnly");
            bundle.remove("android.support.actionExtras");
            Bundle bundle2 = bundle.getBundle("android.car.EXTENSIONS");
            if (bundle2 != null) {
                Bundle bundle3 = new Bundle(bundle2);
                bundle3.remove("invisible_actions");
                bundle.putBundle("android.car.EXTENSIONS", bundle3);
            }
            if (rVar != null) {
                rVar.clearCompatExtraKeys(bundle);
            }
            return bundle;
        }

        protected static CharSequence p(CharSequence charSequence) {
            return charSequence == null ? charSequence : charSequence.length() > 5120 ? charSequence.subSequence(0, GL20.GL_BYTE) : charSequence;
        }

        public m A(PendingIntent pendingIntent) {
            this.f4175g = pendingIntent;
            return this;
        }

        public m B(CharSequence charSequence) {
            this.f4174f = p(charSequence);
            return this;
        }

        public m C(CharSequence charSequence) {
            this.f4173e = p(charSequence);
            return this;
        }

        public m D(int i5) {
            Notification notification = this.f4165U;
            notification.defaults = i5;
            if ((i5 & 4) != 0) {
                notification.flags |= 1;
            }
            return this;
        }

        public m E(PendingIntent pendingIntent) {
            this.f4165U.deleteIntent = pendingIntent;
            return this;
        }

        public m G(int i5) {
            this.f4162R = i5;
            return this;
        }

        public m H(PendingIntent pendingIntent, boolean z4) {
            this.f4176h = pendingIntent;
            F(128, z4);
            return this;
        }

        public m I(String str) {
            this.f4192x = str;
            return this;
        }

        public m J(boolean z4) {
            this.f4193y = z4;
            return this;
        }

        public m K(Bitmap bitmap) {
            this.f4178j = bitmap == null ? null : IconCompat.k(NotificationCompat.reduceLargeIconSize(this.f4169a, bitmap));
            return this;
        }

        public m L(int i5, int i6, int i7) {
            Notification notification = this.f4165U;
            notification.ledARGB = i5;
            notification.ledOnMS = i6;
            notification.ledOffMS = i7;
            notification.flags = ((i6 == 0 || i7 == 0) ? 0 : 1) | (notification.flags & (-2));
            return this;
        }

        public m M(boolean z4) {
            this.f4145A = z4;
            return this;
        }

        public m N(androidx.core.content.b bVar) {
            this.f4159O = bVar;
            return this;
        }

        public m O(int i5) {
            this.f4180l = i5;
            return this;
        }

        public m P(boolean z4) {
            F(2, z4);
            return this;
        }

        public m Q(boolean z4) {
            F(8, z4);
            return this;
        }

        public m R(int i5) {
            this.f4181m = i5;
            return this;
        }

        public m S(int i5, int i6, boolean z4) {
            this.f4189u = i5;
            this.f4190v = i6;
            this.f4191w = z4;
            return this;
        }

        public m T(Notification notification) {
            this.f4152H = notification;
            return this;
        }

        public m U(CharSequence charSequence) {
            this.f4187s = p(charSequence);
            return this;
        }

        public m V(String str) {
            this.f4158N = str;
            return this;
        }

        public m W(boolean z4) {
            this.f4182n = z4;
            return this;
        }

        public m X(int i5) {
            this.f4165U.icon = i5;
            return this;
        }

        public m Y(int i5, int i6) {
            Notification notification = this.f4165U;
            notification.icon = i5;
            notification.iconLevel = i6;
            return this;
        }

        public m Z(String str) {
            this.f4194z = str;
            return this;
        }

        public m a(int i5, CharSequence charSequence, PendingIntent pendingIntent) {
            this.f4170b.add(new b(i5, charSequence, pendingIntent));
            return this;
        }

        public m a0(Uri uri) {
            Notification notification = this.f4165U;
            notification.sound = uri;
            notification.audioStreamType = -1;
            AudioAttributes.Builder e5 = a.e(a.c(a.b(), 4), 5);
            this.f4165U.audioAttributes = a.a(e5);
            return this;
        }

        public m b(b bVar) {
            if (bVar != null) {
                this.f4170b.add(bVar);
            }
            return this;
        }

        public m b0(Uri uri, int i5) {
            Notification notification = this.f4165U;
            notification.sound = uri;
            notification.audioStreamType = i5;
            AudioAttributes.Builder d5 = a.d(a.c(a.b(), 4), i5);
            this.f4165U.audioAttributes = a.a(d5);
            return this;
        }

        public m c(Bundle bundle) {
            if (bundle != null) {
                Bundle bundle2 = this.f4149E;
                if (bundle2 == null) {
                    this.f4149E = new Bundle(bundle);
                    return this;
                }
                bundle2.putAll(bundle);
            }
            return this;
        }

        public m c0(r rVar) {
            if (this.f4185q != rVar) {
                this.f4185q = rVar;
                if (rVar != null) {
                    rVar.setBuilder(this);
                }
            }
            return this;
        }

        public m d(b bVar) {
            if (bVar != null) {
                this.f4172d.add(bVar);
            }
            return this;
        }

        public m d0(CharSequence charSequence) {
            this.f4186r = p(charSequence);
            return this;
        }

        public m e(y yVar) {
            if (yVar != null) {
                this.f4171c.add(yVar);
            }
            return this;
        }

        public m e0(CharSequence charSequence) {
            this.f4165U.tickerText = p(charSequence);
            return this;
        }

        public m f(String str) {
            if (str != null && !str.isEmpty()) {
                this.f4168X.add(str);
            }
            return this;
        }

        public m f0(long j5) {
            this.f4160P = j5;
            return this;
        }

        public Notification g() {
            return new s(this).c();
        }

        public m g0(boolean z4) {
            this.f4183o = z4;
            return this;
        }

        public RemoteViews h() {
            return this.f4154J;
        }

        public m h0(long[] jArr) {
            this.f4165U.vibrate = jArr;
            return this;
        }

        public int i() {
            return this.f4150F;
        }

        public m i0(int i5) {
            this.f4151G = i5;
            return this;
        }

        public RemoteViews j() {
            return this.f4153I;
        }

        public m j0(long j5) {
            this.f4165U.when = j5;
            return this;
        }

        public Bundle k() {
            if (this.f4149E == null) {
                this.f4149E = new Bundle();
            }
            return this.f4149E;
        }

        public RemoteViews m() {
            return this.f4155K;
        }

        public int n() {
            return this.f4181m;
        }

        public long o() {
            if (this.f4182n) {
                return this.f4165U.when;
            }
            return 0L;
        }

        public m q(boolean z4) {
            this.f4163S = z4;
            return this;
        }

        public m r(boolean z4) {
            F(16, z4);
            return this;
        }

        public m s(int i5) {
            this.f4157M = i5;
            return this;
        }

        public m t(l lVar) {
            this.f4164T = lVar;
            return this;
        }

        public m u(String str) {
            this.f4148D = str;
            return this;
        }

        public m v(String str) {
            this.f4156L = str;
            return this;
        }

        public m w(boolean z4) {
            this.f4184p = z4;
            k().putBoolean(NotificationCompat.EXTRA_CHRONOMETER_COUNT_DOWN, z4);
            return this;
        }

        public m x(int i5) {
            this.f4150F = i5;
            return this;
        }

        public m y(boolean z4) {
            this.f4146B = z4;
            this.f4147C = true;
            return this;
        }

        public m z(CharSequence charSequence) {
            this.f4179k = p(charSequence);
            return this;
        }

        public m(@NonNull Context context, @NonNull String str) {
            this.f4170b = new ArrayList();
            this.f4171c = new ArrayList();
            this.f4172d = new ArrayList();
            this.f4182n = true;
            this.f4145A = false;
            this.f4150F = 0;
            this.f4151G = 0;
            this.f4157M = 0;
            this.f4161Q = 0;
            this.f4162R = 0;
            Notification notification = new Notification();
            this.f4165U = notification;
            this.f4169a = context;
            this.f4156L = str;
            notification.when = System.currentTimeMillis();
            this.f4165U.audioStreamType = -1;
            this.f4181m = 0;
            this.f4168X = new ArrayList();
            this.f4163S = true;
        }

        @Deprecated
        public m(@NonNull Context context) {
            this(context, (String) null);
        }
    }
}
