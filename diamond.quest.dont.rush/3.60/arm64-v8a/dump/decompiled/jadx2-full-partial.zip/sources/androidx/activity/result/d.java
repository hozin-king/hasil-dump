package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.AbstractC1108h;
import androidx.lifecycle.InterfaceC1112l;
import androidx.lifecycle.InterfaceC1116p;
import e.AbstractC4968a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Q;
import kotlin.jvm.internal.t;
import kotlin.sequences.l;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: h, reason: collision with root package name */
    private static final b f2512h = new b(null);

    /* renamed from: a, reason: collision with root package name */
    private final Map f2513a = new LinkedHashMap();

    /* renamed from: b, reason: collision with root package name */
    private final Map f2514b = new LinkedHashMap();

    /* renamed from: c, reason: collision with root package name */
    private final Map f2515c = new LinkedHashMap();

    /* renamed from: d, reason: collision with root package name */
    private final List f2516d = new ArrayList();

    /* renamed from: e, reason: collision with root package name */
    private final transient Map f2517e = new LinkedHashMap();

    /* renamed from: f, reason: collision with root package name */
    private final Map f2518f = new LinkedHashMap();

    /* renamed from: g, reason: collision with root package name */
    private final Bundle f2519g = new Bundle();

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        private final androidx.activity.result.a f2520a;

        /* renamed from: b, reason: collision with root package name */
        private final AbstractC4968a f2521b;

        public a(androidx.activity.result.a callback, AbstractC4968a contract) {
            C7150s.j(callback, "callback");
            C7150s.j(contract, "contract");
            this.f2520a = callback;
            this.f2521b = contract;
        }

        public final androidx.activity.result.a a() {
            return this.f2520a;
        }

        public final AbstractC4968a b() {
            return this.f2521b;
        }
    }

    private static final class b {
        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private b() {
        }
    }

    private static final class c {

        /* renamed from: a, reason: collision with root package name */
        private final AbstractC1108h f2522a;

        /* renamed from: b, reason: collision with root package name */
        private final List f2523b;

        public c(AbstractC1108h lifecycle) {
            C7150s.j(lifecycle, "lifecycle");
            this.f2522a = lifecycle;
            this.f2523b = new ArrayList();
        }

        public final void a(InterfaceC1112l observer) {
            C7150s.j(observer, "observer");
            this.f2522a.addObserver(observer);
            this.f2523b.add(observer);
        }

        public final void b() {
            Iterator it = this.f2523b.iterator();
            while (it.hasNext()) {
                this.f2522a.removeObserver((InterfaceC1112l) it.next());
            }
            this.f2523b.clear();
        }
    }

    /* renamed from: androidx.activity.result.d$d, reason: collision with other inner class name */
    static final class C0104d extends t implements U3.a {

        /* renamed from: g, reason: collision with root package name */
        public static final C0104d f2524g = new C0104d();

        C0104d() {
            super(0);
        }

        @Override // U3.a
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final Integer invoke() {
            return Integer.valueOf(kotlin.random.d.f72368b.e(2147418112) + 65536);
        }
    }

    public static final class e extends androidx.activity.result.b {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f2526b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ AbstractC4968a f2527c;

        e(String str, AbstractC4968a abstractC4968a) {
            this.f2526b = str;
            this.f2527c = abstractC4968a;
        }

        @Override // androidx.activity.result.b
        public void b(Object obj, androidx.core.app.d dVar) {
            Object obj2 = d.this.f2514b.get(this.f2526b);
            AbstractC4968a abstractC4968a = this.f2527c;
            if (obj2 != null) {
                int intValue = ((Number) obj2).intValue();
                d.this.f2516d.add(this.f2526b);
                try {
                    d.this.i(intValue, this.f2527c, obj, dVar);
                    return;
                } catch (Exception e5) {
                    d.this.f2516d.remove(this.f2526b);
                    throw e5;
                }
            }
            throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + abstractC4968a + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
        }

        @Override // androidx.activity.result.b
        public void c() {
            d.this.p(this.f2526b);
        }
    }

    public static final class f extends androidx.activity.result.b {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ String f2529b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ AbstractC4968a f2530c;

        f(String str, AbstractC4968a abstractC4968a) {
            this.f2529b = str;
            this.f2530c = abstractC4968a;
        }

        @Override // androidx.activity.result.b
        public void b(Object obj, androidx.core.app.d dVar) {
            Object obj2 = d.this.f2514b.get(this.f2529b);
            AbstractC4968a abstractC4968a = this.f2530c;
            if (obj2 != null) {
                int intValue = ((Number) obj2).intValue();
                d.this.f2516d.add(this.f2529b);
                try {
                    d.this.i(intValue, this.f2530c, obj, dVar);
                    return;
                } catch (Exception e5) {
                    d.this.f2516d.remove(this.f2529b);
                    throw e5;
                }
            }
            throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + abstractC4968a + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
        }

        @Override // androidx.activity.result.b
        public void c() {
            d.this.p(this.f2529b);
        }
    }

    private final void d(int i5, String str) {
        this.f2513a.put(Integer.valueOf(i5), str);
        this.f2514b.put(str, Integer.valueOf(i5));
    }

    private final void g(String str, int i5, Intent intent, a aVar) {
        if ((aVar != null ? aVar.a() : null) == null || !this.f2516d.contains(str)) {
            this.f2518f.remove(str);
            this.f2519g.putParcelable(str, new ActivityResult(i5, intent));
        } else {
            aVar.a().a(aVar.b().c(i5, intent));
            this.f2516d.remove(str);
        }
    }

    private final int h() {
        for (Number number : l.h(C0104d.f2524g)) {
            if (!this.f2513a.containsKey(Integer.valueOf(number.intValue()))) {
                return number.intValue();
            }
        }
        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void n(d this$0, String key, androidx.activity.result.a callback, AbstractC4968a contract, InterfaceC1116p interfaceC1116p, AbstractC1108h.a event) {
        C7150s.j(this$0, "this$0");
        C7150s.j(key, "$key");
        C7150s.j(callback, "$callback");
        C7150s.j(contract, "$contract");
        C7150s.j(interfaceC1116p, "<anonymous parameter 0>");
        C7150s.j(event, "event");
        if (AbstractC1108h.a.ON_START != event) {
            if (AbstractC1108h.a.ON_STOP == event) {
                this$0.f2517e.remove(key);
                return;
            } else {
                if (AbstractC1108h.a.ON_DESTROY == event) {
                    this$0.p(key);
                    return;
                }
                return;
            }
        }
        this$0.f2517e.put(key, new a(callback, contract));
        if (this$0.f2518f.containsKey(key)) {
            Object obj = this$0.f2518f.get(key);
            this$0.f2518f.remove(key);
            callback.a(obj);
        }
        ActivityResult activityResult = (ActivityResult) androidx.core.os.c.a(this$0.f2519g, key, ActivityResult.class);
        if (activityResult != null) {
            this$0.f2519g.remove(key);
            callback.a(contract.c(activityResult.d(), activityResult.c()));
        }
    }

    private final void o(String str) {
        if (((Integer) this.f2514b.get(str)) != null) {
            return;
        }
        d(h(), str);
    }

    public final boolean e(int i5, int i6, Intent intent) {
        String str = (String) this.f2513a.get(Integer.valueOf(i5));
        if (str == null) {
            return false;
        }
        g(str, i6, intent, (a) this.f2517e.get(str));
        return true;
    }

    public final boolean f(int i5, Object obj) {
        String str = (String) this.f2513a.get(Integer.valueOf(i5));
        if (str == null) {
            return false;
        }
        a aVar = (a) this.f2517e.get(str);
        if ((aVar != null ? aVar.a() : null) == null) {
            this.f2519g.remove(str);
            this.f2518f.put(str, obj);
            return true;
        }
        androidx.activity.result.a a5 = aVar.a();
        C7150s.h(a5, "null cannot be cast to non-null type androidx.activity.result.ActivityResultCallback<O of androidx.activity.result.ActivityResultRegistry.dispatchResult>");
        if (!this.f2516d.remove(str)) {
            return true;
        }
        a5.a(obj);
        return true;
    }

    public abstract void i(int i5, AbstractC4968a abstractC4968a, Object obj, androidx.core.app.d dVar);

    public final void j(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null || integerArrayList == null) {
            return;
        }
        ArrayList<String> stringArrayList2 = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        if (stringArrayList2 != null) {
            this.f2516d.addAll(stringArrayList2);
        }
        Bundle bundle2 = bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
        if (bundle2 != null) {
            this.f2519g.putAll(bundle2);
        }
        int size = stringArrayList.size();
        for (int i5 = 0; i5 < size; i5++) {
            String str = stringArrayList.get(i5);
            if (this.f2514b.containsKey(str)) {
                Integer num = (Integer) this.f2514b.remove(str);
                if (!this.f2519g.containsKey(str)) {
                    Q.d(this.f2513a).remove(num);
                }
            }
            Integer num2 = integerArrayList.get(i5);
            C7150s.i(num2, "rcs[i]");
            int intValue = num2.intValue();
            String str2 = stringArrayList.get(i5);
            C7150s.i(str2, "keys[i]");
            d(intValue, str2);
        }
    }

    public final void k(Bundle outState) {
        C7150s.j(outState, "outState");
        outState.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(this.f2514b.values()));
        outState.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(this.f2514b.keySet()));
        outState.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(this.f2516d));
        outState.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(this.f2519g));
    }

    public final androidx.activity.result.b l(final String key, InterfaceC1116p lifecycleOwner, final AbstractC4968a contract, final androidx.activity.result.a callback) {
        C7150s.j(key, "key");
        C7150s.j(lifecycleOwner, "lifecycleOwner");
        C7150s.j(contract, "contract");
        C7150s.j(callback, "callback");
        AbstractC1108h lifecycle = lifecycleOwner.getLifecycle();
        if (lifecycle.getCurrentState().b(AbstractC1108h.b.STARTED)) {
            throw new IllegalStateException(("LifecycleOwner " + lifecycleOwner + " is attempting to register while current state is " + lifecycle.getCurrentState() + ". LifecycleOwners must call register before they are STARTED.").toString());
        }
        o(key);
        c cVar = (c) this.f2515c.get(key);
        if (cVar == null) {
            cVar = new c(lifecycle);
        }
        cVar.a(new InterfaceC1112l() { // from class: androidx.activity.result.c
            @Override // androidx.lifecycle.InterfaceC1112l
            public final void onStateChanged(InterfaceC1116p interfaceC1116p, AbstractC1108h.a aVar) {
                d.n(d.this, key, callback, contract, interfaceC1116p, aVar);
            }
        });
        this.f2515c.put(key, cVar);
        return new e(key, contract);
    }

    public final androidx.activity.result.b m(String key, AbstractC4968a contract, androidx.activity.result.a callback) {
        C7150s.j(key, "key");
        C7150s.j(contract, "contract");
        C7150s.j(callback, "callback");
        o(key);
        this.f2517e.put(key, new a(callback, contract));
        if (this.f2518f.containsKey(key)) {
            Object obj = this.f2518f.get(key);
            this.f2518f.remove(key);
            callback.a(obj);
        }
        ActivityResult activityResult = (ActivityResult) androidx.core.os.c.a(this.f2519g, key, ActivityResult.class);
        if (activityResult != null) {
            this.f2519g.remove(key);
            callback.a(contract.c(activityResult.d(), activityResult.c()));
        }
        return new f(key, contract);
    }

    public final void p(String key) {
        Integer num;
        C7150s.j(key, "key");
        if (!this.f2516d.contains(key) && (num = (Integer) this.f2514b.remove(key)) != null) {
            this.f2513a.remove(num);
        }
        this.f2517e.remove(key);
        if (this.f2518f.containsKey(key)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + key + ": " + this.f2518f.get(key));
            this.f2518f.remove(key);
        }
        if (this.f2519g.containsKey(key)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + key + ": " + ((ActivityResult) androidx.core.os.c.a(this.f2519g, key, ActivityResult.class)));
            this.f2519g.remove(key);
        }
        c cVar = (c) this.f2515c.get(key);
        if (cVar != null) {
            cVar.b();
            this.f2515c.remove(key);
        }
    }
}
