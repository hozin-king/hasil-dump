package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.b;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class e extends b implements g.a {

    /* renamed from: d, reason: collision with root package name */
    private Context f2926d;

    /* renamed from: e, reason: collision with root package name */
    private ActionBarContextView f2927e;

    /* renamed from: f, reason: collision with root package name */
    private b.a f2928f;

    /* renamed from: g, reason: collision with root package name */
    private WeakReference f2929g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f2930h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f2931i;

    /* renamed from: j, reason: collision with root package name */
    private androidx.appcompat.view.menu.g f2932j;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z4) {
        this.f2926d = context;
        this.f2927e = actionBarContextView;
        this.f2928f = aVar;
        androidx.appcompat.view.menu.g T4 = new androidx.appcompat.view.menu.g(actionBarContextView.getContext()).T(1);
        this.f2932j = T4;
        T4.S(this);
        this.f2931i = z4;
    }

    @Override // androidx.appcompat.view.menu.g.a
    public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
        return this.f2928f.b(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.g.a
    public void b(androidx.appcompat.view.menu.g gVar) {
        k();
        this.f2927e.l();
    }

    @Override // androidx.appcompat.view.b
    public void c() {
        if (this.f2930h) {
            return;
        }
        this.f2930h = true;
        this.f2928f.d(this);
    }

    @Override // androidx.appcompat.view.b
    public View d() {
        WeakReference weakReference = this.f2929g;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // androidx.appcompat.view.b
    public Menu e() {
        return this.f2932j;
    }

    @Override // androidx.appcompat.view.b
    public MenuInflater f() {
        return new g(this.f2927e.getContext());
    }

    @Override // androidx.appcompat.view.b
    public CharSequence g() {
        return this.f2927e.getSubtitle();
    }

    @Override // androidx.appcompat.view.b
    public CharSequence i() {
        return this.f2927e.getTitle();
    }

    @Override // androidx.appcompat.view.b
    public void k() {
        this.f2928f.c(this, this.f2932j);
    }

    @Override // androidx.appcompat.view.b
    public boolean l() {
        return this.f2927e.j();
    }

    @Override // androidx.appcompat.view.b
    public void m(View view) {
        this.f2927e.setCustomView(view);
        this.f2929g = view != null ? new WeakReference(view) : null;
    }

    @Override // androidx.appcompat.view.b
    public void n(int i5) {
        o(this.f2926d.getString(i5));
    }

    @Override // androidx.appcompat.view.b
    public void o(CharSequence charSequence) {
        this.f2927e.setSubtitle(charSequence);
    }

    @Override // androidx.appcompat.view.b
    public void q(int i5) {
        r(this.f2926d.getString(i5));
    }

    @Override // androidx.appcompat.view.b
    public void r(CharSequence charSequence) {
        this.f2927e.setTitle(charSequence);
    }

    @Override // androidx.appcompat.view.b
    public void s(boolean z4) {
        super.s(z4);
        this.f2927e.setTitleOptional(z4);
    }
}
