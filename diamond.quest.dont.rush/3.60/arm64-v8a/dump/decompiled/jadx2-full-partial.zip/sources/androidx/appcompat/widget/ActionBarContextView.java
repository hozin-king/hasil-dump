package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import androidx.core.view.C1035l0;
import f.C4993a;
import f.C4998f;
import f.C4999g;

/* loaded from: classes.dex */
public class ActionBarContextView extends AbstractC0982a {

    /* renamed from: j, reason: collision with root package name */
    private CharSequence f3253j;

    /* renamed from: k, reason: collision with root package name */
    private CharSequence f3254k;

    /* renamed from: l, reason: collision with root package name */
    private View f3255l;

    /* renamed from: m, reason: collision with root package name */
    private View f3256m;

    /* renamed from: n, reason: collision with root package name */
    private View f3257n;

    /* renamed from: o, reason: collision with root package name */
    private LinearLayout f3258o;

    /* renamed from: p, reason: collision with root package name */
    private TextView f3259p;

    /* renamed from: q, reason: collision with root package name */
    private TextView f3260q;

    /* renamed from: r, reason: collision with root package name */
    private int f3261r;

    /* renamed from: s, reason: collision with root package name */
    private int f3262s;

    /* renamed from: t, reason: collision with root package name */
    private boolean f3263t;

    /* renamed from: u, reason: collision with root package name */
    private int f3264u;

    class a implements View.OnClickListener {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ androidx.appcompat.view.b f3265b;

        a(androidx.appcompat.view.b bVar) {
            this.f3265b = bVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.f3265b.c();
        }
    }

    public ActionBarContextView(@NonNull Context context) {
        this(context, null);
    }

    private void i() {
        if (this.f3258o == null) {
            LayoutInflater.from(getContext()).inflate(C4999g.f53834a, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f3258o = linearLayout;
            this.f3259p = (TextView) linearLayout.findViewById(C4998f.f53812e);
            this.f3260q = (TextView) this.f3258o.findViewById(C4998f.f53811d);
            if (this.f3261r != 0) {
                this.f3259p.setTextAppearance(getContext(), this.f3261r);
            }
            if (this.f3262s != 0) {
                this.f3260q.setTextAppearance(getContext(), this.f3262s);
            }
        }
        this.f3259p.setText(this.f3253j);
        this.f3260q.setText(this.f3254k);
        boolean isEmpty = TextUtils.isEmpty(this.f3253j);
        boolean isEmpty2 = TextUtils.isEmpty(this.f3254k);
        this.f3260q.setVisibility(!isEmpty2 ? 0 : 8);
        this.f3258o.setVisibility((isEmpty && isEmpty2) ? 8 : 0);
        if (this.f3258o.getParent() == null) {
            addView(this.f3258o);
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0982a
    public /* bridge */ /* synthetic */ C1035l0 f(int i5, long j5) {
        return super.f(i5, j5);
    }

    public void g() {
        if (this.f3255l == null) {
            k();
        }
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.AbstractC0982a
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // androidx.appcompat.widget.AbstractC0982a
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f3254k;
    }

    public CharSequence getTitle() {
        return this.f3253j;
    }

    public void h(androidx.appcompat.view.b bVar) {
        View view = this.f3255l;
        if (view == null) {
            View inflate = LayoutInflater.from(getContext()).inflate(this.f3264u, (ViewGroup) this, false);
            this.f3255l = inflate;
            addView(inflate);
        } else if (view.getParent() == null) {
            addView(this.f3255l);
        }
        View findViewById = this.f3255l.findViewById(C4998f.f53816i);
        this.f3256m = findViewById;
        findViewById.setOnClickListener(new a(bVar));
        androidx.appcompat.view.menu.g gVar = (androidx.appcompat.view.menu.g) bVar.e();
        C0984c c0984c = this.f3640e;
        if (c0984c != null) {
            c0984c.y();
        }
        C0984c c0984c2 = new C0984c(getContext());
        this.f3640e = c0984c2;
        c0984c2.J(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        gVar.c(this.f3640e, this.f3638c);
        ActionMenuView actionMenuView = (ActionMenuView) this.f3640e.o(this);
        this.f3639d = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f3639d, layoutParams);
    }

    public boolean j() {
        return this.f3263t;
    }

    public void k() {
        removeAllViews();
        this.f3257n = null;
        this.f3639d = null;
        this.f3640e = null;
        View view = this.f3256m;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public boolean l() {
        C0984c c0984c = this.f3640e;
        if (c0984c != null) {
            return c0984c.K();
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0984c c0984c = this.f3640e;
        if (c0984c != null) {
            c0984c.B();
            this.f3640e.C();
        }
    }

    @Override // androidx.appcompat.widget.AbstractC0982a, android.view.View
    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        boolean b5 = r0.b(this);
        int paddingRight = b5 ? (i7 - i5) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i8 - i6) - getPaddingTop()) - getPaddingBottom();
        View view = this.f3255l;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f3255l.getLayoutParams();
            int i9 = b5 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i10 = b5 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int d5 = AbstractC0982a.d(paddingRight, i9, b5);
            paddingRight = AbstractC0982a.d(d5 + e(this.f3255l, d5, paddingTop, paddingTop2, b5), i10, b5);
        }
        int i11 = paddingRight;
        LinearLayout linearLayout = this.f3258o;
        if (linearLayout != null && this.f3257n == null && linearLayout.getVisibility() != 8) {
            i11 += e(this.f3258o, i11, paddingTop, paddingTop2, b5);
        }
        View view2 = this.f3257n;
        if (view2 != null) {
            e(view2, i11, paddingTop, paddingTop2, b5);
        }
        int paddingLeft = b5 ? getPaddingLeft() : (i7 - i5) - getPaddingRight();
        ActionMenuView actionMenuView = this.f3639d;
        if (actionMenuView != null) {
            e(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b5);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i5, int i6) {
        if (View.MeasureSpec.getMode(i5) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i6) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i5);
        int i7 = this.f3641f;
        if (i7 <= 0) {
            i7 = View.MeasureSpec.getSize(i6);
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int i8 = i7 - paddingTop;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8, Integer.MIN_VALUE);
        View view = this.f3255l;
        if (view != null) {
            int c5 = c(view, paddingLeft, makeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f3255l.getLayoutParams();
            paddingLeft = c5 - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f3639d;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(this.f3639d, paddingLeft, makeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.f3258o;
        if (linearLayout != null && this.f3257n == null) {
            if (this.f3263t) {
                this.f3258o.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                int measuredWidth = this.f3258o.getMeasuredWidth();
                boolean z4 = measuredWidth <= paddingLeft;
                if (z4) {
                    paddingLeft -= measuredWidth;
                }
                this.f3258o.setVisibility(z4 ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, makeMeasureSpec, 0);
            }
        }
        View view2 = this.f3257n;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i9 = layoutParams.width;
            int i10 = i9 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i9 >= 0) {
                paddingLeft = Math.min(i9, paddingLeft);
            }
            int i11 = layoutParams.height;
            int i12 = i11 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i11 >= 0) {
                i8 = Math.min(i11, i8);
            }
            this.f3257n.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i10), View.MeasureSpec.makeMeasureSpec(i8, i12));
        }
        if (this.f3641f > 0) {
            setMeasuredDimension(size, i7);
            return;
        }
        int childCount = getChildCount();
        int i13 = 0;
        for (int i14 = 0; i14 < childCount; i14++) {
            int measuredHeight = getChildAt(i14).getMeasuredHeight() + paddingTop;
            if (measuredHeight > i13) {
                i13 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i13);
    }

    @Override // androidx.appcompat.widget.AbstractC0982a, android.view.View
    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // androidx.appcompat.widget.AbstractC0982a
    public void setContentHeight(int i5) {
        this.f3641f = i5;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f3257n;
        if (view2 != null) {
            removeView(view2);
        }
        this.f3257n = view;
        if (view != null && (linearLayout = this.f3258o) != null) {
            removeView(linearLayout);
            this.f3258o = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f3254k = charSequence;
        i();
    }

    public void setTitle(CharSequence charSequence) {
        this.f3253j = charSequence;
        i();
        C1015b0.f0(this, charSequence);
    }

    public void setTitleOptional(boolean z4) {
        if (z4 != this.f3263t) {
            requestLayout();
        }
        this.f3263t = z4;
    }

    @Override // androidx.appcompat.widget.AbstractC0982a, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i5) {
        super.setVisibility(i5);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53707k);
    }

    public ActionBarContextView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        g0 u5 = g0.u(context, attributeSet, f.j.f54114y, i5, 0);
        setBackground(u5.f(f.j.f54119z));
        this.f3261r = u5.m(f.j.f53887D, 0);
        this.f3262s = u5.m(f.j.f53882C, 0);
        this.f3641f = u5.l(f.j.f53877B, 0);
        this.f3264u = u5.m(f.j.f53872A, C4999g.f53837d);
        u5.w();
    }
}
