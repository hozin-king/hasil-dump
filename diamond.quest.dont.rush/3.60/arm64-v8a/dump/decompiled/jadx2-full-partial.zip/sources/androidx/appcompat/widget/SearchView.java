package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import androidx.customview.view.AbsSavedState;
import com.badlogic.gdx.Input;
import com.google.firebase.sessions.settings.RemoteSettings;
import f.C4993a;
import f.C4996d;
import f.C4998f;
import f.C4999g;
import f.C5000h;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import x.AbstractC7514a;

/* loaded from: classes.dex */
public class SearchView extends Q implements androidx.appcompat.view.c {

    /* renamed from: o0, reason: collision with root package name */
    static final o f3448o0;

    /* renamed from: A, reason: collision with root package name */
    private Rect f3449A;

    /* renamed from: B, reason: collision with root package name */
    private Rect f3450B;

    /* renamed from: C, reason: collision with root package name */
    private int[] f3451C;

    /* renamed from: D, reason: collision with root package name */
    private int[] f3452D;

    /* renamed from: E, reason: collision with root package name */
    private final ImageView f3453E;

    /* renamed from: F, reason: collision with root package name */
    private final Drawable f3454F;

    /* renamed from: G, reason: collision with root package name */
    private final int f3455G;

    /* renamed from: H, reason: collision with root package name */
    private final int f3456H;

    /* renamed from: I, reason: collision with root package name */
    private final Intent f3457I;

    /* renamed from: J, reason: collision with root package name */
    private final Intent f3458J;

    /* renamed from: K, reason: collision with root package name */
    private final CharSequence f3459K;

    /* renamed from: L, reason: collision with root package name */
    View.OnFocusChangeListener f3460L;

    /* renamed from: M, reason: collision with root package name */
    private View.OnClickListener f3461M;

    /* renamed from: N, reason: collision with root package name */
    private boolean f3462N;

    /* renamed from: O, reason: collision with root package name */
    private boolean f3463O;

    /* renamed from: P, reason: collision with root package name */
    AbstractC7514a f3464P;

    /* renamed from: Q, reason: collision with root package name */
    private boolean f3465Q;

    /* renamed from: R, reason: collision with root package name */
    private CharSequence f3466R;

    /* renamed from: S, reason: collision with root package name */
    private boolean f3467S;

    /* renamed from: T, reason: collision with root package name */
    private boolean f3468T;

    /* renamed from: U, reason: collision with root package name */
    private int f3469U;

    /* renamed from: V, reason: collision with root package name */
    private boolean f3470V;

    /* renamed from: W, reason: collision with root package name */
    private CharSequence f3471W;

    /* renamed from: a0, reason: collision with root package name */
    private CharSequence f3472a0;

    /* renamed from: b0, reason: collision with root package name */
    private boolean f3473b0;

    /* renamed from: c0, reason: collision with root package name */
    private int f3474c0;

    /* renamed from: d0, reason: collision with root package name */
    SearchableInfo f3475d0;

    /* renamed from: e0, reason: collision with root package name */
    private Bundle f3476e0;

    /* renamed from: f0, reason: collision with root package name */
    private final Runnable f3477f0;

    /* renamed from: g0, reason: collision with root package name */
    private Runnable f3478g0;

    /* renamed from: h0, reason: collision with root package name */
    private final WeakHashMap f3479h0;

    /* renamed from: i0, reason: collision with root package name */
    private final View.OnClickListener f3480i0;

    /* renamed from: j0, reason: collision with root package name */
    View.OnKeyListener f3481j0;

    /* renamed from: k0, reason: collision with root package name */
    private final TextView.OnEditorActionListener f3482k0;

    /* renamed from: l0, reason: collision with root package name */
    private final AdapterView.OnItemClickListener f3483l0;

    /* renamed from: m0, reason: collision with root package name */
    private final AdapterView.OnItemSelectedListener f3484m0;

    /* renamed from: n0, reason: collision with root package name */
    private TextWatcher f3485n0;

    /* renamed from: q, reason: collision with root package name */
    final SearchAutoComplete f3486q;

    /* renamed from: r, reason: collision with root package name */
    private final View f3487r;

    /* renamed from: s, reason: collision with root package name */
    private final View f3488s;

    /* renamed from: t, reason: collision with root package name */
    private final View f3489t;

    /* renamed from: u, reason: collision with root package name */
    final ImageView f3490u;

    /* renamed from: v, reason: collision with root package name */
    final ImageView f3491v;

    /* renamed from: w, reason: collision with root package name */
    final ImageView f3492w;

    /* renamed from: x, reason: collision with root package name */
    final ImageView f3493x;

    /* renamed from: y, reason: collision with root package name */
    private final View f3494y;

    /* renamed from: z, reason: collision with root package name */
    private p f3495z;

    static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        boolean f3496d;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public SavedState[] newArray(int i5) {
                return new SavedState[i5];
            }
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.f3496d + "}";
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            super.writeToParcel(parcel, i5);
            parcel.writeValue(Boolean.valueOf(this.f3496d));
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f3496d = ((Boolean) parcel.readValue(null)).booleanValue();
        }
    }

    public static class SearchAutoComplete extends C0985d {

        /* renamed from: f, reason: collision with root package name */
        private int f3497f;

        /* renamed from: g, reason: collision with root package name */
        private SearchView f3498g;

        /* renamed from: h, reason: collision with root package name */
        private boolean f3499h;

        /* renamed from: i, reason: collision with root package name */
        final Runnable f3500i;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchAutoComplete.this.d();
            }
        }

        public SearchAutoComplete(Context context) {
            this(context, null);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i5 = configuration.screenWidthDp;
            int i6 = configuration.screenHeightDp;
            if (i5 >= 960 && i6 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i5 >= 600) {
                return 192;
            }
            if (i5 < 640 || i6 < 480) {
                return Input.Keys.NUMPAD_ENTER;
            }
            return 192;
        }

        void b() {
            if (Build.VERSION.SDK_INT < 29) {
                SearchView.f3448o0.c(this);
                return;
            }
            k.b(this, 1);
            if (enoughToFilter()) {
                showDropDown();
            }
        }

        boolean c() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        void d() {
            if (this.f3499h) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f3499h = false;
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public boolean enoughToFilter() {
            return this.f3497f <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.C0985d, android.widget.TextView, android.view.View
        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f3499h) {
                removeCallbacks(this.f3500i);
                post(this.f3500i);
            }
            return onCreateInputConnection;
        }

        @Override // android.view.View
        protected void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        protected void onFocusChanged(boolean z4, int i5, Rect rect) {
            super.onFocusChanged(z4, i5, rect);
            this.f3498g.V();
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public boolean onKeyPreIme(int i5, KeyEvent keyEvent) {
            if (i5 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f3498g.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i5, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public void onWindowFocusChanged(boolean z4) {
            super.onWindowFocusChanged(z4);
            if (z4 && this.f3498g.hasFocus() && getVisibility() == 0) {
                this.f3499h = true;
                if (SearchView.I(getContext())) {
                    b();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        protected void replaceText(CharSequence charSequence) {
        }

        void setImeVisibility(boolean z4) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z4) {
                this.f3499h = false;
                removeCallbacks(this.f3500i);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f3499h = true;
                    return;
                }
                this.f3499h = false;
                removeCallbacks(this.f3500i);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        void setSearchView(SearchView searchView) {
            this.f3498g = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i5) {
            super.setThreshold(i5);
            this.f3497f = i5;
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, C4993a.f53713q);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i5) {
            super(context, attributeSet, i5);
            this.f3500i = new a();
            this.f3497f = getThreshold();
        }
    }

    class a implements TextWatcher {
        a() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i5, int i6, int i7) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i5, int i6, int i7) {
            SearchView.this.U(charSequence);
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SearchView.this.b0();
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            AbstractC7514a abstractC7514a = SearchView.this.f3464P;
            if (abstractC7514a instanceof a0) {
                abstractC7514a.a(null);
            }
        }
    }

    class d implements View.OnFocusChangeListener {
        d() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z4) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.f3460L;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z4);
            }
        }
    }

    class e implements View.OnLayoutChangeListener {
        e() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12) {
            SearchView.this.x();
        }
    }

    class f implements View.OnClickListener {
        f() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f3490u) {
                searchView.R();
                return;
            }
            if (view == searchView.f3492w) {
                searchView.N();
                return;
            }
            if (view == searchView.f3491v) {
                searchView.S();
            } else if (view == searchView.f3493x) {
                searchView.W();
            } else if (view == searchView.f3486q) {
                searchView.D();
            }
        }
    }

    class g implements View.OnKeyListener {
        g() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i5, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.f3475d0 == null) {
                return false;
            }
            if (searchView.f3486q.isPopupShowing() && SearchView.this.f3486q.getListSelection() != -1) {
                return SearchView.this.T(view, i5, keyEvent);
            }
            if (SearchView.this.f3486q.c() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i5 != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.L(0, null, searchView2.f3486q.getText().toString());
            return true;
        }
    }

    class h implements TextView.OnEditorActionListener {
        h() {
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public boolean onEditorAction(TextView textView, int i5, KeyEvent keyEvent) {
            SearchView.this.S();
            return true;
        }
    }

    class i implements AdapterView.OnItemClickListener {
        i() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView adapterView, View view, int i5, long j5) {
            SearchView.this.O(i5, 0, null);
        }
    }

    class j implements AdapterView.OnItemSelectedListener {
        j() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView adapterView, View view, int i5, long j5) {
            SearchView.this.P(i5);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView adapterView) {
        }
    }

    static class k {
        static void a(AutoCompleteTextView autoCompleteTextView) {
            autoCompleteTextView.refreshAutoCompleteResults();
        }

        static void b(SearchAutoComplete searchAutoComplete, int i5) {
            searchAutoComplete.setInputMethodMode(i5);
        }
    }

    public interface l {
    }

    public interface m {
    }

    public interface n {
    }

    private static class o {

        /* renamed from: a, reason: collision with root package name */
        private Method f3512a;

        /* renamed from: b, reason: collision with root package name */
        private Method f3513b;

        /* renamed from: c, reason: collision with root package name */
        private Method f3514c;

        o() {
            this.f3512a = null;
            this.f3513b = null;
            this.f3514c = null;
            d();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                this.f3512a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                this.f3513b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                this.f3514c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        private static void d() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }

        void a(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f3513b;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, null);
                } catch (Exception unused) {
                }
            }
        }

        void b(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f3512a;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, null);
                } catch (Exception unused) {
                }
            }
        }

        void c(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f3514c;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }
    }

    private static class p extends TouchDelegate {

        /* renamed from: a, reason: collision with root package name */
        private final View f3515a;

        /* renamed from: b, reason: collision with root package name */
        private final Rect f3516b;

        /* renamed from: c, reason: collision with root package name */
        private final Rect f3517c;

        /* renamed from: d, reason: collision with root package name */
        private final Rect f3518d;

        /* renamed from: e, reason: collision with root package name */
        private final int f3519e;

        /* renamed from: f, reason: collision with root package name */
        private boolean f3520f;

        public p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f3519e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            this.f3516b = new Rect();
            this.f3518d = new Rect();
            this.f3517c = new Rect();
            a(rect, rect2);
            this.f3515a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.f3516b.set(rect);
            this.f3518d.set(rect);
            Rect rect3 = this.f3518d;
            int i5 = this.f3519e;
            rect3.inset(-i5, -i5);
            this.f3517c.set(rect2);
        }

        @Override // android.view.TouchDelegate
        public boolean onTouchEvent(MotionEvent motionEvent) {
            boolean z4;
            boolean z5;
            int x5 = (int) motionEvent.getX();
            int y5 = (int) motionEvent.getY();
            int action = motionEvent.getAction();
            boolean z6 = true;
            if (action != 0) {
                if (action == 1 || action == 2) {
                    z5 = this.f3520f;
                    if (z5 && !this.f3518d.contains(x5, y5)) {
                        z6 = z5;
                        z4 = false;
                    }
                } else {
                    if (action == 3) {
                        z5 = this.f3520f;
                        this.f3520f = false;
                    }
                    z4 = true;
                    z6 = false;
                }
                z6 = z5;
                z4 = true;
            } else {
                if (this.f3516b.contains(x5, y5)) {
                    this.f3520f = true;
                    z4 = true;
                }
                z4 = true;
                z6 = false;
            }
            if (!z6) {
                return false;
            }
            if (!z4 || this.f3517c.contains(x5, y5)) {
                Rect rect = this.f3517c;
                motionEvent.setLocation(x5 - rect.left, y5 - rect.top);
            } else {
                motionEvent.setLocation(this.f3515a.getWidth() / 2, this.f3515a.getHeight() / 2);
            }
            return this.f3515a.dispatchTouchEvent(motionEvent);
        }
    }

    static {
        f3448o0 = Build.VERSION.SDK_INT < 29 ? new o() : null;
    }

    public SearchView(@NonNull Context context) {
        this(context, null);
    }

    private Intent A(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f3476e0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    private Intent B(Intent intent, SearchableInfo searchableInfo) {
        Intent intent2 = new Intent(intent);
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        intent2.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
        return intent2;
    }

    private void C() {
        this.f3486q.dismissDropDown();
    }

    private void E(View view, Rect rect) {
        view.getLocationInWindow(this.f3451C);
        getLocationInWindow(this.f3452D);
        int[] iArr = this.f3451C;
        int i5 = iArr[1];
        int[] iArr2 = this.f3452D;
        int i6 = i5 - iArr2[1];
        int i7 = iArr[0] - iArr2[0];
        rect.set(i7, i6, view.getWidth() + i7, view.getHeight() + i6);
    }

    private CharSequence F(CharSequence charSequence) {
        if (!this.f3462N || this.f3454F == null) {
            return charSequence;
        }
        int textSize = (int) (this.f3486q.getTextSize() * 1.25d);
        this.f3454F.setBounds(0, 0, textSize, textSize);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.f3454F), 1, 2, 33);
        spannableStringBuilder.append(charSequence);
        return spannableStringBuilder;
    }

    private boolean G() {
        SearchableInfo searchableInfo = this.f3475d0;
        if (searchableInfo != null && searchableInfo.getVoiceSearchEnabled()) {
            Intent intent = this.f3475d0.getVoiceSearchLaunchWebSearch() ? this.f3457I : this.f3475d0.getVoiceSearchLaunchRecognizer() ? this.f3458J : null;
            if (intent != null && getContext().getPackageManager().resolveActivity(intent, 65536) != null) {
                return true;
            }
        }
        return false;
    }

    static boolean I(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private boolean J() {
        return (this.f3465Q || this.f3470V) && !H();
    }

    private void K(Intent intent) {
        if (intent == null) {
            return;
        }
        try {
            getContext().startActivity(intent);
        } catch (RuntimeException e5) {
            Log.e("SearchView", "Failed launch activity: " + intent, e5);
        }
    }

    private boolean M(int i5, int i6, String str) {
        Cursor b5 = this.f3464P.b();
        if (b5 == null || !b5.moveToPosition(i5)) {
            return false;
        }
        K(z(b5, i6, str));
        return true;
    }

    private void X() {
        post(this.f3477f0);
    }

    private void Y(int i5) {
        Editable text = this.f3486q.getText();
        Cursor b5 = this.f3464P.b();
        if (b5 == null) {
            return;
        }
        if (!b5.moveToPosition(i5)) {
            setQuery(text);
            return;
        }
        CharSequence convertToString = this.f3464P.convertToString(b5);
        if (convertToString != null) {
            setQuery(convertToString);
        } else {
            setQuery(text);
        }
    }

    private void a0() {
        boolean isEmpty = TextUtils.isEmpty(this.f3486q.getText());
        this.f3492w.setVisibility(!isEmpty || (this.f3462N && !this.f3473b0) ? 0 : 8);
        Drawable drawable = this.f3492w.getDrawable();
        if (drawable != null) {
            drawable.setState(!isEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    private void c0() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f3486q;
        if (queryHint == null) {
            queryHint = "";
        }
        searchAutoComplete.setHint(F(queryHint));
    }

    private void d0() {
        this.f3486q.setThreshold(this.f3475d0.getSuggestThreshold());
        this.f3486q.setImeOptions(this.f3475d0.getImeOptions());
        int inputType = this.f3475d0.getInputType();
        if ((inputType & 15) == 1) {
            inputType &= -65537;
            if (this.f3475d0.getSuggestAuthority() != null) {
                inputType |= 589824;
            }
        }
        this.f3486q.setInputType(inputType);
        AbstractC7514a abstractC7514a = this.f3464P;
        if (abstractC7514a != null) {
            abstractC7514a.a(null);
        }
        if (this.f3475d0.getSuggestAuthority() != null) {
            a0 a0Var = new a0(getContext(), this, this.f3475d0, this.f3479h0);
            this.f3464P = a0Var;
            this.f3486q.setAdapter(a0Var);
            ((a0) this.f3464P).w(this.f3467S ? 2 : 1);
        }
    }

    private void e0() {
        this.f3489t.setVisibility((J() && (this.f3491v.getVisibility() == 0 || this.f3493x.getVisibility() == 0)) ? 0 : 8);
    }

    private void f0(boolean z4) {
        this.f3491v.setVisibility((this.f3465Q && J() && hasFocus() && (z4 || !this.f3470V)) ? 0 : 8);
    }

    private void g0(boolean z4) {
        this.f3463O = z4;
        int i5 = 8;
        int i6 = z4 ? 0 : 8;
        boolean isEmpty = TextUtils.isEmpty(this.f3486q.getText());
        this.f3490u.setVisibility(i6);
        f0(!isEmpty);
        this.f3487r.setVisibility(z4 ? 8 : 0);
        if (this.f3453E.getDrawable() != null && !this.f3462N) {
            i5 = 0;
        }
        this.f3453E.setVisibility(i5);
        a0();
        h0(isEmpty);
        e0();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(C4996d.f53738g);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(C4996d.f53739h);
    }

    private void h0(boolean z4) {
        int i5 = 8;
        if (this.f3470V && !H() && z4) {
            this.f3491v.setVisibility(8);
            i5 = 0;
        }
        this.f3493x.setVisibility(i5);
    }

    private void setQuery(CharSequence charSequence) {
        this.f3486q.setText(charSequence);
        this.f3486q.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    private Intent y(String str, Uri uri, String str2, String str3, int i5, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f3472a0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f3476e0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i5 != 0) {
            intent.putExtra("action_key", i5);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f3475d0.getSearchActivity());
        return intent;
    }

    private Intent z(Cursor cursor, int i5, String str) {
        int i6;
        String n5;
        try {
            String n6 = a0.n(cursor, "suggest_intent_action");
            if (n6 == null) {
                n6 = this.f3475d0.getSuggestIntentAction();
            }
            if (n6 == null) {
                n6 = "android.intent.action.SEARCH";
            }
            String str2 = n6;
            String n7 = a0.n(cursor, "suggest_intent_data");
            if (n7 == null) {
                n7 = this.f3475d0.getSuggestIntentData();
            }
            if (n7 != null && (n5 = a0.n(cursor, "suggest_intent_data_id")) != null) {
                n7 = n7 + RemoteSettings.FORWARD_SLASH_STRING + Uri.encode(n5);
            }
            return y(str2, n7 == null ? null : Uri.parse(n7), a0.n(cursor, "suggest_intent_extra_data"), a0.n(cursor, "suggest_intent_query"), i5, str);
        } catch (RuntimeException e5) {
            try {
                i6 = cursor.getPosition();
            } catch (RuntimeException unused) {
                i6 = -1;
            }
            Log.w("SearchView", "Search suggestions cursor at row " + i6 + " returned exception.", e5);
            return null;
        }
    }

    void D() {
        if (Build.VERSION.SDK_INT >= 29) {
            k.a(this.f3486q);
            return;
        }
        o oVar = f3448o0;
        oVar.b(this.f3486q);
        oVar.a(this.f3486q);
    }

    public boolean H() {
        return this.f3463O;
    }

    void L(int i5, String str, String str2) {
        getContext().startActivity(y("android.intent.action.SEARCH", null, null, str2, i5, str));
    }

    void N() {
        if (!TextUtils.isEmpty(this.f3486q.getText())) {
            this.f3486q.setText("");
            this.f3486q.requestFocus();
            this.f3486q.setImeVisibility(true);
        } else if (this.f3462N) {
            clearFocus();
            g0(true);
        }
    }

    boolean O(int i5, int i6, String str) {
        M(i5, 0, null);
        this.f3486q.setImeVisibility(false);
        C();
        return true;
    }

    boolean P(int i5) {
        Y(i5);
        return true;
    }

    protected void Q(CharSequence charSequence) {
        setQuery(charSequence);
    }

    void R() {
        g0(false);
        this.f3486q.requestFocus();
        this.f3486q.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f3461M;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    void S() {
        Editable text = this.f3486q.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f3475d0 != null) {
            L(0, null, text.toString());
        }
        this.f3486q.setImeVisibility(false);
        C();
    }

    boolean T(View view, int i5, KeyEvent keyEvent) {
        if (this.f3475d0 != null && this.f3464P != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i5 == 66 || i5 == 84 || i5 == 61) {
                return O(this.f3486q.getListSelection(), 0, null);
            }
            if (i5 == 21 || i5 == 22) {
                this.f3486q.setSelection(i5 == 21 ? 0 : this.f3486q.length());
                this.f3486q.setListSelection(0);
                this.f3486q.clearListSelection();
                this.f3486q.b();
                return true;
            }
            if (i5 == 19) {
                this.f3486q.getListSelection();
                return false;
            }
        }
        return false;
    }

    void U(CharSequence charSequence) {
        Editable text = this.f3486q.getText();
        this.f3472a0 = text;
        boolean isEmpty = TextUtils.isEmpty(text);
        f0(!isEmpty);
        h0(isEmpty);
        a0();
        e0();
        this.f3471W = charSequence.toString();
    }

    void V() {
        g0(H());
        X();
        if (this.f3486q.hasFocus()) {
            D();
        }
    }

    void W() {
        SearchableInfo searchableInfo = this.f3475d0;
        if (searchableInfo == null) {
            return;
        }
        try {
            if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                getContext().startActivity(B(this.f3457I, searchableInfo));
            } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                getContext().startActivity(A(this.f3458J, searchableInfo));
            }
        } catch (ActivityNotFoundException unused) {
            Log.w("SearchView", "Could not find voice search activity");
        }
    }

    public void Z(CharSequence charSequence, boolean z4) {
        this.f3486q.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.f3486q;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.f3472a0 = charSequence;
        }
        if (!z4 || TextUtils.isEmpty(charSequence)) {
            return;
        }
        S();
    }

    void b0() {
        int[] iArr = this.f3486q.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f3488s.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f3489t.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void clearFocus() {
        this.f3468T = true;
        super.clearFocus();
        this.f3486q.clearFocus();
        this.f3486q.setImeVisibility(false);
        this.f3468T = false;
    }

    public int getImeOptions() {
        return this.f3486q.getImeOptions();
    }

    public int getInputType() {
        return this.f3486q.getInputType();
    }

    public int getMaxWidth() {
        return this.f3469U;
    }

    public CharSequence getQuery() {
        return this.f3486q.getText();
    }

    @Nullable
    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f3466R;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f3475d0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f3459K : getContext().getText(this.f3475d0.getHintId());
    }

    int getSuggestionCommitIconResId() {
        return this.f3456H;
    }

    int getSuggestionRowLayout() {
        return this.f3455G;
    }

    public AbstractC7514a getSuggestionsAdapter() {
        return this.f3464P;
    }

    @Override // androidx.appcompat.view.c
    public void onActionViewCollapsed() {
        Z("", false);
        clearFocus();
        g0(true);
        this.f3486q.setImeOptions(this.f3474c0);
        this.f3473b0 = false;
    }

    @Override // androidx.appcompat.view.c
    public void onActionViewExpanded() {
        if (this.f3473b0) {
            return;
        }
        this.f3473b0 = true;
        int imeOptions = this.f3486q.getImeOptions();
        this.f3474c0 = imeOptions;
        this.f3486q.setImeOptions(imeOptions | 33554432);
        this.f3486q.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.f3477f0);
        post(this.f3478g0);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.Q, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        super.onLayout(z4, i5, i6, i7, i8);
        if (z4) {
            E(this.f3486q, this.f3449A);
            Rect rect = this.f3450B;
            Rect rect2 = this.f3449A;
            rect.set(rect2.left, 0, rect2.right, i8 - i6);
            p pVar = this.f3495z;
            if (pVar != null) {
                pVar.a(this.f3450B, this.f3449A);
                return;
            }
            p pVar2 = new p(this.f3450B, this.f3449A, this.f3486q);
            this.f3495z = pVar2;
            setTouchDelegate(pVar2);
        }
    }

    @Override // androidx.appcompat.widget.Q, android.view.View
    protected void onMeasure(int i5, int i6) {
        int i7;
        if (H()) {
            super.onMeasure(i5, i6);
            return;
        }
        int mode = View.MeasureSpec.getMode(i5);
        int size = View.MeasureSpec.getSize(i5);
        if (mode == Integer.MIN_VALUE) {
            int i8 = this.f3469U;
            size = i8 > 0 ? Math.min(i8, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f3469U;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i7 = this.f3469U) > 0) {
            size = Math.min(i7, size);
        }
        int mode2 = View.MeasureSpec.getMode(i6);
        int size2 = View.MeasureSpec.getSize(i6);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.c());
        g0(savedState.f3496d);
        requestLayout();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f3496d = H();
        return savedState;
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z4) {
        super.onWindowFocusChanged(z4);
        X();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean requestFocus(int i5, Rect rect) {
        if (this.f3468T || !isFocusable()) {
            return false;
        }
        if (H()) {
            return super.requestFocus(i5, rect);
        }
        boolean requestFocus = this.f3486q.requestFocus(i5, rect);
        if (requestFocus) {
            g0(false);
        }
        return requestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.f3476e0 = bundle;
    }

    public void setIconified(boolean z4) {
        if (z4) {
            N();
        } else {
            R();
        }
    }

    public void setIconifiedByDefault(boolean z4) {
        if (this.f3462N == z4) {
            return;
        }
        this.f3462N = z4;
        g0(z4);
        c0();
    }

    public void setImeOptions(int i5) {
        this.f3486q.setImeOptions(i5);
    }

    public void setInputType(int i5) {
        this.f3486q.setInputType(i5);
    }

    public void setMaxWidth(int i5) {
        this.f3469U = i5;
        requestLayout();
    }

    public void setOnCloseListener(l lVar) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f3460L = onFocusChangeListener;
    }

    public void setOnQueryTextListener(m mVar) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f3461M = onClickListener;
    }

    public void setOnSuggestionListener(n nVar) {
    }

    public void setQueryHint(@Nullable CharSequence charSequence) {
        this.f3466R = charSequence;
        c0();
    }

    public void setQueryRefinementEnabled(boolean z4) {
        this.f3467S = z4;
        AbstractC7514a abstractC7514a = this.f3464P;
        if (abstractC7514a instanceof a0) {
            ((a0) abstractC7514a).w(z4 ? 2 : 1);
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f3475d0 = searchableInfo;
        if (searchableInfo != null) {
            d0();
            c0();
        }
        boolean G4 = G();
        this.f3470V = G4;
        if (G4) {
            this.f3486q.setPrivateImeOptions("nm");
        }
        g0(H());
    }

    public void setSubmitButtonEnabled(boolean z4) {
        this.f3465Q = z4;
        g0(H());
    }

    public void setSuggestionsAdapter(AbstractC7514a abstractC7514a) {
        this.f3464P = abstractC7514a;
        this.f3486q.setAdapter(abstractC7514a);
    }

    void x() {
        if (this.f3494y.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.f3488s.getPaddingLeft();
            Rect rect = new Rect();
            boolean b5 = r0.b(this);
            int dimensionPixelSize = this.f3462N ? resources.getDimensionPixelSize(C4996d.f53736e) + resources.getDimensionPixelSize(C4996d.f53737f) : 0;
            this.f3486q.getDropDownBackground().getPadding(rect);
            this.f3486q.setDropDownHorizontalOffset(b5 ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.f3486q.setDropDownWidth((((this.f3494y.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    public SearchView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53690K);
    }

    public SearchView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        this.f3449A = new Rect();
        this.f3450B = new Rect();
        this.f3451C = new int[2];
        this.f3452D = new int[2];
        this.f3477f0 = new b();
        this.f3478g0 = new c();
        this.f3479h0 = new WeakHashMap();
        f fVar = new f();
        this.f3480i0 = fVar;
        this.f3481j0 = new g();
        h hVar = new h();
        this.f3482k0 = hVar;
        i iVar = new i();
        this.f3483l0 = iVar;
        j jVar = new j();
        this.f3484m0 = jVar;
        this.f3485n0 = new a();
        g0 u5 = g0.u(context, attributeSet, f.j.f54022f2, i5, 0);
        C1015b0.b0(this, context, f.j.f54022f2, attributeSet, u5.q(), i5, 0);
        LayoutInflater.from(context).inflate(u5.m(f.j.f54072p2, C4999g.f53851r), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(C4998f.f53795D);
        this.f3486q = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f3487r = findViewById(C4998f.f53833z);
        View findViewById = findViewById(C4998f.f53794C);
        this.f3488s = findViewById;
        View findViewById2 = findViewById(C4998f.f53801J);
        this.f3489t = findViewById2;
        ImageView imageView = (ImageView) findViewById(C4998f.f53831x);
        this.f3490u = imageView;
        ImageView imageView2 = (ImageView) findViewById(C4998f.f53792A);
        this.f3491v = imageView2;
        ImageView imageView3 = (ImageView) findViewById(C4998f.f53832y);
        this.f3492w = imageView3;
        ImageView imageView4 = (ImageView) findViewById(C4998f.f53796E);
        this.f3493x = imageView4;
        ImageView imageView5 = (ImageView) findViewById(C4998f.f53793B);
        this.f3453E = imageView5;
        C1015b0.g0(findViewById, u5.f(f.j.f54077q2));
        C1015b0.g0(findViewById2, u5.f(f.j.f54097u2));
        imageView.setImageDrawable(u5.f(f.j.f54092t2));
        imageView2.setImageDrawable(u5.f(f.j.f54062n2));
        imageView3.setImageDrawable(u5.f(f.j.f54047k2));
        imageView4.setImageDrawable(u5.f(f.j.f54107w2));
        imageView5.setImageDrawable(u5.f(f.j.f54092t2));
        this.f3454F = u5.f(f.j.f54087s2);
        l0.a(imageView, getResources().getString(C5000h.f53867n));
        this.f3455G = u5.m(f.j.f54102v2, C4999g.f53850q);
        this.f3456H = u5.m(f.j.f54052l2, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(this.f3485n0);
        searchAutoComplete.setOnEditorActionListener(hVar);
        searchAutoComplete.setOnItemClickListener(iVar);
        searchAutoComplete.setOnItemSelectedListener(jVar);
        searchAutoComplete.setOnKeyListener(this.f3481j0);
        searchAutoComplete.setOnFocusChangeListener(new d());
        setIconifiedByDefault(u5.a(f.j.f54067o2, true));
        int e5 = u5.e(f.j.f54032h2, -1);
        if (e5 != -1) {
            setMaxWidth(e5);
        }
        this.f3459K = u5.o(f.j.f54057m2);
        this.f3466R = u5.o(f.j.f54082r2);
        int j5 = u5.j(f.j.f54042j2, -1);
        if (j5 != -1) {
            setImeOptions(j5);
        }
        int j6 = u5.j(f.j.f54037i2, -1);
        if (j6 != -1) {
            setInputType(j6);
        }
        setFocusable(u5.a(f.j.f54027g2, true));
        u5.w();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f3457I = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f3458J = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f3494y = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new e());
        }
        g0(this.f3462N);
        c0();
    }
}
