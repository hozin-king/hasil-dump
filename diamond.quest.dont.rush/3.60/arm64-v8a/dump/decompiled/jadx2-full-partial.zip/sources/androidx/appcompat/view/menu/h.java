package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.DialogInterfaceC0977c;
import androidx.appcompat.view.menu.m;
import f.C4999g;

/* loaded from: classes.dex */
class h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, m.a {

    /* renamed from: b, reason: collision with root package name */
    private g f3136b;

    /* renamed from: c, reason: collision with root package name */
    private DialogInterfaceC0977c f3137c;

    /* renamed from: d, reason: collision with root package name */
    e f3138d;

    /* renamed from: e, reason: collision with root package name */
    private m.a f3139e;

    public h(g gVar) {
        this.f3136b = gVar;
    }

    @Override // androidx.appcompat.view.menu.m.a
    public void a(g gVar, boolean z4) {
        if (z4 || gVar == this.f3136b) {
            c();
        }
        m.a aVar = this.f3139e;
        if (aVar != null) {
            aVar.a(gVar, z4);
        }
    }

    @Override // androidx.appcompat.view.menu.m.a
    public boolean b(g gVar) {
        m.a aVar = this.f3139e;
        if (aVar != null) {
            return aVar.b(gVar);
        }
        return false;
    }

    public void c() {
        DialogInterfaceC0977c dialogInterfaceC0977c = this.f3137c;
        if (dialogInterfaceC0977c != null) {
            dialogInterfaceC0977c.dismiss();
        }
    }

    public void d(IBinder iBinder) {
        g gVar = this.f3136b;
        DialogInterfaceC0977c.a aVar = new DialogInterfaceC0977c.a(gVar.u());
        e eVar = new e(aVar.getContext(), C4999g.f53843j);
        this.f3138d = eVar;
        eVar.g(this);
        this.f3136b.b(this.f3138d);
        aVar.a(this.f3138d.i(), this);
        View y5 = gVar.y();
        if (y5 != null) {
            aVar.b(y5);
        } else {
            aVar.c(gVar.w()).setTitle(gVar.x());
        }
        aVar.d(this);
        DialogInterfaceC0977c create = aVar.create();
        this.f3137c = create;
        create.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f3137c.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.f3137c.show();
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i5) {
        this.f3136b.M((i) this.f3138d.i().getItem(i5), 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        this.f3138d.a(this.f3136b, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i5, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i5 == 82 || i5 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f3137c.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f3137c.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f3136b.e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f3136b.performShortcut(i5, keyEvent, 0);
    }
}
