package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;

/* renamed from: androidx.appcompat.widget.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0987f extends Button implements androidx.core.widget.l {

    /* renamed from: b, reason: collision with root package name */
    private final C0986e f3772b;

    /* renamed from: c, reason: collision with root package name */
    private final A f3773c;

    /* renamed from: d, reason: collision with root package name */
    private C0995n f3774d;

    public C0987f(@NonNull Context context) {
        this(context, null);
    }

    @NonNull
    private C0995n getEmojiTextViewHelper() {
        if (this.f3774d == null) {
            this.f3774d = new C0995n(this);
        }
        return this.f3774d;
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            c0986e.b();
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (r0.f3875c) {
            return super.getAutoSizeMaxTextSize();
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            return a5.e();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (r0.f3875c) {
            return super.getAutoSizeMinTextSize();
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            return a5.f();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (r0.f3875c) {
            return super.getAutoSizeStepGranularity();
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            return a5.g();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (r0.f3875c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        A a5 = this.f3773c;
        return a5 != null ? a5.h() : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (r0.f3875c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            return a5.i();
        }
        return 0;
    }

    @Override // android.widget.TextView
    @Nullable
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return androidx.core.widget.j.n(super.getCustomSelectionActionModeCallback());
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f3773c.j();
    }

    @Nullable
    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f3773c.k();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        super.onLayout(z4, i5, i6, i7, i8);
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.o(z4, i5, i6, i7, i8);
        }
    }

    @Override // android.widget.TextView
    protected void onTextChanged(CharSequence charSequence, int i5, int i6, int i7) {
        super.onTextChanged(charSequence, i5, i6, i7);
        A a5 = this.f3773c;
        if (a5 == null || r0.f3875c || !a5.l()) {
            return;
        }
        this.f3773c.c();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().d(z4);
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i5, int i6, int i7, int i8) {
        if (r0.f3875c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i5, i6, i7, i8);
            return;
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.t(i5, i6, i7, i8);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i5) {
        if (r0.f3875c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i5);
            return;
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.u(iArr, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i5) {
        if (r0.f3875c) {
            super.setAutoSizeTextTypeWithDefaults(i5);
            return;
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.v(i5);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(@Nullable ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(androidx.core.widget.j.o(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().e(z4);
    }

    @Override // android.widget.TextView
    public void setFilters(@NonNull InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z4) {
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.s(z4);
        }
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.f3772b;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList colorStateList) {
        this.f3773c.w(colorStateList);
        this.f3773c.b();
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode mode) {
        this.f3773c.x(mode);
        this.f3773c.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i5) {
        super.setTextAppearance(context, i5);
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.q(context, i5);
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(int i5, float f5) {
        if (r0.f3875c) {
            super.setTextSize(i5, f5);
            return;
        }
        A a5 = this.f3773c;
        if (a5 != null) {
            a5.A(i5, f5);
        }
    }

    public C0987f(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53714r);
    }

    public C0987f(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        c0.a(this, getContext());
        C0986e c0986e = new C0986e(this);
        this.f3772b = c0986e;
        c0986e.e(attributeSet, i5);
        A a5 = new A(this);
        this.f3773c = a5;
        a5.m(attributeSet, i5);
        a5.b();
        getEmojiTextViewHelper().c(attributeSet, i5);
    }
}
