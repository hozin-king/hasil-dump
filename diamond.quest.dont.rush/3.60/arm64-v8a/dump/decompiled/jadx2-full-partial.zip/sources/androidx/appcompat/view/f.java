package androidx.appcompat.view;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.b;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.o;
import androidx.collection.k;
import java.util.ArrayList;
import p.InterfaceMenuC7301a;
import p.InterfaceMenuItemC7302b;

/* loaded from: classes.dex */
public class f extends ActionMode {

    /* renamed from: a, reason: collision with root package name */
    final Context f2933a;

    /* renamed from: b, reason: collision with root package name */
    final b f2934b;

    public static class a implements b.a {

        /* renamed from: a, reason: collision with root package name */
        final ActionMode.Callback f2935a;

        /* renamed from: b, reason: collision with root package name */
        final Context f2936b;

        /* renamed from: c, reason: collision with root package name */
        final ArrayList f2937c = new ArrayList();

        /* renamed from: d, reason: collision with root package name */
        final k f2938d = new k();

        public a(Context context, ActionMode.Callback callback) {
            this.f2936b = context;
            this.f2935a = callback;
        }

        private Menu f(Menu menu) {
            Menu menu2 = (Menu) this.f2938d.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            o oVar = new o(this.f2936b, (InterfaceMenuC7301a) menu);
            this.f2938d.put(menu, oVar);
            return oVar;
        }

        @Override // androidx.appcompat.view.b.a
        public boolean a(b bVar, Menu menu) {
            return this.f2935a.onCreateActionMode(e(bVar), f(menu));
        }

        @Override // androidx.appcompat.view.b.a
        public boolean b(b bVar, MenuItem menuItem) {
            return this.f2935a.onActionItemClicked(e(bVar), new j(this.f2936b, (InterfaceMenuItemC7302b) menuItem));
        }

        @Override // androidx.appcompat.view.b.a
        public boolean c(b bVar, Menu menu) {
            return this.f2935a.onPrepareActionMode(e(bVar), f(menu));
        }

        @Override // androidx.appcompat.view.b.a
        public void d(b bVar) {
            this.f2935a.onDestroyActionMode(e(bVar));
        }

        public ActionMode e(b bVar) {
            int size = this.f2937c.size();
            for (int i5 = 0; i5 < size; i5++) {
                f fVar = (f) this.f2937c.get(i5);
                if (fVar != null && fVar.f2934b == bVar) {
                    return fVar;
                }
            }
            f fVar2 = new f(this.f2936b, bVar);
            this.f2937c.add(fVar2);
            return fVar2;
        }
    }

    public f(Context context, b bVar) {
        this.f2933a = context;
        this.f2934b = bVar;
    }

    @Override // android.view.ActionMode
    public void finish() {
        this.f2934b.c();
    }

    @Override // android.view.ActionMode
    public View getCustomView() {
        return this.f2934b.d();
    }

    @Override // android.view.ActionMode
    public Menu getMenu() {
        return new o(this.f2933a, (InterfaceMenuC7301a) this.f2934b.e());
    }

    @Override // android.view.ActionMode
    public MenuInflater getMenuInflater() {
        return this.f2934b.f();
    }

    @Override // android.view.ActionMode
    public CharSequence getSubtitle() {
        return this.f2934b.g();
    }

    @Override // android.view.ActionMode
    public Object getTag() {
        return this.f2934b.h();
    }

    @Override // android.view.ActionMode
    public CharSequence getTitle() {
        return this.f2934b.i();
    }

    @Override // android.view.ActionMode
    public boolean getTitleOptionalHint() {
        return this.f2934b.j();
    }

    @Override // android.view.ActionMode
    public void invalidate() {
        this.f2934b.k();
    }

    @Override // android.view.ActionMode
    public boolean isTitleOptional() {
        return this.f2934b.l();
    }

    @Override // android.view.ActionMode
    public void setCustomView(View view) {
        this.f2934b.m(view);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(CharSequence charSequence) {
        this.f2934b.o(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTag(Object obj) {
        this.f2934b.p(obj);
    }

    @Override // android.view.ActionMode
    public void setTitle(CharSequence charSequence) {
        this.f2934b.r(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTitleOptionalHint(boolean z4) {
        this.f2934b.s(z4);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(int i5) {
        this.f2934b.n(i5);
    }

    @Override // android.view.ActionMode
    public void setTitle(int i5) {
        this.f2934b.q(i5);
    }
}
