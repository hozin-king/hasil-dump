package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.b;
import androidx.core.view.C1053y;
import f.C4993a;

/* loaded from: classes.dex */
public class x extends androidx.activity.q implements InterfaceC0978d {

    /* renamed from: e, reason: collision with root package name */
    private AbstractC0980f f2842e;

    /* renamed from: f, reason: collision with root package name */
    private final C1053y.a f2843f;

    public x(@NonNull Context context) {
        this(context, 0);
    }

    private static int f(Context context, int i5) {
        if (i5 != 0) {
            return i5;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C4993a.f53680A, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // androidx.activity.q, android.app.Dialog
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c();
        e().e(view, layoutParams);
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        super.dismiss();
        e().y();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C1053y.e(this.f2843f, getWindow().getDecorView(), this, keyEvent);
    }

    public AbstractC0980f e() {
        if (this.f2842e == null) {
            this.f2842e = AbstractC0980f.i(this, this);
        }
        return this.f2842e;
    }

    @Override // android.app.Dialog
    public View findViewById(int i5) {
        return e().j(i5);
    }

    boolean g(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean h(int i5) {
        return e().G(i5);
    }

    @Override // android.app.Dialog
    public void invalidateOptionsMenu() {
        e().u();
    }

    @Override // androidx.activity.q, android.app.Dialog
    protected void onCreate(Bundle bundle) {
        e().t();
        super.onCreate(bundle);
        e().x(bundle);
    }

    @Override // androidx.activity.q, android.app.Dialog
    protected void onStop() {
        super.onStop();
        e().D();
    }

    @Override // androidx.appcompat.app.InterfaceC0978d
    public void onSupportActionModeFinished(androidx.appcompat.view.b bVar) {
    }

    @Override // androidx.appcompat.app.InterfaceC0978d
    public void onSupportActionModeStarted(androidx.appcompat.view.b bVar) {
    }

    @Override // androidx.appcompat.app.InterfaceC0978d
    public androidx.appcompat.view.b onWindowStartingSupportActionMode(b.a aVar) {
        return null;
    }

    @Override // androidx.activity.q, android.app.Dialog
    public void setContentView(int i5) {
        c();
        e().H(i5);
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        e().N(charSequence);
    }

    public x(@NonNull Context context, int i5) {
        super(context, f(context, i5));
        this.f2843f = new C1053y.a() { // from class: androidx.appcompat.app.w
            @Override // androidx.core.view.C1053y.a
            public final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
                return x.this.g(keyEvent);
            }
        };
        AbstractC0980f e5 = e();
        e5.M(f(context, i5));
        e5.x(null);
    }

    @Override // androidx.activity.q, android.app.Dialog
    public void setContentView(View view) {
        c();
        e().I(view);
    }

    @Override // android.app.Dialog
    public void setTitle(int i5) {
        super.setTitle(i5);
        e().N(getContext().getString(i5));
    }

    @Override // androidx.activity.q, android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c();
        e().J(view, layoutParams);
    }

    protected x(@NonNull Context context, boolean z4, @Nullable DialogInterface.OnCancelListener onCancelListener) {
        super(context);
        this.f2843f = new C1053y.a() { // from class: androidx.appcompat.app.w
            @Override // androidx.core.view.C1053y.a
            public final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
                return x.this.g(keyEvent);
            }
        };
        setCancelable(z4);
        setOnCancelListener(onCancelListener);
    }
}
