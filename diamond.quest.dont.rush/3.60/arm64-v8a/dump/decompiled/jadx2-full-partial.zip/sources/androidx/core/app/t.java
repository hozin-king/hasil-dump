package androidx.core.app;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: classes.dex */
abstract class t {

    /* renamed from: a, reason: collision with root package name */
    private static final Object f4258a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private static final Object f4259b = new Object();

    private static A a(Bundle bundle) {
        ArrayList<String> stringArrayList = bundle.getStringArrayList("allowedDataTypes");
        HashSet hashSet = new HashSet();
        if (stringArrayList != null) {
            int size = stringArrayList.size();
            int i5 = 0;
            while (i5 < size) {
                String str = stringArrayList.get(i5);
                i5++;
                hashSet.add(str);
            }
        }
        return new A(bundle.getString("resultKey"), bundle.getCharSequence("label"), bundle.getCharSequenceArray("choices"), bundle.getBoolean("allowFreeFormInput"), 0, bundle.getBundle("extras"), hashSet);
    }

    private static A[] b(Bundle[] bundleArr) {
        if (bundleArr == null) {
            return null;
        }
        A[] aArr = new A[bundleArr.length];
        for (int i5 = 0; i5 < bundleArr.length; i5++) {
            aArr[i5] = a(bundleArr[i5]);
        }
        return aArr;
    }

    static NotificationCompat.b c(Bundle bundle) {
        Bundle bundle2 = bundle.getBundle("extras");
        return new NotificationCompat.b(bundle.getInt("icon"), bundle.getCharSequence("title"), (PendingIntent) bundle.getParcelable("actionIntent"), bundle.getBundle("extras"), b(d(bundle, "remoteInputs")), b(d(bundle, "dataOnlyRemoteInputs")), bundle2 != null ? bundle2.getBoolean("android.support.allowGeneratedReplies", false) : false, bundle.getInt("semanticAction"), bundle.getBoolean("showsUserInterface"), false, false);
    }

    private static Bundle[] d(Bundle bundle, String str) {
        Parcelable[] parcelableArray = bundle.getParcelableArray(str);
        if ((parcelableArray instanceof Bundle[]) || parcelableArray == null) {
            return (Bundle[]) parcelableArray;
        }
        Bundle[] bundleArr = (Bundle[]) Arrays.copyOf(parcelableArray, parcelableArray.length, Bundle[].class);
        bundle.putParcelableArray(str, bundleArr);
        return bundleArr;
    }

    static Bundle e(NotificationCompat.b bVar) {
        Bundle bundle = new Bundle();
        IconCompat d5 = bVar.d();
        bundle.putInt("icon", d5 != null ? d5.r() : 0);
        bundle.putCharSequence("title", bVar.h());
        bundle.putParcelable("actionIntent", bVar.a());
        Bundle bundle2 = bVar.c() != null ? new Bundle(bVar.c()) : new Bundle();
        bundle2.putBoolean("android.support.allowGeneratedReplies", bVar.b());
        bundle.putBundle("extras", bundle2);
        bundle.putParcelableArray("remoteInputs", g(bVar.e()));
        bundle.putBoolean("showsUserInterface", bVar.g());
        bundle.putInt("semanticAction", bVar.f());
        return bundle;
    }

    private static Bundle f(A a5) {
        Bundle bundle = new Bundle();
        bundle.putString("resultKey", a5.j());
        bundle.putCharSequence("label", a5.i());
        bundle.putCharSequenceArray("choices", a5.f());
        bundle.putBoolean("allowFreeFormInput", a5.d());
        bundle.putBundle("extras", a5.h());
        Set e5 = a5.e();
        if (e5 != null && !e5.isEmpty()) {
            ArrayList<String> arrayList = new ArrayList<>(e5.size());
            Iterator it = e5.iterator();
            while (it.hasNext()) {
                arrayList.add((String) it.next());
            }
            bundle.putStringArrayList("allowedDataTypes", arrayList);
        }
        return bundle;
    }

    private static Bundle[] g(A[] aArr) {
        if (aArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[aArr.length];
        for (int i5 = 0; i5 < aArr.length; i5++) {
            bundleArr[i5] = f(aArr[i5]);
        }
        return bundleArr;
    }
}
