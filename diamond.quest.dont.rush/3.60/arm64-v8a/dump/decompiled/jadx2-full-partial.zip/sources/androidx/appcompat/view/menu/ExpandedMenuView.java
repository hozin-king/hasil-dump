package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.g0;

/* loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements g.b, n, AdapterView.OnItemClickListener {

    /* renamed from: d, reason: collision with root package name */
    private static final int[] f3002d = {R.attr.background, R.attr.divider};

    /* renamed from: b, reason: collision with root package name */
    private g f3003b;

    /* renamed from: c, reason: collision with root package name */
    private int f3004c;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listViewStyle);
    }

    @Override // androidx.appcompat.view.menu.n
    public void a(g gVar) {
        this.f3003b = gVar;
    }

    @Override // androidx.appcompat.view.menu.g.b
    public boolean b(i iVar) {
        return this.f3003b.M(iVar, 0);
    }

    public int getWindowAnimations() {
        return this.f3004c;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i5, long j5) {
        b((i) getAdapter().getItem(i5));
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i5) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        g0 u5 = g0.u(context, attributeSet, f3002d, i5, 0);
        if (u5.r(0)) {
            setBackgroundDrawable(u5.f(0));
        }
        if (u5.r(1)) {
            setDivider(u5.f(1));
        }
        u5.w();
    }
}
