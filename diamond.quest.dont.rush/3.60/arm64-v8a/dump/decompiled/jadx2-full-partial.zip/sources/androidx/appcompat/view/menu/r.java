package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.g;
import io.appmetrica.analytics.coreutils.internal.StringUtils;

/* loaded from: classes.dex */
public class r extends g implements SubMenu {

    /* renamed from: B, reason: collision with root package name */
    private g f3220B;

    /* renamed from: C, reason: collision with root package name */
    private i f3221C;

    public r(Context context, g gVar, i iVar) {
        super(context);
        this.f3220B = gVar;
        this.f3221C = iVar;
    }

    @Override // androidx.appcompat.view.menu.g
    public g D() {
        return this.f3220B.D();
    }

    @Override // androidx.appcompat.view.menu.g
    public boolean G() {
        return this.f3220B.G();
    }

    @Override // androidx.appcompat.view.menu.g
    public boolean H() {
        return this.f3220B.H();
    }

    @Override // androidx.appcompat.view.menu.g
    public boolean I() {
        return this.f3220B.I();
    }

    @Override // androidx.appcompat.view.menu.g
    public void S(g.a aVar) {
        this.f3220B.S(aVar);
    }

    @Override // androidx.appcompat.view.menu.g
    public boolean f(i iVar) {
        return this.f3220B.f(iVar);
    }

    public Menu f0() {
        return this.f3220B;
    }

    @Override // android.view.SubMenu
    public MenuItem getItem() {
        return this.f3221C;
    }

    @Override // androidx.appcompat.view.menu.g
    boolean h(g gVar, MenuItem menuItem) {
        return super.h(gVar, menuItem) || this.f3220B.h(gVar, menuItem);
    }

    @Override // androidx.appcompat.view.menu.g
    public boolean k(i iVar) {
        return this.f3220B.k(iVar);
    }

    @Override // androidx.appcompat.view.menu.g, android.view.Menu
    public void setGroupDividerEnabled(boolean z4) {
        this.f3220B.setGroupDividerEnabled(z4);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(Drawable drawable) {
        return (SubMenu) super.W(drawable);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        return (SubMenu) super.Z(charSequence);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderView(View view) {
        return (SubMenu) super.a0(view);
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(Drawable drawable) {
        this.f3221C.setIcon(drawable);
        return this;
    }

    @Override // androidx.appcompat.view.menu.g, android.view.Menu
    public void setQwertyMode(boolean z4) {
        this.f3220B.setQwertyMode(z4);
    }

    @Override // androidx.appcompat.view.menu.g
    public String t() {
        i iVar = this.f3221C;
        int itemId = iVar != null ? iVar.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        return super.t() + StringUtils.PROCESS_POSTFIX_DELIMITER + itemId;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(int i5) {
        return (SubMenu) super.V(i5);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(int i5) {
        return (SubMenu) super.Y(i5);
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(int i5) {
        this.f3221C.setIcon(i5);
        return this;
    }
}
