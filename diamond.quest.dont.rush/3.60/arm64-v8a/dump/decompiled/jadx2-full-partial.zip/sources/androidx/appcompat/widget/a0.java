package androidx.appcompat.widget;

import android.R;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.firebase.sessions.settings.RemoteSettings;
import f.C4993a;
import f.C4998f;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.WeakHashMap;
import x.AbstractC7516c;

/* loaded from: classes.dex */
class a0 extends AbstractC7516c implements View.OnClickListener {

    /* renamed from: A, reason: collision with root package name */
    private int f3648A;

    /* renamed from: n, reason: collision with root package name */
    private final SearchView f3649n;

    /* renamed from: o, reason: collision with root package name */
    private final SearchableInfo f3650o;

    /* renamed from: p, reason: collision with root package name */
    private final Context f3651p;

    /* renamed from: q, reason: collision with root package name */
    private final WeakHashMap f3652q;

    /* renamed from: r, reason: collision with root package name */
    private final int f3653r;

    /* renamed from: s, reason: collision with root package name */
    private boolean f3654s;

    /* renamed from: t, reason: collision with root package name */
    private int f3655t;

    /* renamed from: u, reason: collision with root package name */
    private ColorStateList f3656u;

    /* renamed from: v, reason: collision with root package name */
    private int f3657v;

    /* renamed from: w, reason: collision with root package name */
    private int f3658w;

    /* renamed from: x, reason: collision with root package name */
    private int f3659x;

    /* renamed from: y, reason: collision with root package name */
    private int f3660y;

    /* renamed from: z, reason: collision with root package name */
    private int f3661z;

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final TextView f3662a;

        /* renamed from: b, reason: collision with root package name */
        public final TextView f3663b;

        /* renamed from: c, reason: collision with root package name */
        public final ImageView f3664c;

        /* renamed from: d, reason: collision with root package name */
        public final ImageView f3665d;

        /* renamed from: e, reason: collision with root package name */
        public final ImageView f3666e;

        public a(View view) {
            this.f3662a = (TextView) view.findViewById(R.id.text1);
            this.f3663b = (TextView) view.findViewById(R.id.text2);
            this.f3664c = (ImageView) view.findViewById(R.id.icon1);
            this.f3665d = (ImageView) view.findViewById(R.id.icon2);
            this.f3666e = (ImageView) view.findViewById(C4998f.f53824q);
        }
    }

    public a0(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap weakHashMap) {
        super(context, searchView.getSuggestionRowLayout(), (Cursor) null, true);
        this.f3654s = false;
        this.f3655t = 1;
        this.f3657v = -1;
        this.f3658w = -1;
        this.f3659x = -1;
        this.f3660y = -1;
        this.f3661z = -1;
        this.f3648A = -1;
        this.f3649n = searchView;
        this.f3650o = searchableInfo;
        this.f3653r = searchView.getSuggestionCommitIconResId();
        this.f3651p = context;
        this.f3652q = weakHashMap;
    }

    private void A(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null) {
            extras.getBoolean("in_progress");
        }
    }

    private Drawable j(String str) {
        Drawable.ConstantState constantState = (Drawable.ConstantState) this.f3652q.get(str);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    private CharSequence k(CharSequence charSequence) {
        if (this.f3656u == null) {
            TypedValue typedValue = new TypedValue();
            this.f3651p.getTheme().resolveAttribute(C4993a.f53694O, typedValue, true);
            this.f3656u = this.f3651p.getResources().getColorStateList(typedValue.resourceId);
        }
        SpannableString spannableString = new SpannableString(charSequence);
        spannableString.setSpan(new TextAppearanceSpan(null, 0, 0, this.f3656u, null), 0, charSequence.length(), 33);
        return spannableString;
    }

    private Drawable l(ComponentName componentName) {
        PackageManager packageManager = this.f3651p.getPackageManager();
        try {
            ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, 128);
            int iconResource = activityInfo.getIconResource();
            if (iconResource == 0) {
                return null;
            }
            Drawable drawable = packageManager.getDrawable(componentName.getPackageName(), iconResource, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            Log.w("SuggestionsAdapter", "Invalid icon resource " + iconResource + " for " + componentName.flattenToShortString());
            return null;
        } catch (PackageManager.NameNotFoundException e5) {
            Log.w("SuggestionsAdapter", e5.toString());
            return null;
        }
    }

    private Drawable m(ComponentName componentName) {
        String flattenToShortString = componentName.flattenToShortString();
        if (!this.f3652q.containsKey(flattenToShortString)) {
            Drawable l5 = l(componentName);
            this.f3652q.put(flattenToShortString, l5 != null ? l5.getConstantState() : null);
            return l5;
        }
        Drawable.ConstantState constantState = (Drawable.ConstantState) this.f3652q.get(flattenToShortString);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable(this.f3651p.getResources());
    }

    public static String n(Cursor cursor, String str) {
        return v(cursor, cursor.getColumnIndex(str));
    }

    private Drawable o() {
        Drawable m5 = m(this.f3650o.getSearchActivity());
        return m5 != null ? m5 : this.f3651p.getPackageManager().getDefaultActivityIcon();
    }

    private Drawable p(Uri uri) {
        try {
            if ("android.resource".equals(uri.getScheme())) {
                try {
                    return q(uri);
                } catch (Resources.NotFoundException unused) {
                    throw new FileNotFoundException("Resource does not exist: " + uri);
                }
            }
            InputStream openInputStream = this.f3651p.getContentResolver().openInputStream(uri);
            if (openInputStream == null) {
                throw new FileNotFoundException("Failed to open " + uri);
            }
            try {
                Drawable createFromStream = Drawable.createFromStream(openInputStream, null);
                try {
                    return createFromStream;
                } catch (IOException e5) {
                    return createFromStream;
                }
            } finally {
                try {
                    openInputStream.close();
                } catch (IOException e52) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, e52);
                }
            }
        } catch (FileNotFoundException e6) {
            Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e6.getMessage());
            return null;
        }
        Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e6.getMessage());
        return null;
    }

    private Drawable r(String str) {
        if (str == null || str.isEmpty() || "0".equals(str)) {
            return null;
        }
        try {
            int parseInt = Integer.parseInt(str);
            String str2 = "android.resource://" + this.f3651p.getPackageName() + RemoteSettings.FORWARD_SLASH_STRING + parseInt;
            Drawable j5 = j(str2);
            if (j5 != null) {
                return j5;
            }
            Drawable drawable = androidx.core.content.a.getDrawable(this.f3651p, parseInt);
            z(str2, drawable);
            return drawable;
        } catch (Resources.NotFoundException unused) {
            Log.w("SuggestionsAdapter", "Icon resource not found: " + str);
            return null;
        } catch (NumberFormatException unused2) {
            Drawable j6 = j(str);
            if (j6 != null) {
                return j6;
            }
            Drawable p5 = p(Uri.parse(str));
            z(str, p5);
            return p5;
        }
    }

    private Drawable s(Cursor cursor) {
        int i5 = this.f3660y;
        if (i5 == -1) {
            return null;
        }
        Drawable r5 = r(cursor.getString(i5));
        return r5 != null ? r5 : o();
    }

    private Drawable t(Cursor cursor) {
        int i5 = this.f3661z;
        if (i5 == -1) {
            return null;
        }
        return r(cursor.getString(i5));
    }

    private static String v(Cursor cursor, int i5) {
        if (i5 == -1) {
            return null;
        }
        try {
            return cursor.getString(i5);
        } catch (Exception e5) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e5);
            return null;
        }
    }

    private void x(ImageView imageView, Drawable drawable, int i5) {
        imageView.setImageDrawable(drawable);
        if (drawable == null) {
            imageView.setVisibility(i5);
            return;
        }
        imageView.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    private void y(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        if (TextUtils.isEmpty(charSequence)) {
            textView.setVisibility(8);
        } else {
            textView.setVisibility(0);
        }
    }

    private void z(String str, Drawable drawable) {
        if (drawable != null) {
            this.f3652q.put(str, drawable.getConstantState());
        }
    }

    @Override // x.AbstractC7514a, x.C7515b.a
    public void a(Cursor cursor) {
        if (this.f3654s) {
            Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
            if (cursor != null) {
                cursor.close();
                return;
            }
            return;
        }
        try {
            super.a(cursor);
            if (cursor != null) {
                this.f3657v = cursor.getColumnIndex("suggest_text_1");
                this.f3658w = cursor.getColumnIndex("suggest_text_2");
                this.f3659x = cursor.getColumnIndex("suggest_text_2_url");
                this.f3660y = cursor.getColumnIndex("suggest_icon_1");
                this.f3661z = cursor.getColumnIndex("suggest_icon_2");
                this.f3648A = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e5) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e5);
        }
    }

    @Override // x.AbstractC7514a, x.C7515b.a
    public Cursor c(CharSequence charSequence) {
        String charSequence2 = charSequence == null ? "" : charSequence.toString();
        if (this.f3649n.getVisibility() == 0 && this.f3649n.getWindowVisibility() == 0) {
            try {
                Cursor u5 = u(this.f3650o, charSequence2, 50);
                if (u5 != null) {
                    u5.getCount();
                    return u5;
                }
            } catch (RuntimeException e5) {
                Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e5);
            }
        }
        return null;
    }

    @Override // x.AbstractC7514a, x.C7515b.a
    public CharSequence convertToString(Cursor cursor) {
        String n5;
        String n6;
        if (cursor == null) {
            return null;
        }
        String n7 = n(cursor, "suggest_intent_query");
        if (n7 != null) {
            return n7;
        }
        if (this.f3650o.shouldRewriteQueryFromData() && (n6 = n(cursor, "suggest_intent_data")) != null) {
            return n6;
        }
        if (!this.f3650o.shouldRewriteQueryFromText() || (n5 = n(cursor, "suggest_text_1")) == null) {
            return null;
        }
        return n5;
    }

    @Override // x.AbstractC7514a
    public void d(View view, Context context, Cursor cursor) {
        a aVar = (a) view.getTag();
        int i5 = this.f3648A;
        int i6 = i5 != -1 ? cursor.getInt(i5) : 0;
        if (aVar.f3662a != null) {
            y(aVar.f3662a, v(cursor, this.f3657v));
        }
        if (aVar.f3663b != null) {
            String v5 = v(cursor, this.f3659x);
            CharSequence k5 = v5 != null ? k(v5) : v(cursor, this.f3658w);
            if (TextUtils.isEmpty(k5)) {
                TextView textView = aVar.f3662a;
                if (textView != null) {
                    textView.setSingleLine(false);
                    aVar.f3662a.setMaxLines(2);
                }
            } else {
                TextView textView2 = aVar.f3662a;
                if (textView2 != null) {
                    textView2.setSingleLine(true);
                    aVar.f3662a.setMaxLines(1);
                }
            }
            y(aVar.f3663b, k5);
        }
        ImageView imageView = aVar.f3664c;
        if (imageView != null) {
            x(imageView, s(cursor), 4);
        }
        ImageView imageView2 = aVar.f3665d;
        if (imageView2 != null) {
            x(imageView2, t(cursor), 8);
        }
        int i7 = this.f3655t;
        if (i7 != 2 && (i7 != 1 || (i6 & 1) == 0)) {
            aVar.f3666e.setVisibility(8);
            return;
        }
        aVar.f3666e.setVisibility(0);
        aVar.f3666e.setTag(aVar.f3662a.getText());
        aVar.f3666e.setOnClickListener(this);
    }

    @Override // x.AbstractC7516c, x.AbstractC7514a
    public View g(Context context, Cursor cursor, ViewGroup viewGroup) {
        View g5 = super.g(context, cursor, viewGroup);
        g5.setTag(new a(g5));
        ((ImageView) g5.findViewById(C4998f.f53824q)).setImageResource(this.f3653r);
        return g5;
    }

    @Override // x.AbstractC7514a, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i5, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i5, view, viewGroup);
        } catch (RuntimeException e5) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e5);
            View f5 = f(this.f3651p, b(), viewGroup);
            if (f5 != null) {
                ((a) f5.getTag()).f3662a.setText(e5.toString());
            }
            return f5;
        }
    }

    @Override // x.AbstractC7514a, android.widget.Adapter
    public View getView(int i5, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i5, view, viewGroup);
        } catch (RuntimeException e5) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e5);
            View g5 = g(this.f3651p, b(), viewGroup);
            if (g5 != null) {
                ((a) g5.getTag()).f3662a.setText(e5.toString());
            }
            return g5;
        }
    }

    @Override // x.AbstractC7514a, android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return false;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        A(b());
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        A(b());
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f3649n.Q((CharSequence) tag);
        }
    }

    Drawable q(Uri uri) {
        int parseInt;
        String authority = uri.getAuthority();
        if (TextUtils.isEmpty(authority)) {
            throw new FileNotFoundException("No authority: " + uri);
        }
        try {
            Resources resourcesForApplication = this.f3651p.getPackageManager().getResourcesForApplication(authority);
            List<String> pathSegments = uri.getPathSegments();
            if (pathSegments == null) {
                throw new FileNotFoundException("No path: " + uri);
            }
            int size = pathSegments.size();
            if (size == 1) {
                try {
                    parseInt = Integer.parseInt(pathSegments.get(0));
                } catch (NumberFormatException unused) {
                    throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                }
            } else {
                if (size != 2) {
                    throw new FileNotFoundException("More than two path segments: " + uri);
                }
                parseInt = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
            }
            if (parseInt != 0) {
                return resourcesForApplication.getDrawable(parseInt);
            }
            throw new FileNotFoundException("No resource found for: " + uri);
        } catch (PackageManager.NameNotFoundException unused2) {
            throw new FileNotFoundException("No package found for authority: " + uri);
        }
    }

    Cursor u(SearchableInfo searchableInfo, String str, int i5) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder fragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            fragment.appendEncodedPath(suggestPath);
        }
        fragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            fragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        if (i5 > 0) {
            fragment.appendQueryParameter("limit", String.valueOf(i5));
        }
        return this.f3651p.getContentResolver().query(fragment.build(), null, suggestSelection, strArr2, null);
    }

    public void w(int i5) {
        this.f3655t = i5;
    }
}
