package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertController;
import f.C4993a;

/* renamed from: androidx.appcompat.app.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class DialogInterfaceC0977c extends x implements DialogInterface {

    /* renamed from: g, reason: collision with root package name */
    final AlertController f2721g;

    /* renamed from: androidx.appcompat.app.c$a */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        private final AlertController.b f2722a;

        /* renamed from: b, reason: collision with root package name */
        private final int f2723b;

        public a(@NonNull Context context) {
            this(context, DialogInterfaceC0977c.j(context, 0));
        }

        public a a(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f2722a;
            bVar.f2628w = listAdapter;
            bVar.f2629x = onClickListener;
            return this;
        }

        public a b(View view) {
            this.f2722a.f2612g = view;
            return this;
        }

        public a c(Drawable drawable) {
            this.f2722a.f2609d = drawable;
            return this;
        }

        @NonNull
        public DialogInterfaceC0977c create() {
            DialogInterfaceC0977c dialogInterfaceC0977c = new DialogInterfaceC0977c(this.f2722a.f2606a, this.f2723b);
            this.f2722a.a(dialogInterfaceC0977c.f2721g);
            dialogInterfaceC0977c.setCancelable(this.f2722a.f2623r);
            if (this.f2722a.f2623r) {
                dialogInterfaceC0977c.setCanceledOnTouchOutside(true);
            }
            dialogInterfaceC0977c.setOnCancelListener(this.f2722a.f2624s);
            dialogInterfaceC0977c.setOnDismissListener(this.f2722a.f2625t);
            DialogInterface.OnKeyListener onKeyListener = this.f2722a.f2626u;
            if (onKeyListener != null) {
                dialogInterfaceC0977c.setOnKeyListener(onKeyListener);
            }
            return dialogInterfaceC0977c;
        }

        public a d(DialogInterface.OnKeyListener onKeyListener) {
            this.f2722a.f2626u = onKeyListener;
            return this;
        }

        public a e(ListAdapter listAdapter, int i5, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f2722a;
            bVar.f2628w = listAdapter;
            bVar.f2629x = onClickListener;
            bVar.f2599I = i5;
            bVar.f2598H = true;
            return this;
        }

        @NonNull
        public Context getContext() {
            return this.f2722a.f2606a;
        }

        public a setNegativeButton(int i5, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f2722a;
            bVar.f2617l = bVar.f2606a.getText(i5);
            this.f2722a.f2619n = onClickListener;
            return this;
        }

        public a setPositiveButton(int i5, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f2722a;
            bVar.f2614i = bVar.f2606a.getText(i5);
            this.f2722a.f2616k = onClickListener;
            return this;
        }

        public a setTitle(@Nullable CharSequence charSequence) {
            this.f2722a.f2611f = charSequence;
            return this;
        }

        public a setView(View view) {
            AlertController.b bVar = this.f2722a;
            bVar.f2631z = view;
            bVar.f2630y = 0;
            bVar.f2595E = false;
            return this;
        }

        public a(@NonNull Context context, int i5) {
            this.f2722a = new AlertController.b(new ContextThemeWrapper(context, DialogInterfaceC0977c.j(context, i5)));
            this.f2723b = i5;
        }
    }

    protected DialogInterfaceC0977c(@NonNull Context context) {
        this(context, 0);
    }

    static int j(Context context, int i5) {
        if (((i5 >>> 24) & 255) >= 1) {
            return i5;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C4993a.f53712p, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView i() {
        return this.f2721g.d();
    }

    @Override // androidx.appcompat.app.x, androidx.activity.q, android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f2721g.e();
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i5, KeyEvent keyEvent) {
        if (this.f2721g.f(i5, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i5, keyEvent);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i5, KeyEvent keyEvent) {
        if (this.f2721g.g(i5, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i5, keyEvent);
    }

    @Override // androidx.appcompat.app.x, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f2721g.p(charSequence);
    }

    protected DialogInterfaceC0977c(@NonNull Context context, int i5) {
        super(context, j(context, i5));
        this.f2721g = new AlertController(getContext(), this, getWindow());
    }

    protected DialogInterfaceC0977c(@NonNull Context context, boolean z4, @Nullable DialogInterface.OnCancelListener onCancelListener) {
        this(context, 0);
        setCancelable(z4);
        setOnCancelListener(onCancelListener);
    }
}
