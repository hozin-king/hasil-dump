package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;

/* loaded from: classes.dex */
public class Q extends ViewGroup {

    /* renamed from: b, reason: collision with root package name */
    private boolean f3426b;

    /* renamed from: c, reason: collision with root package name */
    private int f3427c;

    /* renamed from: d, reason: collision with root package name */
    private int f3428d;

    /* renamed from: e, reason: collision with root package name */
    private int f3429e;

    /* renamed from: f, reason: collision with root package name */
    private int f3430f;

    /* renamed from: g, reason: collision with root package name */
    private int f3431g;

    /* renamed from: h, reason: collision with root package name */
    private float f3432h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f3433i;

    /* renamed from: j, reason: collision with root package name */
    private int[] f3434j;

    /* renamed from: k, reason: collision with root package name */
    private int[] f3435k;

    /* renamed from: l, reason: collision with root package name */
    private Drawable f3436l;

    /* renamed from: m, reason: collision with root package name */
    private int f3437m;

    /* renamed from: n, reason: collision with root package name */
    private int f3438n;

    /* renamed from: o, reason: collision with root package name */
    private int f3439o;

    /* renamed from: p, reason: collision with root package name */
    private int f3440p;

    public static class a extends LinearLayout.LayoutParams {
        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public a(int i5, int i6) {
            super(i5, i6);
        }

        public a(int i5, int i6, float f5) {
            super(i5, i6, f5);
        }

        public a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    public Q(@NonNull Context context) {
        this(context, null);
    }

    private void g(int i5, int i6) {
        int i7;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        int i8 = 0;
        while (i8 < i5) {
            View o5 = o(i8);
            if (o5.getVisibility() != 8) {
                a aVar = (a) o5.getLayoutParams();
                if (((LinearLayout.LayoutParams) aVar).height == -1) {
                    int i9 = ((LinearLayout.LayoutParams) aVar).width;
                    ((LinearLayout.LayoutParams) aVar).width = o5.getMeasuredWidth();
                    i7 = i6;
                    measureChildWithMargins(o5, i7, 0, makeMeasureSpec, 0);
                    ((LinearLayout.LayoutParams) aVar).width = i9;
                    i8++;
                    i6 = i7;
                }
            }
            i7 = i6;
            i8++;
            i6 = i7;
        }
    }

    private void h(int i5, int i6) {
        int i7;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        int i8 = 0;
        while (i8 < i5) {
            View o5 = o(i8);
            if (o5.getVisibility() != 8) {
                a aVar = (a) o5.getLayoutParams();
                if (((LinearLayout.LayoutParams) aVar).width == -1) {
                    int i9 = ((LinearLayout.LayoutParams) aVar).height;
                    ((LinearLayout.LayoutParams) aVar).height = o5.getMeasuredHeight();
                    i7 = i6;
                    measureChildWithMargins(o5, makeMeasureSpec, 0, i7, 0);
                    ((LinearLayout.LayoutParams) aVar).height = i9;
                    i8++;
                    i6 = i7;
                }
            }
            i7 = i6;
            i8++;
            i6 = i7;
        }
    }

    private void w(View view, int i5, int i6, int i7, int i8) {
        view.layout(i5, i6, i7 + i5, i8 + i6);
    }

    void c(Canvas canvas) {
        int right;
        int left;
        int i5;
        int virtualChildCount = getVirtualChildCount();
        boolean b5 = r0.b(this);
        for (int i6 = 0; i6 < virtualChildCount; i6++) {
            View o5 = o(i6);
            if (o5 != null && o5.getVisibility() != 8 && p(i6)) {
                a aVar = (a) o5.getLayoutParams();
                f(canvas, b5 ? o5.getRight() + ((LinearLayout.LayoutParams) aVar).rightMargin : (o5.getLeft() - ((LinearLayout.LayoutParams) aVar).leftMargin) - this.f3437m);
            }
        }
        if (p(virtualChildCount)) {
            View o6 = o(virtualChildCount - 1);
            if (o6 != null) {
                a aVar2 = (a) o6.getLayoutParams();
                if (b5) {
                    left = o6.getLeft() - ((LinearLayout.LayoutParams) aVar2).leftMargin;
                    i5 = this.f3437m;
                    right = left - i5;
                } else {
                    right = o6.getRight() + ((LinearLayout.LayoutParams) aVar2).rightMargin;
                }
            } else if (b5) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i5 = this.f3437m;
                right = left - i5;
            }
            f(canvas, right);
        }
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof a;
    }

    void d(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        for (int i5 = 0; i5 < virtualChildCount; i5++) {
            View o5 = o(i5);
            if (o5 != null && o5.getVisibility() != 8 && p(i5)) {
                e(canvas, (o5.getTop() - ((LinearLayout.LayoutParams) ((a) o5.getLayoutParams())).topMargin) - this.f3438n);
            }
        }
        if (p(virtualChildCount)) {
            View o6 = o(virtualChildCount - 1);
            e(canvas, o6 == null ? (getHeight() - getPaddingBottom()) - this.f3438n : o6.getBottom() + ((LinearLayout.LayoutParams) ((a) o6.getLayoutParams())).bottomMargin);
        }
    }

    void e(Canvas canvas, int i5) {
        this.f3436l.setBounds(getPaddingLeft() + this.f3440p, i5, (getWidth() - getPaddingRight()) - this.f3440p, this.f3438n + i5);
        this.f3436l.draw(canvas);
    }

    void f(Canvas canvas, int i5) {
        this.f3436l.setBounds(i5, getPaddingTop() + this.f3440p, this.f3437m + i5, (getHeight() - getPaddingBottom()) - this.f3440p);
        this.f3436l.draw(canvas);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i5;
        if (this.f3427c < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i6 = this.f3427c;
        if (childCount <= i6) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i6);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.f3427c == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int i7 = this.f3428d;
        if (this.f3429e == 1 && (i5 = this.f3430f & 112) != 48) {
            if (i5 == 16) {
                i7 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f3431g) / 2;
            } else if (i5 == 80) {
                i7 = ((getBottom() - getTop()) - getPaddingBottom()) - this.f3431g;
            }
        }
        return i7 + ((LinearLayout.LayoutParams) ((a) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.f3427c;
    }

    public Drawable getDividerDrawable() {
        return this.f3436l;
    }

    public int getDividerPadding() {
        return this.f3440p;
    }

    public int getDividerWidth() {
        return this.f3437m;
    }

    public int getGravity() {
        return this.f3430f;
    }

    public int getOrientation() {
        return this.f3429e;
    }

    public int getShowDividers() {
        return this.f3439o;
    }

    int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f3432h;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: i, reason: merged with bridge method [inline-methods] */
    public a generateDefaultLayoutParams() {
        int i5 = this.f3429e;
        if (i5 == 0) {
            return new a(-2, -2);
        }
        if (i5 == 1) {
            return new a(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* renamed from: j, reason: merged with bridge method [inline-methods] */
    public a generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: k, reason: merged with bridge method [inline-methods] */
    public a generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof a ? new a((ViewGroup.MarginLayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new a((ViewGroup.MarginLayoutParams) layoutParams) : new a(layoutParams);
    }

    int l(View view, int i5) {
        return 0;
    }

    int m(View view) {
        return 0;
    }

    int n(View view) {
        return 0;
    }

    View o(int i5) {
        return getChildAt(i5);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.f3436l == null) {
            return;
        }
        if (this.f3429e == 1) {
            d(canvas);
        } else {
            c(canvas);
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        if (this.f3429e == 1) {
            r(i5, i6, i7, i8);
        } else {
            q(i5, i6, i7, i8);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i5, int i6) {
        if (this.f3429e == 1) {
            v(i5, i6);
        } else {
            t(i5, i6);
        }
    }

    protected boolean p(int i5) {
        if (i5 == 0) {
            return (this.f3439o & 1) != 0;
        }
        if (i5 == getChildCount()) {
            return (this.f3439o & 4) != 0;
        }
        if ((this.f3439o & 2) != 0) {
            for (int i6 = i5 - 1; i6 >= 0; i6--) {
                if (getChildAt(i6).getVisibility() != 8) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0105  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00ed  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void q(int r22, int r23, int r24, int r25) {
        /*
            Method dump skipped, instructions count: 321
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Q.q(int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0099  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void r(int r12, int r13, int r14, int r15) {
        /*
            r11 = this;
            int r0 = r11.getPaddingLeft()
            int r14 = r14 - r12
            int r12 = r11.getPaddingRight()
            int r12 = r14 - r12
            int r14 = r14 - r0
            int r1 = r11.getPaddingRight()
            int r14 = r14 - r1
            int r1 = r11.getVirtualChildCount()
            int r2 = r11.f3430f
            r3 = r2 & 112(0x70, float:1.57E-43)
            r4 = 8388615(0x800007, float:1.1754953E-38)
            r2 = r2 & r4
            r4 = 16
            if (r3 == r4) goto L35
            r4 = 80
            if (r3 == r4) goto L2a
            int r13 = r11.getPaddingTop()
            goto L41
        L2a:
            int r3 = r11.getPaddingTop()
            int r3 = r3 + r15
            int r3 = r3 - r13
            int r13 = r11.f3431g
            int r13 = r3 - r13
            goto L41
        L35:
            int r3 = r11.getPaddingTop()
            int r15 = r15 - r13
            int r13 = r11.f3431g
            int r15 = r15 - r13
            int r15 = r15 / 2
            int r13 = r3 + r15
        L41:
            r15 = 0
        L42:
            if (r15 >= r1) goto Lb9
            android.view.View r4 = r11.o(r15)
            r9 = 1
            if (r4 != 0) goto L52
            int r3 = r11.u(r15)
            int r13 = r13 + r3
        L50:
            r3 = r11
            goto Lb7
        L52:
            int r3 = r4.getVisibility()
            r5 = 8
            if (r3 == r5) goto L50
            int r7 = r4.getMeasuredWidth()
            int r8 = r4.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r3 = r4.getLayoutParams()
            r10 = r3
            androidx.appcompat.widget.Q$a r10 = (androidx.appcompat.widget.Q.a) r10
            int r3 = r10.gravity
            if (r3 >= 0) goto L6e
            r3 = r2
        L6e:
            int r5 = r11.getLayoutDirection()
            int r3 = androidx.core.view.C1052x.a(r3, r5)
            r3 = r3 & 7
            if (r3 == r9) goto L88
            r5 = 5
            if (r3 == r5) goto L82
            int r3 = r10.leftMargin
            int r3 = r3 + r0
        L80:
            r5 = r3
            goto L93
        L82:
            int r3 = r12 - r7
            int r5 = r10.rightMargin
        L86:
            int r3 = r3 - r5
            goto L80
        L88:
            int r3 = r14 - r7
            int r3 = r3 / 2
            int r3 = r3 + r0
            int r5 = r10.leftMargin
            int r3 = r3 + r5
            int r5 = r10.rightMargin
            goto L86
        L93:
            boolean r3 = r11.p(r15)
            if (r3 == 0) goto L9c
            int r3 = r11.f3438n
            int r13 = r13 + r3
        L9c:
            int r3 = r10.topMargin
            int r13 = r13 + r3
            int r3 = r11.m(r4)
            int r6 = r13 + r3
            r3 = r11
            r3.w(r4, r5, r6, r7, r8)
            int r5 = r10.bottomMargin
            int r8 = r8 + r5
            int r5 = r11.n(r4)
            int r8 = r8 + r5
            int r13 = r13 + r8
            int r4 = r11.l(r4, r15)
            int r15 = r15 + r4
        Lb7:
            int r15 = r15 + r9
            goto L42
        Lb9:
            r3 = r11
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Q.r(int, int, int, int):void");
    }

    void s(View view, int i5, int i6, int i7, int i8, int i9) {
        measureChildWithMargins(view, i6, i7, i8, i9);
    }

    public void setBaselineAligned(boolean z4) {
        this.f3426b = z4;
    }

    public void setBaselineAlignedChildIndex(int i5) {
        if (i5 >= 0 && i5 < getChildCount()) {
            this.f3427c = i5;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f3436l) {
            return;
        }
        this.f3436l = drawable;
        if (drawable != null) {
            this.f3437m = drawable.getIntrinsicWidth();
            this.f3438n = drawable.getIntrinsicHeight();
        } else {
            this.f3437m = 0;
            this.f3438n = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i5) {
        this.f3440p = i5;
    }

    public void setGravity(int i5) {
        if (this.f3430f != i5) {
            if ((8388615 & i5) == 0) {
                i5 |= 8388611;
            }
            if ((i5 & 112) == 0) {
                i5 |= 48;
            }
            this.f3430f = i5;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i5) {
        int i6 = i5 & 8388615;
        int i7 = this.f3430f;
        if ((8388615 & i7) != i6) {
            this.f3430f = i6 | ((-8388616) & i7);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z4) {
        this.f3433i = z4;
    }

    public void setOrientation(int i5) {
        if (this.f3429e != i5) {
            this.f3429e = i5;
            requestLayout();
        }
    }

    public void setShowDividers(int i5) {
        if (i5 != this.f3439o) {
            requestLayout();
        }
        this.f3439o = i5;
    }

    public void setVerticalGravity(int i5) {
        int i6 = i5 & 112;
        int i7 = this.f3430f;
        if ((i7 & 112) != i6) {
            this.f3430f = i6 | (i7 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f5) {
        this.f3432h = Math.max(0.0f, f5);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:180:0x0461  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void t(int r39, int r40) {
        /*
            Method dump skipped, instructions count: 1294
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Q.t(int, int):void");
    }

    int u(int i5) {
        return 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x0156  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0160  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void v(int r28, int r29) {
        /*
            Method dump skipped, instructions count: 879
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Q.v(int, int):void");
    }

    public Q(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public Q(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        this.f3426b = true;
        this.f3427c = -1;
        this.f3428d = 0;
        this.f3430f = 8388659;
        g0 u5 = g0.u(context, attributeSet, f.j.f53996a1, i5, 0);
        C1015b0.b0(this, context, f.j.f53996a1, attributeSet, u5.q(), i5, 0);
        int j5 = u5.j(f.j.f54006c1, -1);
        if (j5 >= 0) {
            setOrientation(j5);
        }
        int j6 = u5.j(f.j.f54001b1, -1);
        if (j6 >= 0) {
            setGravity(j6);
        }
        boolean a5 = u5.a(f.j.f54011d1, true);
        if (!a5) {
            setBaselineAligned(a5);
        }
        this.f3432h = u5.h(f.j.f54021f1, -1.0f);
        this.f3427c = u5.j(f.j.f54016e1, -1);
        this.f3433i = u5.a(f.j.f54036i1, false);
        setDividerDrawable(u5.f(f.j.f54026g1));
        this.f3439o = u5.j(f.j.f54041j1, 0);
        this.f3440p = u5.e(f.j.f54031h1, 0);
        u5.w();
    }
}
