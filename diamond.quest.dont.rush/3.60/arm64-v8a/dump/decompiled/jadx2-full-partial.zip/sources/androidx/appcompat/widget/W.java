package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import h.C5035a;
import h.C5036b;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class W {

    /* renamed from: i, reason: collision with root package name */
    private static W f3594i;

    /* renamed from: a, reason: collision with root package name */
    private WeakHashMap f3596a;

    /* renamed from: b, reason: collision with root package name */
    private androidx.collection.k f3597b;

    /* renamed from: c, reason: collision with root package name */
    private androidx.collection.l f3598c;

    /* renamed from: d, reason: collision with root package name */
    private final WeakHashMap f3599d = new WeakHashMap(0);

    /* renamed from: e, reason: collision with root package name */
    private TypedValue f3600e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f3601f;

    /* renamed from: g, reason: collision with root package name */
    private f f3602g;

    /* renamed from: h, reason: collision with root package name */
    private static final PorterDuff.Mode f3593h = PorterDuff.Mode.SRC_IN;

    /* renamed from: j, reason: collision with root package name */
    private static final c f3595j = new c(6);

    static class a implements e {
        a() {
        }

        @Override // androidx.appcompat.widget.W.e
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return androidx.appcompat.graphics.drawable.a.m(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e5) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e5);
                return null;
            }
        }
    }

    private static class b implements e {
        b() {
        }

        @Override // androidx.appcompat.widget.W.e
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return androidx.vectordrawable.graphics.drawable.b.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e5) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e5);
                return null;
            }
        }
    }

    private static class c extends androidx.collection.j {
        public c(int i5) {
            super(i5);
        }

        private static int b(int i5, PorterDuff.Mode mode) {
            return ((i5 + 31) * 31) + mode.hashCode();
        }

        PorterDuffColorFilter c(int i5, PorterDuff.Mode mode) {
            return (PorterDuffColorFilter) get(Integer.valueOf(b(i5, mode)));
        }

        PorterDuffColorFilter d(int i5, PorterDuff.Mode mode, PorterDuffColorFilter porterDuffColorFilter) {
            return (PorterDuffColorFilter) put(Integer.valueOf(b(i5, mode)), porterDuffColorFilter);
        }
    }

    static class d implements e {
        d() {
        }

        @Override // androidx.appcompat.widget.W.e
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            String classAttribute = attributeSet.getClassAttribute();
            if (classAttribute != null) {
                try {
                    Drawable drawable = (Drawable) d.class.getClassLoader().loadClass(classAttribute).asSubclass(Drawable.class).getDeclaredConstructor(null).newInstance(null);
                    C5035a.c(drawable, context.getResources(), xmlPullParser, attributeSet, theme);
                    return drawable;
                } catch (Exception e5) {
                    Log.e("DrawableDelegate", "Exception while inflating <drawable>", e5);
                }
            }
            return null;
        }
    }

    private interface e {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    public interface f {
        Drawable a(W w5, Context context, int i5);

        ColorStateList b(Context context, int i5);

        PorterDuff.Mode c(int i5);

        boolean d(Context context, int i5, Drawable drawable);

        boolean e(Context context, int i5, Drawable drawable);
    }

    private static class g implements e {
        g() {
        }

        @Override // androidx.appcompat.widget.W.e
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return androidx.vectordrawable.graphics.drawable.g.c(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e5) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e5);
                return null;
            }
        }
    }

    private void a(String str, e eVar) {
        if (this.f3597b == null) {
            this.f3597b = new androidx.collection.k();
        }
        this.f3597b.put(str, eVar);
    }

    private synchronized boolean b(Context context, long j5, Drawable drawable) {
        try {
            Drawable.ConstantState constantState = drawable.getConstantState();
            if (constantState == null) {
                return false;
            }
            androidx.collection.h hVar = (androidx.collection.h) this.f3599d.get(context);
            if (hVar == null) {
                hVar = new androidx.collection.h();
                this.f3599d.put(context, hVar);
            }
            hVar.k(j5, new WeakReference(constantState));
            return true;
        } catch (Throwable th) {
            throw th;
        }
    }

    private void c(Context context, int i5, ColorStateList colorStateList) {
        if (this.f3596a == null) {
            this.f3596a = new WeakHashMap();
        }
        androidx.collection.l lVar = (androidx.collection.l) this.f3596a.get(context);
        if (lVar == null) {
            lVar = new androidx.collection.l();
            this.f3596a.put(context, lVar);
        }
        lVar.a(i5, colorStateList);
    }

    private void d(Context context) {
        if (this.f3601f) {
            return;
        }
        this.f3601f = true;
        Drawable j5 = j(context, C5036b.f54463a);
        if (j5 == null || !q(j5)) {
            this.f3601f = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
        }
    }

    private static long e(TypedValue typedValue) {
        return (typedValue.assetCookie << 32) | typedValue.data;
    }

    private Drawable f(Context context, int i5) {
        if (this.f3600e == null) {
            this.f3600e = new TypedValue();
        }
        TypedValue typedValue = this.f3600e;
        context.getResources().getValue(i5, typedValue, true);
        long e5 = e(typedValue);
        Drawable i6 = i(context, e5);
        if (i6 != null) {
            return i6;
        }
        f fVar = this.f3602g;
        Drawable a5 = fVar == null ? null : fVar.a(this, context, i5);
        if (a5 != null) {
            a5.setChangingConfigurations(typedValue.changingConfigurations);
            b(context, e5, a5);
        }
        return a5;
    }

    private static PorterDuffColorFilter g(ColorStateList colorStateList, PorterDuff.Mode mode, int[] iArr) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return l(colorStateList.getColorForState(iArr, 0), mode);
    }

    public static synchronized W h() {
        W w5;
        synchronized (W.class) {
            try {
                if (f3594i == null) {
                    W w6 = new W();
                    f3594i = w6;
                    p(w6);
                }
                w5 = f3594i;
            } catch (Throwable th) {
                throw th;
            }
        }
        return w5;
    }

    private synchronized Drawable i(Context context, long j5) {
        androidx.collection.h hVar = (androidx.collection.h) this.f3599d.get(context);
        if (hVar == null) {
            return null;
        }
        WeakReference weakReference = (WeakReference) hVar.f(j5);
        if (weakReference != null) {
            Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
            if (constantState != null) {
                return constantState.newDrawable(context.getResources());
            }
            hVar.l(j5);
        }
        return null;
    }

    public static synchronized PorterDuffColorFilter l(int i5, PorterDuff.Mode mode) {
        PorterDuffColorFilter c5;
        synchronized (W.class) {
            c cVar = f3595j;
            c5 = cVar.c(i5, mode);
            if (c5 == null) {
                c5 = new PorterDuffColorFilter(i5, mode);
                cVar.d(i5, mode, c5);
            }
        }
        return c5;
    }

    private ColorStateList n(Context context, int i5) {
        androidx.collection.l lVar;
        WeakHashMap weakHashMap = this.f3596a;
        if (weakHashMap == null || (lVar = (androidx.collection.l) weakHashMap.get(context)) == null) {
            return null;
        }
        return (ColorStateList) lVar.e(i5);
    }

    private static void p(W w5) {
        if (Build.VERSION.SDK_INT < 24) {
            w5.a("vector", new g());
            w5.a("animated-vector", new b());
            w5.a("animated-selector", new a());
            w5.a("drawable", new d());
        }
    }

    private static boolean q(Drawable drawable) {
        return (drawable instanceof androidx.vectordrawable.graphics.drawable.g) || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }

    private Drawable r(Context context, int i5) {
        int next;
        androidx.collection.k kVar = this.f3597b;
        if (kVar == null || kVar.isEmpty()) {
            return null;
        }
        androidx.collection.l lVar = this.f3598c;
        if (lVar != null) {
            String str = (String) lVar.e(i5);
            if ("appcompat_skip_skip".equals(str) || (str != null && this.f3597b.get(str) == null)) {
                return null;
            }
        } else {
            this.f3598c = new androidx.collection.l();
        }
        if (this.f3600e == null) {
            this.f3600e = new TypedValue();
        }
        TypedValue typedValue = this.f3600e;
        Resources resources = context.getResources();
        resources.getValue(i5, typedValue, true);
        long e5 = e(typedValue);
        Drawable i6 = i(context, e5);
        if (i6 != null) {
            return i6;
        }
        CharSequence charSequence = typedValue.string;
        if (charSequence != null && charSequence.toString().endsWith(".xml")) {
            try {
                XmlResourceParser xml = resources.getXml(i5);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
                do {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } while (next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                String name = xml.getName();
                this.f3598c.a(i5, name);
                e eVar = (e) this.f3597b.get(name);
                if (eVar != null) {
                    i6 = eVar.a(context, xml, asAttributeSet, context.getTheme());
                }
                if (i6 != null) {
                    i6.setChangingConfigurations(typedValue.changingConfigurations);
                    b(context, e5, i6);
                }
            } catch (Exception e6) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", e6);
            }
        }
        if (i6 == null) {
            this.f3598c.a(i5, "appcompat_skip_skip");
        }
        return i6;
    }

    private Drawable v(Context context, int i5, boolean z4, Drawable drawable) {
        ColorStateList m5 = m(context, i5);
        if (m5 != null) {
            Drawable q5 = androidx.core.graphics.drawable.a.q(drawable.mutate());
            androidx.core.graphics.drawable.a.n(q5, m5);
            PorterDuff.Mode o5 = o(i5);
            if (o5 != null) {
                androidx.core.graphics.drawable.a.o(q5, o5);
            }
            return q5;
        }
        f fVar = this.f3602g;
        if ((fVar == null || !fVar.d(context, i5, drawable)) && !x(context, i5, drawable) && z4) {
            return null;
        }
        return drawable;
    }

    static void w(Drawable drawable, e0 e0Var, int[] iArr) {
        int[] state = drawable.getState();
        if (drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
            drawable.setState(new int[0]);
            drawable.setState(state);
        }
        boolean z4 = e0Var.f3771d;
        if (z4 || e0Var.f3770c) {
            drawable.setColorFilter(g(z4 ? e0Var.f3768a : null, e0Var.f3770c ? e0Var.f3769b : f3593h, iArr));
        } else {
            drawable.clearColorFilter();
        }
        if (Build.VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }

    public synchronized Drawable j(Context context, int i5) {
        return k(context, i5, false);
    }

    synchronized Drawable k(Context context, int i5, boolean z4) {
        Drawable r5;
        try {
            d(context);
            r5 = r(context, i5);
            if (r5 == null) {
                r5 = f(context, i5);
            }
            if (r5 == null) {
                r5 = androidx.core.content.a.getDrawable(context, i5);
            }
            if (r5 != null) {
                r5 = v(context, i5, z4, r5);
            }
            if (r5 != null) {
                M.a(r5);
            }
        } catch (Throwable th) {
            throw th;
        }
        return r5;
    }

    synchronized ColorStateList m(Context context, int i5) {
        ColorStateList n5;
        n5 = n(context, i5);
        if (n5 == null) {
            f fVar = this.f3602g;
            n5 = fVar == null ? null : fVar.b(context, i5);
            if (n5 != null) {
                c(context, i5, n5);
            }
        }
        return n5;
    }

    PorterDuff.Mode o(int i5) {
        f fVar = this.f3602g;
        if (fVar == null) {
            return null;
        }
        return fVar.c(i5);
    }

    public synchronized void s(Context context) {
        androidx.collection.h hVar = (androidx.collection.h) this.f3599d.get(context);
        if (hVar != null) {
            hVar.b();
        }
    }

    synchronized Drawable t(Context context, q0 q0Var, int i5) {
        try {
            Drawable r5 = r(context, i5);
            if (r5 == null) {
                r5 = q0Var.a(i5);
            }
            if (r5 == null) {
                return null;
            }
            return v(context, i5, false, r5);
        } catch (Throwable th) {
            throw th;
        }
    }

    public synchronized void u(f fVar) {
        this.f3602g = fVar;
    }

    boolean x(Context context, int i5, Drawable drawable) {
        f fVar = this.f3602g;
        return fVar != null && fVar.e(context, i5, drawable);
    }
}
