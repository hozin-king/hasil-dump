package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.n;
import androidx.core.view.AbstractC1014b;
import f.C5000h;
import g.C5008a;
import p.InterfaceMenuItemC7302b;

/* loaded from: classes.dex */
public final class i implements InterfaceMenuItemC7302b {

    /* renamed from: A, reason: collision with root package name */
    private View f3140A;

    /* renamed from: B, reason: collision with root package name */
    private AbstractC1014b f3141B;

    /* renamed from: C, reason: collision with root package name */
    private MenuItem.OnActionExpandListener f3142C;

    /* renamed from: E, reason: collision with root package name */
    private ContextMenu.ContextMenuInfo f3144E;

    /* renamed from: a, reason: collision with root package name */
    private final int f3145a;

    /* renamed from: b, reason: collision with root package name */
    private final int f3146b;

    /* renamed from: c, reason: collision with root package name */
    private final int f3147c;

    /* renamed from: d, reason: collision with root package name */
    private final int f3148d;

    /* renamed from: e, reason: collision with root package name */
    private CharSequence f3149e;

    /* renamed from: f, reason: collision with root package name */
    private CharSequence f3150f;

    /* renamed from: g, reason: collision with root package name */
    private Intent f3151g;

    /* renamed from: h, reason: collision with root package name */
    private char f3152h;

    /* renamed from: j, reason: collision with root package name */
    private char f3154j;

    /* renamed from: l, reason: collision with root package name */
    private Drawable f3156l;

    /* renamed from: n, reason: collision with root package name */
    g f3158n;

    /* renamed from: o, reason: collision with root package name */
    private r f3159o;

    /* renamed from: p, reason: collision with root package name */
    private Runnable f3160p;

    /* renamed from: q, reason: collision with root package name */
    private MenuItem.OnMenuItemClickListener f3161q;

    /* renamed from: r, reason: collision with root package name */
    private CharSequence f3162r;

    /* renamed from: s, reason: collision with root package name */
    private CharSequence f3163s;

    /* renamed from: z, reason: collision with root package name */
    private int f3170z;

    /* renamed from: i, reason: collision with root package name */
    private int f3153i = 4096;

    /* renamed from: k, reason: collision with root package name */
    private int f3155k = 4096;

    /* renamed from: m, reason: collision with root package name */
    private int f3157m = 0;

    /* renamed from: t, reason: collision with root package name */
    private ColorStateList f3164t = null;

    /* renamed from: u, reason: collision with root package name */
    private PorterDuff.Mode f3165u = null;

    /* renamed from: v, reason: collision with root package name */
    private boolean f3166v = false;

    /* renamed from: w, reason: collision with root package name */
    private boolean f3167w = false;

    /* renamed from: x, reason: collision with root package name */
    private boolean f3168x = false;

    /* renamed from: y, reason: collision with root package name */
    private int f3169y = 16;

    /* renamed from: D, reason: collision with root package name */
    private boolean f3143D = false;

    class a implements AbstractC1014b.InterfaceC0131b {
        a() {
        }

        @Override // androidx.core.view.AbstractC1014b.InterfaceC0131b
        public void onActionProviderVisibilityChanged(boolean z4) {
            i iVar = i.this;
            iVar.f3158n.K(iVar);
        }
    }

    i(g gVar, int i5, int i6, int i7, int i8, CharSequence charSequence, int i9) {
        this.f3158n = gVar;
        this.f3145a = i6;
        this.f3146b = i5;
        this.f3147c = i7;
        this.f3148d = i8;
        this.f3149e = charSequence;
        this.f3170z = i9;
    }

    private static void d(StringBuilder sb, int i5, int i6, String str) {
        if ((i5 & i6) == i6) {
            sb.append(str);
        }
    }

    private Drawable e(Drawable drawable) {
        if (drawable != null && this.f3168x && (this.f3166v || this.f3167w)) {
            drawable = androidx.core.graphics.drawable.a.q(drawable).mutate();
            if (this.f3166v) {
                androidx.core.graphics.drawable.a.n(drawable, this.f3164t);
            }
            if (this.f3167w) {
                androidx.core.graphics.drawable.a.o(drawable, this.f3165u);
            }
            this.f3168x = false;
        }
        return drawable;
    }

    boolean A() {
        return this.f3158n.I() && g() != 0;
    }

    public boolean B() {
        return (this.f3170z & 4) == 4;
    }

    @Override // p.InterfaceMenuItemC7302b
    public AbstractC1014b a() {
        return this.f3141B;
    }

    @Override // p.InterfaceMenuItemC7302b
    public InterfaceMenuItemC7302b b(AbstractC1014b abstractC1014b) {
        AbstractC1014b abstractC1014b2 = this.f3141B;
        if (abstractC1014b2 != null) {
            abstractC1014b2.h();
        }
        this.f3140A = null;
        this.f3141B = abstractC1014b;
        this.f3158n.L(true);
        AbstractC1014b abstractC1014b3 = this.f3141B;
        if (abstractC1014b3 != null) {
            abstractC1014b3.j(new a());
        }
        return this;
    }

    public void c() {
        this.f3158n.J(this);
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean collapseActionView() {
        if ((this.f3170z & 8) == 0) {
            return false;
        }
        if (this.f3140A == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f3142C;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f3158n.f(this);
        }
        return false;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean expandActionView() {
        if (!j()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f3142C;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f3158n.k(this);
        }
        return false;
    }

    public int f() {
        return this.f3148d;
    }

    char g() {
        return this.f3158n.H() ? this.f3154j : this.f3152h;
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public View getActionView() {
        View view = this.f3140A;
        if (view != null) {
            return view;
        }
        AbstractC1014b abstractC1014b = this.f3141B;
        if (abstractC1014b == null) {
            return null;
        }
        View d5 = abstractC1014b.d(this);
        this.f3140A = d5;
        return d5;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f3155k;
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f3154j;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f3162r;
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f3146b;
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        Drawable drawable = this.f3156l;
        if (drawable != null) {
            return e(drawable);
        }
        if (this.f3157m == 0) {
            return null;
        }
        Drawable b5 = C5008a.b(this.f3158n.u(), this.f3157m);
        this.f3157m = 0;
        this.f3156l = b5;
        return e(b5);
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f3164t;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f3165u;
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f3151g;
    }

    @Override // android.view.MenuItem
    public int getItemId() {
        return this.f3145a;
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f3144E;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public int getNumericModifiers() {
        return this.f3153i;
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f3152h;
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f3147c;
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return this.f3159o;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitle() {
        return this.f3149e;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f3150f;
        return charSequence != null ? charSequence : this.f3149e;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f3163s;
    }

    String h() {
        char g5 = g();
        if (g5 == 0) {
            return "";
        }
        Resources resources = this.f3158n.u().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f3158n.u()).hasPermanentMenuKey()) {
            sb.append(resources.getString(C5000h.f53866m));
        }
        int i5 = this.f3158n.H() ? this.f3155k : this.f3153i;
        d(sb, i5, 65536, resources.getString(C5000h.f53862i));
        d(sb, i5, 4096, resources.getString(C5000h.f53858e));
        d(sb, i5, 2, resources.getString(C5000h.f53857d));
        d(sb, i5, 1, resources.getString(C5000h.f53863j));
        d(sb, i5, 4, resources.getString(C5000h.f53865l));
        d(sb, i5, 8, resources.getString(C5000h.f53861h));
        if (g5 == '\b') {
            sb.append(resources.getString(C5000h.f53859f));
        } else if (g5 == '\n') {
            sb.append(resources.getString(C5000h.f53860g));
        } else if (g5 != ' ') {
            sb.append(g5);
        } else {
            sb.append(resources.getString(C5000h.f53864k));
        }
        return sb.toString();
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return this.f3159o != null;
    }

    CharSequence i(n.a aVar) {
        return (aVar == null || !aVar.c()) ? getTitle() : getTitleCondensed();
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean isActionViewExpanded() {
        return this.f3143D;
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return (this.f3169y & 1) == 1;
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return (this.f3169y & 2) == 2;
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return (this.f3169y & 16) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        AbstractC1014b abstractC1014b = this.f3141B;
        return (abstractC1014b == null || !abstractC1014b.g()) ? (this.f3169y & 8) == 0 : (this.f3169y & 8) == 0 && this.f3141B.b();
    }

    public boolean j() {
        AbstractC1014b abstractC1014b;
        if ((this.f3170z & 8) != 0) {
            if (this.f3140A == null && (abstractC1014b = this.f3141B) != null) {
                this.f3140A = abstractC1014b.d(this);
            }
            if (this.f3140A != null) {
                return true;
            }
        }
        return false;
    }

    public boolean k() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f3161q;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick(this)) {
            return true;
        }
        g gVar = this.f3158n;
        if (gVar.h(gVar, this)) {
            return true;
        }
        Runnable runnable = this.f3160p;
        if (runnable != null) {
            runnable.run();
            return true;
        }
        if (this.f3151g != null) {
            try {
                this.f3158n.u().startActivity(this.f3151g);
                return true;
            } catch (ActivityNotFoundException e5) {
                Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e5);
            }
        }
        AbstractC1014b abstractC1014b = this.f3141B;
        return abstractC1014b != null && abstractC1014b.e();
    }

    public boolean l() {
        return (this.f3169y & 32) == 32;
    }

    public boolean m() {
        return (this.f3169y & 4) != 0;
    }

    public boolean n() {
        return (this.f3170z & 1) == 1;
    }

    public boolean o() {
        return (this.f3170z & 2) == 2;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: p, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setActionView(int i5) {
        Context u5 = this.f3158n.u();
        setActionView(LayoutInflater.from(u5).inflate(i5, (ViewGroup) new LinearLayout(u5), false));
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: q, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setActionView(View view) {
        int i5;
        this.f3140A = view;
        this.f3141B = null;
        if (view != null && view.getId() == -1 && (i5 = this.f3145a) > 0) {
            view.setId(i5);
        }
        this.f3158n.J(this);
        return this;
    }

    public void r(boolean z4) {
        this.f3143D = z4;
        this.f3158n.L(false);
    }

    void s(boolean z4) {
        int i5 = this.f3169y;
        int i6 = (z4 ? 2 : 0) | (i5 & (-3));
        this.f3169y = i6;
        if (i5 != i6) {
            this.f3158n.L(false);
        }
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5) {
        if (this.f3154j == c5) {
            return this;
        }
        this.f3154j = Character.toLowerCase(c5);
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z4) {
        int i5 = this.f3169y;
        int i6 = (z4 ? 1 : 0) | (i5 & (-2));
        this.f3169y = i6;
        if (i5 != i6) {
            this.f3158n.L(false);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z4) {
        if ((this.f3169y & 4) != 0) {
            this.f3158n.U(this);
            return this;
        }
        s(z4);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z4) {
        if (z4) {
            this.f3169y |= 16;
        } else {
            this.f3169y &= -17;
        }
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f3157m = 0;
        this.f3156l = drawable;
        this.f3168x = true;
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f3164t = colorStateList;
        this.f3166v = true;
        this.f3168x = true;
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f3165u = mode;
        this.f3167w = true;
        this.f3168x = true;
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f3151g = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c5) {
        if (this.f3152h == c5) {
            return this;
        }
        this.f3152h = c5;
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f3142C = onActionExpandListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f3161q = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6) {
        this.f3152h = c5;
        this.f3154j = Character.toLowerCase(c6);
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public void setShowAsAction(int i5) {
        int i6 = i5 & 3;
        if (i6 != 0 && i6 != 1 && i6 != 2) {
            throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
        this.f3170z = i5;
        this.f3158n.J(this);
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f3149e = charSequence;
        this.f3158n.L(false);
        r rVar = this.f3159o;
        if (rVar != null) {
            rVar.setHeaderTitle(charSequence);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f3150f = charSequence;
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z4) {
        if (y(z4)) {
            this.f3158n.K(this);
        }
        return this;
    }

    public void t(boolean z4) {
        this.f3169y = (z4 ? 4 : 0) | (this.f3169y & (-5));
    }

    public String toString() {
        CharSequence charSequence = this.f3149e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public void u(boolean z4) {
        if (z4) {
            this.f3169y |= 32;
        } else {
            this.f3169y &= -33;
        }
    }

    void v(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.f3144E = contextMenuInfo;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: w, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setShowAsActionFlags(int i5) {
        setShowAsAction(i5);
        return this;
    }

    public void x(r rVar) {
        this.f3159o = rVar;
        rVar.setHeaderTitle(getTitle());
    }

    boolean y(boolean z4) {
        int i5 = this.f3169y;
        int i6 = (z4 ? 0 : 8) | (i5 & (-9));
        this.f3169y = i6;
        return i5 != i6;
    }

    public boolean z() {
        return this.f3158n.A();
    }

    @Override // android.view.MenuItem
    public InterfaceMenuItemC7302b setContentDescription(CharSequence charSequence) {
        this.f3162r = charSequence;
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public InterfaceMenuItemC7302b setTooltipText(CharSequence charSequence) {
        this.f3163s = charSequence;
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5, int i5) {
        if (this.f3154j == c5 && this.f3155k == i5) {
            return this;
        }
        this.f3154j = Character.toLowerCase(c5);
        this.f3155k = KeyEvent.normalizeMetaState(i5);
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setNumericShortcut(char c5, int i5) {
        if (this.f3152h == c5 && this.f3153i == i5) {
            return this;
        }
        this.f3152h = c5;
        this.f3153i = KeyEvent.normalizeMetaState(i5);
        this.f3158n.L(false);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6, int i5, int i6) {
        this.f3152h = c5;
        this.f3153i = KeyEvent.normalizeMetaState(i5);
        this.f3154j = Character.toLowerCase(c6);
        this.f3155k = KeyEvent.normalizeMetaState(i6);
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i5) {
        this.f3156l = null;
        this.f3157m = i5;
        this.f3168x = true;
        this.f3158n.L(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i5) {
        return setTitle(this.f3158n.u().getString(i5));
    }
}
