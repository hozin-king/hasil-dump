package androidx.appcompat.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.M;
import androidx.appcompat.widget.g0;
import androidx.core.view.AbstractC1014b;
import androidx.core.view.E;
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParserException;
import p.InterfaceMenuC7301a;

/* loaded from: classes.dex */
public class g extends MenuInflater {

    /* renamed from: e, reason: collision with root package name */
    static final Class[] f2939e;

    /* renamed from: f, reason: collision with root package name */
    static final Class[] f2940f;

    /* renamed from: a, reason: collision with root package name */
    final Object[] f2941a;

    /* renamed from: b, reason: collision with root package name */
    final Object[] f2942b;

    /* renamed from: c, reason: collision with root package name */
    Context f2943c;

    /* renamed from: d, reason: collision with root package name */
    private Object f2944d;

    private static class a implements MenuItem.OnMenuItemClickListener {

        /* renamed from: c, reason: collision with root package name */
        private static final Class[] f2945c = {MenuItem.class};

        /* renamed from: a, reason: collision with root package name */
        private Object f2946a;

        /* renamed from: b, reason: collision with root package name */
        private Method f2947b;

        public a(Object obj, String str) {
            this.f2946a = obj;
            Class<?> cls = obj.getClass();
            try {
                this.f2947b = cls.getMethod(str, f2945c);
            } catch (Exception e5) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e5);
                throw inflateException;
            }
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f2947b.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f2947b.invoke(this.f2946a, menuItem)).booleanValue();
                }
                this.f2947b.invoke(this.f2946a, menuItem);
                return true;
            } catch (Exception e5) {
                throw new RuntimeException(e5);
            }
        }
    }

    private class b {

        /* renamed from: A, reason: collision with root package name */
        AbstractC1014b f2948A;

        /* renamed from: B, reason: collision with root package name */
        private CharSequence f2949B;

        /* renamed from: C, reason: collision with root package name */
        private CharSequence f2950C;

        /* renamed from: D, reason: collision with root package name */
        private ColorStateList f2951D = null;

        /* renamed from: E, reason: collision with root package name */
        private PorterDuff.Mode f2952E = null;

        /* renamed from: a, reason: collision with root package name */
        private Menu f2954a;

        /* renamed from: b, reason: collision with root package name */
        private int f2955b;

        /* renamed from: c, reason: collision with root package name */
        private int f2956c;

        /* renamed from: d, reason: collision with root package name */
        private int f2957d;

        /* renamed from: e, reason: collision with root package name */
        private int f2958e;

        /* renamed from: f, reason: collision with root package name */
        private boolean f2959f;

        /* renamed from: g, reason: collision with root package name */
        private boolean f2960g;

        /* renamed from: h, reason: collision with root package name */
        private boolean f2961h;

        /* renamed from: i, reason: collision with root package name */
        private int f2962i;

        /* renamed from: j, reason: collision with root package name */
        private int f2963j;

        /* renamed from: k, reason: collision with root package name */
        private CharSequence f2964k;

        /* renamed from: l, reason: collision with root package name */
        private CharSequence f2965l;

        /* renamed from: m, reason: collision with root package name */
        private int f2966m;

        /* renamed from: n, reason: collision with root package name */
        private char f2967n;

        /* renamed from: o, reason: collision with root package name */
        private int f2968o;

        /* renamed from: p, reason: collision with root package name */
        private char f2969p;

        /* renamed from: q, reason: collision with root package name */
        private int f2970q;

        /* renamed from: r, reason: collision with root package name */
        private int f2971r;

        /* renamed from: s, reason: collision with root package name */
        private boolean f2972s;

        /* renamed from: t, reason: collision with root package name */
        private boolean f2973t;

        /* renamed from: u, reason: collision with root package name */
        private boolean f2974u;

        /* renamed from: v, reason: collision with root package name */
        private int f2975v;

        /* renamed from: w, reason: collision with root package name */
        private int f2976w;

        /* renamed from: x, reason: collision with root package name */
        private String f2977x;

        /* renamed from: y, reason: collision with root package name */
        private String f2978y;

        /* renamed from: z, reason: collision with root package name */
        private String f2979z;

        public b(Menu menu) {
            this.f2954a = menu;
            h();
        }

        private char c(String str) {
            if (str == null) {
                return (char) 0;
            }
            return str.charAt(0);
        }

        private Object e(String str, Class[] clsArr, Object[] objArr) {
            try {
                Constructor<?> constructor = Class.forName(str, false, g.this.f2943c.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return constructor.newInstance(objArr);
            } catch (Exception e5) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e5);
                return null;
            }
        }

        private void i(MenuItem menuItem) {
            boolean z4 = false;
            menuItem.setChecked(this.f2972s).setVisible(this.f2973t).setEnabled(this.f2974u).setCheckable(this.f2971r >= 1).setTitleCondensed(this.f2965l).setIcon(this.f2966m);
            int i5 = this.f2975v;
            if (i5 >= 0) {
                menuItem.setShowAsAction(i5);
            }
            if (this.f2979z != null) {
                if (g.this.f2943c.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new a(g.this.b(), this.f2979z));
            }
            if (this.f2971r >= 2) {
                if (menuItem instanceof androidx.appcompat.view.menu.i) {
                    ((androidx.appcompat.view.menu.i) menuItem).t(true);
                } else if (menuItem instanceof j) {
                    ((j) menuItem).h(true);
                }
            }
            String str = this.f2977x;
            if (str != null) {
                menuItem.setActionView((View) e(str, g.f2939e, g.this.f2941a));
                z4 = true;
            }
            int i6 = this.f2976w;
            if (i6 > 0) {
                if (z4) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                } else {
                    menuItem.setActionView(i6);
                }
            }
            AbstractC1014b abstractC1014b = this.f2948A;
            if (abstractC1014b != null) {
                E.a(menuItem, abstractC1014b);
            }
            E.c(menuItem, this.f2949B);
            E.g(menuItem, this.f2950C);
            E.b(menuItem, this.f2967n, this.f2968o);
            E.f(menuItem, this.f2969p, this.f2970q);
            PorterDuff.Mode mode = this.f2952E;
            if (mode != null) {
                E.e(menuItem, mode);
            }
            ColorStateList colorStateList = this.f2951D;
            if (colorStateList != null) {
                E.d(menuItem, colorStateList);
            }
        }

        public void a() {
            this.f2961h = true;
            i(this.f2954a.add(this.f2955b, this.f2962i, this.f2963j, this.f2964k));
        }

        public SubMenu b() {
            this.f2961h = true;
            SubMenu addSubMenu = this.f2954a.addSubMenu(this.f2955b, this.f2962i, this.f2963j, this.f2964k);
            i(addSubMenu.getItem());
            return addSubMenu;
        }

        public boolean d() {
            return this.f2961h;
        }

        public void f(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = g.this.f2943c.obtainStyledAttributes(attributeSet, f.j.f54066o1);
            this.f2955b = obtainStyledAttributes.getResourceId(f.j.f54076q1, 0);
            this.f2956c = obtainStyledAttributes.getInt(f.j.f54086s1, 0);
            this.f2957d = obtainStyledAttributes.getInt(f.j.f54091t1, 0);
            this.f2958e = obtainStyledAttributes.getInt(f.j.f54096u1, 0);
            this.f2959f = obtainStyledAttributes.getBoolean(f.j.f54081r1, true);
            this.f2960g = obtainStyledAttributes.getBoolean(f.j.f54071p1, true);
            obtainStyledAttributes.recycle();
        }

        public void g(AttributeSet attributeSet) {
            g0 t5 = g0.t(g.this.f2943c, attributeSet, f.j.f54101v1);
            this.f2962i = t5.m(f.j.f54116y1, 0);
            this.f2963j = (t5.j(f.j.f53879B1, this.f2956c) & (-65536)) | (t5.j(f.j.f53884C1, this.f2957d) & MeshBuilder.MAX_INDEX);
            this.f2964k = t5.o(f.j.f53889D1);
            this.f2965l = t5.o(f.j.f53894E1);
            this.f2966m = t5.m(f.j.f54106w1, 0);
            this.f2967n = c(t5.n(f.j.f53899F1));
            this.f2968o = t5.j(f.j.f53934M1, 4096);
            this.f2969p = c(t5.n(f.j.f53904G1));
            this.f2970q = t5.j(f.j.f53954Q1, 4096);
            if (t5.r(f.j.f53909H1)) {
                this.f2971r = t5.a(f.j.f53909H1, false) ? 1 : 0;
            } else {
                this.f2971r = this.f2958e;
            }
            this.f2972s = t5.a(f.j.f54121z1, false);
            this.f2973t = t5.a(f.j.f53874A1, this.f2959f);
            this.f2974u = t5.a(f.j.f54111x1, this.f2960g);
            this.f2975v = t5.j(f.j.f53959R1, -1);
            this.f2979z = t5.n(f.j.f53914I1);
            this.f2976w = t5.m(f.j.f53919J1, 0);
            this.f2977x = t5.n(f.j.f53929L1);
            String n5 = t5.n(f.j.f53924K1);
            this.f2978y = n5;
            boolean z4 = n5 != null;
            if (z4 && this.f2976w == 0 && this.f2977x == null) {
                this.f2948A = (AbstractC1014b) e(n5, g.f2940f, g.this.f2942b);
            } else {
                if (z4) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.f2948A = null;
            }
            this.f2949B = t5.o(f.j.f53939N1);
            this.f2950C = t5.o(f.j.f53964S1);
            if (t5.r(f.j.f53949P1)) {
                this.f2952E = M.d(t5.j(f.j.f53949P1, -1), this.f2952E);
            } else {
                this.f2952E = null;
            }
            if (t5.r(f.j.f53944O1)) {
                this.f2951D = t5.c(f.j.f53944O1);
            } else {
                this.f2951D = null;
            }
            t5.w();
            this.f2961h = false;
        }

        public void h() {
            this.f2955b = 0;
            this.f2956c = 0;
            this.f2957d = 0;
            this.f2958e = 0;
            this.f2959f = true;
            this.f2960g = true;
        }
    }

    static {
        Class[] clsArr = {Context.class};
        f2939e = clsArr;
        f2940f = clsArr;
    }

    public g(Context context) {
        super(context);
        this.f2943c = context;
        Object[] objArr = {context};
        this.f2941a = objArr;
        this.f2942b = objArr;
    }

    private Object a(Object obj) {
        return obj instanceof Activity ? obj : obj instanceof ContextWrapper ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0048, code lost:
    
        if (r15 == 2) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x004b, code lost:
    
        if (r15 == 3) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x004f, code lost:
    
        r15 = r13.getName();
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0053, code lost:
    
        if (r7 == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0059, code lost:
    
        if (r15.equals(r8) == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x005b, code lost:
    
        r7 = false;
        r8 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00b9, code lost:
    
        r15 = r13.next();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0062, code lost:
    
        if (r15.equals("group") == false) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0064, code lost:
    
        r0.h();
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x006c, code lost:
    
        if (r15.equals("item") == false) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0072, code lost:
    
        if (r0.d() != false) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0074, code lost:
    
        r15 = r0.f2948A;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0076, code lost:
    
        if (r15 == null) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        if (r15.a() == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x007e, code lost:
    
        r0.b();
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0082, code lost:
    
        r0.a();
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x008a, code lost:
    
        if (r15.equals("menu") == false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x008c, code lost:
    
        r6 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x008e, code lost:
    
        if (r7 == false) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x0091, code lost:
    
        r15 = r13.getName();
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0099, code lost:
    
        if (r15.equals("group") == false) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x009b, code lost:
    
        r0.f(r14);
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00a3, code lost:
    
        if (r15.equals("item") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00a5, code lost:
    
        r0.g(r14);
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00ad, code lost:
    
        if (r15.equals("menu") == false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00af, code lost:
    
        c(r13, r14, r0.b());
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00b7, code lost:
    
        r8 = r15;
        r7 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00c5, code lost:
    
        throw new java.lang.RuntimeException("Unexpected end of document");
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00c6, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x003b, code lost:
    
        r6 = false;
        r7 = false;
        r8 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0040, code lost:
    
        if (r6 != false) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0042, code lost:
    
        if (r15 == 1) goto L61;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void c(org.xmlpull.v1.XmlPullParser r13, android.util.AttributeSet r14, android.view.Menu r15) {
        /*
            r12 = this;
            androidx.appcompat.view.g$b r0 = new androidx.appcompat.view.g$b
            r0.<init>(r15)
            int r15 = r13.getEventType()
        L9:
            r1 = 2
            java.lang.String r2 = "menu"
            r3 = 1
            if (r15 != r1) goto L35
            java.lang.String r15 = r13.getName()
            boolean r4 = r15.equals(r2)
            if (r4 == 0) goto L1e
            int r15 = r13.next()
            goto L3b
        L1e:
            java.lang.RuntimeException r13 = new java.lang.RuntimeException
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            java.lang.String r0 = "Expecting menu, got "
            r14.append(r0)
            r14.append(r15)
            java.lang.String r14 = r14.toString()
            r13.<init>(r14)
            throw r13
        L35:
            int r15 = r13.next()
            if (r15 != r3) goto L9
        L3b:
            r4 = 0
            r5 = 0
            r6 = r4
            r7 = r6
            r8 = r5
        L40:
            if (r6 != 0) goto Lc6
            if (r15 == r3) goto Lbe
            java.lang.String r9 = "item"
            java.lang.String r10 = "group"
            if (r15 == r1) goto L8e
            r11 = 3
            if (r15 == r11) goto L4f
            goto Lb9
        L4f:
            java.lang.String r15 = r13.getName()
            if (r7 == 0) goto L5e
            boolean r11 = r15.equals(r8)
            if (r11 == 0) goto L5e
            r7 = r4
            r8 = r5
            goto Lb9
        L5e:
            boolean r10 = r15.equals(r10)
            if (r10 == 0) goto L68
            r0.h()
            goto Lb9
        L68:
            boolean r9 = r15.equals(r9)
            if (r9 == 0) goto L86
            boolean r15 = r0.d()
            if (r15 != 0) goto Lb9
            androidx.core.view.b r15 = r0.f2948A
            if (r15 == 0) goto L82
            boolean r15 = r15.a()
            if (r15 == 0) goto L82
            r0.b()
            goto Lb9
        L82:
            r0.a()
            goto Lb9
        L86:
            boolean r15 = r15.equals(r2)
            if (r15 == 0) goto Lb9
            r6 = r3
            goto Lb9
        L8e:
            if (r7 == 0) goto L91
            goto Lb9
        L91:
            java.lang.String r15 = r13.getName()
            boolean r10 = r15.equals(r10)
            if (r10 == 0) goto L9f
            r0.f(r14)
            goto Lb9
        L9f:
            boolean r9 = r15.equals(r9)
            if (r9 == 0) goto La9
            r0.g(r14)
            goto Lb9
        La9:
            boolean r9 = r15.equals(r2)
            if (r9 == 0) goto Lb7
            android.view.SubMenu r15 = r0.b()
            r12.c(r13, r14, r15)
            goto Lb9
        Lb7:
            r8 = r15
            r7 = r3
        Lb9:
            int r15 = r13.next()
            goto L40
        Lbe:
            java.lang.RuntimeException r13 = new java.lang.RuntimeException
            java.lang.String r14 = "Unexpected end of document"
            r13.<init>(r14)
            throw r13
        Lc6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.g.c(org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.view.Menu):void");
    }

    Object b() {
        if (this.f2944d == null) {
            this.f2944d = a(this.f2943c);
        }
        return this.f2944d;
    }

    @Override // android.view.MenuInflater
    public void inflate(int i5, Menu menu) {
        if (!(menu instanceof InterfaceMenuC7301a)) {
            super.inflate(i5, menu);
            return;
        }
        XmlResourceParser xmlResourceParser = null;
        boolean z4 = false;
        try {
            try {
                xmlResourceParser = this.f2943c.getResources().getLayout(i5);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xmlResourceParser);
                if (menu instanceof androidx.appcompat.view.menu.g) {
                    androidx.appcompat.view.menu.g gVar = (androidx.appcompat.view.menu.g) menu;
                    if (gVar.F()) {
                        gVar.e0();
                        z4 = true;
                    }
                }
                c(xmlResourceParser, asAttributeSet, menu);
                if (z4) {
                    ((androidx.appcompat.view.menu.g) menu).d0();
                }
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
            } catch (IOException e5) {
                throw new InflateException("Error inflating menu XML", e5);
            } catch (XmlPullParserException e6) {
                throw new InflateException("Error inflating menu XML", e6);
            }
        } catch (Throwable th) {
            if (z4) {
                ((androidx.appcompat.view.menu.g) menu).d0();
            }
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }
}
