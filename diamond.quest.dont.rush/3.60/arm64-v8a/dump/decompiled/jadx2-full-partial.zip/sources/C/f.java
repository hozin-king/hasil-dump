package C;

import androidx.datastore.core.u;
import androidx.datastore.core.v;
import kotlin.jvm.internal.C7150s;
import okio.S;

/* loaded from: classes.dex */
public abstract class f {
    public static final u a(S path) {
        C7150s.j(path, "path");
        return v.a(path.h().toString());
    }
}
