package X0;

/* loaded from: classes3.dex */
public interface f extends e {
    g b(com.fasterxml.jackson.databind.j jVar);

    k c(com.fasterxml.jackson.databind.j jVar);

    h d(com.fasterxml.jackson.databind.j jVar);

    l e(com.fasterxml.jackson.databind.j jVar);

    i f(com.fasterxml.jackson.databind.j jVar);

    a g(com.fasterxml.jackson.databind.j jVar);

    j h(com.fasterxml.jackson.databind.j jVar);

    b i(com.fasterxml.jackson.databind.j jVar);

    c j(com.fasterxml.jackson.databind.j jVar);
}
