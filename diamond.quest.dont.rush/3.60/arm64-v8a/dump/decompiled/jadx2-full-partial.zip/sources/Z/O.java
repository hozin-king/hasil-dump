package Z;

import Z.AbstractC0963m;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/* loaded from: classes.dex */
public abstract class O extends AbstractC0963m {
    private static final String[] sTransitionProperties = {"android:visibility:visibility", "android:visibility:parent"};
    private int mMode;

    class a extends C0964n {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f2064a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f2065b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ View f2066c;

        a(ViewGroup viewGroup, View view, View view2) {
            this.f2064a = viewGroup;
            this.f2065b = view;
            this.f2066c = view2;
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionEnd(AbstractC0963m abstractC0963m) {
            this.f2066c.setTag(C0959i.f2129a, null);
            y.a(this.f2064a).d(this.f2065b);
            abstractC0963m.removeListener(this);
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionPause(AbstractC0963m abstractC0963m) {
            y.a(this.f2064a).d(this.f2065b);
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionResume(AbstractC0963m abstractC0963m) {
            if (this.f2065b.getParent() == null) {
                y.a(this.f2064a).c(this.f2065b);
            } else {
                O.this.cancel();
            }
        }
    }

    private static class c {

        /* renamed from: a, reason: collision with root package name */
        boolean f2074a;

        /* renamed from: b, reason: collision with root package name */
        boolean f2075b;

        /* renamed from: c, reason: collision with root package name */
        int f2076c;

        /* renamed from: d, reason: collision with root package name */
        int f2077d;

        /* renamed from: e, reason: collision with root package name */
        ViewGroup f2078e;

        /* renamed from: f, reason: collision with root package name */
        ViewGroup f2079f;

        c() {
        }
    }

    public O() {
        this.mMode = 3;
    }

    private void p(t tVar) {
        tVar.f2177a.put("android:visibility:visibility", Integer.valueOf(tVar.f2178b.getVisibility()));
        tVar.f2177a.put("android:visibility:parent", tVar.f2178b.getParent());
        int[] iArr = new int[2];
        tVar.f2178b.getLocationOnScreen(iArr);
        tVar.f2177a.put("android:visibility:screenLocation", iArr);
    }

    private c q(t tVar, t tVar2) {
        c cVar = new c();
        cVar.f2074a = false;
        cVar.f2075b = false;
        if (tVar == null || !tVar.f2177a.containsKey("android:visibility:visibility")) {
            cVar.f2076c = -1;
            cVar.f2078e = null;
        } else {
            cVar.f2076c = ((Integer) tVar.f2177a.get("android:visibility:visibility")).intValue();
            cVar.f2078e = (ViewGroup) tVar.f2177a.get("android:visibility:parent");
        }
        if (tVar2 == null || !tVar2.f2177a.containsKey("android:visibility:visibility")) {
            cVar.f2077d = -1;
            cVar.f2079f = null;
        } else {
            cVar.f2077d = ((Integer) tVar2.f2177a.get("android:visibility:visibility")).intValue();
            cVar.f2079f = (ViewGroup) tVar2.f2177a.get("android:visibility:parent");
        }
        if (tVar != null && tVar2 != null) {
            int i5 = cVar.f2076c;
            int i6 = cVar.f2077d;
            if (i5 != i6 || cVar.f2078e != cVar.f2079f) {
                if (i5 != i6) {
                    if (i5 == 0) {
                        cVar.f2075b = false;
                        cVar.f2074a = true;
                        return cVar;
                    }
                    if (i6 == 0) {
                        cVar.f2075b = true;
                        cVar.f2074a = true;
                        return cVar;
                    }
                } else {
                    if (cVar.f2079f == null) {
                        cVar.f2075b = false;
                        cVar.f2074a = true;
                        return cVar;
                    }
                    if (cVar.f2078e == null) {
                        cVar.f2075b = true;
                        cVar.f2074a = true;
                        return cVar;
                    }
                }
            }
        } else {
            if (tVar == null && cVar.f2077d == 0) {
                cVar.f2075b = true;
                cVar.f2074a = true;
                return cVar;
            }
            if (tVar2 == null && cVar.f2076c == 0) {
                cVar.f2075b = false;
                cVar.f2074a = true;
            }
        }
        return cVar;
    }

    @Override // Z.AbstractC0963m
    public void captureEndValues(@NonNull t tVar) {
        p(tVar);
    }

    @Override // Z.AbstractC0963m
    public void captureStartValues(@NonNull t tVar) {
        p(tVar);
    }

    @Override // Z.AbstractC0963m
    @Nullable
    public Animator createAnimator(@NonNull ViewGroup viewGroup, @Nullable t tVar, @Nullable t tVar2) {
        c q5 = q(tVar, tVar2);
        if (!q5.f2074a) {
            return null;
        }
        if (q5.f2078e == null && q5.f2079f == null) {
            return null;
        }
        return q5.f2075b ? onAppear(viewGroup, tVar, q5.f2076c, tVar2, q5.f2077d) : onDisappear(viewGroup, tVar, q5.f2076c, tVar2, q5.f2077d);
    }

    public int getMode() {
        return this.mMode;
    }

    @Override // Z.AbstractC0963m
    @Nullable
    public String[] getTransitionProperties() {
        return sTransitionProperties;
    }

    @Override // Z.AbstractC0963m
    public boolean isTransitionRequired(@Nullable t tVar, @Nullable t tVar2) {
        if (tVar == null && tVar2 == null) {
            return false;
        }
        if (tVar != null && tVar2 != null && tVar2.f2177a.containsKey("android:visibility:visibility") != tVar.f2177a.containsKey("android:visibility:visibility")) {
            return false;
        }
        c q5 = q(tVar, tVar2);
        return q5.f2074a && (q5.f2076c == 0 || q5.f2077d == 0);
    }

    public Animator onAppear(ViewGroup viewGroup, t tVar, int i5, t tVar2, int i6) {
        if ((this.mMode & 1) != 1 || tVar2 == null) {
            return null;
        }
        if (tVar == null) {
            View view = (View) tVar2.f2178b.getParent();
            if (q(getMatchedTransitionValues(view, false), getTransitionValues(view, false)).f2074a) {
                return null;
            }
        }
        return onAppear(viewGroup, tVar2.f2178b, tVar, tVar2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:53:0x0083, code lost:
    
        if (r9.mCanRemoveViews != false) goto L44;
     */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0040  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.animation.Animator onDisappear(android.view.ViewGroup r10, Z.t r11, int r12, Z.t r13, int r14) {
        /*
            Method dump skipped, instructions count: 253
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: Z.O.onDisappear(android.view.ViewGroup, Z.t, int, Z.t, int):android.animation.Animator");
    }

    public void setMode(int i5) {
        if ((i5 & (-4)) != 0) {
            throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
        }
        this.mMode = i5;
    }

    @SuppressLint({"RestrictedApi"})
    public O(@NonNull Context context, @NonNull AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mMode = 3;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0962l.f2142e);
        int g5 = androidx.core.content.res.k.g(obtainStyledAttributes, (XmlResourceParser) attributeSet, "transitionVisibilityMode", 0, 0);
        obtainStyledAttributes.recycle();
        if (g5 != 0) {
            setMode(g5);
        }
    }

    @Nullable
    public Animator onAppear(ViewGroup viewGroup, View view, t tVar, t tVar2) {
        return null;
    }

    private static class b extends AnimatorListenerAdapter implements AbstractC0963m.f {

        /* renamed from: a, reason: collision with root package name */
        private final View f2068a;

        /* renamed from: b, reason: collision with root package name */
        private final int f2069b;

        /* renamed from: c, reason: collision with root package name */
        private final ViewGroup f2070c;

        /* renamed from: d, reason: collision with root package name */
        private final boolean f2071d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f2072e;

        /* renamed from: f, reason: collision with root package name */
        boolean f2073f = false;

        b(View view, int i5, boolean z4) {
            this.f2068a = view;
            this.f2069b = i5;
            this.f2070c = (ViewGroup) view.getParent();
            this.f2071d = z4;
            b(true);
        }

        private void a() {
            if (!this.f2073f) {
                B.h(this.f2068a, this.f2069b);
                ViewGroup viewGroup = this.f2070c;
                if (viewGroup != null) {
                    viewGroup.invalidate();
                }
            }
            b(false);
        }

        private void b(boolean z4) {
            ViewGroup viewGroup;
            if (!this.f2071d || this.f2072e == z4 || (viewGroup = this.f2070c) == null) {
                return;
            }
            this.f2072e = z4;
            y.c(viewGroup, z4);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f2073f = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            a();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
        public void onAnimationPause(Animator animator) {
            if (this.f2073f) {
                return;
            }
            B.h(this.f2068a, this.f2069b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
        public void onAnimationResume(Animator animator) {
            if (this.f2073f) {
                return;
            }
            B.h(this.f2068a, 0);
        }

        @Override // Z.AbstractC0963m.f
        public void onTransitionEnd(AbstractC0963m abstractC0963m) {
            a();
            abstractC0963m.removeListener(this);
        }

        @Override // Z.AbstractC0963m.f
        public void onTransitionPause(AbstractC0963m abstractC0963m) {
            b(false);
        }

        @Override // Z.AbstractC0963m.f
        public void onTransitionResume(AbstractC0963m abstractC0963m) {
            b(true);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
        }

        @Override // Z.AbstractC0963m.f
        public void onTransitionCancel(AbstractC0963m abstractC0963m) {
        }

        @Override // Z.AbstractC0963m.f
        public void onTransitionStart(AbstractC0963m abstractC0963m) {
        }
    }

    @Nullable
    public Animator onDisappear(ViewGroup viewGroup, View view, t tVar, t tVar2) {
        return null;
    }
}
