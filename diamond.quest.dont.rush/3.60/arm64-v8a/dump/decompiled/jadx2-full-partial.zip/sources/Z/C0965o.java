package Z;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import androidx.core.view.C1015b0;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* renamed from: Z.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0965o {

    /* renamed from: c, reason: collision with root package name */
    private static AbstractC0963m f2157c = new C0952b();

    /* renamed from: d, reason: collision with root package name */
    private static ThreadLocal f2158d = new ThreadLocal();

    /* renamed from: e, reason: collision with root package name */
    static ArrayList f2159e = new ArrayList();

    /* renamed from: a, reason: collision with root package name */
    private androidx.collection.a f2160a = new androidx.collection.a();

    /* renamed from: b, reason: collision with root package name */
    private androidx.collection.a f2161b = new androidx.collection.a();

    public static void a(ViewGroup viewGroup, AbstractC0963m abstractC0963m) {
        if (f2159e.contains(viewGroup) || !C1015b0.K(viewGroup)) {
            return;
        }
        f2159e.add(viewGroup);
        if (abstractC0963m == null) {
            abstractC0963m = f2157c;
        }
        AbstractC0963m mo1clone = abstractC0963m.mo1clone();
        g(viewGroup, mo1clone);
        C0961k.f(viewGroup, null);
        f(viewGroup, mo1clone);
    }

    private static void b(C0961k c0961k, AbstractC0963m abstractC0963m) {
        ViewGroup d5 = c0961k.d();
        if (f2159e.contains(d5)) {
            return;
        }
        C0961k c5 = C0961k.c(d5);
        if (abstractC0963m == null) {
            if (c5 != null) {
                c5.b();
            }
            c0961k.a();
            return;
        }
        f2159e.add(d5);
        AbstractC0963m mo1clone = abstractC0963m.mo1clone();
        if (c5 != null && c5.e()) {
            mo1clone.setCanRemoveViews(true);
        }
        g(d5, mo1clone);
        c0961k.a();
        f(d5, mo1clone);
    }

    public static void c(ViewGroup viewGroup) {
        f2159e.remove(viewGroup);
        ArrayList arrayList = (ArrayList) d().get(viewGroup);
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        ArrayList arrayList2 = new ArrayList(arrayList);
        for (int size = arrayList2.size() - 1; size >= 0; size--) {
            ((AbstractC0963m) arrayList2.get(size)).forceToEnd(viewGroup);
        }
    }

    static androidx.collection.a d() {
        androidx.collection.a aVar;
        WeakReference weakReference = (WeakReference) f2158d.get();
        if (weakReference != null && (aVar = (androidx.collection.a) weakReference.get()) != null) {
            return aVar;
        }
        androidx.collection.a aVar2 = new androidx.collection.a();
        f2158d.set(new WeakReference(aVar2));
        return aVar2;
    }

    public static void e(C0961k c0961k, AbstractC0963m abstractC0963m) {
        b(c0961k, abstractC0963m);
    }

    private static void f(ViewGroup viewGroup, AbstractC0963m abstractC0963m) {
        if (abstractC0963m == null || viewGroup == null) {
            return;
        }
        a aVar = new a(abstractC0963m, viewGroup);
        viewGroup.addOnAttachStateChangeListener(aVar);
        viewGroup.getViewTreeObserver().addOnPreDrawListener(aVar);
    }

    private static void g(ViewGroup viewGroup, AbstractC0963m abstractC0963m) {
        ArrayList arrayList = (ArrayList) d().get(viewGroup);
        if (arrayList != null && arrayList.size() > 0) {
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                ((AbstractC0963m) obj).pause(viewGroup);
            }
        }
        if (abstractC0963m != null) {
            abstractC0963m.captureValues(viewGroup, true);
        }
        C0961k c5 = C0961k.c(viewGroup);
        if (c5 != null) {
            c5.b();
        }
    }

    /* renamed from: Z.o$a */
    private static class a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

        /* renamed from: b, reason: collision with root package name */
        AbstractC0963m f2162b;

        /* renamed from: c, reason: collision with root package name */
        ViewGroup f2163c;

        /* renamed from: Z.o$a$a, reason: collision with other inner class name */
        class C0093a extends C0964n {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ androidx.collection.a f2164a;

            C0093a(androidx.collection.a aVar) {
                this.f2164a = aVar;
            }

            @Override // Z.C0964n, Z.AbstractC0963m.f
            public void onTransitionEnd(AbstractC0963m abstractC0963m) {
                ((ArrayList) this.f2164a.get(a.this.f2163c)).remove(abstractC0963m);
                abstractC0963m.removeListener(this);
            }
        }

        a(AbstractC0963m abstractC0963m, ViewGroup viewGroup) {
            this.f2162b = abstractC0963m;
            this.f2163c = viewGroup;
        }

        private void a() {
            this.f2163c.getViewTreeObserver().removeOnPreDrawListener(this);
            this.f2163c.removeOnAttachStateChangeListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            a();
            if (!C0965o.f2159e.remove(this.f2163c)) {
                return true;
            }
            androidx.collection.a d5 = C0965o.d();
            ArrayList arrayList = (ArrayList) d5.get(this.f2163c);
            ArrayList arrayList2 = null;
            if (arrayList == null) {
                arrayList = new ArrayList();
                d5.put(this.f2163c, arrayList);
            } else if (arrayList.size() > 0) {
                arrayList2 = new ArrayList(arrayList);
            }
            arrayList.add(this.f2162b);
            this.f2162b.addListener(new C0093a(d5));
            int i5 = 0;
            this.f2162b.captureValues(this.f2163c, false);
            if (arrayList2 != null) {
                int size = arrayList2.size();
                while (i5 < size) {
                    Object obj = arrayList2.get(i5);
                    i5++;
                    ((AbstractC0963m) obj).resume(this.f2163c);
                }
            }
            this.f2162b.playTransition(this.f2163c);
            return true;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            a();
            C0965o.f2159e.remove(this.f2163c);
            ArrayList arrayList = (ArrayList) C0965o.d().get(this.f2163c);
            if (arrayList != null && arrayList.size() > 0) {
                int size = arrayList.size();
                int i5 = 0;
                while (i5 < size) {
                    Object obj = arrayList.get(i5);
                    i5++;
                    ((AbstractC0963m) obj).resume(this.f2163c);
                }
            }
            this.f2162b.clearValues(true);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }
    }
}
