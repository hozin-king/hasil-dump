package Z;

import Z.AbstractC0963m;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import java.util.ArrayList;

/* renamed from: Z.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0967q extends AbstractC0963m {

    /* renamed from: b, reason: collision with root package name */
    private ArrayList f2166b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f2167c;

    /* renamed from: d, reason: collision with root package name */
    int f2168d;

    /* renamed from: e, reason: collision with root package name */
    boolean f2169e;

    /* renamed from: f, reason: collision with root package name */
    private int f2170f;

    /* renamed from: Z.q$a */
    class a extends C0964n {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ AbstractC0963m f2171a;

        a(AbstractC0963m abstractC0963m) {
            this.f2171a = abstractC0963m;
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionEnd(AbstractC0963m abstractC0963m) {
            this.f2171a.runAnimators();
            abstractC0963m.removeListener(this);
        }
    }

    /* renamed from: Z.q$b */
    static class b extends C0964n {

        /* renamed from: a, reason: collision with root package name */
        C0967q f2173a;

        b(C0967q c0967q) {
            this.f2173a = c0967q;
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionEnd(AbstractC0963m abstractC0963m) {
            C0967q c0967q = this.f2173a;
            int i5 = c0967q.f2168d - 1;
            c0967q.f2168d = i5;
            if (i5 == 0) {
                c0967q.f2169e = false;
                c0967q.end();
            }
            abstractC0963m.removeListener(this);
        }

        @Override // Z.C0964n, Z.AbstractC0963m.f
        public void onTransitionStart(AbstractC0963m abstractC0963m) {
            C0967q c0967q = this.f2173a;
            if (c0967q.f2169e) {
                return;
            }
            c0967q.start();
            this.f2173a.f2169e = true;
        }
    }

    public C0967q() {
        this.f2166b = new ArrayList();
        this.f2167c = true;
        this.f2169e = false;
        this.f2170f = 0;
    }

    private void C() {
        b bVar = new b(this);
        ArrayList arrayList = this.f2166b;
        int size = arrayList.size();
        int i5 = 0;
        while (i5 < size) {
            Object obj = arrayList.get(i5);
            i5++;
            ((AbstractC0963m) obj).addListener(bVar);
        }
        this.f2168d = this.f2166b.size();
    }

    private void t(AbstractC0963m abstractC0963m) {
        this.f2166b.add(abstractC0963m);
        abstractC0963m.mParent = this;
    }

    public C0967q A(int i5) {
        if (i5 == 0) {
            this.f2167c = true;
            return this;
        }
        if (i5 == 1) {
            this.f2167c = false;
            return this;
        }
        throw new AndroidRuntimeException("Invalid parameter for TransitionSet ordering: " + i5);
    }

    @Override // Z.AbstractC0963m
    /* renamed from: B, reason: merged with bridge method [inline-methods] */
    public C0967q setStartDelay(long j5) {
        return (C0967q) super.setStartDelay(j5);
    }

    @Override // Z.AbstractC0963m
    protected void cancel() {
        super.cancel();
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).cancel();
        }
    }

    @Override // Z.AbstractC0963m
    public void captureEndValues(t tVar) {
        if (isValidTarget(tVar.f2178b)) {
            ArrayList arrayList = this.f2166b;
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                AbstractC0963m abstractC0963m = (AbstractC0963m) obj;
                if (abstractC0963m.isValidTarget(tVar.f2178b)) {
                    abstractC0963m.captureEndValues(tVar);
                    tVar.f2179c.add(abstractC0963m);
                }
            }
        }
    }

    @Override // Z.AbstractC0963m
    void capturePropagationValues(t tVar) {
        super.capturePropagationValues(tVar);
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).capturePropagationValues(tVar);
        }
    }

    @Override // Z.AbstractC0963m
    public void captureStartValues(t tVar) {
        if (isValidTarget(tVar.f2178b)) {
            ArrayList arrayList = this.f2166b;
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                AbstractC0963m abstractC0963m = (AbstractC0963m) obj;
                if (abstractC0963m.isValidTarget(tVar.f2178b)) {
                    abstractC0963m.captureStartValues(tVar);
                    tVar.f2179c.add(abstractC0963m);
                }
            }
        }
    }

    @Override // Z.AbstractC0963m
    protected void createAnimators(ViewGroup viewGroup, u uVar, u uVar2, ArrayList arrayList, ArrayList arrayList2) {
        long startDelay = getStartDelay();
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            AbstractC0963m abstractC0963m = (AbstractC0963m) this.f2166b.get(i5);
            if (startDelay > 0 && (this.f2167c || i5 == 0)) {
                long startDelay2 = abstractC0963m.getStartDelay();
                if (startDelay2 > 0) {
                    abstractC0963m.setStartDelay(startDelay2 + startDelay);
                } else {
                    abstractC0963m.setStartDelay(startDelay);
                }
            }
            abstractC0963m.createAnimators(viewGroup, uVar, uVar2, arrayList, arrayList2);
        }
    }

    @Override // Z.AbstractC0963m
    void forceToEnd(ViewGroup viewGroup) {
        super.forceToEnd(viewGroup);
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).forceToEnd(viewGroup);
        }
    }

    @Override // Z.AbstractC0963m
    /* renamed from: p, reason: merged with bridge method [inline-methods] */
    public C0967q addListener(AbstractC0963m.f fVar) {
        return (C0967q) super.addListener(fVar);
    }

    @Override // Z.AbstractC0963m
    public void pause(View view) {
        super.pause(view);
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).pause(view);
        }
    }

    @Override // Z.AbstractC0963m
    /* renamed from: q, reason: merged with bridge method [inline-methods] */
    public C0967q addTarget(int i5) {
        for (int i6 = 0; i6 < this.f2166b.size(); i6++) {
            ((AbstractC0963m) this.f2166b.get(i6)).addTarget(i5);
        }
        return (C0967q) super.addTarget(i5);
    }

    @Override // Z.AbstractC0963m
    /* renamed from: r, reason: merged with bridge method [inline-methods] */
    public C0967q addTarget(View view) {
        for (int i5 = 0; i5 < this.f2166b.size(); i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).addTarget(view);
        }
        return (C0967q) super.addTarget(view);
    }

    @Override // Z.AbstractC0963m
    public void resume(View view) {
        super.resume(view);
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).resume(view);
        }
    }

    @Override // Z.AbstractC0963m
    protected void runAnimators() {
        if (this.f2166b.isEmpty()) {
            start();
            end();
            return;
        }
        C();
        int i5 = 0;
        if (this.f2167c) {
            ArrayList arrayList = this.f2166b;
            int size = arrayList.size();
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                ((AbstractC0963m) obj).runAnimators();
            }
            return;
        }
        for (int i6 = 1; i6 < this.f2166b.size(); i6++) {
            ((AbstractC0963m) this.f2166b.get(i6 - 1)).addListener(new a((AbstractC0963m) this.f2166b.get(i6)));
        }
        AbstractC0963m abstractC0963m = (AbstractC0963m) this.f2166b.get(0);
        if (abstractC0963m != null) {
            abstractC0963m.runAnimators();
        }
    }

    public C0967q s(AbstractC0963m abstractC0963m) {
        t(abstractC0963m);
        long j5 = this.mDuration;
        if (j5 >= 0) {
            abstractC0963m.setDuration(j5);
        }
        if ((this.f2170f & 1) != 0) {
            abstractC0963m.setInterpolator(getInterpolator());
        }
        if ((this.f2170f & 2) != 0) {
            abstractC0963m.setPropagation(getPropagation());
        }
        if ((this.f2170f & 4) != 0) {
            abstractC0963m.setPathMotion(getPathMotion());
        }
        if ((this.f2170f & 8) != 0) {
            abstractC0963m.setEpicenterCallback(getEpicenterCallback());
        }
        return this;
    }

    @Override // Z.AbstractC0963m
    void setCanRemoveViews(boolean z4) {
        super.setCanRemoveViews(z4);
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).setCanRemoveViews(z4);
        }
    }

    @Override // Z.AbstractC0963m
    public void setEpicenterCallback(AbstractC0963m.e eVar) {
        super.setEpicenterCallback(eVar);
        this.f2170f |= 8;
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).setEpicenterCallback(eVar);
        }
    }

    @Override // Z.AbstractC0963m
    public void setPathMotion(AbstractC0957g abstractC0957g) {
        super.setPathMotion(abstractC0957g);
        this.f2170f |= 4;
        if (this.f2166b != null) {
            for (int i5 = 0; i5 < this.f2166b.size(); i5++) {
                ((AbstractC0963m) this.f2166b.get(i5)).setPathMotion(abstractC0957g);
            }
        }
    }

    @Override // Z.AbstractC0963m
    public void setPropagation(AbstractC0966p abstractC0966p) {
        super.setPropagation(abstractC0966p);
        this.f2170f |= 2;
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).setPropagation(abstractC0966p);
        }
    }

    @Override // Z.AbstractC0963m
    String toString(String str) {
        String abstractC0963m = super.toString(str);
        for (int i5 = 0; i5 < this.f2166b.size(); i5++) {
            StringBuilder sb = new StringBuilder();
            sb.append(abstractC0963m);
            sb.append("\n");
            sb.append(((AbstractC0963m) this.f2166b.get(i5)).toString(str + "  "));
            abstractC0963m = sb.toString();
        }
        return abstractC0963m;
    }

    public AbstractC0963m u(int i5) {
        if (i5 < 0 || i5 >= this.f2166b.size()) {
            return null;
        }
        return (AbstractC0963m) this.f2166b.get(i5);
    }

    public int v() {
        return this.f2166b.size();
    }

    @Override // Z.AbstractC0963m
    /* renamed from: w, reason: merged with bridge method [inline-methods] */
    public C0967q removeListener(AbstractC0963m.f fVar) {
        return (C0967q) super.removeListener(fVar);
    }

    @Override // Z.AbstractC0963m
    /* renamed from: x, reason: merged with bridge method [inline-methods] */
    public C0967q removeTarget(View view) {
        for (int i5 = 0; i5 < this.f2166b.size(); i5++) {
            ((AbstractC0963m) this.f2166b.get(i5)).removeTarget(view);
        }
        return (C0967q) super.removeTarget(view);
    }

    @Override // Z.AbstractC0963m
    /* renamed from: y, reason: merged with bridge method [inline-methods] */
    public C0967q setDuration(long j5) {
        ArrayList arrayList;
        super.setDuration(j5);
        if (this.mDuration >= 0 && (arrayList = this.f2166b) != null) {
            int size = arrayList.size();
            for (int i5 = 0; i5 < size; i5++) {
                ((AbstractC0963m) this.f2166b.get(i5)).setDuration(j5);
            }
        }
        return this;
    }

    @Override // Z.AbstractC0963m
    /* renamed from: z, reason: merged with bridge method [inline-methods] */
    public C0967q setInterpolator(TimeInterpolator timeInterpolator) {
        this.f2170f |= 1;
        ArrayList arrayList = this.f2166b;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i5 = 0; i5 < size; i5++) {
                ((AbstractC0963m) this.f2166b.get(i5)).setInterpolator(timeInterpolator);
            }
        }
        return (C0967q) super.setInterpolator(timeInterpolator);
    }

    @Override // Z.AbstractC0963m
    /* renamed from: clone, reason: merged with bridge method [inline-methods] */
    public AbstractC0963m mo1clone() {
        C0967q c0967q = (C0967q) super.mo1clone();
        c0967q.f2166b = new ArrayList();
        int size = this.f2166b.size();
        for (int i5 = 0; i5 < size; i5++) {
            c0967q.t(((AbstractC0963m) this.f2166b.get(i5)).mo1clone());
        }
        return c0967q;
    }

    @SuppressLint({"RestrictedApi"})
    public C0967q(@NonNull Context context, @NonNull AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2166b = new ArrayList();
        this.f2167c = true;
        this.f2169e = false;
        this.f2170f = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0962l.f2146i);
        A(androidx.core.content.res.k.g(obtainStyledAttributes, (XmlResourceParser) attributeSet, "transitionOrdering", 0, 0));
        obtainStyledAttributes.recycle();
    }
}
