package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    final int f2380b;

    /* renamed from: c, reason: collision with root package name */
    final long f2381c;

    /* renamed from: d, reason: collision with root package name */
    final long f2382d;

    /* renamed from: e, reason: collision with root package name */
    final float f2383e;

    /* renamed from: f, reason: collision with root package name */
    final long f2384f;

    /* renamed from: g, reason: collision with root package name */
    final int f2385g;

    /* renamed from: h, reason: collision with root package name */
    final CharSequence f2386h;

    /* renamed from: i, reason: collision with root package name */
    final long f2387i;

    /* renamed from: j, reason: collision with root package name */
    List f2388j;

    /* renamed from: k, reason: collision with root package name */
    final long f2389k;

    /* renamed from: l, reason: collision with root package name */
    final Bundle f2390l;

    /* renamed from: m, reason: collision with root package name */
    private PlaybackState f2391m;

    class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat[] newArray(int i5) {
            return new PlaybackStateCompat[i5];
        }
    }

    private static class b {
        static void a(PlaybackState.Builder builder, PlaybackState.CustomAction customAction) {
            builder.addCustomAction(customAction);
        }

        static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder builder) {
            return builder.build();
        }

        static PlaybackState c(PlaybackState.Builder builder) {
            return builder.build();
        }

        static PlaybackState.Builder d() {
            return new PlaybackState.Builder();
        }

        static PlaybackState.CustomAction.Builder e(String str, CharSequence charSequence, int i5) {
            return new PlaybackState.CustomAction.Builder(str, charSequence, i5);
        }

        static String f(PlaybackState.CustomAction customAction) {
            return customAction.getAction();
        }

        static long g(PlaybackState playbackState) {
            return playbackState.getActions();
        }

        static long h(PlaybackState playbackState) {
            return playbackState.getActiveQueueItemId();
        }

        static long i(PlaybackState playbackState) {
            return playbackState.getBufferedPosition();
        }

        static List<PlaybackState.CustomAction> j(PlaybackState playbackState) {
            return playbackState.getCustomActions();
        }

        static CharSequence k(PlaybackState playbackState) {
            return playbackState.getErrorMessage();
        }

        static Bundle l(PlaybackState.CustomAction customAction) {
            return customAction.getExtras();
        }

        static int m(PlaybackState.CustomAction customAction) {
            return customAction.getIcon();
        }

        static long n(PlaybackState playbackState) {
            return playbackState.getLastPositionUpdateTime();
        }

        static CharSequence o(PlaybackState.CustomAction customAction) {
            return customAction.getName();
        }

        static float p(PlaybackState playbackState) {
            return playbackState.getPlaybackSpeed();
        }

        static long q(PlaybackState playbackState) {
            return playbackState.getPosition();
        }

        static int r(PlaybackState playbackState) {
            return playbackState.getState();
        }

        static void s(PlaybackState.Builder builder, long j5) {
            builder.setActions(j5);
        }

        static void t(PlaybackState.Builder builder, long j5) {
            builder.setActiveQueueItemId(j5);
        }

        static void u(PlaybackState.Builder builder, long j5) {
            builder.setBufferedPosition(j5);
        }

        static void v(PlaybackState.Builder builder, CharSequence charSequence) {
            builder.setErrorMessage(charSequence);
        }

        static void w(PlaybackState.CustomAction.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }

        static void x(PlaybackState.Builder builder, int i5, long j5, float f5, long j6) {
            builder.setState(i5, j5, f5, j6);
        }
    }

    private static class c {
        static Bundle a(PlaybackState playbackState) {
            return playbackState.getExtras();
        }

        static void b(PlaybackState.Builder builder, Bundle bundle) {
            builder.setExtras(bundle);
        }
    }

    PlaybackStateCompat(int i5, long j5, long j6, float f5, long j7, int i6, CharSequence charSequence, long j8, List<CustomAction> list, long j9, Bundle bundle) {
        this.f2380b = i5;
        this.f2381c = j5;
        this.f2382d = j6;
        this.f2383e = f5;
        this.f2384f = j7;
        this.f2385g = i6;
        this.f2386h = charSequence;
        this.f2387i = j8;
        this.f2388j = new ArrayList(list);
        this.f2389k = j9;
        this.f2390l = bundle;
    }

    public static PlaybackStateCompat a(Object obj) {
        ArrayList arrayList = null;
        if (obj == null) {
            return null;
        }
        PlaybackState playbackState = (PlaybackState) obj;
        List<PlaybackState.CustomAction> j5 = b.j(playbackState);
        if (j5 != null) {
            arrayList = new ArrayList(j5.size());
            Iterator<PlaybackState.CustomAction> it = j5.iterator();
            while (it.hasNext()) {
                arrayList.add(CustomAction.a(it.next()));
            }
        }
        Bundle a5 = c.a(playbackState);
        MediaSessionCompat.a(a5);
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(b.r(playbackState), b.q(playbackState), b.i(playbackState), b.p(playbackState), b.g(playbackState), 0, b.k(playbackState), b.n(playbackState), arrayList, b.h(playbackState), a5);
        playbackStateCompat.f2391m = playbackState;
        return playbackStateCompat;
    }

    public long c() {
        return this.f2384f;
    }

    public long d() {
        return this.f2387i;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public float e() {
        return this.f2383e;
    }

    public long f() {
        return this.f2381c;
    }

    public int g() {
        return this.f2380b;
    }

    public String toString() {
        return "PlaybackState {state=" + this.f2380b + ", position=" + this.f2381c + ", buffered position=" + this.f2382d + ", speed=" + this.f2383e + ", updated=" + this.f2387i + ", actions=" + this.f2384f + ", error code=" + this.f2385g + ", error message=" + this.f2386h + ", custom actions=" + this.f2388j + ", active item id=" + this.f2389k + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i5) {
        parcel.writeInt(this.f2380b);
        parcel.writeLong(this.f2381c);
        parcel.writeFloat(this.f2383e);
        parcel.writeLong(this.f2387i);
        parcel.writeLong(this.f2382d);
        parcel.writeLong(this.f2384f);
        TextUtils.writeToParcel(this.f2386h, parcel, i5);
        parcel.writeTypedList(this.f2388j);
        parcel.writeLong(this.f2389k);
        parcel.writeBundle(this.f2390l);
        parcel.writeInt(this.f2385g);
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        private final List f2397a;

        /* renamed from: b, reason: collision with root package name */
        private int f2398b;

        /* renamed from: c, reason: collision with root package name */
        private long f2399c;

        /* renamed from: d, reason: collision with root package name */
        private long f2400d;

        /* renamed from: e, reason: collision with root package name */
        private float f2401e;

        /* renamed from: f, reason: collision with root package name */
        private long f2402f;

        /* renamed from: g, reason: collision with root package name */
        private int f2403g;

        /* renamed from: h, reason: collision with root package name */
        private CharSequence f2404h;

        /* renamed from: i, reason: collision with root package name */
        private long f2405i;

        /* renamed from: j, reason: collision with root package name */
        private long f2406j;

        /* renamed from: k, reason: collision with root package name */
        private Bundle f2407k;

        public d() {
            this.f2397a = new ArrayList();
            this.f2406j = -1L;
        }

        public PlaybackStateCompat a() {
            return new PlaybackStateCompat(this.f2398b, this.f2399c, this.f2400d, this.f2401e, this.f2402f, this.f2403g, this.f2404h, this.f2405i, this.f2397a, this.f2406j, this.f2407k);
        }

        public d b(int i5, long j5, float f5, long j6) {
            this.f2398b = i5;
            this.f2399c = j5;
            this.f2405i = j6;
            this.f2401e = f5;
            return this;
        }

        public d(PlaybackStateCompat playbackStateCompat) {
            ArrayList arrayList = new ArrayList();
            this.f2397a = arrayList;
            this.f2406j = -1L;
            this.f2398b = playbackStateCompat.f2380b;
            this.f2399c = playbackStateCompat.f2381c;
            this.f2401e = playbackStateCompat.f2383e;
            this.f2405i = playbackStateCompat.f2387i;
            this.f2400d = playbackStateCompat.f2382d;
            this.f2402f = playbackStateCompat.f2384f;
            this.f2403g = playbackStateCompat.f2385g;
            this.f2404h = playbackStateCompat.f2386h;
            List list = playbackStateCompat.f2388j;
            if (list != null) {
                arrayList.addAll(list);
            }
            this.f2406j = playbackStateCompat.f2389k;
            this.f2407k = playbackStateCompat.f2390l;
        }
    }

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        private final String f2392b;

        /* renamed from: c, reason: collision with root package name */
        private final CharSequence f2393c;

        /* renamed from: d, reason: collision with root package name */
        private final int f2394d;

        /* renamed from: e, reason: collision with root package name */
        private final Bundle f2395e;

        /* renamed from: f, reason: collision with root package name */
        private PlaybackState.CustomAction f2396f;

        class a implements Parcelable.Creator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public CustomAction[] newArray(int i5) {
                return new CustomAction[i5];
            }
        }

        CustomAction(String str, CharSequence charSequence, int i5, Bundle bundle) {
            this.f2392b = str;
            this.f2393c = charSequence;
            this.f2394d = i5;
            this.f2395e = bundle;
        }

        public static CustomAction a(Object obj) {
            if (obj == null) {
                return null;
            }
            PlaybackState.CustomAction customAction = (PlaybackState.CustomAction) obj;
            Bundle l5 = b.l(customAction);
            MediaSessionCompat.a(l5);
            CustomAction customAction2 = new CustomAction(b.f(customAction), b.o(customAction), b.m(customAction), l5);
            customAction2.f2396f = customAction;
            return customAction2;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "Action:mName='" + ((Object) this.f2393c) + ", mIcon=" + this.f2394d + ", mExtras=" + this.f2395e;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            parcel.writeString(this.f2392b);
            TextUtils.writeToParcel(this.f2393c, parcel, i5);
            parcel.writeInt(this.f2394d);
            parcel.writeBundle(this.f2395e);
        }

        CustomAction(Parcel parcel) {
            this.f2392b = parcel.readString();
            this.f2393c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f2394d = parcel.readInt();
            this.f2395e = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }
    }

    PlaybackStateCompat(Parcel parcel) {
        this.f2380b = parcel.readInt();
        this.f2381c = parcel.readLong();
        this.f2383e = parcel.readFloat();
        this.f2387i = parcel.readLong();
        this.f2382d = parcel.readLong();
        this.f2384f = parcel.readLong();
        this.f2386h = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2388j = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f2389k = parcel.readLong();
        this.f2390l = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f2385g = parcel.readInt();
    }
}
