package android.support.v4.media;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.media.MediaDescription;
import android.media.browse.MediaBrowser;
import android.os.BadParcelableException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.b;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class MediaBrowserCompat {

    /* renamed from: b, reason: collision with root package name */
    static final boolean f2265b = Log.isLoggable("MediaBrowserCompat", 3);

    /* renamed from: a, reason: collision with root package name */
    private final f f2266a;

    private static class CustomActionResultReceiver extends ResultReceiver {

        /* renamed from: e, reason: collision with root package name */
        private final String f2267e;

        /* renamed from: f, reason: collision with root package name */
        private final Bundle f2268f;

        /* renamed from: g, reason: collision with root package name */
        private final d f2269g;

        @Override // android.support.v4.os.ResultReceiver
        protected void a(int i5, Bundle bundle) {
            if (this.f2269g == null) {
                return;
            }
            MediaSessionCompat.a(bundle);
            if (i5 == -1) {
                this.f2269g.a(this.f2267e, this.f2268f, bundle);
                return;
            }
            if (i5 == 0) {
                this.f2269g.c(this.f2267e, this.f2268f, bundle);
                return;
            }
            if (i5 == 1) {
                this.f2269g.b(this.f2267e, this.f2268f, bundle);
                return;
            }
            Log.w("MediaBrowserCompat", "Unknown result code: " + i5 + " (extras=" + this.f2268f + ", resultData=" + bundle + ")");
        }
    }

    private static class ItemReceiver extends ResultReceiver {

        /* renamed from: e, reason: collision with root package name */
        private final String f2270e;

        /* renamed from: f, reason: collision with root package name */
        private final e f2271f;

        @Override // android.support.v4.os.ResultReceiver
        protected void a(int i5, Bundle bundle) {
            if (bundle != null) {
                bundle = MediaSessionCompat.e(bundle);
            }
            if (i5 != 0 || bundle == null || !bundle.containsKey("media_item")) {
                this.f2271f.a(this.f2270e);
                return;
            }
            Parcelable parcelable = bundle.getParcelable("media_item");
            if (parcelable == null || (parcelable instanceof MediaItem)) {
                this.f2271f.b((MediaItem) parcelable);
            } else {
                this.f2271f.a(this.f2270e);
            }
        }
    }

    private static class SearchResultReceiver extends ResultReceiver {

        /* renamed from: e, reason: collision with root package name */
        private final String f2274e;

        /* renamed from: f, reason: collision with root package name */
        private final Bundle f2275f;

        /* renamed from: g, reason: collision with root package name */
        private final k f2276g;

        @Override // android.support.v4.os.ResultReceiver
        protected void a(int i5, Bundle bundle) {
            if (bundle != null) {
                bundle = MediaSessionCompat.e(bundle);
            }
            if (i5 != 0 || bundle == null || !bundle.containsKey("search_results")) {
                this.f2276g.a(this.f2274e, this.f2275f);
                return;
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
            if (parcelableArray == null) {
                this.f2276g.a(this.f2274e, this.f2275f);
                return;
            }
            ArrayList arrayList = new ArrayList(parcelableArray.length);
            for (Parcelable parcelable : parcelableArray) {
                arrayList.add((MediaItem) parcelable);
            }
            this.f2276g.b(this.f2274e, this.f2275f, arrayList);
        }
    }

    private static class a {
        static MediaDescription a(MediaBrowser.MediaItem mediaItem) {
            return mediaItem.getDescription();
        }

        static int b(MediaBrowser.MediaItem mediaItem) {
            return mediaItem.getFlags();
        }
    }

    private static class b extends Handler {

        /* renamed from: a, reason: collision with root package name */
        private final WeakReference f2277a;

        /* renamed from: b, reason: collision with root package name */
        private WeakReference f2278b;

        b(j jVar) {
            this.f2277a = new WeakReference(jVar);
        }

        void a(Messenger messenger) {
            this.f2278b = new WeakReference(messenger);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            WeakReference weakReference = this.f2278b;
            if (weakReference == null || weakReference.get() == null || this.f2277a.get() == null) {
                return;
            }
            Bundle data = message.getData();
            MediaSessionCompat.a(data);
            j jVar = (j) this.f2277a.get();
            Messenger messenger = (Messenger) this.f2278b.get();
            try {
                int i5 = message.what;
                if (i5 == 1) {
                    Bundle bundle = data.getBundle("data_root_hints");
                    MediaSessionCompat.a(bundle);
                    jVar.f(messenger, data.getString("data_media_item_id"), (MediaSessionCompat.Token) data.getParcelable("data_media_session_token"), bundle);
                    return;
                }
                if (i5 == 2) {
                    jVar.c(messenger);
                    return;
                }
                if (i5 == 3) {
                    Bundle bundle2 = data.getBundle("data_options");
                    MediaSessionCompat.a(bundle2);
                    Bundle bundle3 = data.getBundle("data_notify_children_changed_options");
                    MediaSessionCompat.a(bundle3);
                    jVar.d(messenger, data.getString("data_media_item_id"), data.getParcelableArrayList("data_media_item_list"), bundle2, bundle3);
                    return;
                }
                Log.w("MediaBrowserCompat", "Unhandled message: " + message + "\n  Client version: 1\n  Service version: " + message.arg1);
            } catch (BadParcelableException unused) {
                Log.e("MediaBrowserCompat", "Could not unparcel the data.");
                if (message.what == 1) {
                    jVar.c(messenger);
                }
            }
        }
    }

    public static class c {

        /* renamed from: a, reason: collision with root package name */
        final MediaBrowser.ConnectionCallback f2279a = new a();

        /* renamed from: b, reason: collision with root package name */
        b f2280b;

        private class a extends MediaBrowser.ConnectionCallback {
            a() {
            }

            @Override // android.media.browse.MediaBrowser.ConnectionCallback
            public void onConnected() {
                b bVar = c.this.f2280b;
                if (bVar != null) {
                    bVar.onConnected();
                }
                c.this.a();
            }

            @Override // android.media.browse.MediaBrowser.ConnectionCallback
            public void onConnectionFailed() {
                b bVar = c.this.f2280b;
                if (bVar != null) {
                    bVar.e();
                }
                c.this.b();
            }

            @Override // android.media.browse.MediaBrowser.ConnectionCallback
            public void onConnectionSuspended() {
                b bVar = c.this.f2280b;
                if (bVar != null) {
                    bVar.b();
                }
                c.this.c();
            }
        }

        interface b {
            void b();

            void e();

            void onConnected();
        }

        public void a() {
        }

        public void b() {
        }

        public void c() {
        }

        void d(b bVar) {
            this.f2280b = bVar;
        }
    }

    public static abstract class d {
        public void a(String str, Bundle bundle, Bundle bundle2) {
        }

        public void b(String str, Bundle bundle, Bundle bundle2) {
        }

        public void c(String str, Bundle bundle, Bundle bundle2) {
        }
    }

    public static abstract class e {

        /* renamed from: a, reason: collision with root package name */
        final MediaBrowser.ItemCallback f2282a = new a();

        private class a extends MediaBrowser.ItemCallback {
            a() {
            }

            @Override // android.media.browse.MediaBrowser.ItemCallback
            public void onError(String str) {
                e.this.a(str);
            }

            @Override // android.media.browse.MediaBrowser.ItemCallback
            public void onItemLoaded(MediaBrowser.MediaItem mediaItem) {
                e.this.b(MediaItem.a(mediaItem));
            }
        }

        public void a(String str) {
        }

        public void b(MediaItem mediaItem) {
        }
    }

    interface f {
        void a();

        void disconnect();

        MediaSessionCompat.Token getSessionToken();
    }

    static class g implements f, j, c.b {

        /* renamed from: a, reason: collision with root package name */
        final Context f2284a;

        /* renamed from: b, reason: collision with root package name */
        protected final MediaBrowser f2285b;

        /* renamed from: c, reason: collision with root package name */
        protected final Bundle f2286c;

        /* renamed from: d, reason: collision with root package name */
        protected final b f2287d = new b(this);

        /* renamed from: e, reason: collision with root package name */
        private final androidx.collection.a f2288e = new androidx.collection.a();

        /* renamed from: f, reason: collision with root package name */
        protected int f2289f;

        /* renamed from: g, reason: collision with root package name */
        protected l f2290g;

        /* renamed from: h, reason: collision with root package name */
        protected Messenger f2291h;

        /* renamed from: i, reason: collision with root package name */
        private MediaSessionCompat.Token f2292i;

        g(Context context, ComponentName componentName, c cVar, Bundle bundle) {
            this.f2284a = context;
            Bundle bundle2 = bundle != null ? new Bundle(bundle) : new Bundle();
            this.f2286c = bundle2;
            bundle2.putInt("extra_client_version", 1);
            bundle2.putInt("extra_calling_pid", Process.myPid());
            cVar.d(this);
            this.f2285b = new MediaBrowser(context, componentName, cVar.f2279a, bundle2);
        }

        @Override // android.support.v4.media.MediaBrowserCompat.f
        public void a() {
            this.f2285b.connect();
        }

        @Override // android.support.v4.media.MediaBrowserCompat.c.b
        public void b() {
            this.f2290g = null;
            this.f2291h = null;
            this.f2292i = null;
            this.f2287d.a(null);
        }

        @Override // android.support.v4.media.MediaBrowserCompat.j
        public void c(Messenger messenger) {
        }

        @Override // android.support.v4.media.MediaBrowserCompat.j
        public void d(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2) {
            if (this.f2291h != messenger) {
                return;
            }
            android.support.v4.media.a.a(this.f2288e.get(str));
            if (MediaBrowserCompat.f2265b) {
                Log.d("MediaBrowserCompat", "onLoadChildren for id that isn't subscribed id=" + str);
            }
        }

        @Override // android.support.v4.media.MediaBrowserCompat.f
        public void disconnect() {
            Messenger messenger;
            l lVar = this.f2290g;
            if (lVar != null && (messenger = this.f2291h) != null) {
                try {
                    lVar.c(messenger);
                } catch (RemoteException unused) {
                    Log.i("MediaBrowserCompat", "Remote error unregistering client messenger.");
                }
            }
            this.f2285b.disconnect();
        }

        @Override // android.support.v4.media.MediaBrowserCompat.c.b
        public void e() {
        }

        @Override // android.support.v4.media.MediaBrowserCompat.j
        public void f(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle) {
        }

        @Override // android.support.v4.media.MediaBrowserCompat.f
        public MediaSessionCompat.Token getSessionToken() {
            if (this.f2292i == null) {
                this.f2292i = MediaSessionCompat.Token.a(this.f2285b.getSessionToken());
            }
            return this.f2292i;
        }

        @Override // android.support.v4.media.MediaBrowserCompat.c.b
        public void onConnected() {
            try {
                Bundle extras = this.f2285b.getExtras();
                if (extras == null) {
                    return;
                }
                this.f2289f = extras.getInt("extra_service_version", 0);
                IBinder a5 = androidx.core.app.h.a(extras, "extra_messenger");
                if (a5 != null) {
                    this.f2290g = new l(a5, this.f2286c);
                    Messenger messenger = new Messenger(this.f2287d);
                    this.f2291h = messenger;
                    this.f2287d.a(messenger);
                    try {
                        this.f2290g.a(this.f2284a, this.f2291h);
                    } catch (RemoteException unused) {
                        Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
                    }
                }
                android.support.v4.media.session.b C02 = b.a.C0(androidx.core.app.h.a(extras, "extra_session_binder"));
                if (C02 != null) {
                    this.f2292i = MediaSessionCompat.Token.b(this.f2285b.getSessionToken(), C02);
                }
            } catch (IllegalStateException e5) {
                Log.e("MediaBrowserCompat", "Unexpected IllegalStateException", e5);
            }
        }
    }

    static class h extends g {
        h(Context context, ComponentName componentName, c cVar, Bundle bundle) {
            super(context, componentName, cVar, bundle);
        }
    }

    static class i extends h {
        i(Context context, ComponentName componentName, c cVar, Bundle bundle) {
            super(context, componentName, cVar, bundle);
        }
    }

    interface j {
        void c(Messenger messenger);

        void d(Messenger messenger, String str, List list, Bundle bundle, Bundle bundle2);

        void f(Messenger messenger, String str, MediaSessionCompat.Token token, Bundle bundle);
    }

    public static abstract class k {
        public void a(String str, Bundle bundle) {
        }

        public void b(String str, Bundle bundle, List list) {
        }
    }

    private static class l {

        /* renamed from: a, reason: collision with root package name */
        private Messenger f2293a;

        /* renamed from: b, reason: collision with root package name */
        private Bundle f2294b;

        public l(IBinder iBinder, Bundle bundle) {
            this.f2293a = new Messenger(iBinder);
            this.f2294b = bundle;
        }

        private void b(int i5, Bundle bundle, Messenger messenger) {
            Message obtain = Message.obtain();
            obtain.what = i5;
            obtain.arg1 = 1;
            obtain.setData(bundle);
            obtain.replyTo = messenger;
            this.f2293a.send(obtain);
        }

        void a(Context context, Messenger messenger) {
            Bundle bundle = new Bundle();
            bundle.putString("data_package_name", context.getPackageName());
            bundle.putInt("data_calling_pid", Process.myPid());
            bundle.putBundle("data_root_hints", this.f2294b);
            b(6, bundle, messenger);
        }

        void c(Messenger messenger) {
            b(7, null, messenger);
        }
    }

    public MediaBrowserCompat(Context context, ComponentName componentName, c cVar, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 26) {
            this.f2266a = new i(context, componentName, cVar, bundle);
        } else {
            this.f2266a = new h(context, componentName, cVar, bundle);
        }
    }

    public void a() {
        Log.d("MediaBrowserCompat", "Connecting to a MediaBrowserService.");
        this.f2266a.a();
    }

    public void b() {
        this.f2266a.disconnect();
    }

    public MediaSessionCompat.Token c() {
        return this.f2266a.getSessionToken();
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class MediaItem implements Parcelable {
        public static final Parcelable.Creator<MediaItem> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        private final int f2272b;

        /* renamed from: c, reason: collision with root package name */
        private final MediaDescriptionCompat f2273c;

        class a implements Parcelable.Creator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public MediaItem createFromParcel(Parcel parcel) {
                return new MediaItem(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public MediaItem[] newArray(int i5) {
                return new MediaItem[i5];
            }
        }

        public MediaItem(@NonNull MediaDescriptionCompat mediaDescriptionCompat, int i5) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("description cannot be null");
            }
            if (TextUtils.isEmpty(mediaDescriptionCompat.d())) {
                throw new IllegalArgumentException("description must have a non-empty media id");
            }
            this.f2272b = i5;
            this.f2273c = mediaDescriptionCompat;
        }

        public static MediaItem a(Object obj) {
            if (obj == null) {
                return null;
            }
            MediaBrowser.MediaItem mediaItem = (MediaBrowser.MediaItem) obj;
            return new MediaItem(MediaDescriptionCompat.a(a.a(mediaItem)), a.b(mediaItem));
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "MediaItem{mFlags=" + this.f2272b + ", mDescription=" + this.f2273c + '}';
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            parcel.writeInt(this.f2272b);
            this.f2273c.writeToParcel(parcel, i5);
        }

        MediaItem(Parcel parcel) {
            this.f2272b = parcel.readInt();
            this.f2273c = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        }
    }
}
