package android.support.v4.media;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.Nullable;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    private final String f2295b;

    /* renamed from: c, reason: collision with root package name */
    private final CharSequence f2296c;

    /* renamed from: d, reason: collision with root package name */
    private final CharSequence f2297d;

    /* renamed from: e, reason: collision with root package name */
    private final CharSequence f2298e;

    /* renamed from: f, reason: collision with root package name */
    private final Bitmap f2299f;

    /* renamed from: g, reason: collision with root package name */
    private final Uri f2300g;

    /* renamed from: h, reason: collision with root package name */
    private final Bundle f2301h;

    /* renamed from: i, reason: collision with root package name */
    private final Uri f2302i;

    /* renamed from: j, reason: collision with root package name */
    private MediaDescription f2303j;

    class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public MediaDescriptionCompat createFromParcel(Parcel parcel) {
            return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(parcel));
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public MediaDescriptionCompat[] newArray(int i5) {
            return new MediaDescriptionCompat[i5];
        }
    }

    private static class b {
        static MediaDescription a(MediaDescription.Builder builder) {
            return builder.build();
        }

        static MediaDescription.Builder b() {
            return new MediaDescription.Builder();
        }

        @Nullable
        static CharSequence c(MediaDescription mediaDescription) {
            return mediaDescription.getDescription();
        }

        @Nullable
        static Bundle d(MediaDescription mediaDescription) {
            return mediaDescription.getExtras();
        }

        @Nullable
        static Bitmap e(MediaDescription mediaDescription) {
            return mediaDescription.getIconBitmap();
        }

        @Nullable
        static Uri f(MediaDescription mediaDescription) {
            return mediaDescription.getIconUri();
        }

        @Nullable
        static String g(MediaDescription mediaDescription) {
            return mediaDescription.getMediaId();
        }

        @Nullable
        static CharSequence h(MediaDescription mediaDescription) {
            return mediaDescription.getSubtitle();
        }

        @Nullable
        static CharSequence i(MediaDescription mediaDescription) {
            return mediaDescription.getTitle();
        }

        static void j(MediaDescription.Builder builder, @Nullable CharSequence charSequence) {
            builder.setDescription(charSequence);
        }

        static void k(MediaDescription.Builder builder, @Nullable Bundle bundle) {
            builder.setExtras(bundle);
        }

        static void l(MediaDescription.Builder builder, @Nullable Bitmap bitmap) {
            builder.setIconBitmap(bitmap);
        }

        static void m(MediaDescription.Builder builder, @Nullable Uri uri) {
            builder.setIconUri(uri);
        }

        static void n(MediaDescription.Builder builder, @Nullable String str) {
            builder.setMediaId(str);
        }

        static void o(MediaDescription.Builder builder, @Nullable CharSequence charSequence) {
            builder.setSubtitle(charSequence);
        }

        static void p(MediaDescription.Builder builder, @Nullable CharSequence charSequence) {
            builder.setTitle(charSequence);
        }
    }

    private static class c {
        @Nullable
        static Uri a(MediaDescription mediaDescription) {
            return mediaDescription.getMediaUri();
        }

        static void b(MediaDescription.Builder builder, @Nullable Uri uri) {
            builder.setMediaUri(uri);
        }
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        private String f2304a;

        /* renamed from: b, reason: collision with root package name */
        private CharSequence f2305b;

        /* renamed from: c, reason: collision with root package name */
        private CharSequence f2306c;

        /* renamed from: d, reason: collision with root package name */
        private CharSequence f2307d;

        /* renamed from: e, reason: collision with root package name */
        private Bitmap f2308e;

        /* renamed from: f, reason: collision with root package name */
        private Uri f2309f;

        /* renamed from: g, reason: collision with root package name */
        private Bundle f2310g;

        /* renamed from: h, reason: collision with root package name */
        private Uri f2311h;

        public MediaDescriptionCompat a() {
            return new MediaDescriptionCompat(this.f2304a, this.f2305b, this.f2306c, this.f2307d, this.f2308e, this.f2309f, this.f2310g, this.f2311h);
        }

        public d b(CharSequence charSequence) {
            this.f2307d = charSequence;
            return this;
        }

        public d c(Bundle bundle) {
            this.f2310g = bundle;
            return this;
        }

        public d d(Bitmap bitmap) {
            this.f2308e = bitmap;
            return this;
        }

        public d e(Uri uri) {
            this.f2309f = uri;
            return this;
        }

        public d f(String str) {
            this.f2304a = str;
            return this;
        }

        public d g(Uri uri) {
            this.f2311h = uri;
            return this;
        }

        public d h(CharSequence charSequence) {
            this.f2306c = charSequence;
            return this;
        }

        public d i(CharSequence charSequence) {
            this.f2305b = charSequence;
            return this;
        }
    }

    MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f2295b = str;
        this.f2296c = charSequence;
        this.f2297d = charSequence2;
        this.f2298e = charSequence3;
        this.f2299f = bitmap;
        this.f2300g = uri;
        this.f2301h = bundle;
        this.f2302i = uri2;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x006c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.support.v4.media.MediaDescriptionCompat a(java.lang.Object r8) {
        /*
            r0 = 0
            if (r8 == 0) goto L79
            android.support.v4.media.MediaDescriptionCompat$d r1 = new android.support.v4.media.MediaDescriptionCompat$d
            r1.<init>()
            android.media.MediaDescription r8 = (android.media.MediaDescription) r8
            java.lang.String r2 = android.support.v4.media.MediaDescriptionCompat.b.g(r8)
            r1.f(r2)
            java.lang.CharSequence r2 = android.support.v4.media.MediaDescriptionCompat.b.i(r8)
            r1.i(r2)
            java.lang.CharSequence r2 = android.support.v4.media.MediaDescriptionCompat.b.h(r8)
            r1.h(r2)
            java.lang.CharSequence r2 = android.support.v4.media.MediaDescriptionCompat.b.c(r8)
            r1.b(r2)
            android.graphics.Bitmap r2 = android.support.v4.media.MediaDescriptionCompat.b.e(r8)
            r1.d(r2)
            android.net.Uri r2 = android.support.v4.media.MediaDescriptionCompat.b.f(r8)
            r1.e(r2)
            android.os.Bundle r2 = android.support.v4.media.MediaDescriptionCompat.b.d(r8)
            if (r2 == 0) goto L3e
            android.os.Bundle r2 = android.support.v4.media.session.MediaSessionCompat.e(r2)
        L3e:
            java.lang.String r3 = "android.support.v4.media.description.MEDIA_URI"
            if (r2 == 0) goto L49
            android.os.Parcelable r4 = r2.getParcelable(r3)
            android.net.Uri r4 = (android.net.Uri) r4
            goto L4a
        L49:
            r4 = r0
        L4a:
            if (r4 == 0) goto L62
            java.lang.String r5 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r6 = r2.containsKey(r5)
            if (r6 == 0) goto L5c
            int r6 = r2.size()
            r7 = 2
            if (r6 != r7) goto L5c
            goto L63
        L5c:
            r2.remove(r3)
            r2.remove(r5)
        L62:
            r0 = r2
        L63:
            r1.c(r0)
            if (r4 == 0) goto L6c
            r1.g(r4)
            goto L73
        L6c:
            android.net.Uri r0 = android.support.v4.media.MediaDescriptionCompat.c.a(r8)
            r1.g(r0)
        L73:
            android.support.v4.media.MediaDescriptionCompat r0 = r1.a()
            r0.f2303j = r8
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.MediaDescriptionCompat.a(java.lang.Object):android.support.v4.media.MediaDescriptionCompat");
    }

    public Object c() {
        MediaDescription mediaDescription = this.f2303j;
        if (mediaDescription != null) {
            return mediaDescription;
        }
        MediaDescription.Builder b5 = b.b();
        b.n(b5, this.f2295b);
        b.p(b5, this.f2296c);
        b.o(b5, this.f2297d);
        b.j(b5, this.f2298e);
        b.l(b5, this.f2299f);
        b.m(b5, this.f2300g);
        b.k(b5, this.f2301h);
        c.b(b5, this.f2302i);
        MediaDescription a5 = b.a(b5);
        this.f2303j = a5;
        return a5;
    }

    public String d() {
        return this.f2295b;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return ((Object) this.f2296c) + ", " + ((Object) this.f2297d) + ", " + ((Object) this.f2298e);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i5) {
        ((MediaDescription) c()).writeToParcel(parcel, i5);
    }

    MediaDescriptionCompat(Parcel parcel) {
        this.f2295b = parcel.readString();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f2296c = (CharSequence) creator.createFromParcel(parcel);
        this.f2297d = (CharSequence) creator.createFromParcel(parcel);
        this.f2298e = (CharSequence) creator.createFromParcel(parcel);
        ClassLoader classLoader = MediaDescriptionCompat.class.getClassLoader();
        this.f2299f = (Bitmap) parcel.readParcelable(classLoader);
        this.f2300g = (Uri) parcel.readParcelable(classLoader);
        this.f2301h = parcel.readBundle(classLoader);
        this.f2302i = (Uri) parcel.readParcelable(classLoader);
    }
}
