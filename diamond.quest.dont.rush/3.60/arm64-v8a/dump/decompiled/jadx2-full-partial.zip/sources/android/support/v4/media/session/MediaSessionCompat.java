package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaDescription;
import android.media.Rating;
import android.media.session.MediaSession;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteCallbackList;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v4.media.session.b;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.h;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class MediaSessionCompat {

    /* renamed from: d, reason: collision with root package name */
    static int f2339d;

    /* renamed from: a, reason: collision with root package name */
    private final c f2340a;

    /* renamed from: b, reason: collision with root package name */
    private final MediaControllerCompat f2341b;

    /* renamed from: c, reason: collision with root package name */
    private final ArrayList f2342c;

    @SuppressLint({"BanParcelableUsage"})
    public static final class QueueItem implements Parcelable {
        public static final Parcelable.Creator<QueueItem> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        private final MediaDescriptionCompat f2343b;

        /* renamed from: c, reason: collision with root package name */
        private final long f2344c;

        /* renamed from: d, reason: collision with root package name */
        private MediaSession.QueueItem f2345d;

        class a implements Parcelable.Creator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public QueueItem createFromParcel(Parcel parcel) {
                return new QueueItem(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public QueueItem[] newArray(int i5) {
                return new QueueItem[i5];
            }
        }

        private static class b {
            static MediaSession.QueueItem a(MediaDescription mediaDescription, long j5) {
                return new MediaSession.QueueItem(mediaDescription, j5);
            }

            static MediaDescription b(MediaSession.QueueItem queueItem) {
                return queueItem.getDescription();
            }

            static long c(MediaSession.QueueItem queueItem) {
                return queueItem.getQueueId();
            }
        }

        public QueueItem(MediaDescriptionCompat mediaDescriptionCompat, long j5) {
            this(null, mediaDescriptionCompat, j5);
        }

        public static QueueItem a(Object obj) {
            if (obj == null) {
                return null;
            }
            MediaSession.QueueItem queueItem = (MediaSession.QueueItem) obj;
            return new QueueItem(queueItem, MediaDescriptionCompat.a(b.b(queueItem)), b.c(queueItem));
        }

        public static List b(List list) {
            if (list == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList(list.size());
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(a(it.next()));
            }
            return arrayList;
        }

        public MediaDescriptionCompat c() {
            return this.f2343b;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "MediaSession.QueueItem {Description=" + this.f2343b + ", Id=" + this.f2344c + " }";
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            this.f2343b.writeToParcel(parcel, i5);
            parcel.writeLong(this.f2344c);
        }

        private QueueItem(MediaSession.QueueItem queueItem, MediaDescriptionCompat mediaDescriptionCompat, long j5) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("Description cannot be null");
            }
            if (j5 == -1) {
                throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
            }
            this.f2343b = mediaDescriptionCompat;
            this.f2344c = j5;
            this.f2345d = queueItem;
        }

        QueueItem(Parcel parcel) {
            this.f2343b = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.f2344c = parcel.readLong();
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    static final class ResultReceiverWrapper implements Parcelable {
        public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        ResultReceiver f2346b;

        class a implements Parcelable.Creator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public ResultReceiverWrapper createFromParcel(Parcel parcel) {
                return new ResultReceiverWrapper(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public ResultReceiverWrapper[] newArray(int i5) {
                return new ResultReceiverWrapper[i5];
            }
        }

        ResultReceiverWrapper(Parcel parcel) {
            this.f2346b = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            this.f2346b.writeToParcel(parcel, i5);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static final class Token implements Parcelable {
        public static final Parcelable.Creator<Token> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        private final Object f2347b;

        /* renamed from: c, reason: collision with root package name */
        private final Object f2348c;

        /* renamed from: d, reason: collision with root package name */
        private android.support.v4.media.session.b f2349d;

        /* renamed from: e, reason: collision with root package name */
        private androidx.versionedparcelable.d f2350e;

        class a implements Parcelable.Creator {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public Token createFromParcel(Parcel parcel) {
                return new Token(parcel.readParcelable(null));
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public Token[] newArray(int i5) {
                return new Token[i5];
            }
        }

        Token(Object obj) {
            this(obj, null, null);
        }

        public static Token a(Object obj) {
            return b(obj, null);
        }

        public static Token b(Object obj, android.support.v4.media.session.b bVar) {
            if (obj == null) {
                return null;
            }
            if (obj instanceof MediaSession.Token) {
                return new Token(obj, bVar);
            }
            throw new IllegalArgumentException("token is not a valid MediaSession.Token object");
        }

        public android.support.v4.media.session.b c() {
            android.support.v4.media.session.b bVar;
            synchronized (this.f2347b) {
                bVar = this.f2349d;
            }
            return bVar;
        }

        public androidx.versionedparcelable.d d() {
            androidx.versionedparcelable.d dVar;
            synchronized (this.f2347b) {
                dVar = this.f2350e;
            }
            return dVar;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public Object e() {
            return this.f2348c;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Token token = (Token) obj;
            Object obj2 = this.f2348c;
            if (obj2 == null) {
                return token.f2348c == null;
            }
            Object obj3 = token.f2348c;
            if (obj3 == null) {
                return false;
            }
            return obj2.equals(obj3);
        }

        public void f(android.support.v4.media.session.b bVar) {
            synchronized (this.f2347b) {
                this.f2349d = bVar;
            }
        }

        public void g(androidx.versionedparcelable.d dVar) {
            synchronized (this.f2347b) {
                this.f2350e = dVar;
            }
        }

        public int hashCode() {
            Object obj = this.f2348c;
            if (obj == null) {
                return 0;
            }
            return obj.hashCode();
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i5) {
            parcel.writeParcelable((Parcelable) this.f2348c, i5);
        }

        Token(Object obj, android.support.v4.media.session.b bVar) {
            this(obj, bVar, null);
        }

        Token(Object obj, android.support.v4.media.session.b bVar, androidx.versionedparcelable.d dVar) {
            this.f2347b = new Object();
            this.f2348c = obj;
            this.f2349d = bVar;
            this.f2350e = dVar;
        }
    }

    class a extends b {
        a() {
        }
    }

    public static abstract class b {

        /* renamed from: c, reason: collision with root package name */
        private boolean f2354c;

        /* renamed from: e, reason: collision with root package name */
        a f2356e;

        /* renamed from: a, reason: collision with root package name */
        final Object f2352a = new Object();

        /* renamed from: b, reason: collision with root package name */
        final MediaSession.Callback f2353b = new C0098b();

        /* renamed from: d, reason: collision with root package name */
        WeakReference f2355d = new WeakReference(null);

        private class a extends Handler {
            a(Looper looper) {
                super(looper);
            }

            @Override // android.os.Handler
            public void handleMessage(Message message) {
                c cVar;
                b bVar;
                a aVar;
                if (message.what == 1) {
                    synchronized (b.this.f2352a) {
                        cVar = (c) b.this.f2355d.get();
                        bVar = b.this;
                        aVar = bVar.f2356e;
                    }
                    if (cVar == null || bVar != cVar.e() || aVar == null) {
                        return;
                    }
                    cVar.d((androidx.media.a) message.obj);
                    b.this.a(cVar, aVar);
                    cVar.d(null);
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaSessionCompat$b$b, reason: collision with other inner class name */
        private class C0098b extends MediaSession.Callback {
            C0098b() {
            }

            private void a(c cVar) {
                cVar.d(null);
            }

            private d b() {
                d dVar;
                synchronized (b.this.f2352a) {
                    dVar = (d) b.this.f2355d.get();
                }
                if (dVar == null || b.this != dVar.e()) {
                    return null;
                }
                return dVar;
            }

            private void c(c cVar) {
                if (Build.VERSION.SDK_INT >= 28) {
                    return;
                }
                String b5 = cVar.b();
                if (TextUtils.isEmpty(b5)) {
                    b5 = "android.media.session.MediaController";
                }
                cVar.d(new androidx.media.a(b5, -1, -1));
            }

            @Override // android.media.session.MediaSession.Callback
            public void onCommand(String str, Bundle bundle, ResultReceiver resultReceiver) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                try {
                    QueueItem queueItem = null;
                    IBinder asBinder = null;
                    queueItem = null;
                    if (str.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER")) {
                        Bundle bundle2 = new Bundle();
                        Token sessionToken = b5.getSessionToken();
                        android.support.v4.media.session.b c5 = sessionToken.c();
                        if (c5 != null) {
                            asBinder = c5.asBinder();
                        }
                        h.b(bundle2, "android.support.v4.media.session.EXTRA_BINDER", asBinder);
                        androidx.versionedparcelable.a.c(bundle2, "android.support.v4.media.session.SESSION_TOKEN2", sessionToken.d());
                        resultReceiver.send(0, bundle2);
                    } else if (str.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM")) {
                        b.this.b((MediaDescriptionCompat) bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
                    } else if (str.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT")) {
                        b.this.c((MediaDescriptionCompat) bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"), bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX"));
                    } else if (str.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
                        b.this.q((MediaDescriptionCompat) bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
                    } else if (!str.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
                        b.this.d(str, bundle, resultReceiver);
                    } else if (b5.f2366h != null) {
                        int i5 = bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
                        if (i5 >= 0 && i5 < b5.f2366h.size()) {
                            queueItem = (QueueItem) b5.f2366h.get(i5);
                        }
                        if (queueItem != null) {
                            b.this.q(queueItem.c());
                        }
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
                }
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onCustomAction(String str, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                try {
                    if (str.equals("android.support.v4.media.session.action.PLAY_FROM_URI")) {
                        Uri uri = (Uri) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
                        Bundle bundle2 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                        MediaSessionCompat.a(bundle2);
                        b.this.l(uri, bundle2);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE")) {
                        b.this.m();
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
                        String string = bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
                        Bundle bundle3 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                        MediaSessionCompat.a(bundle3);
                        b.this.n(string, bundle3);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
                        String string2 = bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
                        Bundle bundle4 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                        MediaSessionCompat.a(bundle4);
                        b.this.o(string2, bundle4);
                    } else if (str.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
                        Uri uri2 = (Uri) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
                        Bundle bundle5 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                        MediaSessionCompat.a(bundle5);
                        b.this.p(uri2, bundle5);
                    } else if (str.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
                        b.this.t(bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED"));
                    } else if (str.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
                        b.this.x(bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE"));
                    } else if (str.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
                        b.this.y(bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE"));
                    } else if (str.equals("android.support.v4.media.session.action.SET_RATING")) {
                        RatingCompat ratingCompat = (RatingCompat) bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
                        Bundle bundle6 = bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
                        MediaSessionCompat.a(bundle6);
                        b.this.w(ratingCompat, bundle6);
                    } else if (str.equals("android.support.v4.media.session.action.SET_PLAYBACK_SPEED")) {
                        b.this.u(bundle.getFloat("android.support.v4.media.session.action.ARGUMENT_PLAYBACK_SPEED", 1.0f));
                    } else {
                        b.this.e(str, bundle);
                    }
                } catch (BadParcelableException unused) {
                    Log.e("MediaSessionCompat", "Could not unparcel the data.");
                }
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onFastForward() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.f();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public boolean onMediaButtonEvent(Intent intent) {
                d b5 = b();
                if (b5 == null) {
                    return false;
                }
                c(b5);
                boolean g5 = b.this.g(intent);
                a(b5);
                return g5 || super.onMediaButtonEvent(intent);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPause() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.h();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlay() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.i();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromMediaId(String str, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.j(str, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromSearch(String str, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.k(str, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPlayFromUri(Uri uri, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.l(uri, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepare() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.m();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromMediaId(String str, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.n(str, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromSearch(String str, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.o(str, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onPrepareFromUri(Uri uri, Bundle bundle) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                MediaSessionCompat.a(bundle);
                c(b5);
                b.this.p(uri, bundle);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onRewind() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.r();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSeekTo(long j5) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.s(j5);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSetPlaybackSpeed(float f5) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.u(f5);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSetRating(Rating rating) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.v(RatingCompat.a(rating));
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToNext() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.z();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToPrevious() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.A();
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onSkipToQueueItem(long j5) {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.B(j5);
                a(b5);
            }

            @Override // android.media.session.MediaSession.Callback
            public void onStop() {
                d b5 = b();
                if (b5 == null) {
                    return;
                }
                c(b5);
                b.this.C();
                a(b5);
            }
        }

        public void A() {
        }

        public void B(long j5) {
        }

        public void C() {
        }

        void D(c cVar, Handler handler) {
            synchronized (this.f2352a) {
                try {
                    this.f2355d = new WeakReference(cVar);
                    a aVar = this.f2356e;
                    a aVar2 = null;
                    if (aVar != null) {
                        aVar.removeCallbacksAndMessages(null);
                    }
                    if (cVar != null && handler != null) {
                        aVar2 = new a(handler.getLooper());
                    }
                    this.f2356e = aVar2;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        void a(c cVar, Handler handler) {
            if (this.f2354c) {
                this.f2354c = false;
                handler.removeMessages(1);
                PlaybackStateCompat playbackState = cVar.getPlaybackState();
                long c5 = playbackState == null ? 0L : playbackState.c();
                boolean z4 = playbackState != null && playbackState.g() == 3;
                boolean z5 = (516 & c5) != 0;
                boolean z6 = (c5 & 514) != 0;
                if (z4 && z6) {
                    h();
                } else {
                    if (z4 || !z5) {
                        return;
                    }
                    i();
                }
            }
        }

        public void b(MediaDescriptionCompat mediaDescriptionCompat) {
        }

        public void c(MediaDescriptionCompat mediaDescriptionCompat, int i5) {
        }

        public void d(String str, Bundle bundle, ResultReceiver resultReceiver) {
        }

        public void e(String str, Bundle bundle) {
        }

        public void f() {
        }

        public boolean g(Intent intent) {
            c cVar;
            a aVar;
            KeyEvent keyEvent;
            if (Build.VERSION.SDK_INT >= 27) {
                return false;
            }
            synchronized (this.f2352a) {
                cVar = (c) this.f2355d.get();
                aVar = this.f2356e;
            }
            if (cVar == null || aVar == null || (keyEvent = (KeyEvent) intent.getParcelableExtra("android.intent.extra.KEY_EVENT")) == null || keyEvent.getAction() != 0) {
                return false;
            }
            androidx.media.a f5 = cVar.f();
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 79 && keyCode != 85) {
                a(cVar, aVar);
                return false;
            }
            if (keyEvent.getRepeatCount() != 0) {
                a(cVar, aVar);
            } else if (this.f2354c) {
                aVar.removeMessages(1);
                this.f2354c = false;
                PlaybackStateCompat playbackState = cVar.getPlaybackState();
                if (((playbackState == null ? 0L : playbackState.c()) & 32) != 0) {
                    z();
                }
            } else {
                this.f2354c = true;
                aVar.sendMessageDelayed(aVar.obtainMessage(1, f5), ViewConfiguration.getDoubleTapTimeout());
            }
            return true;
        }

        public void h() {
        }

        public void i() {
        }

        public void j(String str, Bundle bundle) {
        }

        public void k(String str, Bundle bundle) {
        }

        public void l(Uri uri, Bundle bundle) {
        }

        public void m() {
        }

        public void n(String str, Bundle bundle) {
        }

        public void o(String str, Bundle bundle) {
        }

        public void p(Uri uri, Bundle bundle) {
        }

        public void q(MediaDescriptionCompat mediaDescriptionCompat) {
        }

        public void r() {
        }

        public void s(long j5) {
        }

        public void t(boolean z4) {
        }

        public void u(float f5) {
        }

        public void v(RatingCompat ratingCompat) {
        }

        public void w(RatingCompat ratingCompat, Bundle bundle) {
        }

        public void x(int i5) {
        }

        public void y(int i5) {
        }

        public void z() {
        }
    }

    interface c {
        void a(b bVar, Handler handler);

        String b();

        void c(PendingIntent pendingIntent);

        void d(androidx.media.a aVar);

        b e();

        androidx.media.a f();

        PlaybackStateCompat getPlaybackState();

        Token getSessionToken();
    }

    static class d implements c {

        /* renamed from: a, reason: collision with root package name */
        final MediaSession f2359a;

        /* renamed from: b, reason: collision with root package name */
        final Token f2360b;

        /* renamed from: d, reason: collision with root package name */
        Bundle f2362d;

        /* renamed from: g, reason: collision with root package name */
        PlaybackStateCompat f2365g;

        /* renamed from: h, reason: collision with root package name */
        List f2366h;

        /* renamed from: i, reason: collision with root package name */
        MediaMetadataCompat f2367i;

        /* renamed from: j, reason: collision with root package name */
        int f2368j;

        /* renamed from: k, reason: collision with root package name */
        boolean f2369k;

        /* renamed from: l, reason: collision with root package name */
        int f2370l;

        /* renamed from: m, reason: collision with root package name */
        int f2371m;

        /* renamed from: n, reason: collision with root package name */
        b f2372n;

        /* renamed from: o, reason: collision with root package name */
        androidx.media.a f2373o;

        /* renamed from: c, reason: collision with root package name */
        final Object f2361c = new Object();

        /* renamed from: e, reason: collision with root package name */
        boolean f2363e = false;

        /* renamed from: f, reason: collision with root package name */
        final RemoteCallbackList f2364f = new RemoteCallbackList();

        class a extends b.a {
            a() {
            }

            @Override // android.support.v4.media.session.b
            public void A(int i5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public boolean B() {
                return d.this.f2369k;
            }

            @Override // android.support.v4.media.session.b
            public void C(String str, Bundle bundle, ResultReceiverWrapper resultReceiverWrapper) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void D() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void E(boolean z4) {
            }

            @Override // android.support.v4.media.session.b
            public void F(android.support.v4.media.session.a aVar) {
                if (d.this.f2363e) {
                    return;
                }
                d.this.f2364f.register(aVar, new androidx.media.a("android.media.session.MediaController", Binder.getCallingPid(), Binder.getCallingUid()));
                synchronized (d.this.f2361c) {
                    d.this.getClass();
                }
            }

            @Override // android.support.v4.media.session.b
            public boolean G() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public CharSequence H() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void I(android.support.v4.media.session.a aVar) {
                d.this.f2364f.unregister(aVar);
                Binder.getCallingPid();
                Binder.getCallingUid();
                synchronized (d.this.f2361c) {
                    d.this.getClass();
                }
            }

            @Override // android.support.v4.media.session.b
            public void J(boolean z4) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public ParcelableVolumeInfo K() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public int L() {
                return d.this.f2368j;
            }

            @Override // android.support.v4.media.session.b
            public Bundle M() {
                if (d.this.f2362d == null) {
                    return null;
                }
                return new Bundle(d.this.f2362d);
            }

            @Override // android.support.v4.media.session.b
            public void O(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void P(Uri uri, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public boolean R(KeyEvent keyEvent) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void S(MediaDescriptionCompat mediaDescriptionCompat, int i5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public int V() {
                return d.this.f2371m;
            }

            @Override // android.support.v4.media.session.b
            public void Z(long j5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void b0(int i5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void d0(RatingCompat ratingCompat) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void e0(int i5, int i6, String str) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void f0(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void g0(MediaDescriptionCompat mediaDescriptionCompat) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public Bundle getExtras() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public MediaMetadataCompat getMetadata() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public String getPackageName() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public PlaybackStateCompat getPlaybackState() {
                d dVar = d.this;
                return MediaSessionCompat.c(dVar.f2365g, dVar.f2367i);
            }

            @Override // android.support.v4.media.session.b
            public int getRepeatMode() {
                return d.this.f2370l;
            }

            @Override // android.support.v4.media.session.b
            public String getTag() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void h0(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void m0() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void next() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public long p() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void pause() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void play() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void prepare() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void previous() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void q(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public boolean r() {
                return false;
            }

            @Override // android.support.v4.media.session.b
            public void s(Uri uri, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void seekTo(long j5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void setPlaybackSpeed(float f5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void setRepeatMode(int i5) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void stop() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public PendingIntent t() {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void t0(int i5, int i6, String str) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void w(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public List w0() {
                return null;
            }

            @Override // android.support.v4.media.session.b
            public void x(String str, Bundle bundle) {
                throw new AssertionError();
            }

            @Override // android.support.v4.media.session.b
            public void y(RatingCompat ratingCompat, Bundle bundle) {
                throw new AssertionError();
            }
        }

        d(Context context, String str, androidx.versionedparcelable.d dVar, Bundle bundle) {
            MediaSession g5 = g(context, str, bundle);
            this.f2359a = g5;
            this.f2360b = new Token(g5.getSessionToken(), new a(), dVar);
            this.f2362d = bundle;
            h(3);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public void a(b bVar, Handler handler) {
            synchronized (this.f2361c) {
                try {
                    this.f2372n = bVar;
                    this.f2359a.setCallback(bVar == null ? null : bVar.f2353b, handler);
                    if (bVar != null) {
                        bVar.D(this, handler);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public String b() {
            if (Build.VERSION.SDK_INT < 24) {
                return null;
            }
            try {
                return (String) this.f2359a.getClass().getMethod("getCallingPackage", null).invoke(this.f2359a, null);
            } catch (Exception e5) {
                Log.e("MediaSessionCompat", "Cannot execute MediaSession.getCallingPackage()", e5);
                return null;
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public void c(PendingIntent pendingIntent) {
            this.f2359a.setMediaButtonReceiver(pendingIntent);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public void d(androidx.media.a aVar) {
            synchronized (this.f2361c) {
                this.f2373o = aVar;
            }
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public b e() {
            b bVar;
            synchronized (this.f2361c) {
                bVar = this.f2372n;
            }
            return bVar;
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public androidx.media.a f() {
            androidx.media.a aVar;
            synchronized (this.f2361c) {
                aVar = this.f2373o;
            }
            return aVar;
        }

        public MediaSession g(Context context, String str, Bundle bundle) {
            return new MediaSession(context, str);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public PlaybackStateCompat getPlaybackState() {
            return this.f2365g;
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.c
        public Token getSessionToken() {
            return this.f2360b;
        }

        public void h(int i5) {
            this.f2359a.setFlags(i5 | 3);
        }
    }

    static class e extends d {
        e(Context context, String str, androidx.versionedparcelable.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }
    }

    static class f extends e {
        f(Context context, String str, androidx.versionedparcelable.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.d, android.support.v4.media.session.MediaSessionCompat.c
        public void d(androidx.media.a aVar) {
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.d, android.support.v4.media.session.MediaSessionCompat.c
        public final androidx.media.a f() {
            MediaSessionManager.RemoteUserInfo currentControllerInfo;
            currentControllerInfo = this.f2359a.getCurrentControllerInfo();
            return new androidx.media.a(currentControllerInfo);
        }
    }

    static class g extends f {
        g(Context context, String str, androidx.versionedparcelable.d dVar, Bundle bundle) {
            super(context, str, dVar, bundle);
        }

        @Override // android.support.v4.media.session.MediaSessionCompat.d
        public MediaSession g(Context context, String str, Bundle bundle) {
            return android.support.v4.media.session.d.a(context, str, bundle);
        }
    }

    public MediaSessionCompat(@NonNull Context context, @NonNull String str) {
        this(context, str, null, null);
    }

    public static void a(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        }
    }

    static PlaybackStateCompat c(PlaybackStateCompat playbackStateCompat, MediaMetadataCompat mediaMetadataCompat) {
        if (playbackStateCompat == null) {
            return playbackStateCompat;
        }
        long j5 = -1;
        if (playbackStateCompat.f() == -1) {
            return playbackStateCompat;
        }
        if (playbackStateCompat.g() != 3 && playbackStateCompat.g() != 4 && playbackStateCompat.g() != 5) {
            return playbackStateCompat;
        }
        if (playbackStateCompat.d() <= 0) {
            return playbackStateCompat;
        }
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long e5 = ((long) (playbackStateCompat.e() * (elapsedRealtime - r0))) + playbackStateCompat.f();
        if (mediaMetadataCompat != null && mediaMetadataCompat.a("android.media.metadata.DURATION")) {
            j5 = mediaMetadataCompat.c("android.media.metadata.DURATION");
        }
        return new PlaybackStateCompat.d(playbackStateCompat).b(playbackStateCompat.g(), (j5 < 0 || e5 <= j5) ? e5 < 0 ? 0L : e5 : j5, playbackStateCompat.e(), elapsedRealtime).a();
    }

    public static Bundle e(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        a(bundle);
        try {
            bundle.isEmpty();
            return bundle;
        } catch (BadParcelableException unused) {
            Log.e("MediaSessionCompat", "Could not unparcel the data.");
            return null;
        }
    }

    public Token b() {
        return this.f2340a.getSessionToken();
    }

    public void d(b bVar, Handler handler) {
        if (bVar == null) {
            this.f2340a.a(null, null);
            return;
        }
        c cVar = this.f2340a;
        if (handler == null) {
            handler = new Handler();
        }
        cVar.a(bVar, handler);
    }

    public MediaSessionCompat(@NonNull Context context, @NonNull String str, @Nullable ComponentName componentName, @Nullable PendingIntent pendingIntent) {
        this(context, str, componentName, pendingIntent, null);
    }

    public MediaSessionCompat(@NonNull Context context, @NonNull String str, @Nullable ComponentName componentName, @Nullable PendingIntent pendingIntent, @Nullable Bundle bundle) {
        this(context, str, componentName, pendingIntent, bundle, null);
    }

    public MediaSessionCompat(@NonNull Context context, @NonNull String str, @Nullable ComponentName componentName, @Nullable PendingIntent pendingIntent, @Nullable Bundle bundle, @Nullable androidx.versionedparcelable.d dVar) {
        this.f2342c = new ArrayList();
        if (context != null) {
            if (!TextUtils.isEmpty(str)) {
                if (componentName == null && (componentName = O.a.a(context)) == null) {
                    Log.w("MediaSessionCompat", "Couldn't find a unique registered media button receiver in the given context.");
                }
                if (componentName != null && pendingIntent == null) {
                    Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
                    intent.setComponent(componentName);
                    pendingIntent = PendingIntent.getBroadcast(context, 0, intent, Build.VERSION.SDK_INT >= 31 ? 33554432 : 0);
                }
                int i5 = Build.VERSION.SDK_INT;
                if (i5 >= 29) {
                    this.f2340a = new g(context, str, dVar, bundle);
                } else if (i5 >= 28) {
                    this.f2340a = new f(context, str, dVar, bundle);
                } else {
                    this.f2340a = new e(context, str, dVar, bundle);
                }
                d(new a(), new Handler(Looper.myLooper() != null ? Looper.myLooper() : Looper.getMainLooper()));
                this.f2340a.c(pendingIntent);
                this.f2341b = new MediaControllerCompat(context, this);
                if (f2339d == 0) {
                    f2339d = (int) (TypedValue.applyDimension(1, 320.0f, context.getResources().getDisplayMetrics()) + 0.5f);
                    return;
                }
                return;
            }
            throw new IllegalArgumentException("tag must not be null or empty");
        }
        throw new IllegalArgumentException("context must not be null");
    }

    private MediaSessionCompat(Context context, c cVar) {
        this.f2342c = new ArrayList();
        this.f2340a = cVar;
        this.f2341b = new MediaControllerCompat(context, this);
    }
}
