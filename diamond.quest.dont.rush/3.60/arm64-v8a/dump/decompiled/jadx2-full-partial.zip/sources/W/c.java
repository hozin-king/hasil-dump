package W;

import android.os.Bundle;
import androidx.lifecycle.AbstractC1108h;
import androidx.savedstate.Recreator;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: d, reason: collision with root package name */
    public static final a f1912d = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final d f1913a;

    /* renamed from: b, reason: collision with root package name */
    private final androidx.savedstate.a f1914b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f1915c;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final c a(d owner) {
            C7150s.j(owner, "owner");
            return new c(owner, null);
        }

        private a() {
        }
    }

    public /* synthetic */ c(d dVar, DefaultConstructorMarker defaultConstructorMarker) {
        this(dVar);
    }

    public static final c a(d dVar) {
        return f1912d.a(dVar);
    }

    public final androidx.savedstate.a b() {
        return this.f1914b;
    }

    public final void c() {
        AbstractC1108h lifecycle = this.f1913a.getLifecycle();
        if (lifecycle.getCurrentState() != AbstractC1108h.b.INITIALIZED) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        lifecycle.addObserver(new Recreator(this.f1913a));
        this.f1914b.e(lifecycle);
        this.f1915c = true;
    }

    public final void d(Bundle bundle) {
        if (!this.f1915c) {
            c();
        }
        AbstractC1108h lifecycle = this.f1913a.getLifecycle();
        if (!lifecycle.getCurrentState().b(AbstractC1108h.b.STARTED)) {
            this.f1914b.f(bundle);
            return;
        }
        throw new IllegalStateException(("performRestore cannot be called when owner is " + lifecycle.getCurrentState()).toString());
    }

    public final void e(Bundle outBundle) {
        C7150s.j(outBundle, "outBundle");
        this.f1914b.g(outBundle);
    }

    private c(d dVar) {
        this.f1913a = dVar;
        this.f1914b = new androidx.savedstate.a();
    }
}
