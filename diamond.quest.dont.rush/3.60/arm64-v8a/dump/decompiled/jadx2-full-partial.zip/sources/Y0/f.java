package Y0;

import V0.b;
import com.fasterxml.jackson.annotation.C;
import com.fasterxml.jackson.core.k;
import com.fasterxml.jackson.core.util.l;

/* loaded from: classes3.dex */
public abstract class f {

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f2005a;

        static {
            int[] iArr = new int[C.a.values().length];
            f2005a = iArr;
            try {
                iArr[C.a.EXISTING_PROPERTY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f2005a[C.a.EXTERNAL_PROPERTY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f2005a[C.a.PROPERTY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f2005a[C.a.WRAPPER_ARRAY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f2005a[C.a.WRAPPER_OBJECT.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public abstract f a(com.fasterxml.jackson.databind.d dVar);

    public abstract String b();

    public abstract C.a c();

    public V0.b d(Object obj, k kVar) {
        V0.b bVar = new V0.b(obj, kVar);
        int i5 = a.f2005a[c().ordinal()];
        if (i5 == 1) {
            bVar.f1898e = b.a.PAYLOAD_PROPERTY;
            bVar.f1897d = b();
            return bVar;
        }
        if (i5 == 2) {
            bVar.f1898e = b.a.PARENT_PROPERTY;
            bVar.f1897d = b();
            return bVar;
        }
        if (i5 == 3) {
            bVar.f1898e = b.a.METADATA_PROPERTY;
            bVar.f1897d = b();
            return bVar;
        }
        if (i5 == 4) {
            bVar.f1898e = b.a.WRAPPER_ARRAY;
            return bVar;
        }
        if (i5 != 5) {
            l.c();
            return bVar;
        }
        bVar.f1898e = b.a.WRAPPER_OBJECT;
        return bVar;
    }

    public V0.b e(Object obj, k kVar, Object obj2) {
        V0.b d5 = d(obj, kVar);
        d5.f1896c = obj2;
        return d5;
    }

    public V0.b f(Object obj, Class cls, k kVar) {
        V0.b d5 = d(obj, kVar);
        d5.f1895b = cls;
        return d5;
    }

    public abstract V0.b g(com.fasterxml.jackson.core.e eVar, V0.b bVar);

    public abstract V0.b h(com.fasterxml.jackson.core.e eVar, V0.b bVar);
}
