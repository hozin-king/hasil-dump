package K3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.collections.C7116i;
import kotlin.jvm.internal.AbstractC7142j;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class F implements Collection, V3.a {

    /* renamed from: b, reason: collision with root package name */
    private final short[] f1371b;

    private static final class a implements Iterator, V3.a {

        /* renamed from: b, reason: collision with root package name */
        private final short[] f1372b;

        /* renamed from: c, reason: collision with root package name */
        private int f1373c;

        public a(short[] array) {
            C7150s.j(array, "array");
            this.f1372b = array;
        }

        public short a() {
            int i5 = this.f1373c;
            short[] sArr = this.f1372b;
            if (i5 >= sArr.length) {
                throw new NoSuchElementException(String.valueOf(this.f1373c));
            }
            this.f1373c = i5 + 1;
            return E.b(sArr[i5]);
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f1373c < this.f1372b.length;
        }

        @Override // java.util.Iterator
        public /* bridge */ /* synthetic */ Object next() {
            return E.a(a());
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    private /* synthetic */ F(short[] sArr) {
        this.f1371b = sArr;
    }

    public static final /* synthetic */ F a(short[] sArr) {
        return new F(sArr);
    }

    public static short[] d(int i5) {
        return e(new short[i5]);
    }

    public static short[] e(short[] storage) {
        C7150s.j(storage, "storage");
        return storage;
    }

    public static boolean g(short[] sArr, short s5) {
        return C7116i.E(sArr, s5);
    }

    public static boolean h(short[] sArr, Collection elements) {
        C7150s.j(elements, "elements");
        Collection collection = elements;
        if (collection.isEmpty()) {
            return true;
        }
        for (Object obj : collection) {
            if (!(obj instanceof E) || !C7116i.E(sArr, ((E) obj).g())) {
                return false;
            }
        }
        return true;
    }

    public static boolean i(short[] sArr, Object obj) {
        return (obj instanceof F) && C7150s.e(sArr, ((F) obj).s());
    }

    public static final short j(short[] sArr, int i5) {
        return E.b(sArr[i5]);
    }

    public static int m(short[] sArr) {
        return sArr.length;
    }

    public static int n(short[] sArr) {
        return Arrays.hashCode(sArr);
    }

    public static boolean o(short[] sArr) {
        return sArr.length == 0;
    }

    public static Iterator p(short[] sArr) {
        return new a(sArr);
    }

    public static final void q(short[] sArr, int i5, short s5) {
        sArr[i5] = s5;
    }

    public static String r(short[] sArr) {
        return "UShortArray(storage=" + Arrays.toString(sArr) + ')';
    }

    @Override // java.util.Collection
    public /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public final /* bridge */ boolean contains(Object obj) {
        if (obj instanceof E) {
            return f(((E) obj).g());
        }
        return false;
    }

    @Override // java.util.Collection
    public boolean containsAll(Collection elements) {
        C7150s.j(elements, "elements");
        return h(this.f1371b, elements);
    }

    @Override // java.util.Collection
    public boolean equals(Object obj) {
        return i(this.f1371b, obj);
    }

    public boolean f(short s5) {
        return g(this.f1371b, s5);
    }

    @Override // java.util.Collection
    public int hashCode() {
        return n(this.f1371b);
    }

    @Override // java.util.Collection
    public boolean isEmpty() {
        return o(this.f1371b);
    }

    @Override // java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return p(this.f1371b);
    }

    @Override // java.util.Collection
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public int size() {
        return m(this.f1371b);
    }

    @Override // java.util.Collection
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* synthetic */ short[] s() {
        return this.f1371b;
    }

    @Override // java.util.Collection
    public Object[] toArray() {
        return AbstractC7142j.a(this);
    }

    public String toString() {
        return r(this.f1371b);
    }

    @Override // java.util.Collection
    public Object[] toArray(Object[] array) {
        C7150s.j(array, "array");
        return AbstractC7142j.b(this, array);
    }
}
