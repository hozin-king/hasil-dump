package K3;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes8.dex */
public abstract class l {

    public /* synthetic */ class a {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[n.values().length];
            try {
                iArr[n.f1384b.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[n.f1385c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[n.f1386d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public static InterfaceC0950j a(n mode, U3.a initializer) {
        C7150s.j(mode, "mode");
        C7150s.j(initializer, "initializer");
        int i5 = a.$EnumSwitchMapping$0[mode.ordinal()];
        int i6 = 2;
        if (i5 == 1) {
            DefaultConstructorMarker defaultConstructorMarker = null;
            return new u(initializer, defaultConstructorMarker, i6, defaultConstructorMarker);
        }
        if (i5 == 2) {
            return new t(initializer);
        }
        if (i5 == 3) {
            return new I(initializer);
        }
        throw new o();
    }

    public static InterfaceC0950j b(U3.a initializer) {
        C7150s.j(initializer, "initializer");
        DefaultConstructorMarker defaultConstructorMarker = null;
        return new u(initializer, defaultConstructorMarker, 2, defaultConstructorMarker);
    }
}
