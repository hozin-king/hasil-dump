package K3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.collections.C7116i;
import kotlin.jvm.internal.AbstractC7142j;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class C implements Collection, V3.a {

    /* renamed from: b, reason: collision with root package name */
    private final long[] f1365b;

    private static final class a implements Iterator, V3.a {

        /* renamed from: b, reason: collision with root package name */
        private final long[] f1366b;

        /* renamed from: c, reason: collision with root package name */
        private int f1367c;

        public a(long[] array) {
            C7150s.j(array, "array");
            this.f1366b = array;
        }

        public long a() {
            int i5 = this.f1367c;
            long[] jArr = this.f1366b;
            if (i5 >= jArr.length) {
                throw new NoSuchElementException(String.valueOf(this.f1367c));
            }
            this.f1367c = i5 + 1;
            return B.b(jArr[i5]);
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f1367c < this.f1366b.length;
        }

        @Override // java.util.Iterator
        public /* bridge */ /* synthetic */ Object next() {
            return B.a(a());
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    private /* synthetic */ C(long[] jArr) {
        this.f1365b = jArr;
    }

    public static final /* synthetic */ C a(long[] jArr) {
        return new C(jArr);
    }

    public static long[] d(int i5) {
        return e(new long[i5]);
    }

    public static long[] e(long[] storage) {
        C7150s.j(storage, "storage");
        return storage;
    }

    public static boolean g(long[] jArr, long j5) {
        return C7116i.C(jArr, j5);
    }

    public static boolean h(long[] jArr, Collection elements) {
        C7150s.j(elements, "elements");
        Collection collection = elements;
        if (collection.isEmpty()) {
            return true;
        }
        for (Object obj : collection) {
            if (!(obj instanceof B) || !C7116i.C(jArr, ((B) obj).g())) {
                return false;
            }
        }
        return true;
    }

    public static boolean i(long[] jArr, Object obj) {
        return (obj instanceof C) && C7150s.e(jArr, ((C) obj).s());
    }

    public static final long j(long[] jArr, int i5) {
        return B.b(jArr[i5]);
    }

    public static int m(long[] jArr) {
        return jArr.length;
    }

    public static int n(long[] jArr) {
        return Arrays.hashCode(jArr);
    }

    public static boolean o(long[] jArr) {
        return jArr.length == 0;
    }

    public static Iterator p(long[] jArr) {
        return new a(jArr);
    }

    public static final void q(long[] jArr, int i5, long j5) {
        jArr[i5] = j5;
    }

    public static String r(long[] jArr) {
        return "ULongArray(storage=" + Arrays.toString(jArr) + ')';
    }

    @Override // java.util.Collection
    public /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public final /* bridge */ boolean contains(Object obj) {
        if (obj instanceof B) {
            return f(((B) obj).g());
        }
        return false;
    }

    @Override // java.util.Collection
    public boolean containsAll(Collection elements) {
        C7150s.j(elements, "elements");
        return h(this.f1365b, elements);
    }

    @Override // java.util.Collection
    public boolean equals(Object obj) {
        return i(this.f1365b, obj);
    }

    public boolean f(long j5) {
        return g(this.f1365b, j5);
    }

    @Override // java.util.Collection
    public int hashCode() {
        return n(this.f1365b);
    }

    @Override // java.util.Collection
    public boolean isEmpty() {
        return o(this.f1365b);
    }

    @Override // java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return p(this.f1365b);
    }

    @Override // java.util.Collection
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public int size() {
        return m(this.f1365b);
    }

    @Override // java.util.Collection
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* synthetic */ long[] s() {
        return this.f1365b;
    }

    @Override // java.util.Collection
    public Object[] toArray() {
        return AbstractC7142j.a(this);
    }

    public String toString() {
        return r(this.f1365b);
    }

    @Override // java.util.Collection
    public Object[] toArray(Object[] array) {
        C7150s.j(array, "array");
        return AbstractC7142j.b(this, array);
    }
}
