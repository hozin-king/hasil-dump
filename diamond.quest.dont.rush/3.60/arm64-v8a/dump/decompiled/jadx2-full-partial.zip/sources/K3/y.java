package K3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.collections.C7116i;
import kotlin.jvm.internal.AbstractC7142j;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class y implements Collection, V3.a {

    /* renamed from: b, reason: collision with root package name */
    private final byte[] f1407b;

    private static final class a implements Iterator, V3.a {

        /* renamed from: b, reason: collision with root package name */
        private final byte[] f1408b;

        /* renamed from: c, reason: collision with root package name */
        private int f1409c;

        public a(byte[] array) {
            C7150s.j(array, "array");
            this.f1408b = array;
        }

        public byte a() {
            int i5 = this.f1409c;
            byte[] bArr = this.f1408b;
            if (i5 >= bArr.length) {
                throw new NoSuchElementException(String.valueOf(this.f1409c));
            }
            this.f1409c = i5 + 1;
            return x.b(bArr[i5]);
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f1409c < this.f1408b.length;
        }

        @Override // java.util.Iterator
        public /* bridge */ /* synthetic */ Object next() {
            return x.a(a());
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    private /* synthetic */ y(byte[] bArr) {
        this.f1407b = bArr;
    }

    public static final /* synthetic */ y a(byte[] bArr) {
        return new y(bArr);
    }

    public static byte[] d(int i5) {
        return e(new byte[i5]);
    }

    public static byte[] e(byte[] storage) {
        C7150s.j(storage, "storage");
        return storage;
    }

    public static boolean g(byte[] bArr, byte b5) {
        return C7116i.z(bArr, b5);
    }

    public static boolean h(byte[] bArr, Collection elements) {
        C7150s.j(elements, "elements");
        Collection collection = elements;
        if (collection.isEmpty()) {
            return true;
        }
        for (Object obj : collection) {
            if (!(obj instanceof x) || !C7116i.z(bArr, ((x) obj).g())) {
                return false;
            }
        }
        return true;
    }

    public static boolean i(byte[] bArr, Object obj) {
        return (obj instanceof y) && C7150s.e(bArr, ((y) obj).s());
    }

    public static final byte j(byte[] bArr, int i5) {
        return x.b(bArr[i5]);
    }

    public static int m(byte[] bArr) {
        return bArr.length;
    }

    public static int n(byte[] bArr) {
        return Arrays.hashCode(bArr);
    }

    public static boolean o(byte[] bArr) {
        return bArr.length == 0;
    }

    public static Iterator p(byte[] bArr) {
        return new a(bArr);
    }

    public static final void q(byte[] bArr, int i5, byte b5) {
        bArr[i5] = b5;
    }

    public static String r(byte[] bArr) {
        return "UByteArray(storage=" + Arrays.toString(bArr) + ')';
    }

    @Override // java.util.Collection
    public /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public final /* bridge */ boolean contains(Object obj) {
        if (obj instanceof x) {
            return f(((x) obj).g());
        }
        return false;
    }

    @Override // java.util.Collection
    public boolean containsAll(Collection elements) {
        C7150s.j(elements, "elements");
        return h(this.f1407b, elements);
    }

    @Override // java.util.Collection
    public boolean equals(Object obj) {
        return i(this.f1407b, obj);
    }

    public boolean f(byte b5) {
        return g(this.f1407b, b5);
    }

    @Override // java.util.Collection
    public int hashCode() {
        return n(this.f1407b);
    }

    @Override // java.util.Collection
    public boolean isEmpty() {
        return o(this.f1407b);
    }

    @Override // java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return p(this.f1407b);
    }

    @Override // java.util.Collection
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public int size() {
        return m(this.f1407b);
    }

    @Override // java.util.Collection
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* synthetic */ byte[] s() {
        return this.f1407b;
    }

    @Override // java.util.Collection
    public Object[] toArray() {
        return AbstractC7142j.a(this);
    }

    public String toString() {
        return r(this.f1407b);
    }

    @Override // java.util.Collection
    public Object[] toArray(Object[] array) {
        C7150s.j(array, "array");
        return AbstractC7142j.b(this, array);
    }
}
