package K3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.collections.C7116i;
import kotlin.jvm.internal.AbstractC7142j;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class A implements Collection, V3.a {

    /* renamed from: b, reason: collision with root package name */
    private final int[] f1360b;

    private static final class a implements Iterator, V3.a {

        /* renamed from: b, reason: collision with root package name */
        private final int[] f1361b;

        /* renamed from: c, reason: collision with root package name */
        private int f1362c;

        public a(int[] array) {
            C7150s.j(array, "array");
            this.f1361b = array;
        }

        public int a() {
            int i5 = this.f1362c;
            int[] iArr = this.f1361b;
            if (i5 >= iArr.length) {
                throw new NoSuchElementException(String.valueOf(this.f1362c));
            }
            this.f1362c = i5 + 1;
            return z.b(iArr[i5]);
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f1362c < this.f1361b.length;
        }

        @Override // java.util.Iterator
        public /* bridge */ /* synthetic */ Object next() {
            return z.a(a());
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    private /* synthetic */ A(int[] iArr) {
        this.f1360b = iArr;
    }

    public static final /* synthetic */ A a(int[] iArr) {
        return new A(iArr);
    }

    public static int[] d(int i5) {
        return e(new int[i5]);
    }

    public static int[] e(int[] storage) {
        C7150s.j(storage, "storage");
        return storage;
    }

    public static boolean g(int[] iArr, int i5) {
        return C7116i.B(iArr, i5);
    }

    public static boolean h(int[] iArr, Collection elements) {
        C7150s.j(elements, "elements");
        Collection collection = elements;
        if (collection.isEmpty()) {
            return true;
        }
        for (Object obj : collection) {
            if (!(obj instanceof z) || !C7116i.B(iArr, ((z) obj).g())) {
                return false;
            }
        }
        return true;
    }

    public static boolean i(int[] iArr, Object obj) {
        return (obj instanceof A) && C7150s.e(iArr, ((A) obj).s());
    }

    public static final int j(int[] iArr, int i5) {
        return z.b(iArr[i5]);
    }

    public static int m(int[] iArr) {
        return iArr.length;
    }

    public static int n(int[] iArr) {
        return Arrays.hashCode(iArr);
    }

    public static boolean o(int[] iArr) {
        return iArr.length == 0;
    }

    public static Iterator p(int[] iArr) {
        return new a(iArr);
    }

    public static final void q(int[] iArr, int i5, int i6) {
        iArr[i5] = i6;
    }

    public static String r(int[] iArr) {
        return "UIntArray(storage=" + Arrays.toString(iArr) + ')';
    }

    @Override // java.util.Collection
    public /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public final /* bridge */ boolean contains(Object obj) {
        if (obj instanceof z) {
            return f(((z) obj).g());
        }
        return false;
    }

    @Override // java.util.Collection
    public boolean containsAll(Collection elements) {
        C7150s.j(elements, "elements");
        return h(this.f1360b, elements);
    }

    @Override // java.util.Collection
    public boolean equals(Object obj) {
        return i(this.f1360b, obj);
    }

    public boolean f(int i5) {
        return g(this.f1360b, i5);
    }

    @Override // java.util.Collection
    public int hashCode() {
        return n(this.f1360b);
    }

    @Override // java.util.Collection
    public boolean isEmpty() {
        return o(this.f1360b);
    }

    @Override // java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return p(this.f1360b);
    }

    @Override // java.util.Collection
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public int size() {
        return m(this.f1360b);
    }

    @Override // java.util.Collection
    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Collection
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* synthetic */ int[] s() {
        return this.f1360b;
    }

    @Override // java.util.Collection
    public Object[] toArray() {
        return AbstractC7142j.a(this);
    }

    public String toString() {
        return r(this.f1360b);
    }

    @Override // java.util.Collection
    public Object[] toArray(Object[] array) {
        C7150s.j(array, "array");
        return AbstractC7142j.b(this, array);
    }
}
