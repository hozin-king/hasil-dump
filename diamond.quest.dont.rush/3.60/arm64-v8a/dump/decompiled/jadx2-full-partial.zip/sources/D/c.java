package D;

import D.f;
import K3.q;
import U3.l;
import com.ironsource.b9;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.collections.C7116i;
import kotlin.collections.C7123p;
import kotlin.collections.M;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.t;

/* loaded from: classes.dex */
public final class c extends f {

    /* renamed from: a, reason: collision with root package name */
    private final Map f462a;

    /* renamed from: b, reason: collision with root package name */
    private final b f463b;

    static final class a extends t implements l {

        /* renamed from: g, reason: collision with root package name */
        public static final a f464g = new a();

        a() {
            super(1);
        }

        @Override // U3.l
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final CharSequence invoke(Map.Entry entry) {
            C7150s.j(entry, "entry");
            Object value = entry.getValue();
            return "  " + ((f.a) entry.getKey()).a() + " = " + (value instanceof byte[] ? C7116i.b0((byte[]) value, ", ", b9.i.f26268d, b9.i.f26270e, 0, null, null, 56, null) : String.valueOf(entry.getValue()));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public c() {
        this(null, false, 3, 0 == true ? 1 : 0);
    }

    @Override // D.f
    public Map a() {
        q qVar;
        Set<Map.Entry> entrySet = this.f462a.entrySet();
        LinkedHashMap linkedHashMap = new LinkedHashMap(Y3.l.d(M.f(C7123p.v(entrySet, 10)), 16));
        for (Map.Entry entry : entrySet) {
            Object value = entry.getValue();
            if (value instanceof byte[]) {
                Object key = entry.getKey();
                byte[] bArr = (byte[]) value;
                byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
                C7150s.i(copyOf, "copyOf(this, size)");
                qVar = new q(key, copyOf);
            } else {
                qVar = new q(entry.getKey(), entry.getValue());
            }
            linkedHashMap.put(qVar.c(), qVar.d());
        }
        return D.a.b(linkedHashMap);
    }

    @Override // D.f
    public Object b(f.a key) {
        C7150s.j(key, "key");
        Object obj = this.f462a.get(key);
        if (!(obj instanceof byte[])) {
            return obj;
        }
        byte[] bArr = (byte[]) obj;
        byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
        C7150s.i(copyOf, "copyOf(this, size)");
        return copyOf;
    }

    public final void e() {
        if (this.f463b.a()) {
            throw new IllegalStateException("Do mutate preferences once returned to DataStore.");
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0066 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:? A[LOOP:0: B:15:0x002e->B:30:?, LOOP_END, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof D.c
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            D.c r6 = (D.c) r6
            java.util.Map r0 = r6.f462a
            java.util.Map r2 = r5.f462a
            r3 = 1
            if (r0 != r2) goto L10
            return r3
        L10:
            int r0 = r0.size()
            java.util.Map r2 = r5.f462a
            int r2 = r2.size()
            if (r0 == r2) goto L1d
            return r1
        L1d:
            java.util.Map r6 = r6.f462a
            boolean r0 = r6.isEmpty()
            if (r0 == 0) goto L26
            return r3
        L26:
            java.util.Set r6 = r6.entrySet()
            java.util.Iterator r6 = r6.iterator()
        L2e:
            boolean r0 = r6.hasNext()
            if (r0 == 0) goto L67
            java.lang.Object r0 = r6.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.util.Map r2 = r5.f462a
            java.lang.Object r4 = r0.getKey()
            java.lang.Object r2 = r2.get(r4)
            if (r2 == 0) goto L63
            java.lang.Object r0 = r0.getValue()
            boolean r4 = r0 instanceof byte[]
            if (r4 == 0) goto L5e
            boolean r4 = r2 instanceof byte[]
            if (r4 == 0) goto L63
            byte[] r0 = (byte[]) r0
            byte[] r2 = (byte[]) r2
            boolean r0 = java.util.Arrays.equals(r0, r2)
            if (r0 == 0) goto L63
            r0 = r3
            goto L64
        L5e:
            boolean r0 = kotlin.jvm.internal.C7150s.e(r0, r2)
            goto L64
        L63:
            r0 = r1
        L64:
            if (r0 != 0) goto L2e
            return r1
        L67:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: D.c.equals(java.lang.Object):boolean");
    }

    public final void f() {
        e();
        this.f462a.clear();
    }

    public final void g() {
        this.f463b.b(true);
    }

    public final void h(f.b... pairs) {
        C7150s.j(pairs, "pairs");
        e();
        for (f.b bVar : pairs) {
            k(bVar.a(), bVar.b());
        }
    }

    public int hashCode() {
        Iterator it = this.f462a.entrySet().iterator();
        int i5 = 0;
        while (it.hasNext()) {
            Object value = ((Map.Entry) it.next()).getValue();
            i5 += value instanceof byte[] ? Arrays.hashCode((byte[]) value) : value.hashCode();
        }
        return i5;
    }

    public final Object i(f.a key) {
        C7150s.j(key, "key");
        e();
        return this.f462a.remove(key);
    }

    public final void j(f.a key, Object obj) {
        C7150s.j(key, "key");
        k(key, obj);
    }

    public final void k(f.a key, Object obj) {
        C7150s.j(key, "key");
        e();
        if (obj == null) {
            i(key);
            return;
        }
        if (obj instanceof Set) {
            this.f462a.put(key, D.a.a((Set) obj));
            return;
        }
        if (!(obj instanceof byte[])) {
            this.f462a.put(key, obj);
            return;
        }
        Map map = this.f462a;
        byte[] bArr = (byte[]) obj;
        byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
        C7150s.i(copyOf, "copyOf(this, size)");
        map.put(key, copyOf);
    }

    public String toString() {
        return C7123p.n0(this.f462a.entrySet(), ",\n", "{\n", "\n}", 0, null, a.f464g, 24, null);
    }

    public /* synthetic */ c(Map map, boolean z4, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this((i5 & 1) != 0 ? new LinkedHashMap() : map, (i5 & 2) != 0 ? true : z4);
    }

    public c(Map<f.a, Object> preferencesMap, boolean z4) {
        C7150s.j(preferencesMap, "preferencesMap");
        this.f462a = preferencesMap;
        this.f463b = new b(z4);
    }
}
