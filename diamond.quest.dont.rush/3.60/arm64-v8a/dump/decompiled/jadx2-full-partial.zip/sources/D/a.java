package D;

import j$.util.DesugarCollections;
import java.util.Map;
import java.util.Set;
import kotlin.collections.C7123p;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class a {
    public static final Set a(Set set) {
        C7150s.j(set, "set");
        Set unmodifiableSet = DesugarCollections.unmodifiableSet(C7123p.Q0(set));
        C7150s.i(unmodifiableSet, "unmodifiableSet(set.toSet())");
        return unmodifiableSet;
    }

    public static final Map b(Map map) {
        C7150s.j(map, "map");
        Map unmodifiableMap = DesugarCollections.unmodifiableMap(map);
        C7150s.i(unmodifiableMap, "unmodifiableMap(map)");
        return unmodifiableMap;
    }
}
