package D;

import K3.H;
import K3.s;
import U3.p;
import androidx.datastore.core.InterfaceC1064j;
import kotlin.coroutines.jvm.internal.l;

/* loaded from: classes.dex */
public abstract class i {

    static final class a extends l implements p {

        /* renamed from: l, reason: collision with root package name */
        int f474l;

        /* renamed from: m, reason: collision with root package name */
        /* synthetic */ Object f475m;

        /* renamed from: n, reason: collision with root package name */
        final /* synthetic */ p f476n;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        a(p pVar, O3.d dVar) {
            super(2, dVar);
            this.f476n = pVar;
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final O3.d create(Object obj, O3.d dVar) {
            a aVar = new a(this.f476n, dVar);
            aVar.f475m = obj;
            return aVar;
        }

        @Override // U3.p
        /* renamed from: e, reason: merged with bridge method [inline-methods] */
        public final Object invoke(f fVar, O3.d dVar) {
            return ((a) create(fVar, dVar)).invokeSuspend(H.f1374a);
        }

        @Override // kotlin.coroutines.jvm.internal.a
        public final Object invokeSuspend(Object obj) {
            Object f5 = kotlin.coroutines.intrinsics.b.f();
            int i5 = this.f474l;
            if (i5 != 0) {
                if (i5 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                c cVar = (c) this.f475m;
                s.b(obj);
                return cVar;
            }
            s.b(obj);
            c c5 = ((f) this.f475m).c();
            p pVar = this.f476n;
            this.f475m = c5;
            this.f474l = 1;
            return pVar.invoke(c5, this) == f5 ? f5 : c5;
        }
    }

    public static final Object a(InterfaceC1064j interfaceC1064j, p pVar, O3.d dVar) {
        return interfaceC1064j.a(new a(pVar, null), dVar);
    }
}
