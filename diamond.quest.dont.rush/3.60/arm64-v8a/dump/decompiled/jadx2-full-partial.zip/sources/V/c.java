package V;

import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.room.i;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class c {
    private c() {
    }

    public static void a(androidx.sqlite.db.b bVar) {
        int i5;
        ArrayList arrayList = new ArrayList();
        Cursor g02 = bVar.g0("SELECT name FROM sqlite_master WHERE type = 'trigger'");
        while (true) {
            try {
                i5 = 0;
                if (!g02.moveToNext()) {
                    break;
                } else {
                    arrayList.add(g02.getString(0));
                }
            } catch (Throwable th) {
                g02.close();
                throw th;
            }
        }
        g02.close();
        int size = arrayList.size();
        while (i5 < size) {
            Object obj = arrayList.get(i5);
            i5++;
            String str = (String) obj;
            if (str.startsWith("room_fts_content_sync_")) {
                bVar.execSQL("DROP TRIGGER IF EXISTS " + str);
            }
        }
    }

    public static Cursor b(i iVar, androidx.sqlite.db.e eVar, boolean z4, CancellationSignal cancellationSignal) {
        Cursor q5 = iVar.q(eVar, cancellationSignal);
        if (!z4 || !(q5 instanceof AbstractWindowedCursor)) {
            return q5;
        }
        AbstractWindowedCursor abstractWindowedCursor = (AbstractWindowedCursor) q5;
        int count = abstractWindowedCursor.getCount();
        return (abstractWindowedCursor.hasWindow() ? abstractWindowedCursor.getWindow().getNumRows() : count) < count ? b.a(abstractWindowedCursor) : q5;
    }

    public static int c(File file) {
        Throwable th;
        ByteBuffer allocate;
        FileChannel channel;
        FileChannel fileChannel = null;
        try {
            allocate = ByteBuffer.allocate(4);
            channel = new FileInputStream(file).getChannel();
        } catch (Throwable th2) {
            th = th2;
        }
        try {
            channel.tryLock(60L, 4L, true);
            channel.position(60L);
            if (channel.read(allocate) != 4) {
                throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
            }
            allocate.rewind();
            int i5 = allocate.getInt();
            channel.close();
            return i5;
        } catch (Throwable th3) {
            th = th3;
            fileChannel = channel;
            if (fileChannel == null) {
                throw th;
            }
            fileChannel.close();
            throw th;
        }
    }
}
