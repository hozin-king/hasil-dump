package H3;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes8.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private static int[] f1005a;

    /* renamed from: b, reason: collision with root package name */
    private static int f1006b;

    /* renamed from: c, reason: collision with root package name */
    private static int f1007c;

    /* renamed from: H3.a$a, reason: collision with other inner class name */
    public static class C0041a {

        /* renamed from: a, reason: collision with root package name */
        public boolean f1008a = true;
    }

    private a() {
    }

    private static boolean a(int i5, boolean z4) {
        if (i5 < 55296 || i5 > 57343) {
            return true;
        }
        if (!z4) {
            return false;
        }
        throw new b("Lone surrogate U+" + Integer.toHexString(i5).toUpperCase() + " is not a scalar value");
    }

    private static char[] b(int i5, int i6) {
        return Character.toChars(((i5 >> i6) & 63) | 128);
    }

    public static String c(String str, C0041a c0041a) {
        boolean z4 = c0041a.f1008a;
        int[] i5 = i(str);
        f1005a = i5;
        f1006b = i5.length;
        f1007c = 0;
        ArrayList arrayList = new ArrayList();
        while (true) {
            int d5 = d(z4);
            if (d5 == -1) {
                return j(g(arrayList));
            }
            arrayList.add(Integer.valueOf(d5));
        }
    }

    private static int d(boolean z4) {
        int i5 = f1007c;
        int i6 = f1006b;
        if (i5 > i6) {
            throw new b("Invalid byte index");
        }
        if (i5 == i6) {
            return -1;
        }
        int i7 = f1005a[i5];
        int i8 = i7 & 255;
        f1007c = i5 + 1;
        if ((i7 & 128) == 0) {
            return i8;
        }
        if ((i7 & 224) == 192) {
            int h5 = h() | ((i7 & 31) << 6);
            if (h5 >= 128) {
                return h5;
            }
            throw new b("Invalid continuation byte");
        }
        if ((i7 & 240) == 224) {
            int h6 = (h() << 6) | ((i7 & 15) << 12) | h();
            if (h6 < 2048) {
                throw new b("Invalid continuation byte");
            }
            if (a(h6, z4)) {
                return h6;
            }
            return 65533;
        }
        if ((i7 & 248) == 240) {
            int h7 = h();
            int i9 = h7 << 12;
            int h8 = i9 | ((i7 & 15) << 18) | (h() << 6) | h();
            if (h8 >= 65536 && h8 <= 1114111) {
                return h8;
            }
        }
        throw new b("Invalid continuation byte");
    }

    public static String e(String str, C0041a c0041a) {
        boolean z4 = c0041a.f1008a;
        int[] i5 = i(str);
        int length = i5.length;
        StringBuilder sb = new StringBuilder();
        int i6 = -1;
        while (true) {
            i6++;
            if (i6 >= length) {
                return sb.toString();
            }
            sb.append(f(i5[i6], z4));
        }
    }

    private static String f(int i5, boolean z4) {
        StringBuilder sb = new StringBuilder();
        if ((i5 & (-128)) == 0) {
            sb.append(Character.toChars(i5));
            return sb.toString();
        }
        if ((i5 & (-2048)) == 0) {
            sb.append(Character.toChars(((i5 >> 6) & 31) | 192));
        } else if (((-65536) & i5) == 0) {
            if (!a(i5, z4)) {
                i5 = 65533;
            }
            sb.append(Character.toChars(((i5 >> 12) & 15) | 224));
            sb.append(b(i5, 6));
        } else if (((-2097152) & i5) == 0) {
            sb.append(Character.toChars(((i5 >> 18) & 7) | 240));
            sb.append(b(i5, 12));
            sb.append(b(i5, 6));
        }
        sb.append(Character.toChars((i5 & 63) | 128));
        return sb.toString();
    }

    private static int[] g(List list) {
        int size = list.size();
        int[] iArr = new int[size];
        for (int i5 = 0; i5 < size; i5++) {
            iArr[i5] = ((Integer) list.get(i5)).intValue();
        }
        return iArr;
    }

    private static int h() {
        int i5 = f1007c;
        if (i5 >= f1006b) {
            throw new b("Invalid byte index");
        }
        int i6 = f1005a[i5];
        f1007c = i5 + 1;
        if ((i6 & 192) == 128) {
            return i6 & 63;
        }
        throw new b("Invalid continuation byte");
    }

    private static int[] i(String str) {
        int length = str.length();
        int i5 = 0;
        int[] iArr = new int[str.codePointCount(0, length)];
        int i6 = 0;
        while (i5 < length) {
            int codePointAt = str.codePointAt(i5);
            iArr[i6] = codePointAt;
            i5 += Character.charCount(codePointAt);
            i6++;
        }
        return iArr;
    }

    private static String j(int[] iArr) {
        StringBuilder sb = new StringBuilder();
        for (int i5 : iArr) {
            sb.appendCodePoint(i5);
        }
        return sb.toString();
    }
}
