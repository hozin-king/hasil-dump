package H3;

import java.io.IOException;

/* loaded from: classes8.dex */
public class b extends IOException {
    public b() {
    }

    public b(String str) {
        super(str);
    }

    public b(String str, Throwable th) {
        super(str, th);
    }

    public b(Throwable th) {
        super(th);
    }
}
