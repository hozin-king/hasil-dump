package I;

import android.view.animation.Interpolator;

/* loaded from: classes.dex */
abstract class b implements Interpolator {

    /* renamed from: a, reason: collision with root package name */
    private final float[] f1010a;

    /* renamed from: b, reason: collision with root package name */
    private final float f1011b;

    protected b(float[] fArr) {
        this.f1010a = fArr;
        this.f1011b = 1.0f / (fArr.length - 1);
    }

    @Override // android.animation.TimeInterpolator
    public float getInterpolation(float f5) {
        if (f5 >= 1.0f) {
            return 1.0f;
        }
        if (f5 <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f1010a;
        int min = Math.min((int) ((fArr.length - 1) * f5), fArr.length - 2);
        float f6 = this.f1011b;
        float f7 = (f5 - (min * f6)) / f6;
        float[] fArr2 = this.f1010a;
        float f8 = fArr2[min];
        return f8 + (f7 * (fArr2[min + 1] - f8));
    }
}
