package a4;

/* loaded from: classes8.dex */
public interface j {
    long a();
}
