package a4;

import a4.k;

/* loaded from: classes8.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public static final i f2261a = new i();

    /* renamed from: b, reason: collision with root package name */
    private static final long f2262b = System.nanoTime();

    private i() {
    }

    private final long d() {
        return System.nanoTime() - f2262b;
    }

    public final long a(long j5, long j6) {
        return h.d(j5, j6, e.f2251c);
    }

    public final long b(long j5) {
        return h.b(d(), j5, e.f2251c);
    }

    public long c() {
        return k.a.e(d());
    }

    public String toString() {
        return "TimeSource(System.nanoTime())";
    }
}
