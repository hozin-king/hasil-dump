package a4;

import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public interface a extends j, Comparable {

    /* renamed from: a4.a$a, reason: collision with other inner class name */
    public static final class C0095a {
        public static int a(a aVar, a other) {
            C7150s.j(other, "other");
            return b.i(aVar.d(other), b.f2244c.c());
        }
    }

    long d(a aVar);
}
