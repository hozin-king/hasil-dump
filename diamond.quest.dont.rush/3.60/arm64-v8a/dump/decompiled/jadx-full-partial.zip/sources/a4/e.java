package a4;

import java.util.concurrent.TimeUnit;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes8.dex */
public final class e {

    /* renamed from: c, reason: collision with root package name */
    public static final e f2251c = new e("NANOSECONDS", 0, TimeUnit.NANOSECONDS);

    /* renamed from: d, reason: collision with root package name */
    public static final e f2252d = new e("MICROSECONDS", 1, TimeUnit.MICROSECONDS);

    /* renamed from: e, reason: collision with root package name */
    public static final e f2253e = new e("MILLISECONDS", 2, TimeUnit.MILLISECONDS);

    /* renamed from: f, reason: collision with root package name */
    public static final e f2254f = new e("SECONDS", 3, TimeUnit.SECONDS);

    /* renamed from: g, reason: collision with root package name */
    public static final e f2255g = new e("MINUTES", 4, TimeUnit.MINUTES);

    /* renamed from: h, reason: collision with root package name */
    public static final e f2256h = new e("HOURS", 5, TimeUnit.HOURS);

    /* renamed from: i, reason: collision with root package name */
    public static final e f2257i = new e("DAYS", 6, TimeUnit.DAYS);

    /* renamed from: j, reason: collision with root package name */
    private static final /* synthetic */ e[] f2258j;

    /* renamed from: k, reason: collision with root package name */
    private static final /* synthetic */ P3.a f2259k;

    /* renamed from: b, reason: collision with root package name */
    private final TimeUnit f2260b;

    static {
        e[] a5 = a();
        f2258j = a5;
        f2259k = P3.b.a(a5);
    }

    private e(String str, int i5, TimeUnit timeUnit) {
        this.f2260b = timeUnit;
    }

    private static final /* synthetic */ e[] a() {
        return new e[]{f2251c, f2252d, f2253e, f2254f, f2255g, f2256h, f2257i};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) f2258j.clone();
    }

    public final TimeUnit b() {
        return this.f2260b;
    }
}
