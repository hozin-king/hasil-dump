package a4;

import a4.a;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public static final k f2263a = new k();

    private k() {
    }

    public long a() {
        return i.f2261a.c();
    }

    public String toString() {
        return i.f2261a.toString();
    }

    public static final class a implements a4.a {

        /* renamed from: b, reason: collision with root package name */
        private final long f2264b;

        private /* synthetic */ a(long j5) {
            this.f2264b = j5;
        }

        public static final /* synthetic */ a b(long j5) {
            return new a(j5);
        }

        public static long f(long j5) {
            return i.f2261a.b(j5);
        }

        public static boolean g(long j5, Object obj) {
            return (obj instanceof a) && j5 == ((a) obj).l();
        }

        public static int h(long j5) {
            return androidx.privacysandbox.ads.adservices.topics.j.a(j5);
        }

        public static final long i(long j5, long j6) {
            return i.f2261a.a(j5, j6);
        }

        public static long j(long j5, a4.a other) {
            C7150s.j(other, "other");
            if (other instanceof a) {
                return i(j5, ((a) other).l());
            }
            throw new IllegalArgumentException("Subtracting or comparing time marks from different time sources is not possible: " + ((Object) k(j5)) + " and " + other);
        }

        public static String k(long j5) {
            return "ValueTimeMark(reading=" + j5 + ')';
        }

        @Override // a4.j
        public long a() {
            return f(this.f2264b);
        }

        @Override // java.lang.Comparable
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public int compareTo(a4.a aVar) {
            return a.C0095a.a(this, aVar);
        }

        @Override // a4.a
        public long d(a4.a other) {
            C7150s.j(other, "other");
            return j(this.f2264b, other);
        }

        public boolean equals(Object obj) {
            return g(this.f2264b, obj);
        }

        public int hashCode() {
            return h(this.f2264b);
        }

        public final /* synthetic */ long l() {
            return this.f2264b;
        }

        public String toString() {
            return k(this.f2264b);
        }

        public static long e(long j5) {
            return j5;
        }
    }
}
