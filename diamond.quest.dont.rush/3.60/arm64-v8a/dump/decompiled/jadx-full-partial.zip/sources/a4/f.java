package a4;

import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
abstract class f {
    public static final double a(double d5, e sourceUnit, e targetUnit) {
        C7150s.j(sourceUnit, "sourceUnit");
        C7150s.j(targetUnit, "targetUnit");
        long convert = targetUnit.b().convert(1L, sourceUnit.b());
        return convert > 0 ? d5 * convert : d5 / sourceUnit.b().convert(1L, targetUnit.b());
    }

    public static final long b(long j5, e sourceUnit, e targetUnit) {
        C7150s.j(sourceUnit, "sourceUnit");
        C7150s.j(targetUnit, "targetUnit");
        return targetUnit.b().convert(j5, sourceUnit.b());
    }

    public static final long c(long j5, e sourceUnit, e targetUnit) {
        C7150s.j(sourceUnit, "sourceUnit");
        C7150s.j(targetUnit, "targetUnit");
        return targetUnit.b().convert(j5, sourceUnit.b());
    }
}
