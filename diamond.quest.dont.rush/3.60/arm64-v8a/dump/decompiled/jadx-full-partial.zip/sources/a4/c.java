package a4;

/* loaded from: classes8.dex */
public abstract class c {

    /* renamed from: a, reason: collision with root package name */
    private static final boolean f2249a = false;

    /* renamed from: b, reason: collision with root package name */
    private static final ThreadLocal[] f2250b;

    static {
        ThreadLocal[] threadLocalArr = new ThreadLocal[4];
        for (int i5 = 0; i5 < 4; i5++) {
            threadLocalArr[i5] = new ThreadLocal();
        }
        f2250b = threadLocalArr;
    }

    public static final boolean a() {
        return f2249a;
    }
}
