package a4;

import com.fyber.inneractive.sdk.external.InneractiveMediationDefs;
import io.bidmachine.media3.exoplayer.upstream.CmcdData;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
abstract class g extends f {
    public static final e d(char c5, boolean z4) {
        if (!z4) {
            if (c5 == 'D') {
                return e.f2257i;
            }
            throw new IllegalArgumentException("Invalid or unsupported duration ISO non-time unit: " + c5);
        }
        if (c5 == 'H') {
            return e.f2256h;
        }
        if (c5 == 'M') {
            return e.f2255g;
        }
        if (c5 == 'S') {
            return e.f2254f;
        }
        throw new IllegalArgumentException("Invalid duration ISO time unit: " + c5);
    }

    public static final e e(String shortName) {
        C7150s.j(shortName, "shortName");
        int hashCode = shortName.hashCode();
        if (hashCode != 100) {
            if (hashCode != 104) {
                if (hashCode != 109) {
                    if (hashCode != 115) {
                        if (hashCode != 3494) {
                            if (hashCode != 3525) {
                                if (hashCode == 3742 && shortName.equals("us")) {
                                    return e.f2252d;
                                }
                            } else if (shortName.equals("ns")) {
                                return e.f2251c;
                            }
                        } else if (shortName.equals("ms")) {
                            return e.f2253e;
                        }
                    } else if (shortName.equals(CmcdData.Factory.STREAMING_FORMAT_SS)) {
                        return e.f2254f;
                    }
                } else if (shortName.equals(InneractiveMediationDefs.GENDER_MALE)) {
                    return e.f2255g;
                }
            } else if (shortName.equals("h")) {
                return e.f2256h;
            }
        } else if (shortName.equals("d")) {
            return e.f2257i;
        }
        throw new IllegalArgumentException("Unknown duration unit short name: " + shortName);
    }
}
