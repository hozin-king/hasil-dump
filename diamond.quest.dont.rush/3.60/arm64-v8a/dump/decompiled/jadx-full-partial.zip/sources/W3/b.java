package W3;

/* loaded from: classes8.dex */
abstract class b {
}
