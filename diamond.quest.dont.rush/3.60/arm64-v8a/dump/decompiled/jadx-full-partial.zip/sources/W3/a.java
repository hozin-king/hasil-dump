package W3;

/* loaded from: classes8.dex */
public final class a extends c {
    private a() {
    }
}
