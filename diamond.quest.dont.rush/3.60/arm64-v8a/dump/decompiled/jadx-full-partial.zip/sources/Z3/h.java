package Z3;

/* loaded from: classes8.dex */
public interface h extends k, j {

    public interface a extends g, U3.l {
    }

    /* renamed from: getSetter */
    a mo567getSetter();

    void set(Object obj);
}
