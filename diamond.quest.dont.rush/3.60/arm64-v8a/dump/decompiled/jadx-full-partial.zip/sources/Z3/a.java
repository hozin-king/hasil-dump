package Z3;

import java.util.List;

/* loaded from: classes8.dex */
public interface a {
    List getAnnotations();
}
