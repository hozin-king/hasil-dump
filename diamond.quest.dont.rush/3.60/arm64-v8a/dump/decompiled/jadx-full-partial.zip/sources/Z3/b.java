package Z3;

import java.util.List;
import java.util.Map;

/* loaded from: classes8.dex */
public interface b extends a {
    Object call(Object... objArr);

    Object callBy(Map map);

    List getParameters();

    m getReturnType();

    List getTypeParameters();

    p getVisibility();

    boolean isAbstract();

    boolean isFinal();

    boolean isOpen();

    boolean isSuspend();
}
