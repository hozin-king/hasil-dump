package Z3;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes8.dex */
public final class o {

    /* renamed from: b, reason: collision with root package name */
    public static final o f2215b = new o("INVARIANT", 0);

    /* renamed from: c, reason: collision with root package name */
    public static final o f2216c = new o("IN", 1);

    /* renamed from: d, reason: collision with root package name */
    public static final o f2217d = new o("OUT", 2);

    /* renamed from: e, reason: collision with root package name */
    private static final /* synthetic */ o[] f2218e;

    /* renamed from: f, reason: collision with root package name */
    private static final /* synthetic */ P3.a f2219f;

    static {
        o[] a5 = a();
        f2218e = a5;
        f2219f = P3.b.a(a5);
    }

    private o(String str, int i5) {
    }

    private static final /* synthetic */ o[] a() {
        return new o[]{f2215b, f2216c, f2217d};
    }

    public static o valueOf(String str) {
        return (o) Enum.valueOf(o.class, str);
    }

    public static o[] values() {
        return (o[]) f2218e.clone();
    }
}
