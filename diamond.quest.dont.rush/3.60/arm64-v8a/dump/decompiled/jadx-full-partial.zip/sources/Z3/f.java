package Z3;

import K3.InterfaceC0947g;

/* loaded from: classes8.dex */
public interface f extends b, InterfaceC0947g {
    boolean isExternal();

    boolean isInfix();

    boolean isInline();

    boolean isOperator();

    @Override // Z3.b
    boolean isSuspend();
}
