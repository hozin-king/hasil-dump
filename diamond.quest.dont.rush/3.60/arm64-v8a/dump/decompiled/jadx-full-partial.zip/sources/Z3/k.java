package Z3;

import Z3.j;

/* loaded from: classes8.dex */
public interface k extends j, U3.a {

    public interface a extends j.a, U3.a {
    }

    Object get();

    Object getDelegate();

    /* renamed from: getGetter */
    a mo566getGetter();
}
