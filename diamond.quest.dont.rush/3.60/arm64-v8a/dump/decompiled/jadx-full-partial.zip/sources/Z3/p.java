package Z3;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes8.dex */
public final class p {

    /* renamed from: b, reason: collision with root package name */
    public static final p f2220b = new p("PUBLIC", 0);

    /* renamed from: c, reason: collision with root package name */
    public static final p f2221c = new p("PROTECTED", 1);

    /* renamed from: d, reason: collision with root package name */
    public static final p f2222d = new p("INTERNAL", 2);

    /* renamed from: e, reason: collision with root package name */
    public static final p f2223e = new p("PRIVATE", 3);

    /* renamed from: f, reason: collision with root package name */
    private static final /* synthetic */ p[] f2224f;

    /* renamed from: g, reason: collision with root package name */
    private static final /* synthetic */ P3.a f2225g;

    static {
        p[] a5 = a();
        f2224f = a5;
        f2225g = P3.b.a(a5);
    }

    private p(String str, int i5) {
    }

    private static final /* synthetic */ p[] a() {
        return new p[]{f2220b, f2221c, f2222d, f2223e};
    }

    public static p valueOf(String str) {
        return (p) Enum.valueOf(p.class, str);
    }

    public static p[] values() {
        return (p[]) f2224f.clone();
    }
}
