package Z3;

import Z3.j;

/* loaded from: classes8.dex */
public interface l extends j, U3.l {

    public interface a extends j.a, U3.l {
    }

    Object get(Object obj);

    Object getDelegate(Object obj);

    /* renamed from: getGetter */
    a mo565getGetter();
}
