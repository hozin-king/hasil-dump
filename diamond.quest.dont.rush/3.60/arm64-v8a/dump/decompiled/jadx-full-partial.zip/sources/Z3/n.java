package Z3;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class n {

    /* renamed from: c, reason: collision with root package name */
    public static final a f2211c = new a(null);

    /* renamed from: d, reason: collision with root package name */
    public static final n f2212d = new n(null, null);

    /* renamed from: a, reason: collision with root package name */
    private final o f2213a;

    /* renamed from: b, reason: collision with root package name */
    private final m f2214b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final n a(m type) {
            C7150s.j(type, "type");
            return new n(o.f2215b, type);
        }

        private a() {
        }
    }

    public /* synthetic */ class b {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[o.values().length];
            try {
                iArr[o.f2215b.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[o.f2216c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[o.f2217d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public n(o oVar, m mVar) {
        String str;
        this.f2213a = oVar;
        this.f2214b = mVar;
        if ((oVar == null) == (mVar == null)) {
            return;
        }
        if (oVar == null) {
            str = "Star projection must have no type specified.";
        } else {
            str = "The projection variance " + oVar + " requires type to be specified.";
        }
        throw new IllegalArgumentException(str.toString());
    }

    public final m a() {
        return this.f2214b;
    }

    public final o b() {
        return this.f2213a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        return this.f2213a == nVar.f2213a && C7150s.e(this.f2214b, nVar.f2214b);
    }

    public int hashCode() {
        o oVar = this.f2213a;
        int hashCode = (oVar == null ? 0 : oVar.hashCode()) * 31;
        m mVar = this.f2214b;
        return hashCode + (mVar != null ? mVar.hashCode() : 0);
    }

    public String toString() {
        o oVar = this.f2213a;
        int i5 = oVar == null ? -1 : b.$EnumSwitchMapping$0[oVar.ordinal()];
        if (i5 == -1) {
            return "*";
        }
        if (i5 == 1) {
            return String.valueOf(this.f2214b);
        }
        if (i5 == 2) {
            return "in " + this.f2214b;
        }
        if (i5 != 3) {
            throw new K3.o();
        }
        return "out " + this.f2214b;
    }
}
