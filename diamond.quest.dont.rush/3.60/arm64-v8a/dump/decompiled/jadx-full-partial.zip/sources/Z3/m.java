package Z3;

import java.util.List;

/* loaded from: classes8.dex */
public interface m extends a {
    boolean c();

    d d();

    List g();
}
