package Z3;

/* loaded from: classes8.dex */
public interface g extends f {
}
