package S1;

/* loaded from: classes4.dex */
public abstract class l extends i {
    @Override // S1.i
    public void h() {
        i(null);
    }

    public abstract void i(k kVar);
}
