package S1;

/* loaded from: classes4.dex */
public interface k {
    void b();

    void c(float f5);
}
