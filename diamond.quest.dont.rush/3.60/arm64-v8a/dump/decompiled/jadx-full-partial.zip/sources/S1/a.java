package S1;

import io.appmetrica.analytics.coreutils.internal.StringUtils;
import k2.C7105a;

/* loaded from: classes4.dex */
public class a extends Z1.b {

    /* renamed from: c, reason: collision with root package name */
    public String f1739c;

    /* renamed from: d, reason: collision with root package name */
    public String[] f1740d;

    /* renamed from: e, reason: collision with root package name */
    public String[] f1741e;

    /* renamed from: a, reason: collision with root package name */
    public int f1737a = 60;

    /* renamed from: b, reason: collision with root package name */
    public int f1738b = 60;

    /* renamed from: f, reason: collision with root package name */
    public String[] f1742f = null;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1743g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean f1744h = false;

    @Override // Z1.b
    public void a(Z1.c cVar) {
        String[] split;
        String[] split2;
        super.a(cVar);
        try {
            this.f1743g = cVar.a("maxBanner", false);
            this.f1744h = cVar.a("maxFirst", false);
            int d5 = cVar.d("adInterstitialTime", -1);
            int d6 = cVar.d("collapsibleTime", -1);
            String e5 = cVar.e("banner", null);
            String e6 = cVar.e("ad_unit_interstitial", null);
            String e7 = cVar.e("ad_unit_reward", null);
            if (d5 != -1) {
                this.f1737a = d5;
            }
            if (d6 != -1) {
                this.f1738b = d6;
            }
            if (!C7105a.b(e5)) {
                this.f1739c = e5;
            }
            if (!C7105a.b(e6) && (split2 = e6.split(StringUtils.COMMA)) != null) {
                this.f1740d = split2;
            }
            if (C7105a.b(e7) || (split = e7.split(StringUtils.COMMA)) == null) {
                return;
            }
            this.f1741e = split;
        } catch (Exception unused) {
        }
    }
}
