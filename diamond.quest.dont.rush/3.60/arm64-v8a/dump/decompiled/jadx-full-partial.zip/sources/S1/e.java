package S1;

/* loaded from: classes4.dex */
public interface e {
    void a(boolean z4);
}
