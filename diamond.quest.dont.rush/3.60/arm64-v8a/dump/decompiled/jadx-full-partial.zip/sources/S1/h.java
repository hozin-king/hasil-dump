package S1;

/* loaded from: classes4.dex */
public interface h {
    void a();
}
