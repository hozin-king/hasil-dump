package S1;

import com.badlogic.gdx.pay.Transaction;

/* loaded from: classes4.dex */
public interface f {
    void g(double d5, String str, Transaction transaction);

    void i(boolean z4, boolean z5);
}
