package S1;

/* loaded from: classes4.dex */
public abstract class i {

    /* renamed from: b, reason: collision with root package name */
    private h f1783b;

    /* renamed from: c, reason: collision with root package name */
    private a f1784c;

    public interface a {
        void a(String str);

        void b(String str);

        void onFailed(String str);
    }

    public void a(String str) {
        h hVar = this.f1783b;
        if (hVar != null) {
            hVar.a();
        }
        a aVar = this.f1784c;
        if (aVar != null) {
            aVar.a(str);
        }
    }

    public abstract boolean b();

    public abstract void c();

    public void d(String str) {
        a aVar = this.f1784c;
        if (aVar != null) {
            aVar.b(str);
        }
    }

    public void e(String str) {
        a aVar = this.f1784c;
        if (aVar != null) {
            aVar.onFailed(str);
        }
    }

    public void f(h hVar) {
        this.f1783b = hVar;
    }

    public void g(a aVar) {
        this.f1784c = aVar;
    }

    public abstract void h();
}
