package O1;

/* loaded from: classes4.dex */
public class a {
    public void a(b bVar, boolean z4, String[] strArr, boolean z5, String str) {
    }
}
