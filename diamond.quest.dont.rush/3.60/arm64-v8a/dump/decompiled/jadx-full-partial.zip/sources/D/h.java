package D;

import D.f;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class h {
    public static final f.a a(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a b(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a c(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a d(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a e(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a f(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a g(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }

    public static final f.a h(String name) {
        C7150s.j(name, "name");
        return new f.a(name);
    }
}
