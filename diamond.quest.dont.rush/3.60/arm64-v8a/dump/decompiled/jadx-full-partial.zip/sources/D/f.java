package D;

import java.util.Map;
import kotlin.collections.M;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class f {

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private final String f471a;

        public a(String name) {
            C7150s.j(name, "name");
            this.f471a = name;
        }

        public final String a() {
            return this.f471a;
        }

        public boolean equals(Object obj) {
            if (obj instanceof a) {
                return C7150s.e(this.f471a, ((a) obj).f471a);
            }
            return false;
        }

        public int hashCode() {
            return this.f471a.hashCode();
        }

        public String toString() {
            return this.f471a;
        }
    }

    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        private final a f472a;

        /* renamed from: b, reason: collision with root package name */
        private final Object f473b;

        public b(a key, Object obj) {
            C7150s.j(key, "key");
            this.f472a = key;
            this.f473b = obj;
        }

        public final a a() {
            return this.f472a;
        }

        public final Object b() {
            return this.f473b;
        }
    }

    public abstract Map a();

    public abstract Object b(a aVar);

    public final c c() {
        return new c(M.B(a()), false);
    }

    public final f d() {
        return new c(M.B(a()), true);
    }
}
