package D;

import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    private final AtomicBoolean f461a;

    public b(boolean z4) {
        this.f461a = new AtomicBoolean(z4);
    }

    public final boolean a() {
        return this.f461a.get();
    }

    public final void b(boolean z4) {
        this.f461a.set(z4);
    }
}
