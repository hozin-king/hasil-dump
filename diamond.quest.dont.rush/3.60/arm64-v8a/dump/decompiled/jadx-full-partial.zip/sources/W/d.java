package W;

import androidx.lifecycle.InterfaceC1116p;

/* loaded from: classes.dex */
public interface d extends InterfaceC1116p {
    androidx.savedstate.a getSavedStateRegistry();
}
