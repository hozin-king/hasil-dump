package W;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static int f1910a = 2131362791;

    private a() {
    }
}
