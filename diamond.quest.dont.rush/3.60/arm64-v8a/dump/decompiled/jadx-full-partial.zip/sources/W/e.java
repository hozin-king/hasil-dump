package W;

import android.view.View;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class e {
    public static final void a(View view, d dVar) {
        C7150s.j(view, "<this>");
        view.setTag(a.f1910a, dVar);
    }
}
