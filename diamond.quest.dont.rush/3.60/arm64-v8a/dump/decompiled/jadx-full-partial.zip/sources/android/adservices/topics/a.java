package android.adservices.topics;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: android.adservices.topics.a$a, reason: collision with other inner class name */
    public static final class C0096a {
        public C0096a() {
            throw new RuntimeException("Stub!");
        }

        public a a() {
            throw new RuntimeException("Stub!");
        }

        public C0096a b(String str) {
            throw new RuntimeException("Stub!");
        }

        public C0096a c(boolean z4) {
            throw new RuntimeException("Stub!");
        }
    }

    a() {
        throw new RuntimeException("Stub!");
    }
}
