package android.adservices.topics;

import java.util.List;

/* loaded from: classes.dex */
public final class b {
    b() {
        throw new RuntimeException("Stub!");
    }

    public List a() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }
}
