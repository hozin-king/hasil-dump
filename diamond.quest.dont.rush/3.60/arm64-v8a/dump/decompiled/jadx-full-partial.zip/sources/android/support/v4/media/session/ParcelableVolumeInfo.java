package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    public int f2375b;

    /* renamed from: c, reason: collision with root package name */
    public int f2376c;

    /* renamed from: d, reason: collision with root package name */
    public int f2377d;

    /* renamed from: e, reason: collision with root package name */
    public int f2378e;

    /* renamed from: f, reason: collision with root package name */
    public int f2379f;

    class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public ParcelableVolumeInfo createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public ParcelableVolumeInfo[] newArray(int i5) {
            return new ParcelableVolumeInfo[i5];
        }
    }

    public ParcelableVolumeInfo(int i5, int i6, int i7, int i8, int i9) {
        this.f2375b = i5;
        this.f2376c = i6;
        this.f2377d = i7;
        this.f2378e = i8;
        this.f2379f = i9;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i5) {
        parcel.writeInt(this.f2375b);
        parcel.writeInt(this.f2377d);
        parcel.writeInt(this.f2378e);
        parcel.writeInt(this.f2379f);
        parcel.writeInt(this.f2376c);
    }

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f2375b = parcel.readInt();
        this.f2377d = parcel.readInt();
        this.f2378e = parcel.readInt();
        this.f2379f = parcel.readInt();
        this.f2376c = parcel.readInt();
    }
}
