package android.adservices.topics;

/* loaded from: classes.dex */
public final class c {
    c() {
        throw new RuntimeException("Stub!");
    }

    public long a() {
        throw new RuntimeException("Stub!");
    }

    public long b() {
        throw new RuntimeException("Stub!");
    }

    public int c() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }
}
