package android.support.v4.os;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.os.a;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    final boolean f2412b;

    /* renamed from: c, reason: collision with root package name */
    final Handler f2413c;

    /* renamed from: d, reason: collision with root package name */
    android.support.v4.os.a f2414d;

    class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public ResultReceiver createFromParcel(Parcel parcel) {
            return new ResultReceiver(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public ResultReceiver[] newArray(int i5) {
            return new ResultReceiver[i5];
        }
    }

    class b extends a.AbstractBinderC0102a {
        b() {
        }

        @Override // android.support.v4.os.a
        public void g(int i5, Bundle bundle) {
            ResultReceiver resultReceiver = ResultReceiver.this;
            Handler handler = resultReceiver.f2413c;
            if (handler != null) {
                handler.post(resultReceiver.new c(i5, bundle));
            } else {
                resultReceiver.a(i5, bundle);
            }
        }
    }

    class c implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final int f2416b;

        /* renamed from: c, reason: collision with root package name */
        final Bundle f2417c;

        c(int i5, Bundle bundle) {
            this.f2416b = i5;
            this.f2417c = bundle;
        }

        @Override // java.lang.Runnable
        public void run() {
            ResultReceiver.this.a(this.f2416b, this.f2417c);
        }
    }

    public ResultReceiver(Handler handler) {
        this.f2412b = true;
        this.f2413c = handler;
    }

    protected void a(int i5, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i5) {
        synchronized (this) {
            try {
                if (this.f2414d == null) {
                    this.f2414d = new b();
                }
                parcel.writeStrongBinder(this.f2414d.asBinder());
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    ResultReceiver(Parcel parcel) {
        this.f2412b = false;
        this.f2413c = null;
        this.f2414d = a.AbstractBinderC0102a.C0(parcel.readStrongBinder());
    }
}
