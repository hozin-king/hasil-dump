package android.support.v4.media;

import android.annotation.SuppressLint;
import android.media.Rating;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    private final int f2318b;

    /* renamed from: c, reason: collision with root package name */
    private final float f2319c;

    /* renamed from: d, reason: collision with root package name */
    private Object f2320d;

    class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public RatingCompat createFromParcel(Parcel parcel) {
            return new RatingCompat(parcel.readInt(), parcel.readFloat());
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public RatingCompat[] newArray(int i5) {
            return new RatingCompat[i5];
        }
    }

    private static class b {
        static float a(Rating rating) {
            return rating.getPercentRating();
        }

        static int b(Rating rating) {
            return rating.getRatingStyle();
        }

        static float c(Rating rating) {
            return rating.getStarRating();
        }

        static boolean d(Rating rating) {
            return rating.hasHeart();
        }

        static boolean e(Rating rating) {
            return rating.isRated();
        }

        static boolean f(Rating rating) {
            return rating.isThumbUp();
        }

        static Rating g(boolean z4) {
            return Rating.newHeartRating(z4);
        }

        static Rating h(float f5) {
            return Rating.newPercentageRating(f5);
        }

        static Rating i(int i5, float f5) {
            return Rating.newStarRating(i5, f5);
        }

        static Rating j(boolean z4) {
            return Rating.newThumbRating(z4);
        }

        static Rating k(int i5) {
            return Rating.newUnratedRating(i5);
        }
    }

    RatingCompat(int i5, float f5) {
        this.f2318b = i5;
        this.f2319c = f5;
    }

    public static RatingCompat a(Object obj) {
        RatingCompat ratingCompat = null;
        if (obj != null) {
            Rating rating = (Rating) obj;
            int b5 = b.b(rating);
            if (b.e(rating)) {
                switch (b5) {
                    case 1:
                        ratingCompat = b(b.d(rating));
                        break;
                    case 2:
                        ratingCompat = e(b.f(rating));
                        break;
                    case 3:
                    case 4:
                    case 5:
                        ratingCompat = d(b5, b.c(rating));
                        break;
                    case 6:
                        ratingCompat = c(b.a(rating));
                        break;
                    default:
                        return null;
                }
            } else {
                ratingCompat = f(b5);
            }
            ratingCompat.f2320d = obj;
        }
        return ratingCompat;
    }

    public static RatingCompat b(boolean z4) {
        return new RatingCompat(1, z4 ? 1.0f : 0.0f);
    }

    public static RatingCompat c(float f5) {
        if (f5 >= 0.0f && f5 <= 100.0f) {
            return new RatingCompat(6, f5);
        }
        Log.e("Rating", "Invalid percentage-based rating value");
        return null;
    }

    public static RatingCompat d(int i5, float f5) {
        float f6;
        if (i5 == 3) {
            f6 = 3.0f;
        } else if (i5 == 4) {
            f6 = 4.0f;
        } else {
            if (i5 != 5) {
                Log.e("Rating", "Invalid rating style (" + i5 + ") for a star rating");
                return null;
            }
            f6 = 5.0f;
        }
        if (f5 >= 0.0f && f5 <= f6) {
            return new RatingCompat(i5, f5);
        }
        Log.e("Rating", "Trying to set out of range star-based rating");
        return null;
    }

    public static RatingCompat e(boolean z4) {
        return new RatingCompat(2, z4 ? 1.0f : 0.0f);
    }

    public static RatingCompat f(int i5) {
        switch (i5) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return new RatingCompat(i5, -1.0f);
            default:
                return null;
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return this.f2318b;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rating:style=");
        sb.append(this.f2318b);
        sb.append(" rating=");
        float f5 = this.f2319c;
        sb.append(f5 < 0.0f ? "unrated" : String.valueOf(f5));
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i5) {
        parcel.writeInt(this.f2318b);
        parcel.writeFloat(this.f2319c);
    }
}
