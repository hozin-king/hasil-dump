package android.adservices.topics;

import android.content.Context;
import android.os.OutcomeReceiver;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class d {
    d() {
        throw new RuntimeException("Stub!");
    }

    public static d a(Context context) {
        throw new RuntimeException("Stub!");
    }

    public void b(a aVar, Executor executor, OutcomeReceiver outcomeReceiver) {
        throw new RuntimeException("Stub!");
    }
}
