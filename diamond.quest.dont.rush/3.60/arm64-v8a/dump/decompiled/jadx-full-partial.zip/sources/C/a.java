package C;

import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private final AtomicBoolean f363a;

    public a(boolean z4) {
        this.f363a = new AtomicBoolean(z4);
    }

    public final boolean a() {
        return this.f363a.get();
    }

    public final void b(boolean z4) {
        this.f363a.set(z4);
    }
}
