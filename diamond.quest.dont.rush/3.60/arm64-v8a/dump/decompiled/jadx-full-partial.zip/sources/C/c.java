package C;

import okio.InterfaceC7281f;
import okio.InterfaceC7282g;

/* loaded from: classes.dex */
public interface c {
    Object a(InterfaceC7282g interfaceC7282g, O3.d dVar);

    Object b(Object obj, InterfaceC7281f interfaceC7281f, O3.d dVar);

    Object getDefaultValue();
}
