package I3;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes8.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private static char[] f1220a;

    /* renamed from: b, reason: collision with root package name */
    private static int f1221b;

    /* renamed from: c, reason: collision with root package name */
    private static int f1222c;

    /* renamed from: d, reason: collision with root package name */
    private static String f1223d;

    /* renamed from: e, reason: collision with root package name */
    private static Map f1224e;

    static {
        char[] charArray = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_".toCharArray();
        f1220a = charArray;
        f1221b = charArray.length;
        f1222c = 0;
        f1224e = new HashMap(f1221b);
        for (int i5 = 0; i5 < f1221b; i5++) {
            f1224e.put(Character.valueOf(f1220a[i5]), Integer.valueOf(i5));
        }
    }

    private a() {
    }

    public static String a(long j5) {
        StringBuilder sb = new StringBuilder();
        do {
            sb.insert(0, f1220a[(int) (j5 % f1221b)]);
            j5 /= f1221b;
        } while (j5 > 0);
        return sb.toString();
    }

    public static String b() {
        String a5 = a(new Date().getTime());
        if (!a5.equals(f1223d)) {
            f1222c = 0;
            f1223d = a5;
            return a5;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(a5);
        sb.append(".");
        int i5 = f1222c;
        f1222c = i5 + 1;
        sb.append(a(i5));
        return sb.toString();
    }
}
