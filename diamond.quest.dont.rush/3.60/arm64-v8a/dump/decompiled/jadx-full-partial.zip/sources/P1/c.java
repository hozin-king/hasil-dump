package P1;

import io.appmetrica.analytics.coreutils.internal.StringUtils;

/* loaded from: classes4.dex */
public class c {
    public static boolean a(String str, String str2) {
        return str != null ? str.equals(str2) : str2 == null;
    }

    public static boolean b(String str) {
        return str == null || str.length() == 0;
    }

    public static float[] c(String str) {
        String[] split;
        if (str == null || str.length() <= 0 || (split = str.split(StringUtils.COMMA)) == null || split.length <= 0) {
            return null;
        }
        int length = split.length;
        float[] fArr = new float[length];
        for (int i5 = 0; i5 < length; i5++) {
            fArr[i5] = Float.parseFloat(split[i5]);
        }
        return fArr;
    }

    public static int[] d(String str) {
        String[] split;
        if (str == null || str.length() <= 0 || (split = str.split(StringUtils.COMMA)) == null || split.length <= 0) {
            return null;
        }
        int length = split.length;
        int[] iArr = new int[length];
        for (int i5 = 0; i5 < length; i5++) {
            iArr[i5] = Integer.parseInt(split[i5].trim());
        }
        return iArr;
    }
}
