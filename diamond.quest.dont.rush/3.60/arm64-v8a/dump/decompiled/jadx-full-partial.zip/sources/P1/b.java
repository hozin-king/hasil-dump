package P1;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.unity3d.ads.core.data.datasource.AndroidStaticDeviceInfoDataSource;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Locale;

/* loaded from: classes4.dex */
public class b {
    public static String a(byte[] bArr) {
        Formatter formatter = new Formatter();
        for (byte b5 : bArr) {
            formatter.format("%02x", Byte.valueOf(b5));
        }
        String formatter2 = formatter.toString();
        formatter.close();
        return formatter2;
    }

    public static String b(String str) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(AndroidStaticDeviceInfoDataSource.ALGORITHM_SHA1);
            messageDigest.reset();
            messageDigest.update(str.getBytes("UTF-8"));
            return a(messageDigest.digest());
        } catch (UnsupportedEncodingException e5) {
            e5.printStackTrace();
            return "";
        } catch (NoSuchAlgorithmException e6) {
            e6.printStackTrace();
            return "";
        }
    }

    public static String c(int i5) {
        return i5 == 0 ? "0" : String.format(Locale.US, "%,d", Integer.valueOf(i5)).replace((char) 160, '.');
    }

    public static float d(Label label, long j5, float f5, float f6) {
        float b5 = d.b(j5) * f6;
        if (b5 > f5) {
            b5 = f5;
        }
        float f7 = f5 - b5;
        label.setText(f((int) f7));
        return f7;
    }

    public static float e(Label label, long j5, int i5) {
        return d(label, j5, i5, 1.0f);
    }

    public static String f(int i5) {
        if (i5 <= 0) {
            return "00:00:00";
        }
        int i6 = i5 / 3600;
        if (i6 > 24) {
            return String.format(Locale.US, "%dd %dh", Integer.valueOf(i6 / 24), Integer.valueOf(i6 % 24));
        }
        int i7 = i5 % 3600;
        return String.format(Locale.US, "%02d:%02d:%02d", Integer.valueOf(i6), Integer.valueOf(i7 / 60), Integer.valueOf(i7 % 60));
    }

    public static String g(int i5) {
        if (i5 <= 0) {
            return "0h";
        }
        int i6 = i5 / 3600;
        if (i6 >= 24) {
            int i7 = i6 / 24;
            int i8 = i6 % 24;
            return i8 > 0 ? String.format(Locale.US, "%dd %dh", Integer.valueOf(i7), Integer.valueOf(i8)) : String.format(Locale.US, "%dd", Integer.valueOf(i7));
        }
        if (i6 != 0) {
            int i9 = (i5 % 3600) / 60;
            return i9 > 0 ? String.format(Locale.US, "%dh %dm", Integer.valueOf(i6), Integer.valueOf(i9)) : String.format(Locale.US, "%dh", Integer.valueOf(i6));
        }
        int i10 = i5 % 3600;
        int i11 = i10 / 60;
        int i12 = i10 % 60;
        return i12 == 0 ? String.format(Locale.US, "%dm", Integer.valueOf(i11)) : i11 > 0 ? String.format(Locale.US, "%dm %ds", Integer.valueOf(i11), Integer.valueOf(i12)) : String.format(Locale.US, "%ds", Integer.valueOf(i12));
    }

    public static float h(Label label, long j5, float f5, float f6) {
        float d5 = d.d(j5) * f6;
        if (d5 > f5) {
            d5 = f5;
        }
        float f7 = f5 - d5;
        label.setText(f((int) f7));
        return f7;
    }
}
