package P1;

import java.math.BigInteger;
import java.util.Comparator;
import java.util.regex.Pattern;

/* loaded from: classes4.dex */
public final class a implements Comparator {

    /* renamed from: b, reason: collision with root package name */
    private static final Pattern f1635b = Pattern.compile("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");

    @Override // java.util.Comparator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final int compare(String str, String str2) {
        if (str == null || str2 == null) {
            if (str == null) {
                return str2 == null ? 0 : -1;
            }
            return 1;
        }
        Pattern pattern = f1635b;
        String[] split = pattern.split(str);
        String[] split2 = pattern.split(str2);
        for (int i5 = 0; i5 < Math.min(split.length, split2.length); i5++) {
            char charAt = split[i5].charAt(0);
            char charAt2 = split2[i5].charAt(0);
            int compareTo = (charAt < '0' || charAt > '9' || charAt2 < 0 || charAt2 > '9') ? 0 : new BigInteger(split[i5]).compareTo(new BigInteger(split2[i5]));
            if (compareTo == 0) {
                compareTo = split[i5].compareTo(split2[i5]);
            }
            if (compareTo != 0) {
                return compareTo;
            }
        }
        return split.length - split2.length;
    }
}
