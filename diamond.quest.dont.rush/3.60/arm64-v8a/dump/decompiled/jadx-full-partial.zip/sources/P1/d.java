package P1;

import com.badlogic.gdx.math.MathUtils;
import io.bidmachine.iab.vast.tags.VastAttributes;
import j$.util.DesugarTimeZone;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/* loaded from: classes4.dex */
public class d {
    public static boolean a(Date date, Date date2, String str) {
        TimeZone timeZone = TimeZone.getDefault();
        if (str != null) {
            try {
                timeZone = DesugarTimeZone.getTimeZone(str);
            } catch (Exception unused) {
                timeZone = TimeZone.getDefault();
            }
        }
        int f5 = f(date, timeZone, VastAttributes.VERTICAL_POSITION);
        int f6 = f(date2, timeZone, VastAttributes.VERTICAL_POSITION);
        if (f5 > f6) {
            return true;
        }
        if (f5 < f6) {
            return false;
        }
        int f7 = f(date, timeZone, "M");
        int f8 = f(date2, timeZone, "M");
        return f7 > f8 || f7 < f8 || f(date, timeZone, "d") > f(date2, timeZone, "d");
    }

    public static float b(long j5) {
        return (i() - j5) / 1000.0f;
    }

    public static float c(long j5, long j6) {
        return (j5 - j6) / 1000.0f;
    }

    public static float d(long j5) {
        return (k() - j5) / 1.0E9f;
    }

    public static float e(long j5, long j6) {
        return (j5 - j6) / 1.0E9f;
    }

    public static int f(Date date, TimeZone timeZone, String str) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
        if (timeZone != null) {
            simpleDateFormat.setTimeZone(timeZone);
        }
        return Integer.parseInt(simpleDateFormat.format(date));
    }

    public static boolean g(long j5, float f5, float f6) {
        float b5 = b(j5) * f6;
        if (b5 > f5) {
            b5 = f5;
        }
        return b5 == f5;
    }

    public static boolean h(long j5, float f5, float f6) {
        float d5 = d(j5) * f6;
        if (d5 > f5) {
            d5 = f5;
        }
        return d5 == f5;
    }

    public static long i() {
        return System.currentTimeMillis();
    }

    public static long j(long j5) {
        return j5 * 1000000;
    }

    public static long k() {
        return System.nanoTime();
    }

    public static long l(float f5) {
        return i() + MathUtils.round(f5 * 1000.0f);
    }
}
