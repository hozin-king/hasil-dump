package Q0;

/* loaded from: classes3.dex */
public interface a {

    /* renamed from: a, reason: collision with root package name */
    public static final C0070a f1643a = C0070a.f1644a;

    /* renamed from: Q0.a$a, reason: collision with other inner class name */
    public static final class C0070a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ C0070a f1644a = new C0070a();

        private C0070a() {
        }

        public final a a() {
            return null;
        }
    }
}
