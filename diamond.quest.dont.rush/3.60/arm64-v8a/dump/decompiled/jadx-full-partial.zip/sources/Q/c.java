package Q;

import U3.l;
import android.content.Context;
import android.util.Log;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final c f1642a = new c();

    private c() {
    }

    public final Object a(Context context, String tag, l manager) {
        C7150s.j(context, "context");
        C7150s.j(tag, "tag");
        C7150s.j(manager, "manager");
        try {
            return manager.invoke(context);
        } catch (NoClassDefFoundError unused) {
            Log.d(tag, "Unable to find adservices code, check manifest for uses-library tag, versionS=" + b.f1639a.b());
            return null;
        }
    }
}
