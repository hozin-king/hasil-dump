package Q;

import android.os.Build;
import android.os.ext.SdkExtensions;
import io.bidmachine.media3.common.PlaybackException;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final b f1639a = new b();

    private static final class a {

        /* renamed from: a, reason: collision with root package name */
        public static final a f1640a = new a();

        private a() {
        }

        public final int a() {
            int extensionVersion;
            extensionVersion = SdkExtensions.getExtensionVersion(31);
            return extensionVersion;
        }
    }

    /* renamed from: Q.b$b, reason: collision with other inner class name */
    private static final class C0069b {

        /* renamed from: a, reason: collision with root package name */
        public static final C0069b f1641a = new C0069b();

        private C0069b() {
        }

        public final int a() {
            int extensionVersion;
            extensionVersion = SdkExtensions.getExtensionVersion(PlaybackException.CUSTOM_ERROR_CODE_BASE);
            return extensionVersion;
        }
    }

    private b() {
    }

    public final int a() {
        if (Build.VERSION.SDK_INT >= 33) {
            return C0069b.f1641a.a();
        }
        return 0;
    }

    public final int b() {
        int i5 = Build.VERSION.SDK_INT;
        if (i5 == 31 || i5 == 32) {
            return a.f1640a.a();
        }
        return 0;
    }
}
