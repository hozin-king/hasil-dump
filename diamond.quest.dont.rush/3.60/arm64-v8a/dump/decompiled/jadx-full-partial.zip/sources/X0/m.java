package X0;

/* loaded from: classes3.dex */
public enum m {
    COLOR("color"),
    DATE("date"),
    DATE_TIME("date-time"),
    EMAIL("email"),
    HOST_NAME("host-name"),
    IP_ADDRESS("ip-address"),
    IPV6("ipv6"),
    PHONE("phone"),
    REGEX("regex"),
    STYLE("style"),
    TIME("time"),
    URI("uri"),
    UTC_MILLISEC("utc-millisec");


    /* renamed from: b, reason: collision with root package name */
    private final String f1987b;

    m(String str) {
        this.f1987b = str;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.f1987b;
    }
}
