package X0;

import com.fasterxml.jackson.databind.A;

/* loaded from: classes3.dex */
public interface e {
    A a();
}
