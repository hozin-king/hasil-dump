package X0;

import java.util.HashMap;
import java.util.Map;

/* loaded from: classes3.dex */
public enum d {
    STRING,
    NUMBER,
    INTEGER,
    BOOLEAN,
    OBJECT,
    ARRAY,
    NULL,
    ANY;


    /* renamed from: j, reason: collision with root package name */
    private static final Map f1971j = new HashMap();

    static {
        for (d dVar : values()) {
            f1971j.put(dVar.name().toLowerCase(), dVar);
        }
    }
}
