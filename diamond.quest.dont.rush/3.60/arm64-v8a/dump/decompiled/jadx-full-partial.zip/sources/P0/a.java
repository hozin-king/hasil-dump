package P0;

/* loaded from: classes3.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final a f1632a = new a();

    /* renamed from: b, reason: collision with root package name */
    private static final String f1633b = a.class.getCanonicalName();

    /* renamed from: c, reason: collision with root package name */
    private static boolean f1634c;

    private a() {
    }

    public static final void a() {
        f1634c = true;
    }
}
