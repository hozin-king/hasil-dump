package G3;

/* loaded from: classes8.dex */
public interface d {

    /* renamed from: a, reason: collision with root package name */
    public static final String[] f946a = {"CONNECT", "DISCONNECT", "EVENT", "ACK", "ERROR", "BINARY_EVENT", "BINARY_ACK"};

    public interface a {

        /* renamed from: G3.d$a$a, reason: collision with other inner class name */
        public interface InterfaceC0039a {
            void a(c cVar);
        }

        void a(InterfaceC0039a interfaceC0039a);

        void add(String str);

        void add(byte[] bArr);

        void destroy();
    }

    public interface b {

        public interface a {
            void call(Object[] objArr);
        }

        void a(c cVar, a aVar);
    }
}
