package G3;

/* loaded from: classes8.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public int f940a;

    /* renamed from: b, reason: collision with root package name */
    public int f941b;

    /* renamed from: c, reason: collision with root package name */
    public String f942c;

    /* renamed from: d, reason: collision with root package name */
    public Object f943d;

    /* renamed from: e, reason: collision with root package name */
    public int f944e;

    /* renamed from: f, reason: collision with root package name */
    public String f945f;

    public c() {
        this.f940a = -1;
        this.f941b = -1;
    }

    public c(int i5) {
        this.f941b = -1;
        this.f940a = i5;
    }

    public c(int i5, Object obj) {
        this.f941b = -1;
        this.f940a = i5;
        this.f943d = obj;
    }
}
