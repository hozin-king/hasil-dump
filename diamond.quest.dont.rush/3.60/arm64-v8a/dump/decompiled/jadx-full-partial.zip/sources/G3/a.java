package G3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes8.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private static final Logger f932a = Logger.getLogger(a.class.getName());

    /* renamed from: G3.a$a, reason: collision with other inner class name */
    public static class C0037a {

        /* renamed from: a, reason: collision with root package name */
        public c f933a;

        /* renamed from: b, reason: collision with root package name */
        public byte[][] f934b;
    }

    private static Object a(Object obj, List list) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof byte[]) {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("_placeholder", true);
                jSONObject.put("num", list.size());
                list.add((byte[]) obj);
                return jSONObject;
            } catch (JSONException e5) {
                f932a.log(Level.WARNING, "An error occured while putting data to JSONObject", (Throwable) e5);
                return null;
            }
        }
        if (obj instanceof JSONArray) {
            JSONArray jSONArray = new JSONArray();
            JSONArray jSONArray2 = (JSONArray) obj;
            int length = jSONArray2.length();
            for (int i5 = 0; i5 < length; i5++) {
                try {
                    jSONArray.put(i5, a(jSONArray2.get(i5), list));
                } catch (JSONException e6) {
                    f932a.log(Level.WARNING, "An error occured while putting packet data to JSONObject", (Throwable) e6);
                    return null;
                }
            }
            return jSONArray;
        }
        if (!(obj instanceof JSONObject)) {
            return obj;
        }
        JSONObject jSONObject2 = new JSONObject();
        JSONObject jSONObject3 = (JSONObject) obj;
        Iterator keys = jSONObject3.keys();
        while (keys.hasNext()) {
            String str = (String) keys.next();
            try {
                jSONObject2.put(str, a(jSONObject3.get(str), list));
            } catch (JSONException e7) {
                f932a.log(Level.WARNING, "An error occured while putting data to JSONObject", (Throwable) e7);
                return null;
            }
        }
        return jSONObject2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v2, types: [org.json.JSONObject] */
    private static Object b(Object obj, byte[][] bArr) {
        if (obj instanceof JSONArray) {
            JSONArray jSONArray = (JSONArray) obj;
            int length = jSONArray.length();
            for (int i5 = 0; i5 < length; i5++) {
                try {
                    jSONArray.put(i5, b(jSONArray.get(i5), bArr));
                } catch (JSONException e5) {
                    f932a.log(Level.WARNING, "An error occured while putting packet data to JSONObject", (Throwable) e5);
                    return null;
                }
            }
            return jSONArray;
        }
        if (obj instanceof JSONObject) {
            obj = (JSONObject) obj;
            if (obj.optBoolean("_placeholder")) {
                int optInt = obj.optInt("num", -1);
                if (optInt < 0 || optInt >= bArr.length) {
                    return null;
                }
                return bArr[optInt];
            }
            Iterator keys = obj.keys();
            while (keys.hasNext()) {
                String str = (String) keys.next();
                try {
                    obj.put(str, b(obj.get(str), bArr));
                } catch (JSONException e6) {
                    f932a.log(Level.WARNING, "An error occured while putting data to JSONObject", (Throwable) e6);
                    return null;
                }
            }
        }
        return obj;
    }

    public static C0037a c(c cVar) {
        ArrayList arrayList = new ArrayList();
        cVar.f943d = a(cVar.f943d, arrayList);
        cVar.f944e = arrayList.size();
        C0037a c0037a = new C0037a();
        c0037a.f933a = cVar;
        c0037a.f934b = (byte[][]) arrayList.toArray(new byte[arrayList.size()][]);
        return c0037a;
    }

    public static c d(c cVar, byte[][] bArr) {
        cVar.f943d = b(cVar.f943d, bArr);
        cVar.f944e = -1;
        return cVar;
    }
}
