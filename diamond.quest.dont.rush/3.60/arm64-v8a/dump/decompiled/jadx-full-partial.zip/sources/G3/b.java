package G3;

import G3.a;
import G3.d;
import com.google.firebase.sessions.settings.RemoteSettings;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONTokener;

/* loaded from: classes8.dex */
public final class b implements d {

    /* renamed from: b, reason: collision with root package name */
    private static final Logger f935b = Logger.getLogger(b.class.getName());

    static class a {

        /* renamed from: a, reason: collision with root package name */
        public G3.c f936a;

        /* renamed from: b, reason: collision with root package name */
        List f937b = new ArrayList();

        a(G3.c cVar) {
            this.f936a = cVar;
        }

        public void a() {
            this.f936a = null;
            this.f937b = new ArrayList();
        }

        public G3.c b(byte[] bArr) {
            this.f937b.add(bArr);
            int size = this.f937b.size();
            G3.c cVar = this.f936a;
            if (size != cVar.f944e) {
                return null;
            }
            List list = this.f937b;
            G3.c d5 = G3.a.d(cVar, (byte[][]) list.toArray(new byte[list.size()][]));
            a();
            return d5;
        }
    }

    public static final class c implements d.b {
        private void b(G3.c cVar, d.b.a aVar) {
            a.C0037a c5 = G3.a.c(cVar);
            String c6 = c(c5.f933a);
            ArrayList arrayList = new ArrayList(Arrays.asList(c5.f934b));
            arrayList.add(0, c6);
            aVar.call(arrayList.toArray());
        }

        private String c(G3.c cVar) {
            StringBuilder sb = new StringBuilder("" + cVar.f940a);
            int i5 = cVar.f940a;
            if (5 == i5 || 6 == i5) {
                sb.append(cVar.f944e);
                sb.append("-");
            }
            String str = cVar.f942c;
            if (str != null && str.length() != 0 && !RemoteSettings.FORWARD_SLASH_STRING.equals(cVar.f942c)) {
                sb.append(cVar.f942c);
                sb.append(StringUtils.COMMA);
            }
            int i6 = cVar.f941b;
            if (i6 >= 0) {
                sb.append(i6);
            }
            Object obj = cVar.f943d;
            if (obj != null) {
                sb.append(obj);
            }
            if (b.f935b.isLoggable(Level.FINE)) {
                b.f935b.fine(String.format("encoded %s as %s", cVar, sb));
            }
            return sb.toString();
        }

        @Override // G3.d.b
        public void a(G3.c cVar, d.b.a aVar) {
            int i5 = cVar.f940a;
            if ((i5 == 2 || i5 == 3) && E3.a.b(cVar.f943d)) {
                cVar.f940a = cVar.f940a == 2 ? 5 : 6;
            }
            if (b.f935b.isLoggable(Level.FINE)) {
                b.f935b.fine(String.format("encoding packet %s", cVar));
            }
            int i6 = cVar.f940a;
            if (5 == i6 || 6 == i6) {
                b(cVar, aVar);
            } else {
                aVar.call(new String[]{c(cVar)});
            }
        }
    }

    private b() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static G3.c c() {
        return new G3.c(4, "parser error");
    }

    /* renamed from: G3.b$b, reason: collision with other inner class name */
    public static final class C0038b implements d.a {

        /* renamed from: a, reason: collision with root package name */
        a f938a = null;

        /* renamed from: b, reason: collision with root package name */
        private d.a.InterfaceC0039a f939b;

        private static G3.c b(String str) {
            int i5;
            int i6;
            int length = str.length();
            G3.c cVar = new G3.c(Character.getNumericValue(str.charAt(0)));
            int i7 = cVar.f940a;
            if (i7 < 0 || i7 > d.f946a.length - 1) {
                return b.c();
            }
            if (5 != i7 && 6 != i7) {
                i5 = 0;
            } else {
                if (!str.contains("-") || length <= 1) {
                    return b.c();
                }
                StringBuilder sb = new StringBuilder();
                i5 = 0;
                while (true) {
                    i5++;
                    if (str.charAt(i5) == '-') {
                        break;
                    }
                    sb.append(str.charAt(i5));
                }
                cVar.f944e = Integer.parseInt(sb.toString());
            }
            int i8 = i5 + 1;
            if (length <= i8 || '/' != str.charAt(i8)) {
                cVar.f942c = RemoteSettings.FORWARD_SLASH_STRING;
            } else {
                StringBuilder sb2 = new StringBuilder();
                while (true) {
                    i6 = i5 + 1;
                    char charAt = str.charAt(i6);
                    if (',' == charAt) {
                        break;
                    }
                    sb2.append(charAt);
                    if (i5 + 2 == length) {
                        break;
                    }
                    i5 = i6;
                }
                cVar.f942c = sb2.toString();
                i5 = i6;
            }
            int i9 = i5 + 1;
            if (length > i9 && Character.getNumericValue(str.charAt(i9)) > -1) {
                StringBuilder sb3 = new StringBuilder();
                while (true) {
                    int i10 = i5 + 1;
                    char charAt2 = str.charAt(i10);
                    if (Character.getNumericValue(charAt2) >= 0) {
                        sb3.append(charAt2);
                        if (i5 + 2 == length) {
                            i5 = i10;
                            break;
                        }
                        i5 = i10;
                    }
                }
                try {
                    cVar.f941b = Integer.parseInt(sb3.toString());
                    break;
                } catch (NumberFormatException unused) {
                    return b.c();
                }
            }
            int i11 = i5 + 1;
            if (length > i11) {
                try {
                    str.charAt(i11);
                    cVar.f943d = new JSONTokener(str.substring(i11)).nextValue();
                } catch (JSONException e5) {
                    b.f935b.log(Level.WARNING, "An error occured while retrieving data from JSONTokener", (Throwable) e5);
                    return b.c();
                }
            }
            if (b.f935b.isLoggable(Level.FINE)) {
                b.f935b.fine(String.format("decoded %s as %s", str, cVar));
            }
            return cVar;
        }

        @Override // G3.d.a
        public void a(d.a.InterfaceC0039a interfaceC0039a) {
            this.f939b = interfaceC0039a;
        }

        @Override // G3.d.a
        public void add(String str) {
            d.a.InterfaceC0039a interfaceC0039a;
            G3.c b5 = b(str);
            int i5 = b5.f940a;
            if (5 != i5 && 6 != i5) {
                d.a.InterfaceC0039a interfaceC0039a2 = this.f939b;
                if (interfaceC0039a2 != null) {
                    interfaceC0039a2.a(b5);
                    return;
                }
                return;
            }
            a aVar = new a(b5);
            this.f938a = aVar;
            if (aVar.f936a.f944e != 0 || (interfaceC0039a = this.f939b) == null) {
                return;
            }
            interfaceC0039a.a(b5);
        }

        @Override // G3.d.a
        public void destroy() {
            a aVar = this.f938a;
            if (aVar != null) {
                aVar.a();
            }
            this.f939b = null;
        }

        @Override // G3.d.a
        public void add(byte[] bArr) {
            a aVar = this.f938a;
            if (aVar != null) {
                G3.c b5 = aVar.b(bArr);
                if (b5 != null) {
                    this.f938a = null;
                    d.a.InterfaceC0039a interfaceC0039a = this.f939b;
                    if (interfaceC0039a != null) {
                        interfaceC0039a.a(b5);
                        return;
                    }
                    return;
                }
                return;
            }
            throw new RuntimeException("got binary data when not reconstructing a packet");
        }
    }
}
