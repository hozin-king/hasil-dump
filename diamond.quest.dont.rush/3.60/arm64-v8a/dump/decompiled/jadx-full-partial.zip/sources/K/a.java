package K;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static int f1295a = 2131362789;

    private a() {
    }
}
