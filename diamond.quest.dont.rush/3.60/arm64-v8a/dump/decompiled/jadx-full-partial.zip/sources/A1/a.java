package A1;

/* loaded from: classes4.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private boolean f169a;

    public a(boolean z4) {
        this.f169a = z4;
    }

    public boolean a() {
        return this.f169a;
    }

    public boolean b(boolean z4) {
        if (this.f169a == z4) {
            return false;
        }
        this.f169a = z4;
        return true;
    }
}
