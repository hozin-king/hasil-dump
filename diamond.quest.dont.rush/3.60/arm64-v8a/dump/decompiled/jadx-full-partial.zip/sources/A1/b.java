package A1;

/* loaded from: classes4.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    private int f170a;

    public b(int i5) {
        this.f170a = i5;
    }

    public int a() {
        return this.f170a;
    }

    public boolean b(int i5) {
        if (this.f170a == i5) {
            return false;
        }
        this.f170a = i5;
        return true;
    }
}
