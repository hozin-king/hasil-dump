package D2;

import android.os.Bundle;

/* loaded from: classes6.dex */
public class a {

    /* renamed from: b, reason: collision with root package name */
    public static String f528b = "query_info_type";

    /* renamed from: c, reason: collision with root package name */
    public static String f529c = "requester_type_5";

    /* renamed from: d, reason: collision with root package name */
    public static String f530d = "UnityScar";

    /* renamed from: a, reason: collision with root package name */
    private String f531a;

    public a(String str) {
        this.f531a = f530d + str;
    }

    public Bundle a() {
        Bundle bundle = new Bundle();
        bundle.putString(f528b, f529c);
        return bundle;
    }

    public String b() {
        return this.f531a;
    }
}
