package F2;

/* loaded from: classes6.dex */
public class d implements a {

    /* renamed from: a, reason: collision with root package name */
    private com.unity3d.scar.adapter.common.a f830a;

    /* renamed from: b, reason: collision with root package name */
    private g f831b;

    /* renamed from: c, reason: collision with root package name */
    private f f832c;

    public d(com.unity3d.scar.adapter.common.a aVar, f fVar) {
        this(aVar, null, fVar);
    }

    @Override // F2.a
    public void a(String str, String str2, Object obj) {
        this.f832c.a(str, str2);
        g gVar = this.f831b;
        if (gVar != null) {
            gVar.a(str, obj);
        }
        this.f830a.b();
    }

    @Override // F2.a
    public void onFailure(String str) {
        this.f832c.d(str);
        this.f830a.b();
    }

    public d(com.unity3d.scar.adapter.common.a aVar, g gVar, f fVar) {
        this.f830a = aVar;
        this.f831b = gVar;
        this.f832c = fVar;
    }
}
