package F2;

import android.content.Context;
import java.util.List;

/* loaded from: classes6.dex */
public interface c {
    void a(Context context, List list, b bVar);

    void b(Context context, String str, E2.d dVar, b bVar);

    void c(Context context, boolean z4, b bVar);

    void d(Context context, E2.d dVar, com.unity3d.scar.adapter.common.a aVar, f fVar);

    void e(Context context, String str, E2.d dVar, com.unity3d.scar.adapter.common.a aVar, f fVar);
}
