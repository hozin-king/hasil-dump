package F2;

import java.util.HashMap;
import java.util.Map;

/* loaded from: classes6.dex */
public class f {

    /* renamed from: a, reason: collision with root package name */
    private Map f837a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    private String f838b = null;

    public void a(String str, String str2) {
        this.f837a.put(str, str2);
    }

    public String b() {
        return this.f838b;
    }

    public Map c() {
        return this.f837a;
    }

    public void d(String str) {
        this.f838b = str;
    }
}
