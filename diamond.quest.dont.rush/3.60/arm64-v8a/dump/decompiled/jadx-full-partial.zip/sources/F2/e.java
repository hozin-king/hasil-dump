package F2;

import android.content.Context;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

/* loaded from: classes6.dex */
public abstract class e implements c {

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f833a;

        static {
            int[] iArr = new int[E2.d.values().length];
            f833a = iArr;
            try {
                iArr[E2.d.BANNER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f833a[E2.d.INTERSTITIAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f833a[E2.d.REWARDED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private class b implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        private F2.b f834b;

        /* renamed from: c, reason: collision with root package name */
        private f f835c;

        public b(F2.b bVar, f fVar) {
            this.f834b = bVar;
            this.f835c = fVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            Map c5 = this.f835c.c();
            if (c5.size() > 0) {
                this.f834b.onSignalsCollected(new JSONObject(c5).toString());
            } else if (this.f835c.b() == null) {
                this.f834b.onSignalsCollected("");
            } else {
                this.f834b.onSignalsCollectionFailed(this.f835c.b());
            }
        }
    }

    @Override // F2.c
    public void a(Context context, List list, F2.b bVar) {
        com.unity3d.scar.adapter.common.a aVar = new com.unity3d.scar.adapter.common.a();
        f fVar = new f();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            E2.d dVar = (E2.d) it.next();
            aVar.a();
            d(context, dVar, aVar, fVar);
        }
        aVar.c(new b(bVar, fVar));
    }

    @Override // F2.c
    public void b(Context context, String str, E2.d dVar, F2.b bVar) {
        com.unity3d.scar.adapter.common.a aVar = new com.unity3d.scar.adapter.common.a();
        f fVar = new f();
        aVar.a();
        e(context, str, dVar, aVar, fVar);
        aVar.c(new b(bVar, fVar));
    }

    @Override // F2.c
    public void c(Context context, boolean z4, F2.b bVar) {
        com.unity3d.scar.adapter.common.a aVar = new com.unity3d.scar.adapter.common.a();
        f fVar = new f();
        aVar.a();
        d(context, E2.d.INTERSTITIAL, aVar, fVar);
        aVar.a();
        d(context, E2.d.REWARDED, aVar, fVar);
        if (z4) {
            aVar.a();
            d(context, E2.d.BANNER, aVar, fVar);
        }
        aVar.c(new b(bVar, fVar));
    }

    public String f(E2.d dVar) {
        int i5 = a.f833a[dVar.ordinal()];
        return i5 != 1 ? i5 != 2 ? i5 != 3 ? "" : "gmaScarBiddingRewardedSignal" : "gmaScarBiddingInterstitialSignal" : "gmaScarBiddingBannerSignal";
    }
}
