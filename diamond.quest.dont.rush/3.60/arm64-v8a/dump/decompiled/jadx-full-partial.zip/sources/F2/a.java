package F2;

/* loaded from: classes6.dex */
public interface a {
    void a(String str, String str2, Object obj);

    void onFailure(String str);
}
