package F2;

/* loaded from: classes6.dex */
public interface b {
    void onSignalsCollected(String str);

    void onSignalsCollectionFailed(String str);
}
