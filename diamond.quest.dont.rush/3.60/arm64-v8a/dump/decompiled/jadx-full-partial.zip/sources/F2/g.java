package F2;

import j$.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/* loaded from: classes6.dex */
public class g {

    /* renamed from: a, reason: collision with root package name */
    private final Map f839a = new ConcurrentHashMap();

    public void a(String str, Object obj) {
        this.f839a.put(str, obj);
    }
}
