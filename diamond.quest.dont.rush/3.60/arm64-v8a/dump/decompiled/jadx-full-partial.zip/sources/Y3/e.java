package Y3;

/* loaded from: classes8.dex */
public interface e {
    boolean contains(Comparable comparable);
}
