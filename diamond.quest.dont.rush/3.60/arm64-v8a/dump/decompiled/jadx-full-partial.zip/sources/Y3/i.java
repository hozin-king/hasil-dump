package Y3;

import kotlin.collections.J;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public class i implements Iterable, V3.a {

    /* renamed from: e, reason: collision with root package name */
    public static final a f2044e = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final long f2045b;

    /* renamed from: c, reason: collision with root package name */
    private final long f2046c;

    /* renamed from: d, reason: collision with root package name */
    private final long f2047d;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public i(long j5, long j6, long j7) {
        if (j7 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        }
        if (j7 == Long.MIN_VALUE) {
            throw new IllegalArgumentException("Step must be greater than Long.MIN_VALUE to avoid overflow on negation.");
        }
        this.f2045b = j5;
        this.f2046c = Q3.c.d(j5, j6, j7);
        this.f2047d = j7;
    }

    public final long d() {
        return this.f2045b;
    }

    public final long e() {
        return this.f2046c;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof i)) {
            return false;
        }
        if (isEmpty() && ((i) obj).isEmpty()) {
            return true;
        }
        i iVar = (i) obj;
        return this.f2045b == iVar.f2045b && this.f2046c == iVar.f2046c && this.f2047d == iVar.f2047d;
    }

    @Override // java.lang.Iterable
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public J iterator() {
        return new j(this.f2045b, this.f2046c, this.f2047d);
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        long j5 = 31;
        long j6 = this.f2045b;
        long j7 = this.f2046c;
        long j8 = j5 * (((j6 ^ (j6 >>> 32)) * j5) + (j7 ^ (j7 >>> 32)));
        long j9 = this.f2047d;
        return (int) (j8 + (j9 ^ (j9 >>> 32)));
    }

    public boolean isEmpty() {
        long j5 = this.f2047d;
        long j6 = this.f2045b;
        long j7 = this.f2046c;
        return j5 > 0 ? j6 > j7 : j6 < j7;
    }

    public String toString() {
        StringBuilder sb;
        long j5;
        if (this.f2047d > 0) {
            sb = new StringBuilder();
            sb.append(this.f2045b);
            sb.append("..");
            sb.append(this.f2046c);
            sb.append(" step ");
            j5 = this.f2047d;
        } else {
            sb = new StringBuilder();
            sb.append(this.f2045b);
            sb.append(" downTo ");
            sb.append(this.f2046c);
            sb.append(" step ");
            j5 = -this.f2047d;
        }
        sb.append(j5);
        return sb.toString();
    }
}
