package Y3;

import java.util.NoSuchElementException;
import kotlin.collections.AbstractC7122o;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class b extends AbstractC7122o {

    /* renamed from: b, reason: collision with root package name */
    private final int f2026b;

    /* renamed from: c, reason: collision with root package name */
    private final int f2027c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f2028d;

    /* renamed from: e, reason: collision with root package name */
    private int f2029e;

    public b(char c5, char c6, int i5) {
        this.f2026b = i5;
        this.f2027c = c6;
        boolean z4 = false;
        if (i5 <= 0 ? C7150s.k(c5, c6) >= 0 : C7150s.k(c5, c6) <= 0) {
            z4 = true;
        }
        this.f2028d = z4;
        this.f2029e = z4 ? c5 : c6;
    }

    @Override // kotlin.collections.AbstractC7122o
    public char a() {
        int i5 = this.f2029e;
        if (i5 != this.f2027c) {
            this.f2029e = this.f2026b + i5;
        } else {
            if (!this.f2028d) {
                throw new NoSuchElementException();
            }
            this.f2028d = false;
        }
        return (char) i5;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.f2028d;
    }
}
