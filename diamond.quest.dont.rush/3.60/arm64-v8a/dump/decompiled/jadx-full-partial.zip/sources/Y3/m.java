package Y3;

import kotlin.jvm.internal.C7150s;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes8.dex */
public abstract class m {
    public static final void a(boolean z4, Number step) {
        C7150s.j(step, "step");
        if (z4) {
            return;
        }
        throw new IllegalArgumentException("Step must be positive, was: " + step + '.');
    }

    public static e b(float f5, float f6) {
        return new d(f5, f6);
    }
}
