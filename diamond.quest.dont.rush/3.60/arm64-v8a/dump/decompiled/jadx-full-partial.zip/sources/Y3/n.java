package Y3;

import Y3.f;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.C7150s;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes8.dex */
public abstract class n extends m {
    public static float c(float f5, float f6) {
        return f5 < f6 ? f6 : f5;
    }

    public static int d(int i5, int i6) {
        return i5 < i6 ? i6 : i5;
    }

    public static long e(long j5, long j6) {
        return j5 < j6 ? j6 : j5;
    }

    public static float f(float f5, float f6) {
        return f5 > f6 ? f6 : f5;
    }

    public static int g(int i5, int i6) {
        return i5 > i6 ? i6 : i5;
    }

    public static long h(long j5, long j6) {
        return j5 > j6 ? j6 : j5;
    }

    public static double i(double d5, double d6, double d7) {
        if (d6 <= d7) {
            return d5 < d6 ? d6 : d5 > d7 ? d7 : d5;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + d7 + " is less than minimum " + d6 + '.');
    }

    public static float j(float f5, float f6, float f7) {
        if (f6 <= f7) {
            return f5 < f6 ? f6 : f5 > f7 ? f7 : f5;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + f7 + " is less than minimum " + f6 + '.');
    }

    public static int k(int i5, int i6, int i7) {
        if (i6 <= i7) {
            return i5 < i6 ? i6 : i5 > i7 ? i7 : i5;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i7 + " is less than minimum " + i6 + '.');
    }

    public static long l(long j5, long j6, long j7) {
        if (j6 <= j7) {
            return j5 < j6 ? j6 : j5 > j7 ? j7 : j5;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + j7 + " is less than minimum " + j6 + '.');
    }

    public static f m(int i5, int i6) {
        return f.f2034e.a(i5, i6, -1);
    }

    public static int n(h hVar, kotlin.random.d random) {
        C7150s.j(hVar, "<this>");
        C7150s.j(random, "random");
        try {
            return kotlin.random.e.e(random, hVar);
        } catch (IllegalArgumentException e5) {
            throw new NoSuchElementException(e5.getMessage());
        }
    }

    public static f o(f fVar) {
        C7150s.j(fVar, "<this>");
        return f.f2034e.a(fVar.e(), fVar.d(), -fVar.f());
    }

    public static f p(f fVar, int i5) {
        C7150s.j(fVar, "<this>");
        m.a(i5 > 0, Integer.valueOf(i5));
        f.a aVar = f.f2034e;
        int d5 = fVar.d();
        int e5 = fVar.e();
        if (fVar.f() <= 0) {
            i5 = -i5;
        }
        return aVar.a(d5, e5, i5);
    }

    public static h q(int i5, int i6) {
        return i6 <= Integer.MIN_VALUE ? h.f2042f.a() : new h(i5, i6 - 1);
    }
}
