package Y3;

/* loaded from: classes8.dex */
final class d implements e {

    /* renamed from: a, reason: collision with root package name */
    private final float f2032a;

    /* renamed from: b, reason: collision with root package name */
    private final float f2033b;

    public d(float f5, float f6) {
        this.f2032a = f5;
        this.f2033b = f6;
    }

    public boolean a(float f5) {
        return f5 >= this.f2032a && f5 <= this.f2033b;
    }

    public boolean b() {
        return this.f2032a > this.f2033b;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // Y3.e
    public /* bridge */ /* synthetic */ boolean contains(Comparable comparable) {
        return a(((Number) comparable).floatValue());
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof d)) {
            return false;
        }
        if (b() && ((d) obj).b()) {
            return true;
        }
        d dVar = (d) obj;
        return this.f2032a == dVar.f2032a && this.f2033b == dVar.f2033b;
    }

    public int hashCode() {
        if (b()) {
            return -1;
        }
        return (Float.floatToIntBits(this.f2032a) * 31) + Float.floatToIntBits(this.f2033b);
    }

    public String toString() {
        return this.f2032a + ".." + this.f2033b;
    }
}
