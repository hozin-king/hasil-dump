package Y3;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class h extends f {

    /* renamed from: f, reason: collision with root package name */
    public static final a f2042f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static final h f2043g = new h(1, 0);

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final h a() {
            return h.f2043g;
        }

        private a() {
        }
    }

    public h(int i5, int i6) {
        super(i5, i6, 1);
    }

    @Override // Y3.f
    public boolean equals(Object obj) {
        if (!(obj instanceof h)) {
            return false;
        }
        if (isEmpty() && ((h) obj).isEmpty()) {
            return true;
        }
        h hVar = (h) obj;
        return d() == hVar.d() && e() == hVar.e();
    }

    @Override // Y3.f
    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (d() * 31) + e();
    }

    public boolean i(int i5) {
        return d() <= i5 && i5 <= e();
    }

    @Override // Y3.f
    public boolean isEmpty() {
        return d() > e();
    }

    public Integer j() {
        return Integer.valueOf(e());
    }

    public Integer l() {
        return Integer.valueOf(d());
    }

    @Override // Y3.f
    public String toString() {
        return d() + ".." + e();
    }
}
