package Y3;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class c extends Y3.a {

    /* renamed from: f, reason: collision with root package name */
    public static final a f2030f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static final c f2031g = new c(1, 0);

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public c(char c5, char c6) {
        super(c5, c6, 1);
    }

    @Override // Y3.a
    public boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        if (isEmpty() && ((c) obj).isEmpty()) {
            return true;
        }
        c cVar = (c) obj;
        return d() == cVar.d() && e() == cVar.e();
    }

    public boolean g(char c5) {
        return C7150s.k(d(), c5) <= 0 && C7150s.k(c5, e()) <= 0;
    }

    @Override // Y3.a
    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (d() * 31) + e();
    }

    @Override // Y3.a
    public boolean isEmpty() {
        return C7150s.k(d(), e()) > 0;
    }

    @Override // Y3.a
    public String toString() {
        return d() + ".." + e();
    }
}
