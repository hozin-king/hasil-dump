package Y3;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class k extends i {

    /* renamed from: f, reason: collision with root package name */
    public static final a f2052f = new a(null);

    /* renamed from: g, reason: collision with root package name */
    private static final k f2053g = new k(1, 0);

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public k(long j5, long j6) {
        super(j5, j6, 1L);
    }

    @Override // Y3.i
    public boolean equals(Object obj) {
        if (!(obj instanceof k)) {
            return false;
        }
        if (isEmpty() && ((k) obj).isEmpty()) {
            return true;
        }
        k kVar = (k) obj;
        return d() == kVar.d() && e() == kVar.e();
    }

    public boolean g(long j5) {
        return d() <= j5 && j5 <= e();
    }

    @Override // Y3.i
    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (int) ((31 * (d() ^ (d() >>> 32))) + (e() ^ (e() >>> 32)));
    }

    @Override // Y3.i
    public boolean isEmpty() {
        return d() > e();
    }

    @Override // Y3.i
    public String toString() {
        return d() + ".." + e();
    }
}
