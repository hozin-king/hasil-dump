package Y3;

import kotlin.collections.I;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public class f implements Iterable, V3.a {

    /* renamed from: e, reason: collision with root package name */
    public static final a f2034e = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final int f2035b;

    /* renamed from: c, reason: collision with root package name */
    private final int f2036c;

    /* renamed from: d, reason: collision with root package name */
    private final int f2037d;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final f a(int i5, int i6, int i7) {
            return new f(i5, i6, i7);
        }

        private a() {
        }
    }

    public f(int i5, int i6, int i7) {
        if (i7 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        }
        if (i7 == Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
        this.f2035b = i5;
        this.f2036c = Q3.c.c(i5, i6, i7);
        this.f2037d = i7;
    }

    public final int d() {
        return this.f2035b;
    }

    public final int e() {
        return this.f2036c;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof f)) {
            return false;
        }
        if (isEmpty() && ((f) obj).isEmpty()) {
            return true;
        }
        f fVar = (f) obj;
        return this.f2035b == fVar.f2035b && this.f2036c == fVar.f2036c && this.f2037d == fVar.f2037d;
    }

    public final int f() {
        return this.f2037d;
    }

    @Override // java.lang.Iterable
    /* renamed from: g, reason: merged with bridge method [inline-methods] */
    public I iterator() {
        return new g(this.f2035b, this.f2036c, this.f2037d);
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.f2035b * 31) + this.f2036c) * 31) + this.f2037d;
    }

    public boolean isEmpty() {
        return this.f2037d > 0 ? this.f2035b > this.f2036c : this.f2035b < this.f2036c;
    }

    public String toString() {
        StringBuilder sb;
        int i5;
        if (this.f2037d > 0) {
            sb = new StringBuilder();
            sb.append(this.f2035b);
            sb.append("..");
            sb.append(this.f2036c);
            sb.append(" step ");
            i5 = this.f2037d;
        } else {
            sb = new StringBuilder();
            sb.append(this.f2035b);
            sb.append(" downTo ");
            sb.append(this.f2036c);
            sb.append(" step ");
            i5 = -this.f2037d;
        }
        sb.append(i5);
        return sb.toString();
    }
}
