package Y3;

import java.util.NoSuchElementException;
import kotlin.collections.J;

/* loaded from: classes8.dex */
public final class j extends J {

    /* renamed from: b, reason: collision with root package name */
    private final long f2048b;

    /* renamed from: c, reason: collision with root package name */
    private final long f2049c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f2050d;

    /* renamed from: e, reason: collision with root package name */
    private long f2051e;

    public j(long j5, long j6, long j7) {
        this.f2048b = j7;
        this.f2049c = j6;
        boolean z4 = false;
        if (j7 <= 0 ? j5 >= j6 : j5 <= j6) {
            z4 = true;
        }
        this.f2050d = z4;
        this.f2051e = z4 ? j5 : j6;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.f2050d;
    }

    @Override // kotlin.collections.J
    public long nextLong() {
        long j5 = this.f2051e;
        if (j5 != this.f2049c) {
            this.f2051e = this.f2048b + j5;
            return j5;
        }
        if (!this.f2050d) {
            throw new NoSuchElementException();
        }
        this.f2050d = false;
        return j5;
    }
}
