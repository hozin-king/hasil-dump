package Y3;

import kotlin.collections.AbstractC7122o;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public class a implements Iterable, V3.a {

    /* renamed from: e, reason: collision with root package name */
    public static final C0090a f2022e = new C0090a(null);

    /* renamed from: b, reason: collision with root package name */
    private final char f2023b;

    /* renamed from: c, reason: collision with root package name */
    private final char f2024c;

    /* renamed from: d, reason: collision with root package name */
    private final int f2025d;

    /* renamed from: Y3.a$a, reason: collision with other inner class name */
    public static final class C0090a {
        public /* synthetic */ C0090a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private C0090a() {
        }
    }

    public a(char c5, char c6, int i5) {
        if (i5 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        }
        if (i5 == Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
        this.f2023b = c5;
        this.f2024c = (char) Q3.c.c(c5, c6, i5);
        this.f2025d = i5;
    }

    public final char d() {
        return this.f2023b;
    }

    public final char e() {
        return this.f2024c;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        if (isEmpty() && ((a) obj).isEmpty()) {
            return true;
        }
        a aVar = (a) obj;
        return this.f2023b == aVar.f2023b && this.f2024c == aVar.f2024c && this.f2025d == aVar.f2025d;
    }

    @Override // java.lang.Iterable
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public AbstractC7122o iterator() {
        return new b(this.f2023b, this.f2024c, this.f2025d);
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.f2023b * 31) + this.f2024c) * 31) + this.f2025d;
    }

    public boolean isEmpty() {
        return this.f2025d > 0 ? C7150s.k(this.f2023b, this.f2024c) > 0 : C7150s.k(this.f2023b, this.f2024c) < 0;
    }

    public String toString() {
        StringBuilder sb;
        int i5;
        if (this.f2025d > 0) {
            sb = new StringBuilder();
            sb.append(this.f2023b);
            sb.append("..");
            sb.append(this.f2024c);
            sb.append(" step ");
            i5 = this.f2025d;
        } else {
            sb = new StringBuilder();
            sb.append(this.f2023b);
            sb.append(" downTo ");
            sb.append(this.f2024c);
            sb.append(" step ");
            i5 = -this.f2025d;
        }
        sb.append(i5);
        return sb.toString();
    }
}
