package Y3;

/* loaded from: classes8.dex */
public final class l extends n {
    private l() {
    }
}
