package Y3;

import java.util.NoSuchElementException;
import kotlin.collections.I;

/* loaded from: classes8.dex */
public final class g extends I {

    /* renamed from: b, reason: collision with root package name */
    private final int f2038b;

    /* renamed from: c, reason: collision with root package name */
    private final int f2039c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f2040d;

    /* renamed from: e, reason: collision with root package name */
    private int f2041e;

    public g(int i5, int i6, int i7) {
        this.f2038b = i7;
        this.f2039c = i6;
        boolean z4 = false;
        if (i7 <= 0 ? i5 >= i6 : i5 <= i6) {
            z4 = true;
        }
        this.f2040d = z4;
        this.f2041e = z4 ? i5 : i6;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.f2040d;
    }

    @Override // kotlin.collections.I
    public int nextInt() {
        int i5 = this.f2041e;
        if (i5 != this.f2039c) {
            this.f2041e = this.f2038b + i5;
            return i5;
        }
        if (!this.f2040d) {
            throw new NoSuchElementException();
        }
        this.f2040d = false;
        return i5;
    }
}
