package a0;

import android.R;

/* renamed from: a0.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0969a {

    /* renamed from: a, reason: collision with root package name */
    public static int[] f2227a = {R.attr.orientation};

    /* renamed from: b, reason: collision with root package name */
    public static int f2228b;

    private C0969a() {
    }
}
