package W0;

import com.fasterxml.jackson.databind.k;
import com.fasterxml.jackson.databind.p;
import com.fasterxml.jackson.databind.util.j;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
/* loaded from: classes3.dex */
public @interface c {
    Class as() default Void.class;

    Class builder() default Void.class;

    Class contentAs() default Void.class;

    Class contentConverter() default j.a.class;

    Class contentUsing() default k.a.class;

    Class converter() default j.a.class;

    Class keyAs() default Void.class;

    Class keyUsing() default p.a.class;

    Class using() default k.a.class;
}
