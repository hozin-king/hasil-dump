package W0;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
/* loaded from: classes3.dex */
public @interface e {

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final String f1916a;

        /* renamed from: b, reason: collision with root package name */
        public final String f1917b;

        public a(e eVar) {
            this(eVar.buildMethodName(), eVar.withPrefix());
        }

        public a(String str, String str2) {
            this.f1916a = str;
            this.f1917b = str2;
        }
    }

    String buildMethodName() default "build";

    String withPrefix() default "with";
}
