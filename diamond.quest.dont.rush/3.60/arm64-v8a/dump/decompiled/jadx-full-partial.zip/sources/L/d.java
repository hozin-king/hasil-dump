package L;

import L.a;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes.dex */
public final class d extends a {
    /* JADX WARN: Multi-variable type inference failed */
    public d() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    @Override // L.a
    public Object a(a.b key) {
        C7150s.j(key, "key");
        return b().get(key);
    }

    public final void c(a.b key, Object obj) {
        C7150s.j(key, "key");
        b().put(key, obj);
    }

    public d(a initialExtras) {
        C7150s.j(initialExtras, "initialExtras");
        b().putAll(initialExtras.b());
    }

    public /* synthetic */ d(a aVar, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this((i5 & 1) != 0 ? a.C0053a.f1413b : aVar);
    }
}
