package L;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    private final Map f1412a = new LinkedHashMap();

    /* renamed from: L.a$a, reason: collision with other inner class name */
    public static final class C0053a extends a {

        /* renamed from: b, reason: collision with root package name */
        public static final C0053a f1413b = new C0053a();

        private C0053a() {
        }

        @Override // L.a
        public Object a(b key) {
            C7150s.j(key, "key");
            return null;
        }
    }

    public interface b {
    }

    public abstract Object a(b bVar);

    public final Map b() {
        return this.f1412a;
    }
}
