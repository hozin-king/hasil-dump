package L;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public static int f1416a = 2131362792;

    private e() {
    }
}
