package L;

import U3.l;
import androidx.lifecycle.K;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    private final Class f1417a;

    /* renamed from: b, reason: collision with root package name */
    private final l f1418b;

    public f(Class<K> clazz, l initializer) {
        C7150s.j(clazz, "clazz");
        C7150s.j(initializer, "initializer");
        this.f1417a = clazz;
        this.f1418b = initializer;
    }

    public final Class a() {
        return this.f1417a;
    }

    public final l b() {
        return this.f1418b;
    }
}
