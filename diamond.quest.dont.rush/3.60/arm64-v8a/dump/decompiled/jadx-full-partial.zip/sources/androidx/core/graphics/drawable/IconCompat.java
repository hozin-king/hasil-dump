package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.versionedparcelable.CustomVersionedParcelable;
import com.google.firebase.sessions.settings.RemoteSettings;
import com.ironsource.b9;
import com.mbridge.msdk.playercommon.exoplayer2.C;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import io.bidmachine.iab.vast.tags.VastAttributes;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import t.i;

/* loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k, reason: collision with root package name */
    static final PorterDuff.Mode f4368k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a, reason: collision with root package name */
    public int f4369a;

    /* renamed from: b, reason: collision with root package name */
    Object f4370b;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f4371c;

    /* renamed from: d, reason: collision with root package name */
    public Parcelable f4372d;

    /* renamed from: e, reason: collision with root package name */
    public int f4373e;

    /* renamed from: f, reason: collision with root package name */
    public int f4374f;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f4375g;

    /* renamed from: h, reason: collision with root package name */
    PorterDuff.Mode f4376h;

    /* renamed from: i, reason: collision with root package name */
    public String f4377i;

    /* renamed from: j, reason: collision with root package name */
    public String f4378j;

    static class a {
        static IconCompat a(Object obj) {
            i.g(obj);
            int d5 = d(obj);
            if (d5 == 2) {
                return IconCompat.o(null, c(obj), b(obj));
            }
            if (d5 == 4) {
                return IconCompat.l(e(obj));
            }
            if (d5 == 6) {
                return IconCompat.i(e(obj));
            }
            IconCompat iconCompat = new IconCompat(-1);
            iconCompat.f4370b = obj;
            return iconCompat;
        }

        static int b(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.a(obj);
            }
            try {
                return ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
            } catch (IllegalAccessException e5) {
                Log.e("IconCompat", "Unable to get icon resource", e5);
                return 0;
            } catch (NoSuchMethodException e6) {
                Log.e("IconCompat", "Unable to get icon resource", e6);
                return 0;
            } catch (InvocationTargetException e7) {
                Log.e("IconCompat", "Unable to get icon resource", e7);
                return 0;
            }
        }

        static String c(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.b(obj);
            }
            try {
                return (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
            } catch (IllegalAccessException e5) {
                Log.e("IconCompat", "Unable to get icon package", e5);
                return null;
            } catch (NoSuchMethodException e6) {
                Log.e("IconCompat", "Unable to get icon package", e6);
                return null;
            } catch (InvocationTargetException e7) {
                Log.e("IconCompat", "Unable to get icon package", e7);
                return null;
            }
        }

        static int d(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.c(obj);
            }
            try {
                return ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
            } catch (IllegalAccessException e5) {
                Log.e("IconCompat", "Unable to get icon type " + obj, e5);
                return -1;
            } catch (NoSuchMethodException e6) {
                Log.e("IconCompat", "Unable to get icon type " + obj, e6);
                return -1;
            } catch (InvocationTargetException e7) {
                Log.e("IconCompat", "Unable to get icon type " + obj, e7);
                return -1;
            }
        }

        @Nullable
        static Uri e(@NonNull Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.d(obj);
            }
            try {
                return (Uri) obj.getClass().getMethod("getUri", null).invoke(obj, null);
            } catch (IllegalAccessException e5) {
                Log.e("IconCompat", "Unable to get icon uri", e5);
                return null;
            } catch (NoSuchMethodException e6) {
                Log.e("IconCompat", "Unable to get icon uri", e6);
                return null;
            } catch (InvocationTargetException e7) {
                Log.e("IconCompat", "Unable to get icon uri", e7);
                return null;
            }
        }

        static Drawable f(Icon icon, Context context) {
            return icon.loadDrawable(context);
        }

        static Icon g(IconCompat iconCompat, Context context) {
            Icon createWithBitmap;
            switch (iconCompat.f4369a) {
                case -1:
                    return (Icon) iconCompat.f4370b;
                case 0:
                default:
                    throw new IllegalArgumentException("Unknown type");
                case 1:
                    createWithBitmap = Icon.createWithBitmap((Bitmap) iconCompat.f4370b);
                    break;
                case 2:
                    createWithBitmap = Icon.createWithResource(iconCompat.s(), iconCompat.f4373e);
                    break;
                case 3:
                    createWithBitmap = Icon.createWithData((byte[]) iconCompat.f4370b, iconCompat.f4373e, iconCompat.f4374f);
                    break;
                case 4:
                    createWithBitmap = Icon.createWithContentUri((String) iconCompat.f4370b);
                    break;
                case 5:
                    if (Build.VERSION.SDK_INT < 26) {
                        createWithBitmap = Icon.createWithBitmap(IconCompat.h((Bitmap) iconCompat.f4370b, false));
                        break;
                    } else {
                        createWithBitmap = b.b((Bitmap) iconCompat.f4370b);
                        break;
                    }
                case 6:
                    int i5 = Build.VERSION.SDK_INT;
                    if (i5 >= 30) {
                        createWithBitmap = d.a(iconCompat.v());
                        break;
                    } else {
                        if (context == null) {
                            throw new IllegalArgumentException("Context is required to resolve the file uri of the icon: " + iconCompat.v());
                        }
                        InputStream w5 = iconCompat.w(context);
                        if (w5 == null) {
                            throw new IllegalStateException("Cannot load adaptive icon from uri: " + iconCompat.v());
                        }
                        if (i5 < 26) {
                            createWithBitmap = Icon.createWithBitmap(IconCompat.h(BitmapFactory.decodeStream(w5), false));
                            break;
                        } else {
                            createWithBitmap = b.b(BitmapFactory.decodeStream(w5));
                            break;
                        }
                    }
            }
            ColorStateList colorStateList = iconCompat.f4375g;
            if (colorStateList != null) {
                createWithBitmap.setTintList(colorStateList);
            }
            PorterDuff.Mode mode = iconCompat.f4376h;
            if (mode != IconCompat.f4368k) {
                createWithBitmap.setTintMode(mode);
            }
            return createWithBitmap;
        }
    }

    static class b {
        static Drawable a(Drawable drawable, Drawable drawable2) {
            return new AdaptiveIconDrawable(drawable, drawable2);
        }

        static Icon b(Bitmap bitmap) {
            return Icon.createWithAdaptiveBitmap(bitmap);
        }
    }

    static class c {
        static int a(Object obj) {
            return ((Icon) obj).getResId();
        }

        static String b(Object obj) {
            return ((Icon) obj).getResPackage();
        }

        static int c(Object obj) {
            return ((Icon) obj).getType();
        }

        static Uri d(Object obj) {
            return ((Icon) obj).getUri();
        }
    }

    static class d {
        static Icon a(Uri uri) {
            return Icon.createWithAdaptiveBitmapContentUri(uri);
        }
    }

    public IconCompat() {
        this.f4369a = -1;
        this.f4371c = null;
        this.f4372d = null;
        this.f4373e = 0;
        this.f4374f = 0;
        this.f4375g = null;
        this.f4376h = f4368k;
        this.f4377i = null;
    }

    private static String D(int i5) {
        switch (i5) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case 5:
                return "BITMAP_MASKABLE";
            case 6:
                return "URI_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    public static IconCompat e(Bundle bundle) {
        int i5 = bundle.getInt("type");
        IconCompat iconCompat = new IconCompat(i5);
        iconCompat.f4373e = bundle.getInt("int1");
        iconCompat.f4374f = bundle.getInt("int2");
        iconCompat.f4378j = bundle.getString("string1");
        if (bundle.containsKey("tint_list")) {
            iconCompat.f4375g = (ColorStateList) bundle.getParcelable("tint_list");
        }
        if (bundle.containsKey("tint_mode")) {
            iconCompat.f4376h = PorterDuff.Mode.valueOf(bundle.getString("tint_mode"));
        }
        switch (i5) {
            case -1:
            case 1:
            case 5:
                iconCompat.f4370b = bundle.getParcelable("obj");
                return iconCompat;
            case 0:
            default:
                Log.w("IconCompat", "Unknown type " + i5);
                return null;
            case 2:
            case 4:
            case 6:
                iconCompat.f4370b = bundle.getString("obj");
                return iconCompat;
            case 3:
                iconCompat.f4370b = bundle.getByteArray("obj");
                return iconCompat;
        }
    }

    public static IconCompat f(Icon icon) {
        return a.a(icon);
    }

    public static IconCompat g(Icon icon) {
        if (a.d(icon) == 2 && a.b(icon) == 0) {
            return null;
        }
        return a.a(icon);
    }

    static Bitmap h(Bitmap bitmap, boolean z4) {
        int min = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f5 = min;
        float f6 = 0.5f * f5;
        float f7 = 0.9166667f * f6;
        if (z4) {
            float f8 = 0.010416667f * f5;
            paint.setColor(0);
            paint.setShadowLayer(f8, 0.0f, f5 * 0.020833334f, 1023410176);
            canvas.drawCircle(f6, f6, f7, paint);
            paint.setShadowLayer(f8, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f6, f6, f7, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - min)) / 2.0f, (-(bitmap.getHeight() - min)) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f6, f6, f7, paint);
        canvas.setBitmap(null);
        return createBitmap;
    }

    public static IconCompat i(Uri uri) {
        t.d.c(uri);
        return j(uri.toString());
    }

    public static IconCompat j(String str) {
        t.d.c(str);
        IconCompat iconCompat = new IconCompat(6);
        iconCompat.f4370b = str;
        return iconCompat;
    }

    public static IconCompat k(Bitmap bitmap) {
        t.d.c(bitmap);
        IconCompat iconCompat = new IconCompat(1);
        iconCompat.f4370b = bitmap;
        return iconCompat;
    }

    public static IconCompat l(Uri uri) {
        t.d.c(uri);
        return m(uri.toString());
    }

    public static IconCompat m(String str) {
        t.d.c(str);
        IconCompat iconCompat = new IconCompat(4);
        iconCompat.f4370b = str;
        return iconCompat;
    }

    public static IconCompat n(Context context, int i5) {
        t.d.c(context);
        return o(context.getResources(), context.getPackageName(), i5);
    }

    public static IconCompat o(Resources resources, String str, int i5) {
        t.d.c(str);
        if (i5 == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f4373e = i5;
        if (resources != null) {
            try {
                iconCompat.f4370b = resources.getResourceName(i5);
            } catch (Resources.NotFoundException unused) {
                throw new IllegalArgumentException("Icon resource cannot be found");
            }
        } else {
            iconCompat.f4370b = str;
        }
        iconCompat.f4378j = str;
        return iconCompat;
    }

    static Resources t(Context context, String str) {
        if ("android".equals(str)) {
            return Resources.getSystem();
        }
        PackageManager packageManager = context.getPackageManager();
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str, 8192);
            if (applicationInfo != null) {
                return packageManager.getResourcesForApplication(applicationInfo);
            }
            return null;
        } catch (PackageManager.NameNotFoundException e5) {
            Log.e("IconCompat", String.format("Unable to find pkg=%s for icon", str), e5);
            return null;
        }
    }

    public Bundle A() {
        Bundle bundle = new Bundle();
        switch (this.f4369a) {
            case -1:
                bundle.putParcelable("obj", (Parcelable) this.f4370b);
                break;
            case 0:
            default:
                throw new IllegalArgumentException("Invalid icon");
            case 1:
            case 5:
                bundle.putParcelable("obj", (Bitmap) this.f4370b);
                break;
            case 2:
            case 4:
            case 6:
                bundle.putString("obj", (String) this.f4370b);
                break;
            case 3:
                bundle.putByteArray("obj", (byte[]) this.f4370b);
                break;
        }
        bundle.putInt("type", this.f4369a);
        bundle.putInt("int1", this.f4373e);
        bundle.putInt("int2", this.f4374f);
        bundle.putString("string1", this.f4378j);
        ColorStateList colorStateList = this.f4375g;
        if (colorStateList != null) {
            bundle.putParcelable("tint_list", colorStateList);
        }
        PorterDuff.Mode mode = this.f4376h;
        if (mode != f4368k) {
            bundle.putString("tint_mode", mode.name());
        }
        return bundle;
    }

    public Icon B() {
        return C(null);
    }

    public Icon C(Context context) {
        return a.g(this, context);
    }

    public void d(Context context) {
        Object obj;
        if (this.f4369a != 2 || (obj = this.f4370b) == null) {
            return;
        }
        String str = (String) obj;
        if (str.contains(StringUtils.PROCESS_POSTFIX_DELIMITER)) {
            String str2 = str.split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1)[1];
            String str3 = str2.split(RemoteSettings.FORWARD_SLASH_STRING, -1)[0];
            String str4 = str2.split(RemoteSettings.FORWARD_SLASH_STRING, -1)[1];
            String str5 = str.split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1)[0];
            if ("0_resource_name_obfuscated".equals(str4)) {
                Log.i("IconCompat", "Found obfuscated resource, not trying to update resource id for it");
                return;
            }
            String s5 = s();
            int identifier = t(context, s5).getIdentifier(str4, str3, str5);
            if (this.f4373e != identifier) {
                Log.i("IconCompat", "Id has changed for " + s5 + " " + str);
                this.f4373e = identifier;
            }
        }
    }

    public Bitmap q() {
        int i5 = this.f4369a;
        if (i5 == -1) {
            Object obj = this.f4370b;
            if (obj instanceof Bitmap) {
                return (Bitmap) obj;
            }
            return null;
        }
        if (i5 == 1) {
            return (Bitmap) this.f4370b;
        }
        if (i5 == 5) {
            return h((Bitmap) this.f4370b, true);
        }
        throw new IllegalStateException("called getBitmap() on " + this);
    }

    public int r() {
        int i5 = this.f4369a;
        if (i5 == -1) {
            return a.b(this.f4370b);
        }
        if (i5 == 2) {
            return this.f4373e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public String s() {
        int i5 = this.f4369a;
        if (i5 == -1) {
            return a.c(this.f4370b);
        }
        if (i5 == 2) {
            String str = this.f4378j;
            return (str == null || TextUtils.isEmpty(str)) ? ((String) this.f4370b).split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1)[0] : this.f4378j;
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public String toString() {
        if (this.f4369a == -1) {
            return String.valueOf(this.f4370b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        sb.append(D(this.f4369a));
        switch (this.f4369a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f4370b).getWidth());
                sb.append(VastAttributes.HORIZONTAL_POSITION);
                sb.append(((Bitmap) this.f4370b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f4378j);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(r())));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f4373e);
                if (this.f4374f != 0) {
                    sb.append(" off=");
                    sb.append(this.f4374f);
                    break;
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f4370b);
                break;
        }
        if (this.f4375g != null) {
            sb.append(" tint=");
            sb.append(this.f4375g);
        }
        if (this.f4376h != f4368k) {
            sb.append(" mode=");
            sb.append(this.f4376h);
        }
        sb.append(")");
        return sb.toString();
    }

    public int u() {
        int i5 = this.f4369a;
        return i5 == -1 ? a.d(this.f4370b) : i5;
    }

    public Uri v() {
        int i5 = this.f4369a;
        if (i5 == -1) {
            return a.e(this.f4370b);
        }
        if (i5 == 4 || i5 == 6) {
            return Uri.parse((String) this.f4370b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public InputStream w(Context context) {
        Uri v5 = v();
        String scheme = v5.getScheme();
        if ("content".equals(scheme) || b9.h.f26186b.equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(v5);
            } catch (Exception e5) {
                Log.w("IconCompat", "Unable to load image from URI: " + v5, e5);
                return null;
            }
        }
        try {
            return new FileInputStream(new File((String) this.f4370b));
        } catch (FileNotFoundException e6) {
            Log.w("IconCompat", "Unable to load image from path: " + v5, e6);
            return null;
        }
    }

    public Drawable x(Context context) {
        d(context);
        return a.f(C(context), context);
    }

    public void y() {
        this.f4376h = PorterDuff.Mode.valueOf(this.f4377i);
        switch (this.f4369a) {
            case -1:
                Parcelable parcelable = this.f4372d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                this.f4370b = parcelable;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                Parcelable parcelable2 = this.f4372d;
                if (parcelable2 != null) {
                    this.f4370b = parcelable2;
                    return;
                }
                byte[] bArr = this.f4371c;
                this.f4370b = bArr;
                this.f4369a = 3;
                this.f4373e = 0;
                this.f4374f = bArr.length;
                return;
            case 2:
            case 4:
            case 6:
                String str = new String(this.f4371c, Charset.forName(C.UTF16_NAME));
                this.f4370b = str;
                if (this.f4369a == 2 && this.f4378j == null) {
                    this.f4378j = str.split(StringUtils.PROCESS_POSTFIX_DELIMITER, -1)[0];
                    return;
                }
                return;
            case 3:
                this.f4370b = this.f4371c;
                return;
        }
    }

    public void z(boolean z4) {
        this.f4377i = this.f4376h.name();
        switch (this.f4369a) {
            case -1:
                if (z4) {
                    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
                }
                this.f4372d = (Parcelable) this.f4370b;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                if (!z4) {
                    this.f4372d = (Parcelable) this.f4370b;
                    return;
                }
                Bitmap bitmap = (Bitmap) this.f4370b;
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                this.f4371c = byteArrayOutputStream.toByteArray();
                return;
            case 2:
                this.f4371c = ((String) this.f4370b).getBytes(Charset.forName(C.UTF16_NAME));
                return;
            case 3:
                this.f4371c = (byte[]) this.f4370b;
                return;
            case 4:
            case 6:
                this.f4371c = this.f4370b.toString().getBytes(Charset.forName(C.UTF16_NAME));
                return;
        }
    }

    IconCompat(int i5) {
        this.f4371c = null;
        this.f4372d = null;
        this.f4373e = 0;
        this.f4374f = 0;
        this.f4375g = null;
        this.f4376h = f4368k;
        this.f4377i = null;
        this.f4369a = i5;
    }
}
