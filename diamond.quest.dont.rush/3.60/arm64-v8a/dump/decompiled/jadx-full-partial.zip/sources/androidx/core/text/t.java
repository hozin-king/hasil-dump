package androidx.core.text;

/* loaded from: classes.dex */
public interface t {
    boolean isRtl(CharSequence charSequence, int i5, int i6);
}
