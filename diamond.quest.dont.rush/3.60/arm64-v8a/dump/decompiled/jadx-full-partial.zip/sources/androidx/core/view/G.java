package androidx.core.view;

import android.view.MotionEvent;

/* loaded from: classes.dex */
public final class G {
    private G() {
    }

    public static boolean a(MotionEvent motionEvent, int i5) {
        return (motionEvent.getSource() & i5) == i5;
    }
}
