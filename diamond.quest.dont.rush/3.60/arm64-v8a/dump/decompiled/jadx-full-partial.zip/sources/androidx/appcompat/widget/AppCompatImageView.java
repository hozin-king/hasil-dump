package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/* loaded from: classes.dex */
public class AppCompatImageView extends ImageView {
    private final C0986e mBackgroundTintHelper;
    private boolean mHasLevel;
    private final C0998q mImageHelper;

    public AppCompatImageView(@NonNull Context context) {
        this(context, null);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.b();
        }
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportImageTintList() {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            return c0998q.d();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportImageTintMode() {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            return c0998q.e();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.mImageHelper.f() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(@Nullable Drawable drawable) {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null && drawable != null && !this.mHasLevel) {
            c0998q.h(drawable);
        }
        super.setImageDrawable(drawable);
        C0998q c0998q2 = this.mImageHelper;
        if (c0998q2 != null) {
            c0998q2.c();
            if (this.mHasLevel) {
                return;
            }
            this.mImageHelper.b();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i5) {
        super.setImageLevel(i5);
        this.mHasLevel = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i5) {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.i(i5);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(@Nullable Uri uri) {
        super.setImageURI(uri);
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.c();
        }
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    public void setSupportImageTintList(@Nullable ColorStateList colorStateList) {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(@Nullable PorterDuff.Mode mode) {
        C0998q c0998q = this.mImageHelper;
        if (c0998q != null) {
            c0998q.k(mode);
        }
    }

    public AppCompatImageView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AppCompatImageView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        this.mHasLevel = false;
        c0.a(this, getContext());
        C0986e c0986e = new C0986e(this);
        this.mBackgroundTintHelper = c0986e;
        c0986e.e(attributeSet, i5);
        C0998q c0998q = new C0998q(this);
        this.mImageHelper = c0998q;
        c0998q.g(attributeSet, i5);
    }
}
