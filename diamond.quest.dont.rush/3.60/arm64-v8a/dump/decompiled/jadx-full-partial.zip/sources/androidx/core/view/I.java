package androidx.core.view;

import android.view.View;

/* loaded from: classes.dex */
public interface I {
    void h(View view, View view2, int i5, int i6);

    void i(View view, int i5);

    void j(View view, int i5, int i6, int i7, int i8, int i9);

    void l(View view, int i5, int i6, int[] iArr, int i7);

    boolean o(View view, View view2, int i5, int i6);
}
