package androidx.core.os;

import java.util.Locale;

/* loaded from: classes.dex */
interface l {
    String a();

    Locale get(int i5);

    Object getLocaleList();

    boolean isEmpty();

    int size();
}
