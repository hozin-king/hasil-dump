package androidx.appcompat.app;

import androidx.appcompat.view.b;

/* renamed from: androidx.appcompat.app.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0978d {
    void onSupportActionModeFinished(androidx.appcompat.view.b bVar);

    void onSupportActionModeStarted(androidx.appcompat.view.b bVar);

    androidx.appcompat.view.b onWindowStartingSupportActionMode(b.a aVar);
}
