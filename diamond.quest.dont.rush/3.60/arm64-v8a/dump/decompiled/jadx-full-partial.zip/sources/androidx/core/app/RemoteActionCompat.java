package androidx.core.app;

import android.app.PendingIntent;
import androidx.annotation.NonNull;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements androidx.versionedparcelable.d {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f4217a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f4218b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f4219c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f4220d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f4221e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f4222f;

    public RemoteActionCompat(@NonNull IconCompat iconCompat, @NonNull CharSequence charSequence, @NonNull CharSequence charSequence2, @NonNull PendingIntent pendingIntent) {
        this.f4217a = (IconCompat) t.i.g(iconCompat);
        this.f4218b = (CharSequence) t.i.g(charSequence);
        this.f4219c = (CharSequence) t.i.g(charSequence2);
        this.f4220d = (PendingIntent) t.i.g(pendingIntent);
        this.f4221e = true;
        this.f4222f = true;
    }

    public RemoteActionCompat() {
    }

    public RemoteActionCompat(@NonNull RemoteActionCompat remoteActionCompat) {
        t.i.g(remoteActionCompat);
        this.f4217a = remoteActionCompat.f4217a;
        this.f4218b = remoteActionCompat.f4218b;
        this.f4219c = remoteActionCompat.f4219c;
        this.f4220d = remoteActionCompat.f4220d;
        this.f4221e = remoteActionCompat.f4221e;
        this.f4222f = remoteActionCompat.f4222f;
    }
}
