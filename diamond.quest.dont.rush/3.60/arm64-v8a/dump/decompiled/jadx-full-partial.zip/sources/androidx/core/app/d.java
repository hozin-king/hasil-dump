package androidx.core.app;

import android.app.ActivityOptions;
import android.content.Context;
import android.os.Bundle;

/* loaded from: classes.dex */
public class d {

    private static class a extends d {

        /* renamed from: a, reason: collision with root package name */
        private final ActivityOptions f4226a;

        a(ActivityOptions activityOptions) {
            this.f4226a = activityOptions;
        }

        @Override // androidx.core.app.d
        public Bundle b() {
            return this.f4226a.toBundle();
        }
    }

    protected d() {
    }

    public static d a(Context context, int i5, int i6) {
        return new a(ActivityOptions.makeCustomAnimation(context, i5, i6));
    }

    public Bundle b() {
        return null;
    }
}
