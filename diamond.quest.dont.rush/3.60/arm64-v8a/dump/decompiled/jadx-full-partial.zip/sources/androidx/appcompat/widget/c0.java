package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;

/* loaded from: classes.dex */
public class c0 {

    /* renamed from: a, reason: collision with root package name */
    private static final ThreadLocal f3744a = new ThreadLocal();

    /* renamed from: b, reason: collision with root package name */
    static final int[] f3745b = {-16842910};

    /* renamed from: c, reason: collision with root package name */
    static final int[] f3746c = {R.attr.state_focused};

    /* renamed from: d, reason: collision with root package name */
    static final int[] f3747d = {R.attr.state_activated};

    /* renamed from: e, reason: collision with root package name */
    static final int[] f3748e = {R.attr.state_pressed};

    /* renamed from: f, reason: collision with root package name */
    static final int[] f3749f = {R.attr.state_checked};

    /* renamed from: g, reason: collision with root package name */
    static final int[] f3750g = {R.attr.state_selected};

    /* renamed from: h, reason: collision with root package name */
    static final int[] f3751h = {-16842919, -16842908};

    /* renamed from: i, reason: collision with root package name */
    static final int[] f3752i = new int[0];

    /* renamed from: j, reason: collision with root package name */
    private static final int[] f3753j = new int[1];

    private c0() {
    }

    public static void a(View view, Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(f.j.f54115y0);
        try {
            if (!obtainStyledAttributes.hasValue(f.j.f53888D0)) {
                Log.e("ThemeUtils", "View " + view.getClass() + " is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public static int b(Context context, int i5) {
        ColorStateList e5 = e(context, i5);
        if (e5 != null && e5.isStateful()) {
            return e5.getColorForState(f3745b, e5.getDefaultColor());
        }
        TypedValue f5 = f();
        context.getTheme().resolveAttribute(R.attr.disabledAlpha, f5, true);
        return d(context, i5, f5.getFloat());
    }

    public static int c(Context context, int i5) {
        int[] iArr = f3753j;
        iArr[0] = i5;
        g0 t5 = g0.t(context, null, iArr);
        try {
            return t5.b(0, 0);
        } finally {
            t5.w();
        }
    }

    static int d(Context context, int i5, float f5) {
        return androidx.core.graphics.a.g(c(context, i5), Math.round(Color.alpha(r0) * f5));
    }

    public static ColorStateList e(Context context, int i5) {
        int[] iArr = f3753j;
        iArr[0] = i5;
        g0 t5 = g0.t(context, null, iArr);
        try {
            return t5.c(0);
        } finally {
            t5.w();
        }
    }

    private static TypedValue f() {
        ThreadLocal threadLocal = f3744a;
        TypedValue typedValue = (TypedValue) threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }
}
