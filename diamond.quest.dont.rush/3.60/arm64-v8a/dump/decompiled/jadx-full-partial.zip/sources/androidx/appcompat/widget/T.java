package androidx.appcompat.widget;

import android.view.MenuItem;

/* loaded from: classes.dex */
public interface T {
    void a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem);

    void d(androidx.appcompat.view.menu.g gVar, MenuItem menuItem);
}
