package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.m;

/* loaded from: classes.dex */
public interface G {
    boolean a();

    boolean b();

    boolean c();

    boolean d();

    void e(Menu menu, m.a aVar);

    void f();

    boolean g();

    void k(int i5);

    void m();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
