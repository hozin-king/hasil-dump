package androidx.appcompat.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.SparseArray;
import com.badlogic.gdx.Input;

/* loaded from: classes.dex */
public class b extends Drawable implements Drawable.Callback {

    /* renamed from: b, reason: collision with root package name */
    private d f2870b;

    /* renamed from: c, reason: collision with root package name */
    private Rect f2871c;

    /* renamed from: d, reason: collision with root package name */
    private Drawable f2872d;

    /* renamed from: e, reason: collision with root package name */
    private Drawable f2873e;

    /* renamed from: g, reason: collision with root package name */
    private boolean f2875g;

    /* renamed from: i, reason: collision with root package name */
    private boolean f2877i;

    /* renamed from: j, reason: collision with root package name */
    private Runnable f2878j;

    /* renamed from: k, reason: collision with root package name */
    private long f2879k;

    /* renamed from: l, reason: collision with root package name */
    private long f2880l;

    /* renamed from: m, reason: collision with root package name */
    private c f2881m;

    /* renamed from: f, reason: collision with root package name */
    private int f2874f = 255;

    /* renamed from: h, reason: collision with root package name */
    private int f2876h = -1;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.a(true);
            b.this.invalidateSelf();
        }
    }

    /* renamed from: androidx.appcompat.graphics.drawable.b$b, reason: collision with other inner class name */
    private static class C0109b {
        public static boolean a(Drawable.ConstantState constantState) {
            return constantState.canApplyTheme();
        }

        public static void b(Drawable drawable, Outline outline) {
            drawable.getOutline(outline);
        }

        public static Resources c(Resources.Theme theme) {
            return theme.getResources();
        }
    }

    static class c implements Drawable.Callback {

        /* renamed from: b, reason: collision with root package name */
        private Drawable.Callback f2883b;

        c() {
        }

        public Drawable.Callback a() {
            Drawable.Callback callback = this.f2883b;
            this.f2883b = null;
            return callback;
        }

        public c b(Drawable.Callback callback) {
            this.f2883b = callback;
            return this;
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void invalidateDrawable(Drawable drawable) {
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j5) {
            Drawable.Callback callback = this.f2883b;
            if (callback != null) {
                callback.scheduleDrawable(drawable, runnable, j5);
            }
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            Drawable.Callback callback = this.f2883b;
            if (callback != null) {
                callback.unscheduleDrawable(drawable, runnable);
            }
        }
    }

    static abstract class d extends Drawable.ConstantState {

        /* renamed from: A, reason: collision with root package name */
        int f2884A;

        /* renamed from: B, reason: collision with root package name */
        int f2885B;

        /* renamed from: C, reason: collision with root package name */
        boolean f2886C;

        /* renamed from: D, reason: collision with root package name */
        ColorFilter f2887D;

        /* renamed from: E, reason: collision with root package name */
        boolean f2888E;

        /* renamed from: F, reason: collision with root package name */
        ColorStateList f2889F;

        /* renamed from: G, reason: collision with root package name */
        PorterDuff.Mode f2890G;

        /* renamed from: H, reason: collision with root package name */
        boolean f2891H;

        /* renamed from: I, reason: collision with root package name */
        boolean f2892I;

        /* renamed from: a, reason: collision with root package name */
        final b f2893a;

        /* renamed from: b, reason: collision with root package name */
        Resources f2894b;

        /* renamed from: c, reason: collision with root package name */
        int f2895c;

        /* renamed from: d, reason: collision with root package name */
        int f2896d;

        /* renamed from: e, reason: collision with root package name */
        int f2897e;

        /* renamed from: f, reason: collision with root package name */
        SparseArray f2898f;

        /* renamed from: g, reason: collision with root package name */
        Drawable[] f2899g;

        /* renamed from: h, reason: collision with root package name */
        int f2900h;

        /* renamed from: i, reason: collision with root package name */
        boolean f2901i;

        /* renamed from: j, reason: collision with root package name */
        boolean f2902j;

        /* renamed from: k, reason: collision with root package name */
        Rect f2903k;

        /* renamed from: l, reason: collision with root package name */
        boolean f2904l;

        /* renamed from: m, reason: collision with root package name */
        boolean f2905m;

        /* renamed from: n, reason: collision with root package name */
        int f2906n;

        /* renamed from: o, reason: collision with root package name */
        int f2907o;

        /* renamed from: p, reason: collision with root package name */
        int f2908p;

        /* renamed from: q, reason: collision with root package name */
        int f2909q;

        /* renamed from: r, reason: collision with root package name */
        boolean f2910r;

        /* renamed from: s, reason: collision with root package name */
        int f2911s;

        /* renamed from: t, reason: collision with root package name */
        boolean f2912t;

        /* renamed from: u, reason: collision with root package name */
        boolean f2913u;

        /* renamed from: v, reason: collision with root package name */
        boolean f2914v;

        /* renamed from: w, reason: collision with root package name */
        boolean f2915w;

        /* renamed from: x, reason: collision with root package name */
        boolean f2916x;

        /* renamed from: y, reason: collision with root package name */
        boolean f2917y;

        /* renamed from: z, reason: collision with root package name */
        int f2918z;

        d(d dVar, b bVar, Resources resources) {
            this.f2901i = false;
            this.f2904l = false;
            this.f2916x = true;
            this.f2884A = 0;
            this.f2885B = 0;
            this.f2893a = bVar;
            this.f2894b = resources != null ? resources : dVar != null ? dVar.f2894b : null;
            int f5 = b.f(resources, dVar != null ? dVar.f2895c : 0);
            this.f2895c = f5;
            if (dVar == null) {
                this.f2899g = new Drawable[10];
                this.f2900h = 0;
                return;
            }
            this.f2896d = dVar.f2896d;
            this.f2897e = dVar.f2897e;
            this.f2914v = true;
            this.f2915w = true;
            this.f2901i = dVar.f2901i;
            this.f2904l = dVar.f2904l;
            this.f2916x = dVar.f2916x;
            this.f2917y = dVar.f2917y;
            this.f2918z = dVar.f2918z;
            this.f2884A = dVar.f2884A;
            this.f2885B = dVar.f2885B;
            this.f2886C = dVar.f2886C;
            this.f2887D = dVar.f2887D;
            this.f2888E = dVar.f2888E;
            this.f2889F = dVar.f2889F;
            this.f2890G = dVar.f2890G;
            this.f2891H = dVar.f2891H;
            this.f2892I = dVar.f2892I;
            if (dVar.f2895c == f5) {
                if (dVar.f2902j) {
                    this.f2903k = dVar.f2903k != null ? new Rect(dVar.f2903k) : null;
                    this.f2902j = true;
                }
                if (dVar.f2905m) {
                    this.f2906n = dVar.f2906n;
                    this.f2907o = dVar.f2907o;
                    this.f2908p = dVar.f2908p;
                    this.f2909q = dVar.f2909q;
                    this.f2905m = true;
                }
            }
            if (dVar.f2910r) {
                this.f2911s = dVar.f2911s;
                this.f2910r = true;
            }
            if (dVar.f2912t) {
                this.f2913u = dVar.f2913u;
                this.f2912t = true;
            }
            Drawable[] drawableArr = dVar.f2899g;
            this.f2899g = new Drawable[drawableArr.length];
            this.f2900h = dVar.f2900h;
            SparseArray sparseArray = dVar.f2898f;
            if (sparseArray != null) {
                this.f2898f = sparseArray.clone();
            } else {
                this.f2898f = new SparseArray(this.f2900h);
            }
            int i5 = this.f2900h;
            for (int i6 = 0; i6 < i5; i6++) {
                Drawable drawable = drawableArr[i6];
                if (drawable != null) {
                    Drawable.ConstantState constantState = drawable.getConstantState();
                    if (constantState != null) {
                        this.f2898f.put(i6, constantState);
                    } else {
                        this.f2899g[i6] = drawableArr[i6];
                    }
                }
            }
        }

        private void e() {
            SparseArray sparseArray = this.f2898f;
            if (sparseArray != null) {
                int size = sparseArray.size();
                for (int i5 = 0; i5 < size; i5++) {
                    this.f2899g[this.f2898f.keyAt(i5)] = t(((Drawable.ConstantState) this.f2898f.valueAt(i5)).newDrawable(this.f2894b));
                }
                this.f2898f = null;
            }
        }

        private Drawable t(Drawable drawable) {
            androidx.core.graphics.drawable.a.l(drawable, this.f2918z);
            Drawable mutate = drawable.mutate();
            mutate.setCallback(this.f2893a);
            return mutate;
        }

        public final int a(Drawable drawable) {
            int i5 = this.f2900h;
            if (i5 >= this.f2899g.length) {
                o(i5, i5 + 10);
            }
            drawable.mutate();
            drawable.setVisible(false, true);
            drawable.setCallback(this.f2893a);
            this.f2899g[i5] = drawable;
            this.f2900h++;
            this.f2897e = drawable.getChangingConfigurations() | this.f2897e;
            p();
            this.f2903k = null;
            this.f2902j = false;
            this.f2905m = false;
            this.f2914v = false;
            return i5;
        }

        final void b(Resources.Theme theme) {
            if (theme != null) {
                e();
                int i5 = this.f2900h;
                Drawable[] drawableArr = this.f2899g;
                for (int i6 = 0; i6 < i5; i6++) {
                    Drawable drawable = drawableArr[i6];
                    if (drawable != null && androidx.core.graphics.drawable.a.b(drawable)) {
                        androidx.core.graphics.drawable.a.a(drawableArr[i6], theme);
                        this.f2897e |= drawableArr[i6].getChangingConfigurations();
                    }
                }
                z(C0109b.c(theme));
            }
        }

        public boolean c() {
            if (this.f2914v) {
                return this.f2915w;
            }
            e();
            this.f2914v = true;
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            for (int i6 = 0; i6 < i5; i6++) {
                if (drawableArr[i6].getConstantState() == null) {
                    this.f2915w = false;
                    return false;
                }
            }
            this.f2915w = true;
            return true;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            for (int i6 = 0; i6 < i5; i6++) {
                Drawable drawable = drawableArr[i6];
                if (drawable == null) {
                    Drawable.ConstantState constantState = (Drawable.ConstantState) this.f2898f.get(i6);
                    if (constantState != null && C0109b.a(constantState)) {
                        return true;
                    }
                } else if (androidx.core.graphics.drawable.a.b(drawable)) {
                    return true;
                }
            }
            return false;
        }

        protected void d() {
            this.f2905m = true;
            e();
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            this.f2907o = -1;
            this.f2906n = -1;
            this.f2909q = 0;
            this.f2908p = 0;
            for (int i6 = 0; i6 < i5; i6++) {
                Drawable drawable = drawableArr[i6];
                int intrinsicWidth = drawable.getIntrinsicWidth();
                if (intrinsicWidth > this.f2906n) {
                    this.f2906n = intrinsicWidth;
                }
                int intrinsicHeight = drawable.getIntrinsicHeight();
                if (intrinsicHeight > this.f2907o) {
                    this.f2907o = intrinsicHeight;
                }
                int minimumWidth = drawable.getMinimumWidth();
                if (minimumWidth > this.f2908p) {
                    this.f2908p = minimumWidth;
                }
                int minimumHeight = drawable.getMinimumHeight();
                if (minimumHeight > this.f2909q) {
                    this.f2909q = minimumHeight;
                }
            }
        }

        final int f() {
            return this.f2899g.length;
        }

        public final Drawable g(int i5) {
            int indexOfKey;
            Drawable drawable = this.f2899g[i5];
            if (drawable != null) {
                return drawable;
            }
            SparseArray sparseArray = this.f2898f;
            if (sparseArray == null || (indexOfKey = sparseArray.indexOfKey(i5)) < 0) {
                return null;
            }
            Drawable t5 = t(((Drawable.ConstantState) this.f2898f.valueAt(indexOfKey)).newDrawable(this.f2894b));
            this.f2899g[i5] = t5;
            this.f2898f.removeAt(indexOfKey);
            if (this.f2898f.size() == 0) {
                this.f2898f = null;
            }
            return t5;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f2896d | this.f2897e;
        }

        public final int h() {
            return this.f2900h;
        }

        public final int i() {
            if (!this.f2905m) {
                d();
            }
            return this.f2907o;
        }

        public final int j() {
            if (!this.f2905m) {
                d();
            }
            return this.f2909q;
        }

        public final int k() {
            if (!this.f2905m) {
                d();
            }
            return this.f2908p;
        }

        public final Rect l() {
            Rect rect = null;
            if (this.f2901i) {
                return null;
            }
            Rect rect2 = this.f2903k;
            if (rect2 != null || this.f2902j) {
                return rect2;
            }
            e();
            Rect rect3 = new Rect();
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            for (int i6 = 0; i6 < i5; i6++) {
                if (drawableArr[i6].getPadding(rect3)) {
                    if (rect == null) {
                        rect = new Rect(0, 0, 0, 0);
                    }
                    int i7 = rect3.left;
                    if (i7 > rect.left) {
                        rect.left = i7;
                    }
                    int i8 = rect3.top;
                    if (i8 > rect.top) {
                        rect.top = i8;
                    }
                    int i9 = rect3.right;
                    if (i9 > rect.right) {
                        rect.right = i9;
                    }
                    int i10 = rect3.bottom;
                    if (i10 > rect.bottom) {
                        rect.bottom = i10;
                    }
                }
            }
            this.f2902j = true;
            this.f2903k = rect;
            return rect;
        }

        public final int m() {
            if (!this.f2905m) {
                d();
            }
            return this.f2906n;
        }

        public final int n() {
            if (this.f2910r) {
                return this.f2911s;
            }
            e();
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            int opacity = i5 > 0 ? drawableArr[0].getOpacity() : -2;
            for (int i6 = 1; i6 < i5; i6++) {
                opacity = Drawable.resolveOpacity(opacity, drawableArr[i6].getOpacity());
            }
            this.f2911s = opacity;
            this.f2910r = true;
            return opacity;
        }

        public void o(int i5, int i6) {
            Drawable[] drawableArr = new Drawable[i6];
            Drawable[] drawableArr2 = this.f2899g;
            if (drawableArr2 != null) {
                System.arraycopy(drawableArr2, 0, drawableArr, 0, i5);
            }
            this.f2899g = drawableArr;
        }

        void p() {
            this.f2910r = false;
            this.f2912t = false;
        }

        public final boolean q() {
            return this.f2904l;
        }

        public final boolean r() {
            if (this.f2912t) {
                return this.f2913u;
            }
            e();
            int i5 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            boolean z4 = false;
            int i6 = 0;
            while (true) {
                if (i6 >= i5) {
                    break;
                }
                if (drawableArr[i6].isStateful()) {
                    z4 = true;
                    break;
                }
                i6++;
            }
            this.f2913u = z4;
            this.f2912t = true;
            return z4;
        }

        abstract void s();

        public final void u(boolean z4) {
            this.f2904l = z4;
        }

        public final void v(int i5) {
            this.f2884A = i5;
        }

        public final void w(int i5) {
            this.f2885B = i5;
        }

        final boolean x(int i5, int i6) {
            int i7 = this.f2900h;
            Drawable[] drawableArr = this.f2899g;
            boolean z4 = false;
            for (int i8 = 0; i8 < i7; i8++) {
                Drawable drawable = drawableArr[i8];
                if (drawable != null) {
                    boolean l5 = androidx.core.graphics.drawable.a.l(drawable, i5);
                    if (i8 == i6) {
                        z4 = l5;
                    }
                }
            }
            this.f2918z = i5;
            return z4;
        }

        public final void y(boolean z4) {
            this.f2901i = z4;
        }

        final void z(Resources resources) {
            if (resources != null) {
                this.f2894b = resources;
                int f5 = b.f(resources, this.f2895c);
                int i5 = this.f2895c;
                this.f2895c = f5;
                if (i5 != f5) {
                    this.f2905m = false;
                    this.f2902j = false;
                }
            }
        }
    }

    private void d(Drawable drawable) {
        if (this.f2881m == null) {
            this.f2881m = new c();
        }
        drawable.setCallback(this.f2881m.b(drawable.getCallback()));
        try {
            if (this.f2870b.f2884A <= 0 && this.f2875g) {
                drawable.setAlpha(this.f2874f);
            }
            d dVar = this.f2870b;
            if (dVar.f2888E) {
                drawable.setColorFilter(dVar.f2887D);
            } else {
                if (dVar.f2891H) {
                    androidx.core.graphics.drawable.a.n(drawable, dVar.f2889F);
                }
                d dVar2 = this.f2870b;
                if (dVar2.f2892I) {
                    androidx.core.graphics.drawable.a.o(drawable, dVar2.f2890G);
                }
            }
            drawable.setVisible(isVisible(), true);
            drawable.setDither(this.f2870b.f2916x);
            drawable.setState(getState());
            drawable.setLevel(getLevel());
            drawable.setBounds(getBounds());
            androidx.core.graphics.drawable.a.l(drawable, androidx.core.graphics.drawable.a.e(this));
            androidx.core.graphics.drawable.a.i(drawable, this.f2870b.f2886C);
            Rect rect = this.f2871c;
            if (rect != null) {
                androidx.core.graphics.drawable.a.k(drawable, rect.left, rect.top, rect.right, rect.bottom);
            }
            drawable.setCallback(this.f2881m.a());
        } catch (Throwable th) {
            drawable.setCallback(this.f2881m.a());
            throw th;
        }
    }

    private boolean e() {
        return isAutoMirrored() && androidx.core.graphics.drawable.a.e(this) == 1;
    }

    static int f(Resources resources, int i5) {
        if (resources != null) {
            i5 = resources.getDisplayMetrics().densityDpi;
        }
        return i5 == 0 ? Input.Keys.NUMPAD_ENTER : i5;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0066 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0061  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void a(boolean r14) {
        /*
            r13 = this;
            r0 = 1
            r13.f2875g = r0
            long r1 = android.os.SystemClock.uptimeMillis()
            android.graphics.drawable.Drawable r3 = r13.f2872d
            r4 = 255(0xff, double:1.26E-321)
            r6 = 0
            r8 = 0
            if (r3 == 0) goto L36
            long r9 = r13.f2879k
            int r11 = (r9 > r6 ? 1 : (r9 == r6 ? 0 : -1))
            if (r11 == 0) goto L38
            int r11 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r11 > 0) goto L22
            int r9 = r13.f2874f
            r3.setAlpha(r9)
            r13.f2879k = r6
            goto L38
        L22:
            long r9 = r9 - r1
            long r9 = r9 * r4
            int r9 = (int) r9
            androidx.appcompat.graphics.drawable.b$d r10 = r13.f2870b
            int r10 = r10.f2884A
            int r9 = r9 / r10
            int r9 = 255 - r9
            int r10 = r13.f2874f
            int r9 = r9 * r10
            int r9 = r9 / 255
            r3.setAlpha(r9)
            r3 = r0
            goto L39
        L36:
            r13.f2879k = r6
        L38:
            r3 = r8
        L39:
            android.graphics.drawable.Drawable r9 = r13.f2873e
            if (r9 == 0) goto L61
            long r10 = r13.f2880l
            int r12 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
            if (r12 == 0) goto L63
            int r12 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r12 > 0) goto L50
            r9.setVisible(r8, r8)
            r0 = 0
            r13.f2873e = r0
            r13.f2880l = r6
            goto L63
        L50:
            long r10 = r10 - r1
            long r10 = r10 * r4
            int r3 = (int) r10
            androidx.appcompat.graphics.drawable.b$d r4 = r13.f2870b
            int r4 = r4.f2885B
            int r3 = r3 / r4
            int r4 = r13.f2874f
            int r3 = r3 * r4
            int r3 = r3 / 255
            r9.setAlpha(r3)
            goto L64
        L61:
            r13.f2880l = r6
        L63:
            r0 = r3
        L64:
            if (r14 == 0) goto L70
            if (r0 == 0) goto L70
            java.lang.Runnable r14 = r13.f2878j
            r3 = 16
            long r1 = r1 + r3
            r13.scheduleSelf(r14, r1)
        L70:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.graphics.drawable.b.a(boolean):void");
    }

    @Override // android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        this.f2870b.b(theme);
    }

    d b() {
        return this.f2870b;
    }

    int c() {
        return this.f2876h;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        return this.f2870b.canApplyTheme();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            drawable.draw(canvas);
        }
        Drawable drawable2 = this.f2873e;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0073  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    boolean g(int r10) {
        /*
            r9 = this;
            int r0 = r9.f2876h
            r1 = 0
            if (r10 != r0) goto L6
            return r1
        L6:
            long r2 = android.os.SystemClock.uptimeMillis()
            androidx.appcompat.graphics.drawable.b$d r0 = r9.f2870b
            int r0 = r0.f2885B
            r4 = 0
            r5 = 0
            if (r0 <= 0) goto L2e
            android.graphics.drawable.Drawable r0 = r9.f2873e
            if (r0 == 0) goto L1a
            r0.setVisible(r1, r1)
        L1a:
            android.graphics.drawable.Drawable r0 = r9.f2872d
            if (r0 == 0) goto L29
            r9.f2873e = r0
            androidx.appcompat.graphics.drawable.b$d r0 = r9.f2870b
            int r0 = r0.f2885B
            long r0 = (long) r0
            long r0 = r0 + r2
            r9.f2880l = r0
            goto L35
        L29:
            r9.f2873e = r4
            r9.f2880l = r5
            goto L35
        L2e:
            android.graphics.drawable.Drawable r0 = r9.f2872d
            if (r0 == 0) goto L35
            r0.setVisible(r1, r1)
        L35:
            if (r10 < 0) goto L55
            androidx.appcompat.graphics.drawable.b$d r0 = r9.f2870b
            int r1 = r0.f2900h
            if (r10 >= r1) goto L55
            android.graphics.drawable.Drawable r0 = r0.g(r10)
            r9.f2872d = r0
            r9.f2876h = r10
            if (r0 == 0) goto L5a
            androidx.appcompat.graphics.drawable.b$d r10 = r9.f2870b
            int r10 = r10.f2884A
            if (r10 <= 0) goto L51
            long r7 = (long) r10
            long r2 = r2 + r7
            r9.f2879k = r2
        L51:
            r9.d(r0)
            goto L5a
        L55:
            r9.f2872d = r4
            r10 = -1
            r9.f2876h = r10
        L5a:
            long r0 = r9.f2879k
            int r10 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            r0 = 1
            if (r10 != 0) goto L67
            long r1 = r9.f2880l
            int r10 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r10 == 0) goto L79
        L67:
            java.lang.Runnable r10 = r9.f2878j
            if (r10 != 0) goto L73
            androidx.appcompat.graphics.drawable.b$a r10 = new androidx.appcompat.graphics.drawable.b$a
            r10.<init>()
            r9.f2878j = r10
            goto L76
        L73:
            r9.unscheduleSelf(r10)
        L76:
            r9.a(r0)
        L79:
            r9.invalidateSelf()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.graphics.drawable.b.g(int):boolean");
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.f2874f;
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.f2870b.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public final Drawable.ConstantState getConstantState() {
        if (!this.f2870b.c()) {
            return null;
        }
        this.f2870b.f2896d = getChangingConfigurations();
        return this.f2870b;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable getCurrent() {
        return this.f2872d;
    }

    @Override // android.graphics.drawable.Drawable
    public void getHotspotBounds(Rect rect) {
        Rect rect2 = this.f2871c;
        if (rect2 != null) {
            rect.set(rect2);
        } else {
            super.getHotspotBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        if (this.f2870b.q()) {
            return this.f2870b.i();
        }
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        if (this.f2870b.q()) {
            return this.f2870b.m();
        }
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumHeight() {
        if (this.f2870b.q()) {
            return this.f2870b.j();
        }
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            return drawable.getMinimumHeight();
        }
        return 0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumWidth() {
        if (this.f2870b.q()) {
            return this.f2870b.k();
        }
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            return drawable.getMinimumWidth();
        }
        return 0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f2872d;
        if (drawable == null || !drawable.isVisible()) {
            return -2;
        }
        return this.f2870b.n();
    }

    @Override // android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            C0109b.b(drawable, outline);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        boolean padding;
        Rect l5 = this.f2870b.l();
        if (l5 != null) {
            rect.set(l5);
            padding = (l5.right | ((l5.left | l5.top) | l5.bottom)) != 0;
        } else {
            Drawable drawable = this.f2872d;
            padding = drawable != null ? drawable.getPadding(rect) : super.getPadding(rect);
        }
        if (e()) {
            int i5 = rect.left;
            rect.left = rect.right;
            rect.right = i5;
        }
        return padding;
    }

    void h(d dVar) {
        this.f2870b = dVar;
        int i5 = this.f2876h;
        if (i5 >= 0) {
            Drawable g5 = dVar.g(i5);
            this.f2872d = g5;
            if (g5 != null) {
                d(g5);
            }
        }
        this.f2873e = null;
    }

    final void i(Resources resources) {
        this.f2870b.z(resources);
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void invalidateDrawable(Drawable drawable) {
        d dVar = this.f2870b;
        if (dVar != null) {
            dVar.p();
        }
        if (drawable != this.f2872d || getCallback() == null) {
            return;
        }
        getCallback().invalidateDrawable(this);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        return this.f2870b.f2886C;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        return this.f2870b.r();
    }

    @Override // android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        boolean z4;
        Drawable drawable = this.f2873e;
        boolean z5 = true;
        if (drawable != null) {
            drawable.jumpToCurrentState();
            this.f2873e = null;
            z4 = true;
        } else {
            z4 = false;
        }
        Drawable drawable2 = this.f2872d;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
            if (this.f2875g) {
                this.f2872d.setAlpha(this.f2874f);
            }
        }
        if (this.f2880l != 0) {
            this.f2880l = 0L;
            z4 = true;
        }
        if (this.f2879k != 0) {
            this.f2879k = 0L;
        } else {
            z5 = z4;
        }
        if (z5) {
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.f2877i && super.mutate() == this) {
            d b5 = b();
            b5.s();
            h(b5);
            this.f2877i = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2873e;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
        Drawable drawable2 = this.f2872d;
        if (drawable2 != null) {
            drawable2.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLayoutDirectionChanged(int i5) {
        return this.f2870b.x(i5, c());
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onLevelChange(int i5) {
        Drawable drawable = this.f2873e;
        if (drawable != null) {
            return drawable.setLevel(i5);
        }
        Drawable drawable2 = this.f2872d;
        if (drawable2 != null) {
            return drawable2.setLevel(i5);
        }
        return false;
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f2873e;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        Drawable drawable2 = this.f2872d;
        if (drawable2 != null) {
            return drawable2.setState(iArr);
        }
        return false;
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j5) {
        if (drawable != this.f2872d || getCallback() == null) {
            return;
        }
        getCallback().scheduleDrawable(this, runnable, j5);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i5) {
        if (this.f2875g && this.f2874f == i5) {
            return;
        }
        this.f2875g = true;
        this.f2874f = i5;
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            if (this.f2879k == 0) {
                drawable.setAlpha(i5);
            } else {
                a(false);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z4) {
        d dVar = this.f2870b;
        if (dVar.f2886C != z4) {
            dVar.f2886C = z4;
            Drawable drawable = this.f2872d;
            if (drawable != null) {
                androidx.core.graphics.drawable.a.i(drawable, z4);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        d dVar = this.f2870b;
        dVar.f2888E = true;
        if (dVar.f2887D != colorFilter) {
            dVar.f2887D = colorFilter;
            Drawable drawable = this.f2872d;
            if (drawable != null) {
                drawable.setColorFilter(colorFilter);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setDither(boolean z4) {
        d dVar = this.f2870b;
        if (dVar.f2916x != z4) {
            dVar.f2916x = z4;
            Drawable drawable = this.f2872d;
            if (drawable != null) {
                drawable.setDither(z4);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setHotspot(float f5, float f6) {
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.j(drawable, f5, f6);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setHotspotBounds(int i5, int i6, int i7, int i8) {
        Rect rect = this.f2871c;
        if (rect == null) {
            this.f2871c = new Rect(i5, i6, i7, i8);
        } else {
            rect.set(i5, i6, i7, i8);
        }
        Drawable drawable = this.f2872d;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.k(drawable, i5, i6, i7, i8);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i5) {
        setTintList(ColorStateList.valueOf(i5));
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        d dVar = this.f2870b;
        dVar.f2891H = true;
        if (dVar.f2889F != colorStateList) {
            dVar.f2889F = colorStateList;
            androidx.core.graphics.drawable.a.n(this.f2872d, colorStateList);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        d dVar = this.f2870b;
        dVar.f2892I = true;
        if (dVar.f2890G != mode) {
            dVar.f2890G = mode;
            androidx.core.graphics.drawable.a.o(this.f2872d, mode);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z4, boolean z5) {
        boolean visible = super.setVisible(z4, z5);
        Drawable drawable = this.f2873e;
        if (drawable != null) {
            drawable.setVisible(z4, z5);
        }
        Drawable drawable2 = this.f2872d;
        if (drawable2 != null) {
            drawable2.setVisible(z4, z5);
        }
        return visible;
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        if (drawable != this.f2872d || getCallback() == null) {
            return;
        }
        getCallback().unscheduleDrawable(this, runnable);
    }
}
