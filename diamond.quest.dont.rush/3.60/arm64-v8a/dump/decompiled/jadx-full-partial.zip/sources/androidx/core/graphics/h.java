package androidx.core.graphics;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.core.content.res.e;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Map;
import s.k;

/* loaded from: classes.dex */
public class h extends f {

    /* renamed from: g, reason: collision with root package name */
    protected final Class f4391g;

    /* renamed from: h, reason: collision with root package name */
    protected final Constructor f4392h;

    /* renamed from: i, reason: collision with root package name */
    protected final Method f4393i;

    /* renamed from: j, reason: collision with root package name */
    protected final Method f4394j;

    /* renamed from: k, reason: collision with root package name */
    protected final Method f4395k;

    /* renamed from: l, reason: collision with root package name */
    protected final Method f4396l;

    /* renamed from: m, reason: collision with root package name */
    protected final Method f4397m;

    public h() {
        Class cls;
        Constructor constructor;
        Method method;
        Method method2;
        Method method3;
        Method method4;
        Method method5;
        try {
            cls = v();
            constructor = w(cls);
            method = s(cls);
            method2 = t(cls);
            method3 = x(cls);
            method4 = r(cls);
            method5 = u(cls);
        } catch (ClassNotFoundException | NoSuchMethodException e5) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class " + e5.getClass().getName(), e5);
            cls = null;
            constructor = null;
            method = null;
            method2 = null;
            method3 = null;
            method4 = null;
            method5 = null;
        }
        this.f4391g = cls;
        this.f4392h = constructor;
        this.f4393i = method;
        this.f4394j = method2;
        this.f4395k = method3;
        this.f4396l = method4;
        this.f4397m = method5;
    }

    private Object l() {
        try {
            return this.f4392h.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            return null;
        }
    }

    private void m(Object obj) {
        try {
            this.f4396l.invoke(obj, null);
        } catch (IllegalAccessException | InvocationTargetException unused) {
        }
    }

    private boolean n(Context context, Object obj, String str, int i5, int i6, int i7, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f4393i.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i5), Integer.valueOf(i6), Integer.valueOf(i7), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    private boolean o(Object obj, ByteBuffer byteBuffer, int i5, int i6, int i7) {
        try {
            return ((Boolean) this.f4394j.invoke(obj, byteBuffer, Integer.valueOf(i5), null, Integer.valueOf(i6), Integer.valueOf(i7))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    private boolean p(Object obj) {
        try {
            return ((Boolean) this.f4395k.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    private boolean q() {
        if (this.f4393i == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.f4393i != null;
    }

    @Override // androidx.core.graphics.f, androidx.core.graphics.k
    public Typeface a(Context context, e.c cVar, Resources resources, int i5) {
        if (!q()) {
            return super.a(context, cVar, resources, i5);
        }
        Object l5 = l();
        if (l5 == null) {
            return null;
        }
        e.d[] a5 = cVar.a();
        int length = a5.length;
        int i6 = 0;
        while (i6 < length) {
            e.d dVar = a5[i6];
            Context context2 = context;
            if (!n(context2, l5, dVar.a(), dVar.c(), dVar.e(), dVar.f() ? 1 : 0, FontVariationAxis.fromFontVariationSettings(dVar.d()))) {
                m(l5);
                return null;
            }
            i6++;
            context = context2;
        }
        if (p(l5)) {
            return i(l5);
        }
        return null;
    }

    @Override // androidx.core.graphics.f, androidx.core.graphics.k
    public Typeface b(Context context, CancellationSignal cancellationSignal, k.b[] bVarArr, int i5) {
        Typeface i6;
        Object obj;
        if (bVarArr.length < 1) {
            return null;
        }
        if (q()) {
            Map h5 = l.h(context, bVarArr, cancellationSignal);
            Object l5 = l();
            if (l5 == null) {
                return null;
            }
            int length = bVarArr.length;
            int i7 = 0;
            boolean z4 = false;
            while (i7 < length) {
                k.b bVar = bVarArr[i7];
                ByteBuffer byteBuffer = (ByteBuffer) h5.get(bVar.d());
                if (byteBuffer == null) {
                    obj = l5;
                } else {
                    boolean o5 = o(l5, byteBuffer, bVar.c(), bVar.e(), bVar.f() ? 1 : 0);
                    obj = l5;
                    if (!o5) {
                        m(obj);
                        return null;
                    }
                    z4 = true;
                }
                i7++;
                l5 = obj;
                z4 = z4;
            }
            Object obj2 = l5;
            if (!z4) {
                m(obj2);
                return null;
            }
            if (p(obj2) && (i6 = i(obj2)) != null) {
                return Typeface.create(i6, i5);
            }
            return null;
        }
        k.b g5 = g(bVarArr, i5);
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(g5.d(), "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            try {
                Typeface build = new Typeface.Builder(openFileDescriptor.getFileDescriptor()).setWeight(g5.e()).setItalic(g5.f()).build();
                openFileDescriptor.close();
                return build;
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    @Override // androidx.core.graphics.k
    public Typeface d(Context context, Resources resources, int i5, String str, int i6) {
        if (!q()) {
            return super.d(context, resources, i5, str, i6);
        }
        Object l5 = l();
        if (l5 == null) {
            return null;
        }
        if (!n(context, l5, str, 0, -1, -1, null)) {
            m(l5);
            return null;
        }
        if (p(l5)) {
            return i(l5);
        }
        return null;
    }

    protected Typeface i(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) this.f4391g, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.f4397m.invoke(null, newInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    protected Method r(Class cls) {
        return cls.getMethod("abortCreation", null);
    }

    protected Method s(Class cls) {
        Class<?> cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls2, Boolean.TYPE, cls2, cls2, cls2, FontVariationAxis[].class);
    }

    protected Method t(Class cls) {
        Class<?> cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromBuffer", ByteBuffer.class, cls2, FontVariationAxis[].class, cls2, cls2);
    }

    protected Method u(Class cls) {
        Class cls2 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", Array.newInstance((Class<?>) cls, 1).getClass(), cls2, cls2);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    protected Class v() {
        return Class.forName("android.graphics.FontFamily");
    }

    protected Constructor w(Class cls) {
        return cls.getConstructor(null);
    }

    protected Method x(Class cls) {
        return cls.getMethod("freeze", null);
    }
}
