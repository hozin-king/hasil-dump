package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.core.content.res.h;
import g.C5008a;

/* loaded from: classes.dex */
public class g0 {

    /* renamed from: a, reason: collision with root package name */
    private final Context f3780a;

    /* renamed from: b, reason: collision with root package name */
    private final TypedArray f3781b;

    /* renamed from: c, reason: collision with root package name */
    private TypedValue f3782c;

    private g0(Context context, TypedArray typedArray) {
        this.f3780a = context;
        this.f3781b = typedArray;
    }

    public static g0 s(Context context, int i5, int[] iArr) {
        return new g0(context, context.obtainStyledAttributes(i5, iArr));
    }

    public static g0 t(Context context, AttributeSet attributeSet, int[] iArr) {
        return new g0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static g0 u(Context context, AttributeSet attributeSet, int[] iArr, int i5, int i6) {
        return new g0(context, context.obtainStyledAttributes(attributeSet, iArr, i5, i6));
    }

    public boolean a(int i5, boolean z4) {
        return this.f3781b.getBoolean(i5, z4);
    }

    public int b(int i5, int i6) {
        return this.f3781b.getColor(i5, i6);
    }

    public ColorStateList c(int i5) {
        int resourceId;
        ColorStateList a5;
        return (!this.f3781b.hasValue(i5) || (resourceId = this.f3781b.getResourceId(i5, 0)) == 0 || (a5 = C5008a.a(this.f3780a, resourceId)) == null) ? this.f3781b.getColorStateList(i5) : a5;
    }

    public int d(int i5, int i6) {
        return this.f3781b.getDimensionPixelOffset(i5, i6);
    }

    public int e(int i5, int i6) {
        return this.f3781b.getDimensionPixelSize(i5, i6);
    }

    public Drawable f(int i5) {
        int resourceId;
        return (!this.f3781b.hasValue(i5) || (resourceId = this.f3781b.getResourceId(i5, 0)) == 0) ? this.f3781b.getDrawable(i5) : C5008a.b(this.f3780a, resourceId);
    }

    public Drawable g(int i5) {
        int resourceId;
        if (!this.f3781b.hasValue(i5) || (resourceId = this.f3781b.getResourceId(i5, 0)) == 0) {
            return null;
        }
        return C0992k.b().d(this.f3780a, resourceId, true);
    }

    public float h(int i5, float f5) {
        return this.f3781b.getFloat(i5, f5);
    }

    public Typeface i(int i5, int i6, h.e eVar) {
        int resourceId = this.f3781b.getResourceId(i5, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f3782c == null) {
            this.f3782c = new TypedValue();
        }
        return androidx.core.content.res.h.g(this.f3780a, resourceId, this.f3782c, i6, eVar);
    }

    public int j(int i5, int i6) {
        return this.f3781b.getInt(i5, i6);
    }

    public int k(int i5, int i6) {
        return this.f3781b.getInteger(i5, i6);
    }

    public int l(int i5, int i6) {
        return this.f3781b.getLayoutDimension(i5, i6);
    }

    public int m(int i5, int i6) {
        return this.f3781b.getResourceId(i5, i6);
    }

    public String n(int i5) {
        return this.f3781b.getString(i5);
    }

    public CharSequence o(int i5) {
        return this.f3781b.getText(i5);
    }

    public CharSequence[] p(int i5) {
        return this.f3781b.getTextArray(i5);
    }

    public TypedArray q() {
        return this.f3781b;
    }

    public boolean r(int i5) {
        return this.f3781b.hasValue(i5);
    }

    public TypedValue v(int i5) {
        return this.f3781b.peekValue(i5);
    }

    public void w() {
        this.f3781b.recycle();
    }
}
