package androidx.core.graphics;

import android.graphics.Insets;
import android.graphics.Rect;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: e, reason: collision with root package name */
    public static final b f4358e = new b(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f4359a;

    /* renamed from: b, reason: collision with root package name */
    public final int f4360b;

    /* renamed from: c, reason: collision with root package name */
    public final int f4361c;

    /* renamed from: d, reason: collision with root package name */
    public final int f4362d;

    static class a {
        static Insets a(int i5, int i6, int i7, int i8) {
            return Insets.of(i5, i6, i7, i8);
        }
    }

    private b(int i5, int i6, int i7, int i8) {
        this.f4359a = i5;
        this.f4360b = i6;
        this.f4361c = i7;
        this.f4362d = i8;
    }

    public static b a(b bVar, b bVar2) {
        return b(Math.max(bVar.f4359a, bVar2.f4359a), Math.max(bVar.f4360b, bVar2.f4360b), Math.max(bVar.f4361c, bVar2.f4361c), Math.max(bVar.f4362d, bVar2.f4362d));
    }

    public static b b(int i5, int i6, int i7, int i8) {
        return (i5 == 0 && i6 == 0 && i7 == 0 && i8 == 0) ? f4358e : new b(i5, i6, i7, i8);
    }

    public static b c(Rect rect) {
        return b(rect.left, rect.top, rect.right, rect.bottom);
    }

    public static b d(Insets insets) {
        int i5;
        int i6;
        int i7;
        int i8;
        i5 = insets.left;
        i6 = insets.top;
        i7 = insets.right;
        i8 = insets.bottom;
        return b(i5, i6, i7, i8);
    }

    public Insets e() {
        return a.a(this.f4359a, this.f4360b, this.f4361c, this.f4362d);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        return this.f4362d == bVar.f4362d && this.f4359a == bVar.f4359a && this.f4361c == bVar.f4361c && this.f4360b == bVar.f4360b;
    }

    public int hashCode() {
        return (((((this.f4359a * 31) + this.f4360b) * 31) + this.f4361c) * 31) + this.f4362d;
    }

    public String toString() {
        return "Insets{left=" + this.f4359a + ", top=" + this.f4360b + ", right=" + this.f4361c + ", bottom=" + this.f4362d + '}';
    }
}
