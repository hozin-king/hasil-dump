package androidx.activity;

import K3.H;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: a, reason: collision with root package name */
    private final Executor f2531a;

    /* renamed from: b, reason: collision with root package name */
    private final U3.a f2532b;

    /* renamed from: c, reason: collision with root package name */
    private final Object f2533c;

    /* renamed from: d, reason: collision with root package name */
    private int f2534d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f2535e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f2536f;

    /* renamed from: g, reason: collision with root package name */
    private final List f2537g;

    /* renamed from: h, reason: collision with root package name */
    private final Runnable f2538h;

    public s(Executor executor, U3.a reportFullyDrawn) {
        C7150s.j(executor, "executor");
        C7150s.j(reportFullyDrawn, "reportFullyDrawn");
        this.f2531a = executor;
        this.f2532b = reportFullyDrawn;
        this.f2533c = new Object();
        this.f2537g = new ArrayList();
        this.f2538h = new Runnable() { // from class: androidx.activity.r
            @Override // java.lang.Runnable
            public final void run() {
                s.d(s.this);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(s this$0) {
        C7150s.j(this$0, "this$0");
        synchronized (this$0.f2533c) {
            try {
                this$0.f2535e = false;
                if (this$0.f2534d == 0 && !this$0.f2536f) {
                    this$0.f2532b.invoke();
                    this$0.b();
                }
                H h5 = H.f1374a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.f2533c) {
            try {
                this.f2536f = true;
                Iterator it = this.f2537g.iterator();
                while (it.hasNext()) {
                    ((U3.a) it.next()).invoke();
                }
                this.f2537g.clear();
                H h5 = H.f1374a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean c() {
        boolean z4;
        synchronized (this.f2533c) {
            z4 = this.f2536f;
        }
        return z4;
    }
}
