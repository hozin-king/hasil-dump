package androidx.appcompat.app;

/* loaded from: classes.dex */
class E {

    /* renamed from: d, reason: collision with root package name */
    private static E f2670d;

    /* renamed from: a, reason: collision with root package name */
    public long f2671a;

    /* renamed from: b, reason: collision with root package name */
    public long f2672b;

    /* renamed from: c, reason: collision with root package name */
    public int f2673c;

    E() {
    }

    static E b() {
        if (f2670d == null) {
            f2670d = new E();
        }
        return f2670d;
    }

    public void a(long j5, double d5, double d6) {
        double d7 = (0.01720197f * ((j5 - 946728000000L) / 8.64E7f)) + 6.24006f;
        double sin = (Math.sin(d7) * 0.03341960161924362d) + d7 + (Math.sin(2.0f * r3) * 3.4906598739326E-4d) + (Math.sin(r3 * 3.0f) * 5.236000106378924E-6d) + 1.796593063d + 3.141592653589793d;
        double round = Math.round((r2 - 9.0E-4f) - r6) + 9.0E-4f + ((-d6) / 360.0d) + (Math.sin(d7) * 0.0053d) + (Math.sin(2.0d * sin) * (-0.0069d));
        double asin = Math.asin(Math.sin(sin) * Math.sin(0.4092797040939331d));
        double d8 = 0.01745329238474369d * d5;
        double sin2 = (Math.sin(-0.10471975803375244d) - (Math.sin(d8) * Math.sin(asin))) / (Math.cos(d8) * Math.cos(asin));
        if (sin2 >= 1.0d) {
            this.f2673c = 1;
            this.f2671a = -1L;
            this.f2672b = -1L;
        } else {
            if (sin2 <= -1.0d) {
                this.f2673c = 0;
                this.f2671a = -1L;
                this.f2672b = -1L;
                return;
            }
            double acos = (float) (Math.acos(sin2) / 6.283185307179586d);
            this.f2671a = Math.round((round + acos) * 8.64E7d) + 946728000000L;
            long round2 = Math.round((round - acos) * 8.64E7d) + 946728000000L;
            this.f2672b = round2;
            if (round2 >= j5 || this.f2671a <= j5) {
                this.f2673c = 1;
            } else {
                this.f2673c = 0;
            }
        }
    }
}
