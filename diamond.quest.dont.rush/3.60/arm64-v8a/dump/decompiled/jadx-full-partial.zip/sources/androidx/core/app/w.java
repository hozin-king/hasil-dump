package androidx.core.app;

/* loaded from: classes.dex */
public interface w {
    void addOnPictureInPictureModeChangedListener(t.b bVar);

    void removeOnPictureInPictureModeChangedListener(t.b bVar);
}
