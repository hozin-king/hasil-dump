package androidx.core.app;

import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/* loaded from: classes.dex */
abstract class e {

    /* renamed from: a, reason: collision with root package name */
    protected static final Class f4227a;

    /* renamed from: b, reason: collision with root package name */
    protected static final Field f4228b;

    /* renamed from: c, reason: collision with root package name */
    protected static final Field f4229c;

    /* renamed from: d, reason: collision with root package name */
    protected static final Method f4230d;

    /* renamed from: e, reason: collision with root package name */
    protected static final Method f4231e;

    /* renamed from: f, reason: collision with root package name */
    protected static final Method f4232f;

    /* renamed from: g, reason: collision with root package name */
    private static final Handler f4233g = new Handler(Looper.getMainLooper());

    class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ d f4234b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ Object f4235c;

        a(d dVar, Object obj) {
            this.f4234b = dVar;
            this.f4235c = obj;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f4234b.f4240b = this.f4235c;
        }
    }

    class b implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Application f4236b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ d f4237c;

        b(Application application, d dVar) {
            this.f4236b = application;
            this.f4237c = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f4236b.unregisterActivityLifecycleCallbacks(this.f4237c);
        }
    }

    class c implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Object f4238b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ Object f4239c;

        c(Object obj, Object obj2) {
            this.f4238b = obj;
            this.f4239c = obj2;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Method method = e.f4230d;
                if (method != null) {
                    method.invoke(this.f4238b, this.f4239c, Boolean.FALSE, "AppCompat recreation");
                } else {
                    e.f4231e.invoke(this.f4238b, this.f4239c, Boolean.FALSE);
                }
            } catch (RuntimeException e5) {
                if (e5.getClass() == RuntimeException.class && e5.getMessage() != null && e5.getMessage().startsWith("Unable to stop")) {
                    throw e5;
                }
            } catch (Throwable th) {
                Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
            }
        }
    }

    private static final class d implements Application.ActivityLifecycleCallbacks {

        /* renamed from: b, reason: collision with root package name */
        Object f4240b;

        /* renamed from: c, reason: collision with root package name */
        private Activity f4241c;

        /* renamed from: d, reason: collision with root package name */
        private final int f4242d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f4243e = false;

        /* renamed from: f, reason: collision with root package name */
        private boolean f4244f = false;

        /* renamed from: g, reason: collision with root package name */
        private boolean f4245g = false;

        d(Activity activity) {
            this.f4241c = activity;
            this.f4242d = activity.hashCode();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            if (this.f4241c == activity) {
                this.f4241c = null;
                this.f4244f = true;
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            if (!this.f4244f || this.f4245g || this.f4243e || !e.h(this.f4240b, this.f4242d, activity)) {
                return;
            }
            this.f4245g = true;
            this.f4240b = null;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            if (this.f4241c == activity) {
                this.f4243e = true;
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }
    }

    static {
        Class a5 = a();
        f4227a = a5;
        f4228b = b();
        f4229c = f();
        f4230d = d(a5);
        f4231e = c(a5);
        f4232f = e(a5);
    }

    private static Class a() {
        try {
            return Class.forName("android.app.ActivityThread");
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Field b() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mMainThread");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method c(Class cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", IBinder.class, Boolean.TYPE);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method d(Class cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", IBinder.class, Boolean.TYPE, String.class);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method e(Class cls) {
        if (g() && cls != null) {
            try {
                Class<?> cls2 = Boolean.TYPE;
                Method declaredMethod = cls.getDeclaredMethod("requestRelaunchActivity", IBinder.class, List.class, List.class, Integer.TYPE, cls2, Configuration.class, Configuration.class, cls2, cls2);
                declaredMethod.setAccessible(true);
                return declaredMethod;
            } catch (Throwable unused) {
            }
        }
        return null;
    }

    private static Field f() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mToken");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static boolean g() {
        int i5 = Build.VERSION.SDK_INT;
        return i5 == 26 || i5 == 27;
    }

    protected static boolean h(Object obj, int i5, Activity activity) {
        try {
            Object obj2 = f4229c.get(activity);
            if (obj2 == obj && activity.hashCode() == i5) {
                f4233g.postAtFrontOfQueue(new c(f4228b.get(activity), obj2));
                return true;
            }
            return false;
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while fetching field values", th);
            return false;
        }
    }

    static boolean i(Activity activity) {
        Object obj;
        if (Build.VERSION.SDK_INT >= 28) {
            activity.recreate();
            return true;
        }
        if (g() && f4232f == null) {
            return false;
        }
        if (f4231e == null && f4230d == null) {
            return false;
        }
        try {
            Object obj2 = f4229c.get(activity);
            if (obj2 == null || (obj = f4228b.get(activity)) == null) {
                return false;
            }
            Application application = activity.getApplication();
            d dVar = new d(activity);
            application.registerActivityLifecycleCallbacks(dVar);
            Handler handler = f4233g;
            handler.post(new a(dVar, obj2));
            try {
                if (g()) {
                    Method method = f4232f;
                    Boolean bool = Boolean.FALSE;
                    method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                } else {
                    activity.recreate();
                }
                handler.post(new b(application, dVar));
                return true;
            } catch (Throwable th) {
                f4233g.post(new b(application, dVar));
                throw th;
            }
        } catch (Throwable unused) {
            return false;
        }
    }
}
