package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import androidx.core.view.AbstractC1014b;
import java.lang.reflect.Method;
import p.InterfaceMenuItemC7302b;

/* loaded from: classes.dex */
public class j extends androidx.appcompat.view.menu.c implements MenuItem {

    /* renamed from: d, reason: collision with root package name */
    private final InterfaceMenuItemC7302b f3172d;

    /* renamed from: e, reason: collision with root package name */
    private Method f3173e;

    private class a extends AbstractC1014b implements ActionProvider.VisibilityListener {

        /* renamed from: d, reason: collision with root package name */
        private AbstractC1014b.InterfaceC0131b f3174d;

        /* renamed from: e, reason: collision with root package name */
        private final ActionProvider f3175e;

        a(Context context, ActionProvider actionProvider) {
            super(context);
            this.f3175e = actionProvider;
        }

        @Override // androidx.core.view.AbstractC1014b
        public boolean a() {
            return this.f3175e.hasSubMenu();
        }

        @Override // androidx.core.view.AbstractC1014b
        public boolean b() {
            return this.f3175e.isVisible();
        }

        @Override // androidx.core.view.AbstractC1014b
        public View c() {
            return this.f3175e.onCreateActionView();
        }

        @Override // androidx.core.view.AbstractC1014b
        public View d(MenuItem menuItem) {
            return this.f3175e.onCreateActionView(menuItem);
        }

        @Override // androidx.core.view.AbstractC1014b
        public boolean e() {
            return this.f3175e.onPerformDefaultAction();
        }

        @Override // androidx.core.view.AbstractC1014b
        public void f(SubMenu subMenu) {
            this.f3175e.onPrepareSubMenu(j.this.d(subMenu));
        }

        @Override // androidx.core.view.AbstractC1014b
        public boolean g() {
            return this.f3175e.overridesItemVisibility();
        }

        @Override // androidx.core.view.AbstractC1014b
        public void j(AbstractC1014b.InterfaceC0131b interfaceC0131b) {
            this.f3174d = interfaceC0131b;
            this.f3175e.setVisibilityListener(interfaceC0131b != null ? this : null);
        }

        @Override // android.view.ActionProvider.VisibilityListener
        public void onActionProviderVisibilityChanged(boolean z4) {
            AbstractC1014b.InterfaceC0131b interfaceC0131b = this.f3174d;
            if (interfaceC0131b != null) {
                interfaceC0131b.onActionProviderVisibilityChanged(z4);
            }
        }
    }

    static class b extends FrameLayout implements androidx.appcompat.view.c {

        /* renamed from: b, reason: collision with root package name */
        final CollapsibleActionView f3177b;

        /* JADX WARN: Multi-variable type inference failed */
        b(View view) {
            super(view.getContext());
            this.f3177b = (CollapsibleActionView) view;
            addView(view);
        }

        View a() {
            return (View) this.f3177b;
        }

        @Override // androidx.appcompat.view.c
        public void onActionViewCollapsed() {
            this.f3177b.onActionViewCollapsed();
        }

        @Override // androidx.appcompat.view.c
        public void onActionViewExpanded() {
            this.f3177b.onActionViewExpanded();
        }
    }

    private class c implements MenuItem.OnActionExpandListener {

        /* renamed from: a, reason: collision with root package name */
        private final MenuItem.OnActionExpandListener f3178a;

        c(MenuItem.OnActionExpandListener onActionExpandListener) {
            this.f3178a = onActionExpandListener;
        }

        @Override // android.view.MenuItem.OnActionExpandListener
        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return this.f3178a.onMenuItemActionCollapse(j.this.c(menuItem));
        }

        @Override // android.view.MenuItem.OnActionExpandListener
        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return this.f3178a.onMenuItemActionExpand(j.this.c(menuItem));
        }
    }

    private class d implements MenuItem.OnMenuItemClickListener {

        /* renamed from: a, reason: collision with root package name */
        private final MenuItem.OnMenuItemClickListener f3180a;

        d(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            this.f3180a = onMenuItemClickListener;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            return this.f3180a.onMenuItemClick(j.this.c(menuItem));
        }
    }

    public j(Context context, InterfaceMenuItemC7302b interfaceMenuItemC7302b) {
        super(context);
        if (interfaceMenuItemC7302b == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.f3172d = interfaceMenuItemC7302b;
    }

    @Override // android.view.MenuItem
    public boolean collapseActionView() {
        return this.f3172d.collapseActionView();
    }

    @Override // android.view.MenuItem
    public boolean expandActionView() {
        return this.f3172d.expandActionView();
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        AbstractC1014b a5 = this.f3172d.a();
        if (a5 instanceof a) {
            return ((a) a5).f3175e;
        }
        return null;
    }

    @Override // android.view.MenuItem
    public View getActionView() {
        View actionView = this.f3172d.getActionView();
        return actionView instanceof b ? ((b) actionView).a() : actionView;
    }

    @Override // android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f3172d.getAlphabeticModifiers();
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f3172d.getAlphabeticShortcut();
    }

    @Override // android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f3172d.getContentDescription();
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f3172d.getGroupId();
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        return this.f3172d.getIcon();
    }

    @Override // android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f3172d.getIconTintList();
    }

    @Override // android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f3172d.getIconTintMode();
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f3172d.getIntent();
    }

    @Override // android.view.MenuItem
    public int getItemId() {
        return this.f3172d.getItemId();
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f3172d.getMenuInfo();
    }

    @Override // android.view.MenuItem
    public int getNumericModifiers() {
        return this.f3172d.getNumericModifiers();
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f3172d.getNumericShortcut();
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f3172d.getOrder();
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return d(this.f3172d.getSubMenu());
    }

    @Override // android.view.MenuItem
    public CharSequence getTitle() {
        return this.f3172d.getTitle();
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        return this.f3172d.getTitleCondensed();
    }

    @Override // android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f3172d.getTooltipText();
    }

    public void h(boolean z4) {
        try {
            if (this.f3173e == null) {
                this.f3173e = this.f3172d.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
            }
            this.f3173e.invoke(this.f3172d, Boolean.valueOf(z4));
        } catch (Exception e5) {
            Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e5);
        }
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return this.f3172d.hasSubMenu();
    }

    @Override // android.view.MenuItem
    public boolean isActionViewExpanded() {
        return this.f3172d.isActionViewExpanded();
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return this.f3172d.isCheckable();
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return this.f3172d.isChecked();
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return this.f3172d.isEnabled();
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        return this.f3172d.isVisible();
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        a aVar = new a(this.f3052a, actionProvider);
        InterfaceMenuItemC7302b interfaceMenuItemC7302b = this.f3172d;
        if (actionProvider == null) {
            aVar = null;
        }
        interfaceMenuItemC7302b.b(aVar);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new b(view);
        }
        this.f3172d.setActionView(view);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5) {
        this.f3172d.setAlphabeticShortcut(c5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z4) {
        this.f3172d.setCheckable(z4);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z4) {
        this.f3172d.setChecked(z4);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f3172d.setContentDescription(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z4) {
        this.f3172d.setEnabled(z4);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f3172d.setIcon(drawable);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f3172d.setIconTintList(colorStateList);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f3172d.setIconTintMode(mode);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f3172d.setIntent(intent);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c5) {
        this.f3172d.setNumericShortcut(c5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f3172d.setOnActionExpandListener(onActionExpandListener != null ? new c(onActionExpandListener) : null);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f3172d.setOnMenuItemClickListener(onMenuItemClickListener != null ? new d(onMenuItemClickListener) : null);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6) {
        this.f3172d.setShortcut(c5, c6);
        return this;
    }

    @Override // android.view.MenuItem
    public void setShowAsAction(int i5) {
        this.f3172d.setShowAsAction(i5);
    }

    @Override // android.view.MenuItem
    public MenuItem setShowAsActionFlags(int i5) {
        this.f3172d.setShowAsActionFlags(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f3172d.setTitle(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f3172d.setTitleCondensed(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f3172d.setTooltipText(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z4) {
        return this.f3172d.setVisible(z4);
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5, int i5) {
        this.f3172d.setAlphabeticShortcut(c5, i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i5) {
        this.f3172d.setIcon(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c5, int i5) {
        this.f3172d.setNumericShortcut(c5, i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6, int i5, int i6) {
        this.f3172d.setShortcut(c5, c6, i5, i6);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i5) {
        this.f3172d.setTitle(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionView(int i5) {
        this.f3172d.setActionView(i5);
        View actionView = this.f3172d.getActionView();
        if (actionView instanceof CollapsibleActionView) {
            this.f3172d.setActionView(new b(actionView));
        }
        return this;
    }
}
