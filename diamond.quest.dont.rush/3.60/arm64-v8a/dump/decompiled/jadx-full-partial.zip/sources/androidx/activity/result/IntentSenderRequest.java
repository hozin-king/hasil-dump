package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class IntentSenderRequest implements Parcelable {

    /* renamed from: b, reason: collision with root package name */
    private final IntentSender f2500b;

    /* renamed from: c, reason: collision with root package name */
    private final Intent f2501c;

    /* renamed from: d, reason: collision with root package name */
    private final int f2502d;

    /* renamed from: e, reason: collision with root package name */
    private final int f2503e;

    /* renamed from: f, reason: collision with root package name */
    public static final c f2499f = new c(null);
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new b();

    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        private final IntentSender f2504a;

        /* renamed from: b, reason: collision with root package name */
        private Intent f2505b;

        /* renamed from: c, reason: collision with root package name */
        private int f2506c;

        /* renamed from: d, reason: collision with root package name */
        private int f2507d;

        public a(IntentSender intentSender) {
            C7150s.j(intentSender, "intentSender");
            this.f2504a = intentSender;
        }

        public final IntentSenderRequest a() {
            return new IntentSenderRequest(this.f2504a, this.f2505b, this.f2506c, this.f2507d);
        }

        public final a b(Intent intent) {
            this.f2505b = intent;
            return this;
        }

        public final a c(int i5, int i6) {
            this.f2507d = i5;
            this.f2506c = i6;
            return this;
        }

        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public a(android.app.PendingIntent r2) {
            /*
                r1 = this;
                java.lang.String r0 = "pendingIntent"
                kotlin.jvm.internal.C7150s.j(r2, r0)
                android.content.IntentSender r2 = r2.getIntentSender()
                java.lang.String r0 = "pendingIntent.intentSender"
                kotlin.jvm.internal.C7150s.i(r2, r0)
                r1.<init>(r2)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.activity.result.IntentSenderRequest.a.<init>(android.app.PendingIntent):void");
        }
    }

    public static final class b implements Parcelable.Creator {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public IntentSenderRequest createFromParcel(Parcel inParcel) {
            C7150s.j(inParcel, "inParcel");
            return new IntentSenderRequest(inParcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public IntentSenderRequest[] newArray(int i5) {
            return new IntentSenderRequest[i5];
        }
    }

    public static final class c {
        public /* synthetic */ c(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private c() {
        }
    }

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i5, int i6) {
        C7150s.j(intentSender, "intentSender");
        this.f2500b = intentSender;
        this.f2501c = intent;
        this.f2502d = i5;
        this.f2503e = i6;
    }

    public final Intent c() {
        return this.f2501c;
    }

    public final int d() {
        return this.f2502d;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final int e() {
        return this.f2503e;
    }

    public final IntentSender f() {
        return this.f2500b;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i5) {
        C7150s.j(dest, "dest");
        dest.writeParcelable(this.f2500b, i5);
        dest.writeParcelable(this.f2501c, i5);
        dest.writeInt(this.f2502d);
        dest.writeInt(this.f2503e);
    }

    public /* synthetic */ IntentSenderRequest(IntentSender intentSender, Intent intent, int i5, int i6, int i7, DefaultConstructorMarker defaultConstructorMarker) {
        this(intentSender, (i7 & 2) != 0 ? null : intent, (i7 & 4) != 0 ? 0 : i5, (i7 & 8) != 0 ? 0 : i6);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public IntentSenderRequest(android.os.Parcel r4) {
        /*
            r3 = this;
            java.lang.String r0 = "parcel"
            kotlin.jvm.internal.C7150s.j(r4, r0)
            java.lang.Class<android.content.IntentSender> r0 = android.content.IntentSender.class
            java.lang.ClassLoader r0 = r0.getClassLoader()
            android.os.Parcelable r0 = r4.readParcelable(r0)
            kotlin.jvm.internal.C7150s.g(r0)
            android.content.IntentSender r0 = (android.content.IntentSender) r0
            java.lang.Class<android.content.Intent> r1 = android.content.Intent.class
            java.lang.ClassLoader r1 = r1.getClassLoader()
            android.os.Parcelable r1 = r4.readParcelable(r1)
            android.content.Intent r1 = (android.content.Intent) r1
            int r2 = r4.readInt()
            int r4 = r4.readInt()
            r3.<init>(r0, r1, r2, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.result.IntentSenderRequest.<init>(android.os.Parcel):void");
    }
}
