package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;

/* renamed from: androidx.appcompat.widget.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0995n {

    /* renamed from: a, reason: collision with root package name */
    private final TextView f3837a;

    /* renamed from: b, reason: collision with root package name */
    private final F.f f3838b;

    C0995n(TextView textView) {
        this.f3837a = textView;
        this.f3838b = new F.f(textView, false);
    }

    InputFilter[] a(InputFilter[] inputFilterArr) {
        return this.f3838b.a(inputFilterArr);
    }

    public boolean b() {
        return this.f3838b.b();
    }

    void c(AttributeSet attributeSet, int i5) {
        TypedArray obtainStyledAttributes = this.f3837a.getContext().obtainStyledAttributes(attributeSet, f.j.f54025g0, i5, 0);
        try {
            boolean z4 = obtainStyledAttributes.hasValue(f.j.f54095u0) ? obtainStyledAttributes.getBoolean(f.j.f54095u0, true) : true;
            obtainStyledAttributes.recycle();
            e(z4);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    void d(boolean z4) {
        this.f3838b.c(z4);
    }

    void e(boolean z4) {
        this.f3838b.d(z4);
    }

    public TransformationMethod f(TransformationMethod transformationMethod) {
        return this.f3838b.e(transformationMethod);
    }
}
