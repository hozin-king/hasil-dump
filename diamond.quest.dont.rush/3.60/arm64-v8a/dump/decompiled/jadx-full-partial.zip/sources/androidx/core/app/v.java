package androidx.core.app;

/* loaded from: classes.dex */
public interface v {
    void addOnMultiWindowModeChangedListener(t.b bVar);

    void removeOnMultiWindowModeChangedListener(t.b bVar);
}
