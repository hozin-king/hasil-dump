package androidx.core.os;

import android.os.Build;
import android.os.LocaleList;
import androidx.annotation.NonNull;
import com.ironsource.b9;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.util.Locale;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: b, reason: collision with root package name */
    private static final j f4413b = a(new Locale[0]);

    /* renamed from: a, reason: collision with root package name */
    private final l f4414a;

    static class a {

        /* renamed from: a, reason: collision with root package name */
        private static final Locale[] f4415a = {new Locale("en", "XA"), new Locale("ar", "XB")};

        static Locale a(String str) {
            return Locale.forLanguageTag(str);
        }

        private static boolean b(Locale locale) {
            for (Locale locale2 : f4415a) {
                if (locale2.equals(locale)) {
                    return true;
                }
            }
            return false;
        }

        static boolean c(@NonNull Locale locale, @NonNull Locale locale2) {
            if (locale.equals(locale2)) {
                return true;
            }
            if (!locale.getLanguage().equals(locale2.getLanguage()) || b(locale) || b(locale2)) {
                return false;
            }
            String a5 = androidx.core.text.b.a(locale);
            if (!a5.isEmpty()) {
                return a5.equals(androidx.core.text.b.a(locale2));
            }
            String country = locale.getCountry();
            return country.isEmpty() || country.equals(locale2.getCountry());
        }
    }

    static class b {
        static LocaleList a(Locale... localeArr) {
            return new LocaleList(localeArr);
        }

        static LocaleList b() {
            return LocaleList.getAdjustedDefault();
        }

        static LocaleList c() {
            return LocaleList.getDefault();
        }
    }

    private j(l lVar) {
        this.f4414a = lVar;
    }

    public static j a(Locale... localeArr) {
        return Build.VERSION.SDK_INT >= 24 ? j(b.a(localeArr)) : new j(new k(localeArr));
    }

    static Locale b(String str) {
        if (str.contains("-")) {
            String[] split = str.split("-", -1);
            if (split.length > 2) {
                return new Locale(split[0], split[1], split[2]);
            }
            if (split.length > 1) {
                return new Locale(split[0], split[1]);
            }
            if (split.length == 1) {
                return new Locale(split[0]);
            }
        } else {
            if (!str.contains("_")) {
                return new Locale(str);
            }
            String[] split2 = str.split("_", -1);
            if (split2.length > 2) {
                return new Locale(split2[0], split2[1], split2[2]);
            }
            if (split2.length > 1) {
                return new Locale(split2[0], split2[1]);
            }
            if (split2.length == 1) {
                return new Locale(split2[0]);
            }
        }
        throw new IllegalArgumentException("Can not parse language tag: [" + str + b9.i.f26270e);
    }

    public static j c(String str) {
        if (str == null || str.isEmpty()) {
            return e();
        }
        String[] split = str.split(StringUtils.COMMA, -1);
        int length = split.length;
        Locale[] localeArr = new Locale[length];
        for (int i5 = 0; i5 < length; i5++) {
            localeArr[i5] = a.a(split[i5]);
        }
        return a(localeArr);
    }

    public static j e() {
        return f4413b;
    }

    public static j j(LocaleList localeList) {
        return new j(new s(localeList));
    }

    public Locale d(int i5) {
        return this.f4414a.get(i5);
    }

    public boolean equals(Object obj) {
        return (obj instanceof j) && this.f4414a.equals(((j) obj).f4414a);
    }

    public boolean f() {
        return this.f4414a.isEmpty();
    }

    public int g() {
        return this.f4414a.size();
    }

    public String h() {
        return this.f4414a.a();
    }

    public int hashCode() {
        return this.f4414a.hashCode();
    }

    public Object i() {
        return this.f4414a.getLocaleList();
    }

    public String toString() {
        return this.f4414a.toString();
    }
}
