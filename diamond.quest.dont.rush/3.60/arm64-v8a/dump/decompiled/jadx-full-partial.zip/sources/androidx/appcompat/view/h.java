package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.C1035l0;
import androidx.core.view.C1039n0;
import androidx.core.view.InterfaceC1037m0;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class h {

    /* renamed from: c, reason: collision with root package name */
    private Interpolator f2982c;

    /* renamed from: d, reason: collision with root package name */
    InterfaceC1037m0 f2983d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f2984e;

    /* renamed from: b, reason: collision with root package name */
    private long f2981b = -1;

    /* renamed from: f, reason: collision with root package name */
    private final C1039n0 f2985f = new a();

    /* renamed from: a, reason: collision with root package name */
    final ArrayList f2980a = new ArrayList();

    class a extends C1039n0 {

        /* renamed from: a, reason: collision with root package name */
        private boolean f2986a = false;

        /* renamed from: b, reason: collision with root package name */
        private int f2987b = 0;

        a() {
        }

        @Override // androidx.core.view.C1039n0, androidx.core.view.InterfaceC1037m0
        public void b(View view) {
            int i5 = this.f2987b + 1;
            this.f2987b = i5;
            if (i5 == h.this.f2980a.size()) {
                InterfaceC1037m0 interfaceC1037m0 = h.this.f2983d;
                if (interfaceC1037m0 != null) {
                    interfaceC1037m0.b(null);
                }
                d();
            }
        }

        @Override // androidx.core.view.C1039n0, androidx.core.view.InterfaceC1037m0
        public void c(View view) {
            if (this.f2986a) {
                return;
            }
            this.f2986a = true;
            InterfaceC1037m0 interfaceC1037m0 = h.this.f2983d;
            if (interfaceC1037m0 != null) {
                interfaceC1037m0.c(null);
            }
        }

        void d() {
            this.f2987b = 0;
            this.f2986a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.f2984e) {
            ArrayList arrayList = this.f2980a;
            int size = arrayList.size();
            int i5 = 0;
            while (i5 < size) {
                Object obj = arrayList.get(i5);
                i5++;
                ((C1035l0) obj).c();
            }
            this.f2984e = false;
        }
    }

    void b() {
        this.f2984e = false;
    }

    public h c(C1035l0 c1035l0) {
        if (!this.f2984e) {
            this.f2980a.add(c1035l0);
        }
        return this;
    }

    public h d(C1035l0 c1035l0, C1035l0 c1035l02) {
        this.f2980a.add(c1035l0);
        c1035l02.i(c1035l0.d());
        this.f2980a.add(c1035l02);
        return this;
    }

    public h e(long j5) {
        if (!this.f2984e) {
            this.f2981b = j5;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.f2984e) {
            this.f2982c = interpolator;
        }
        return this;
    }

    public h g(InterfaceC1037m0 interfaceC1037m0) {
        if (!this.f2984e) {
            this.f2983d = interfaceC1037m0;
        }
        return this;
    }

    public void h() {
        if (this.f2984e) {
            return;
        }
        ArrayList arrayList = this.f2980a;
        int size = arrayList.size();
        int i5 = 0;
        while (i5 < size) {
            Object obj = arrayList.get(i5);
            i5++;
            C1035l0 c1035l0 = (C1035l0) obj;
            long j5 = this.f2981b;
            if (j5 >= 0) {
                c1035l0.e(j5);
            }
            Interpolator interpolator = this.f2982c;
            if (interpolator != null) {
                c1035l0.f(interpolator);
            }
            if (this.f2983d != null) {
                c1035l0.g(this.f2985f);
            }
            c1035l0.k();
        }
        this.f2984e = true;
    }
}
