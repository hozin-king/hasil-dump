package androidx.core.app;

import android.app.Notification;

/* loaded from: classes.dex */
public abstract /* synthetic */ class q {
    public static /* bridge */ /* synthetic */ Class a() {
        return Notification.MessagingStyle.class;
    }
}
