package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.core.view.AbstractC1014b;
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import p.InterfaceMenuC7301a;

/* loaded from: classes.dex */
public class g implements InterfaceMenuC7301a {

    /* renamed from: A, reason: collision with root package name */
    private static final int[] f3109A = {1, 4, 5, 3, 2, 0};

    /* renamed from: a, reason: collision with root package name */
    private final Context f3110a;

    /* renamed from: b, reason: collision with root package name */
    private final Resources f3111b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f3112c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f3113d;

    /* renamed from: e, reason: collision with root package name */
    private a f3114e;

    /* renamed from: m, reason: collision with root package name */
    private ContextMenu.ContextMenuInfo f3122m;

    /* renamed from: n, reason: collision with root package name */
    CharSequence f3123n;

    /* renamed from: o, reason: collision with root package name */
    Drawable f3124o;

    /* renamed from: p, reason: collision with root package name */
    View f3125p;

    /* renamed from: x, reason: collision with root package name */
    private i f3133x;

    /* renamed from: z, reason: collision with root package name */
    private boolean f3135z;

    /* renamed from: l, reason: collision with root package name */
    private int f3121l = 0;

    /* renamed from: q, reason: collision with root package name */
    private boolean f3126q = false;

    /* renamed from: r, reason: collision with root package name */
    private boolean f3127r = false;

    /* renamed from: s, reason: collision with root package name */
    private boolean f3128s = false;

    /* renamed from: t, reason: collision with root package name */
    private boolean f3129t = false;

    /* renamed from: u, reason: collision with root package name */
    private boolean f3130u = false;

    /* renamed from: v, reason: collision with root package name */
    private ArrayList f3131v = new ArrayList();

    /* renamed from: w, reason: collision with root package name */
    private CopyOnWriteArrayList f3132w = new CopyOnWriteArrayList();

    /* renamed from: y, reason: collision with root package name */
    private boolean f3134y = false;

    /* renamed from: f, reason: collision with root package name */
    private ArrayList f3115f = new ArrayList();

    /* renamed from: g, reason: collision with root package name */
    private ArrayList f3116g = new ArrayList();

    /* renamed from: h, reason: collision with root package name */
    private boolean f3117h = true;

    /* renamed from: i, reason: collision with root package name */
    private ArrayList f3118i = new ArrayList();

    /* renamed from: j, reason: collision with root package name */
    private ArrayList f3119j = new ArrayList();

    /* renamed from: k, reason: collision with root package name */
    private boolean f3120k = true;

    public interface a {
        boolean a(g gVar, MenuItem menuItem);

        void b(g gVar);
    }

    public interface b {
        boolean b(i iVar);
    }

    public g(Context context) {
        this.f3110a = context;
        this.f3111b = context.getResources();
        c0(true);
    }

    private static int B(int i5) {
        int i6 = ((-65536) & i5) >> 16;
        if (i6 >= 0) {
            int[] iArr = f3109A;
            if (i6 < iArr.length) {
                return (i5 & MeshBuilder.MAX_INDEX) | (iArr[i6] << 16);
            }
        }
        throw new IllegalArgumentException("order does not contain a valid category.");
    }

    private void O(int i5, boolean z4) {
        if (i5 < 0 || i5 >= this.f3115f.size()) {
            return;
        }
        this.f3115f.remove(i5);
        if (z4) {
            L(true);
        }
    }

    private void X(int i5, CharSequence charSequence, int i6, Drawable drawable, View view) {
        Resources C4 = C();
        if (view != null) {
            this.f3125p = view;
            this.f3123n = null;
            this.f3124o = null;
        } else {
            if (i5 > 0) {
                this.f3123n = C4.getText(i5);
            } else if (charSequence != null) {
                this.f3123n = charSequence;
            }
            if (i6 > 0) {
                this.f3124o = androidx.core.content.a.getDrawable(u(), i6);
            } else if (drawable != null) {
                this.f3124o = drawable;
            }
            this.f3125p = null;
        }
        L(false);
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x0019, code lost:
    
        if (androidx.core.view.C1023f0.l(android.view.ViewConfiguration.get(r2.f3110a), r2.f3110a) != false) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void c0(boolean r3) {
        /*
            r2 = this;
            if (r3 == 0) goto L1c
            android.content.res.Resources r3 = r2.f3111b
            android.content.res.Configuration r3 = r3.getConfiguration()
            int r3 = r3.keyboard
            r0 = 1
            if (r3 == r0) goto L1c
            android.content.Context r3 = r2.f3110a
            android.view.ViewConfiguration r3 = android.view.ViewConfiguration.get(r3)
            android.content.Context r1 = r2.f3110a
            boolean r3 = androidx.core.view.C1023f0.l(r3, r1)
            if (r3 == 0) goto L1c
            goto L1d
        L1c:
            r0 = 0
        L1d:
            r2.f3113d = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.g.c0(boolean):void");
    }

    private i g(int i5, int i6, int i7, int i8, CharSequence charSequence, int i9) {
        return new i(this, i5, i6, i7, i8, charSequence, i9);
    }

    private void i(boolean z4) {
        if (this.f3132w.isEmpty()) {
            return;
        }
        e0();
        Iterator it = this.f3132w.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            m mVar = (m) weakReference.get();
            if (mVar == null) {
                this.f3132w.remove(weakReference);
            } else {
                mVar.c(z4);
            }
        }
        d0();
    }

    private boolean j(r rVar, m mVar) {
        if (this.f3132w.isEmpty()) {
            return false;
        }
        boolean h5 = mVar != null ? mVar.h(rVar) : false;
        Iterator it = this.f3132w.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            m mVar2 = (m) weakReference.get();
            if (mVar2 == null) {
                this.f3132w.remove(weakReference);
            } else if (!h5) {
                h5 = mVar2.h(rVar);
            }
        }
        return h5;
    }

    private static int n(ArrayList arrayList, int i5) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (((i) arrayList.get(size)).f() <= i5) {
                return size + 1;
            }
        }
        return 0;
    }

    boolean A() {
        return this.f3129t;
    }

    Resources C() {
        return this.f3111b;
    }

    public g D() {
        return this;
    }

    public ArrayList E() {
        if (!this.f3117h) {
            return this.f3116g;
        }
        this.f3116g.clear();
        int size = this.f3115f.size();
        for (int i5 = 0; i5 < size; i5++) {
            i iVar = (i) this.f3115f.get(i5);
            if (iVar.isVisible()) {
                this.f3116g.add(iVar);
            }
        }
        this.f3117h = false;
        this.f3120k = true;
        return this.f3116g;
    }

    public boolean F() {
        return !this.f3126q;
    }

    public boolean G() {
        return this.f3134y;
    }

    boolean H() {
        return this.f3112c;
    }

    public boolean I() {
        return this.f3113d;
    }

    void J(i iVar) {
        this.f3120k = true;
        L(true);
    }

    void K(i iVar) {
        this.f3117h = true;
        L(true);
    }

    public void L(boolean z4) {
        if (this.f3126q) {
            this.f3127r = true;
            if (z4) {
                this.f3128s = true;
                return;
            }
            return;
        }
        if (z4) {
            this.f3117h = true;
            this.f3120k = true;
        }
        i(z4);
    }

    public boolean M(MenuItem menuItem, int i5) {
        return N(menuItem, null, i5);
    }

    public boolean N(MenuItem menuItem, m mVar, int i5) {
        i iVar = (i) menuItem;
        if (iVar == null || !iVar.isEnabled()) {
            return false;
        }
        boolean k5 = iVar.k();
        AbstractC1014b a5 = iVar.a();
        boolean z4 = a5 != null && a5.a();
        if (iVar.j()) {
            boolean expandActionView = iVar.expandActionView() | k5;
            if (expandActionView) {
                e(true);
            }
            return expandActionView;
        }
        if (!iVar.hasSubMenu() && !z4) {
            if ((i5 & 1) == 0) {
                e(true);
            }
            return k5;
        }
        if ((i5 & 4) == 0) {
            e(false);
        }
        if (!iVar.hasSubMenu()) {
            iVar.x(new r(u(), this, iVar));
        }
        r rVar = (r) iVar.getSubMenu();
        if (z4) {
            a5.f(rVar);
        }
        boolean j5 = j(rVar, mVar) | k5;
        if (!j5) {
            e(true);
        }
        return j5;
    }

    public void P(m mVar) {
        Iterator it = this.f3132w.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            m mVar2 = (m) weakReference.get();
            if (mVar2 == null || mVar2 == mVar) {
                this.f3132w.remove(weakReference);
            }
        }
    }

    public void Q(Bundle bundle) {
        MenuItem findItem;
        if (bundle == null) {
            return;
        }
        SparseArray<Parcelable> sparseParcelableArray = bundle.getSparseParcelableArray(t());
        int size = size();
        for (int i5 = 0; i5 < size; i5++) {
            MenuItem item = getItem(i5);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                actionView.restoreHierarchyState(sparseParcelableArray);
            }
            if (item.hasSubMenu()) {
                ((r) item.getSubMenu()).Q(bundle);
            }
        }
        int i6 = bundle.getInt("android:menu:expandedactionview");
        if (i6 <= 0 || (findItem = findItem(i6)) == null) {
            return;
        }
        findItem.expandActionView();
    }

    public void R(Bundle bundle) {
        int size = size();
        SparseArray<? extends Parcelable> sparseArray = null;
        for (int i5 = 0; i5 < size; i5++) {
            MenuItem item = getItem(i5);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray<>();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((r) item.getSubMenu()).R(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(t(), sparseArray);
        }
    }

    public void S(a aVar) {
        this.f3114e = aVar;
    }

    public g T(int i5) {
        this.f3121l = i5;
        return this;
    }

    void U(MenuItem menuItem) {
        int groupId = menuItem.getGroupId();
        int size = this.f3115f.size();
        e0();
        for (int i5 = 0; i5 < size; i5++) {
            i iVar = (i) this.f3115f.get(i5);
            if (iVar.getGroupId() == groupId && iVar.m() && iVar.isCheckable()) {
                iVar.s(iVar == menuItem);
            }
        }
        d0();
    }

    protected g V(int i5) {
        X(0, null, i5, null, null);
        return this;
    }

    protected g W(Drawable drawable) {
        X(0, null, 0, drawable, null);
        return this;
    }

    protected g Y(int i5) {
        X(i5, null, 0, null, null);
        return this;
    }

    protected g Z(CharSequence charSequence) {
        X(0, charSequence, 0, null, null);
        return this;
    }

    protected MenuItem a(int i5, int i6, int i7, CharSequence charSequence) {
        int B4 = B(i7);
        i g5 = g(i5, i6, i7, B4, charSequence, this.f3121l);
        ContextMenu.ContextMenuInfo contextMenuInfo = this.f3122m;
        if (contextMenuInfo != null) {
            g5.v(contextMenuInfo);
        }
        ArrayList arrayList = this.f3115f;
        arrayList.add(n(arrayList, B4), g5);
        L(true);
        return g5;
    }

    protected g a0(View view) {
        X(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.Menu
    public MenuItem add(CharSequence charSequence) {
        return a(0, 0, 0, charSequence);
    }

    @Override // android.view.Menu
    public int addIntentOptions(int i5, int i6, int i7, ComponentName componentName, Intent[] intentArr, Intent intent, int i8, MenuItem[] menuItemArr) {
        int i9;
        PackageManager packageManager = this.f3110a.getPackageManager();
        List<ResolveInfo> queryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = queryIntentActivityOptions != null ? queryIntentActivityOptions.size() : 0;
        if ((i8 & 1) == 0) {
            removeGroup(i5);
        }
        for (int i10 = 0; i10 < size; i10++) {
            ResolveInfo resolveInfo = queryIntentActivityOptions.get(i10);
            int i11 = resolveInfo.specificIndex;
            Intent intent2 = new Intent(i11 < 0 ? intent : intentArr[i11]);
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            intent2.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
            MenuItem intent3 = add(i5, i6, i7, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent2);
            if (menuItemArr != null && (i9 = resolveInfo.specificIndex) >= 0) {
                menuItemArr[i9] = intent3;
            }
        }
        return size;
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    public void b(m mVar) {
        c(mVar, this.f3110a);
    }

    public void b0(boolean z4) {
        this.f3135z = z4;
    }

    public void c(m mVar, Context context) {
        this.f3132w.add(new WeakReference(mVar));
        mVar.f(context, this);
        this.f3120k = true;
    }

    @Override // android.view.Menu
    public void clear() {
        i iVar = this.f3133x;
        if (iVar != null) {
            f(iVar);
        }
        this.f3115f.clear();
        L(true);
    }

    public void clearHeader() {
        this.f3124o = null;
        this.f3123n = null;
        this.f3125p = null;
        L(false);
    }

    @Override // android.view.Menu
    public void close() {
        e(true);
    }

    public void d() {
        a aVar = this.f3114e;
        if (aVar != null) {
            aVar.b(this);
        }
    }

    public void d0() {
        this.f3126q = false;
        if (this.f3127r) {
            this.f3127r = false;
            L(this.f3128s);
        }
    }

    public final void e(boolean z4) {
        if (this.f3130u) {
            return;
        }
        this.f3130u = true;
        Iterator it = this.f3132w.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            m mVar = (m) weakReference.get();
            if (mVar == null) {
                this.f3132w.remove(weakReference);
            } else {
                mVar.a(this, z4);
            }
        }
        this.f3130u = false;
    }

    public void e0() {
        if (this.f3126q) {
            return;
        }
        this.f3126q = true;
        this.f3127r = false;
        this.f3128s = false;
    }

    public boolean f(i iVar) {
        boolean z4 = false;
        if (!this.f3132w.isEmpty() && this.f3133x == iVar) {
            e0();
            Iterator it = this.f3132w.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                m mVar = (m) weakReference.get();
                if (mVar == null) {
                    this.f3132w.remove(weakReference);
                } else {
                    z4 = mVar.e(this, iVar);
                    if (z4) {
                        break;
                    }
                }
            }
            d0();
            if (z4) {
                this.f3133x = null;
            }
        }
        return z4;
    }

    @Override // android.view.Menu
    public MenuItem findItem(int i5) {
        MenuItem findItem;
        int size = size();
        for (int i6 = 0; i6 < size; i6++) {
            i iVar = (i) this.f3115f.get(i6);
            if (iVar.getItemId() == i5) {
                return iVar;
            }
            if (iVar.hasSubMenu() && (findItem = iVar.getSubMenu().findItem(i5)) != null) {
                return findItem;
            }
        }
        return null;
    }

    @Override // android.view.Menu
    public MenuItem getItem(int i5) {
        return (MenuItem) this.f3115f.get(i5);
    }

    boolean h(g gVar, MenuItem menuItem) {
        a aVar = this.f3114e;
        return aVar != null && aVar.a(gVar, menuItem);
    }

    @Override // android.view.Menu
    public boolean hasVisibleItems() {
        if (this.f3135z) {
            return true;
        }
        int size = size();
        for (int i5 = 0; i5 < size; i5++) {
            if (((i) this.f3115f.get(i5)).isVisible()) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.Menu
    public boolean isShortcutKey(int i5, KeyEvent keyEvent) {
        return p(i5, keyEvent) != null;
    }

    public boolean k(i iVar) {
        boolean z4 = false;
        if (this.f3132w.isEmpty()) {
            return false;
        }
        e0();
        Iterator it = this.f3132w.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            m mVar = (m) weakReference.get();
            if (mVar == null) {
                this.f3132w.remove(weakReference);
            } else {
                z4 = mVar.b(this, iVar);
                if (z4) {
                    break;
                }
            }
        }
        d0();
        if (z4) {
            this.f3133x = iVar;
        }
        return z4;
    }

    public int l(int i5) {
        return m(i5, 0);
    }

    public int m(int i5, int i6) {
        int size = size();
        if (i6 < 0) {
            i6 = 0;
        }
        while (i6 < size) {
            if (((i) this.f3115f.get(i6)).getGroupId() == i5) {
                return i6;
            }
            i6++;
        }
        return -1;
    }

    public int o(int i5) {
        int size = size();
        for (int i6 = 0; i6 < size; i6++) {
            if (((i) this.f3115f.get(i6)).getItemId() == i5) {
                return i6;
            }
        }
        return -1;
    }

    i p(int i5, KeyEvent keyEvent) {
        ArrayList arrayList = this.f3131v;
        arrayList.clear();
        q(arrayList, i5, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return (i) arrayList.get(0);
        }
        boolean H4 = H();
        for (int i6 = 0; i6 < size; i6++) {
            i iVar = (i) arrayList.get(i6);
            char alphabeticShortcut = H4 ? iVar.getAlphabeticShortcut() : iVar.getNumericShortcut();
            char[] cArr = keyData.meta;
            if ((alphabeticShortcut == cArr[0] && (metaState & 2) == 0) || ((alphabeticShortcut == cArr[2] && (metaState & 2) != 0) || (H4 && alphabeticShortcut == '\b' && i5 == 67))) {
                return iVar;
            }
        }
        return null;
    }

    @Override // android.view.Menu
    public boolean performIdentifierAction(int i5, int i6) {
        return M(findItem(i5), i6);
    }

    @Override // android.view.Menu
    public boolean performShortcut(int i5, KeyEvent keyEvent, int i6) {
        i p5 = p(i5, keyEvent);
        boolean M4 = p5 != null ? M(p5, i6) : false;
        if ((i6 & 2) != 0) {
            e(true);
        }
        return M4;
    }

    void q(List list, int i5, KeyEvent keyEvent) {
        boolean H4 = H();
        int modifiers = keyEvent.getModifiers();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (keyEvent.getKeyData(keyData) || i5 == 67) {
            int size = this.f3115f.size();
            for (int i6 = 0; i6 < size; i6++) {
                i iVar = (i) this.f3115f.get(i6);
                if (iVar.hasSubMenu()) {
                    ((g) iVar.getSubMenu()).q(list, i5, keyEvent);
                }
                char alphabeticShortcut = H4 ? iVar.getAlphabeticShortcut() : iVar.getNumericShortcut();
                if ((modifiers & 69647) == ((H4 ? iVar.getAlphabeticModifiers() : iVar.getNumericModifiers()) & 69647) && alphabeticShortcut != 0) {
                    char[] cArr = keyData.meta;
                    if ((alphabeticShortcut == cArr[0] || alphabeticShortcut == cArr[2] || (H4 && alphabeticShortcut == '\b' && i5 == 67)) && iVar.isEnabled()) {
                        list.add(iVar);
                    }
                }
            }
        }
    }

    public void r() {
        ArrayList E4 = E();
        if (this.f3120k) {
            Iterator it = this.f3132w.iterator();
            boolean z4 = false;
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                m mVar = (m) weakReference.get();
                if (mVar == null) {
                    this.f3132w.remove(weakReference);
                } else {
                    z4 |= mVar.d();
                }
            }
            if (z4) {
                this.f3118i.clear();
                this.f3119j.clear();
                int size = E4.size();
                for (int i5 = 0; i5 < size; i5++) {
                    i iVar = (i) E4.get(i5);
                    if (iVar.l()) {
                        this.f3118i.add(iVar);
                    } else {
                        this.f3119j.add(iVar);
                    }
                }
            } else {
                this.f3118i.clear();
                this.f3119j.clear();
                this.f3119j.addAll(E());
            }
            this.f3120k = false;
        }
    }

    @Override // android.view.Menu
    public void removeGroup(int i5) {
        int l5 = l(i5);
        if (l5 >= 0) {
            int size = this.f3115f.size() - l5;
            int i6 = 0;
            while (true) {
                int i7 = i6 + 1;
                if (i6 >= size || ((i) this.f3115f.get(l5)).getGroupId() != i5) {
                    break;
                }
                O(l5, false);
                i6 = i7;
            }
            L(true);
        }
    }

    @Override // android.view.Menu
    public void removeItem(int i5) {
        O(o(i5), true);
    }

    public ArrayList s() {
        r();
        return this.f3118i;
    }

    @Override // android.view.Menu
    public void setGroupCheckable(int i5, boolean z4, boolean z5) {
        int size = this.f3115f.size();
        for (int i6 = 0; i6 < size; i6++) {
            i iVar = (i) this.f3115f.get(i6);
            if (iVar.getGroupId() == i5) {
                iVar.t(z5);
                iVar.setCheckable(z4);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupDividerEnabled(boolean z4) {
        this.f3134y = z4;
    }

    @Override // android.view.Menu
    public void setGroupEnabled(int i5, boolean z4) {
        int size = this.f3115f.size();
        for (int i6 = 0; i6 < size; i6++) {
            i iVar = (i) this.f3115f.get(i6);
            if (iVar.getGroupId() == i5) {
                iVar.setEnabled(z4);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupVisible(int i5, boolean z4) {
        int size = this.f3115f.size();
        boolean z5 = false;
        for (int i6 = 0; i6 < size; i6++) {
            i iVar = (i) this.f3115f.get(i6);
            if (iVar.getGroupId() == i5 && iVar.y(z4)) {
                z5 = true;
            }
        }
        if (z5) {
            L(true);
        }
    }

    @Override // android.view.Menu
    public void setQwertyMode(boolean z4) {
        this.f3112c = z4;
        L(false);
    }

    @Override // android.view.Menu
    public int size() {
        return this.f3115f.size();
    }

    protected String t() {
        return "android:menu:actionviewstates";
    }

    public Context u() {
        return this.f3110a;
    }

    public i v() {
        return this.f3133x;
    }

    public Drawable w() {
        return this.f3124o;
    }

    public CharSequence x() {
        return this.f3123n;
    }

    public View y() {
        return this.f3125p;
    }

    public ArrayList z() {
        r();
        return this.f3119j;
    }

    @Override // android.view.Menu
    public MenuItem add(int i5) {
        return a(0, 0, 0, this.f3111b.getString(i5));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i5) {
        return addSubMenu(0, 0, 0, this.f3111b.getString(i5));
    }

    @Override // android.view.Menu
    public MenuItem add(int i5, int i6, int i7, CharSequence charSequence) {
        return a(i5, i6, i7, charSequence);
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i5, int i6, int i7, CharSequence charSequence) {
        i iVar = (i) a(i5, i6, i7, charSequence);
        r rVar = new r(this.f3110a, this, iVar);
        iVar.x(rVar);
        return rVar;
    }

    @Override // android.view.Menu
    public MenuItem add(int i5, int i6, int i7, int i8) {
        return a(i5, i6, i7, this.f3111b.getString(i8));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i5, int i6, int i7, int i8) {
        return addSubMenu(i5, i6, i7, this.f3111b.getString(i8));
    }
}
