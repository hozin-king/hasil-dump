package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class u {
    private final CopyOnWriteArrayList<c> cancellables = new CopyOnWriteArrayList<>();
    private U3.a enabledChangedCallback;
    private boolean isEnabled;

    public u(boolean z4) {
        this.isEnabled = z4;
    }

    public final void addCancellable(c cancellable) {
        C7150s.j(cancellable, "cancellable");
        this.cancellables.add(cancellable);
    }

    public final U3.a getEnabledChangedCallback$activity_release() {
        return this.enabledChangedCallback;
    }

    public void handleOnBackCancelled() {
    }

    public abstract void handleOnBackPressed();

    public void handleOnBackProgressed(b backEvent) {
        C7150s.j(backEvent, "backEvent");
    }

    public void handleOnBackStarted(b backEvent) {
        C7150s.j(backEvent, "backEvent");
    }

    public final boolean isEnabled() {
        return this.isEnabled;
    }

    public final void remove() {
        Iterator<T> it = this.cancellables.iterator();
        while (it.hasNext()) {
            ((c) it.next()).cancel();
        }
    }

    public final void removeCancellable(c cancellable) {
        C7150s.j(cancellable, "cancellable");
        this.cancellables.remove(cancellable);
    }

    public final void setEnabled(boolean z4) {
        this.isEnabled = z4;
        U3.a aVar = this.enabledChangedCallback;
        if (aVar != null) {
            aVar.invoke();
        }
    }

    public final void setEnabledChangedCallback$activity_release(U3.a aVar) {
        this.enabledChangedCallback = aVar;
    }
}
