package androidx.activity;

import android.window.BackEvent;
import kotlin.jvm.internal.C7150s;

/* renamed from: androidx.activity.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0974a {

    /* renamed from: a, reason: collision with root package name */
    public static final C0974a f2468a = new C0974a();

    private C0974a() {
    }

    public final BackEvent a(float f5, float f6, float f7, int i5) {
        return new BackEvent(f5, f6, f7, i5);
    }

    public final float b(BackEvent backEvent) {
        C7150s.j(backEvent, "backEvent");
        return backEvent.getProgress();
    }

    public final int c(BackEvent backEvent) {
        C7150s.j(backEvent, "backEvent");
        return backEvent.getSwipeEdge();
    }

    public final float d(BackEvent backEvent) {
        C7150s.j(backEvent, "backEvent");
        return backEvent.getTouchX();
    }

    public final float e(BackEvent backEvent) {
        C7150s.j(backEvent, "backEvent");
        return backEvent.getTouchY();
    }
}
