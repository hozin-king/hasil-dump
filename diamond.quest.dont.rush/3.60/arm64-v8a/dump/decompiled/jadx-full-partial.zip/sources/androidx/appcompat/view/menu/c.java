package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import p.InterfaceMenuItemC7302b;

/* loaded from: classes.dex */
abstract class c {

    /* renamed from: a, reason: collision with root package name */
    final Context f3052a;

    /* renamed from: b, reason: collision with root package name */
    private androidx.collection.k f3053b;

    /* renamed from: c, reason: collision with root package name */
    private androidx.collection.k f3054c;

    c(Context context) {
        this.f3052a = context;
    }

    final MenuItem c(MenuItem menuItem) {
        if (!(menuItem instanceof InterfaceMenuItemC7302b)) {
            return menuItem;
        }
        InterfaceMenuItemC7302b interfaceMenuItemC7302b = (InterfaceMenuItemC7302b) menuItem;
        if (this.f3053b == null) {
            this.f3053b = new androidx.collection.k();
        }
        MenuItem menuItem2 = (MenuItem) this.f3053b.get(interfaceMenuItemC7302b);
        if (menuItem2 != null) {
            return menuItem2;
        }
        j jVar = new j(this.f3052a, interfaceMenuItemC7302b);
        this.f3053b.put(interfaceMenuItemC7302b, jVar);
        return jVar;
    }

    final SubMenu d(SubMenu subMenu) {
        return subMenu;
    }

    final void e() {
        androidx.collection.k kVar = this.f3053b;
        if (kVar != null) {
            kVar.clear();
        }
        androidx.collection.k kVar2 = this.f3054c;
        if (kVar2 != null) {
            kVar2.clear();
        }
    }

    final void f(int i5) {
        if (this.f3053b == null) {
            return;
        }
        int i6 = 0;
        while (i6 < this.f3053b.size()) {
            if (((InterfaceMenuItemC7302b) this.f3053b.g(i6)).getGroupId() == i5) {
                this.f3053b.i(i6);
                i6--;
            }
            i6++;
        }
    }

    final void g(int i5) {
        if (this.f3053b == null) {
            return;
        }
        for (int i6 = 0; i6 < this.f3053b.size(); i6++) {
            if (((InterfaceMenuItemC7302b) this.f3053b.g(i6)).getItemId() == i5) {
                this.f3053b.i(i6);
                return;
            }
        }
    }
}
