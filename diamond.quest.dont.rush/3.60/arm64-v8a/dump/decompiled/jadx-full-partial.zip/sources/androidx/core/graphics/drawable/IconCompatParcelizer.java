package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    public static IconCompat read(androidx.versionedparcelable.b bVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f4369a = bVar.p(iconCompat.f4369a, 1);
        iconCompat.f4371c = bVar.j(iconCompat.f4371c, 2);
        iconCompat.f4372d = bVar.r(iconCompat.f4372d, 3);
        iconCompat.f4373e = bVar.p(iconCompat.f4373e, 4);
        iconCompat.f4374f = bVar.p(iconCompat.f4374f, 5);
        iconCompat.f4375g = (ColorStateList) bVar.r(iconCompat.f4375g, 6);
        iconCompat.f4377i = bVar.t(iconCompat.f4377i, 7);
        iconCompat.f4378j = bVar.t(iconCompat.f4378j, 8);
        iconCompat.y();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, androidx.versionedparcelable.b bVar) {
        bVar.x(true, true);
        iconCompat.z(bVar.f());
        int i5 = iconCompat.f4369a;
        if (-1 != i5) {
            bVar.F(i5, 1);
        }
        byte[] bArr = iconCompat.f4371c;
        if (bArr != null) {
            bVar.B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f4372d;
        if (parcelable != null) {
            bVar.H(parcelable, 3);
        }
        int i6 = iconCompat.f4373e;
        if (i6 != 0) {
            bVar.F(i6, 4);
        }
        int i7 = iconCompat.f4374f;
        if (i7 != 0) {
            bVar.F(i7, 5);
        }
        ColorStateList colorStateList = iconCompat.f4375g;
        if (colorStateList != null) {
            bVar.H(colorStateList, 6);
        }
        String str = iconCompat.f4377i;
        if (str != null) {
            bVar.J(str, 7);
        }
        String str2 = iconCompat.f4378j;
        if (str2 != null) {
            bVar.J(str2, 8);
        }
    }
}
