package androidx.core.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/* loaded from: classes.dex */
public final class x {
    private x() {
    }

    private static int a(boolean z4, int i5) {
        int i6;
        if (!z4) {
            i6 = 67108864;
        } else {
            if (Build.VERSION.SDK_INT < 31) {
                return i5;
            }
            i6 = 33554432;
        }
        return i6 | i5;
    }

    public static PendingIntent b(Context context, int i5, Intent intent, int i6, boolean z4) {
        return PendingIntent.getActivity(context, i5, intent, a(z4, i6));
    }
}
