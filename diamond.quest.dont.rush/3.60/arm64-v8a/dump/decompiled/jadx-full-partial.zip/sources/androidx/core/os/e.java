package androidx.core.os;

import android.os.CancellationSignal;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    private boolean f4407a;

    /* renamed from: b, reason: collision with root package name */
    private a f4408b;

    /* renamed from: c, reason: collision with root package name */
    private Object f4409c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f4410d;

    public interface a {
        void onCancel();
    }

    private void c() {
        while (this.f4410d) {
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
    }

    public void a() {
        synchronized (this) {
            try {
                if (this.f4407a) {
                    return;
                }
                this.f4407a = true;
                this.f4410d = true;
                a aVar = this.f4408b;
                Object obj = this.f4409c;
                if (aVar != null) {
                    try {
                        aVar.onCancel();
                    } catch (Throwable th) {
                        synchronized (this) {
                            this.f4410d = false;
                            notifyAll();
                            throw th;
                        }
                    }
                }
                if (obj != null) {
                    ((CancellationSignal) obj).cancel();
                }
                synchronized (this) {
                    this.f4410d = false;
                    notifyAll();
                }
            } finally {
            }
        }
    }

    public void b(a aVar) {
        synchronized (this) {
            try {
                c();
                if (this.f4408b == aVar) {
                    return;
                }
                this.f4408b = aVar;
                if (this.f4407a && aVar != null) {
                    aVar.onCancel();
                }
            } finally {
            }
        }
    }
}
