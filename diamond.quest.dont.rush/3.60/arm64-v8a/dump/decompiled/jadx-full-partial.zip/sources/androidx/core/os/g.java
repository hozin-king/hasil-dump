package androidx.core.os;

import K3.r;
import android.os.OutcomeReceiver;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
final class g extends AtomicBoolean implements OutcomeReceiver {

    /* renamed from: b, reason: collision with root package name */
    private final O3.d f4411b;

    public g(O3.d dVar) {
        super(false);
        this.f4411b = dVar;
    }

    public void onError(Throwable th) {
        if (compareAndSet(false, true)) {
            O3.d dVar = this.f4411b;
            r.a aVar = K3.r.f1391c;
            dVar.resumeWith(K3.r.b(K3.s.a(th)));
        }
    }

    public void onResult(Object obj) {
        if (compareAndSet(false, true)) {
            this.f4411b.resumeWith(K3.r.b(obj));
        }
    }

    @Override // java.util.concurrent.atomic.AtomicBoolean
    public String toString() {
        return "ContinuationOutcomeReceiver(outcomeReceived = " + get() + ')';
    }
}
