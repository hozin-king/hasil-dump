package androidx.appcompat.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vungle.ads.internal.signals.SignalManager;
import java.util.Calendar;

/* loaded from: classes.dex */
class F {

    /* renamed from: d, reason: collision with root package name */
    private static F f2674d;

    /* renamed from: a, reason: collision with root package name */
    private final Context f2675a;

    /* renamed from: b, reason: collision with root package name */
    private final LocationManager f2676b;

    /* renamed from: c, reason: collision with root package name */
    private final a f2677c = new a();

    private static class a {

        /* renamed from: a, reason: collision with root package name */
        boolean f2678a;

        /* renamed from: b, reason: collision with root package name */
        long f2679b;

        a() {
        }
    }

    F(Context context, LocationManager locationManager) {
        this.f2675a = context;
        this.f2676b = locationManager;
    }

    static F a(Context context) {
        if (f2674d == null) {
            Context applicationContext = context.getApplicationContext();
            f2674d = new F(applicationContext, (LocationManager) applicationContext.getSystemService(FirebaseAnalytics.Param.LOCATION));
        }
        return f2674d;
    }

    private Location b() {
        Location c5 = androidx.core.content.e.c(this.f2675a, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? c("network") : null;
        Location c6 = androidx.core.content.e.c(this.f2675a, "android.permission.ACCESS_FINE_LOCATION") == 0 ? c("gps") : null;
        return (c6 == null || c5 == null) ? c6 != null ? c6 : c5 : c6.getTime() > c5.getTime() ? c6 : c5;
    }

    private Location c(String str) {
        try {
            if (this.f2676b.isProviderEnabled(str)) {
                return this.f2676b.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e5) {
            Log.d("TwilightManager", "Failed to get last known location", e5);
            return null;
        }
    }

    private boolean e() {
        return this.f2677c.f2679b > System.currentTimeMillis();
    }

    private void f(Location location) {
        long j5;
        a aVar = this.f2677c;
        long currentTimeMillis = System.currentTimeMillis();
        E b5 = E.b();
        b5.a(currentTimeMillis - SignalManager.TWENTY_FOUR_HOURS_MILLIS, location.getLatitude(), location.getLongitude());
        b5.a(currentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z4 = b5.f2673c == 1;
        long j6 = b5.f2672b;
        long j7 = b5.f2671a;
        b5.a(currentTimeMillis + SignalManager.TWENTY_FOUR_HOURS_MILLIS, location.getLatitude(), location.getLongitude());
        long j8 = b5.f2672b;
        if (j6 == -1 || j7 == -1) {
            j5 = currentTimeMillis + 43200000;
        } else {
            if (currentTimeMillis > j7) {
                j6 = j8;
            } else if (currentTimeMillis > j6) {
                j6 = j7;
            }
            j5 = j6 + 60000;
        }
        aVar.f2678a = z4;
        aVar.f2679b = j5;
    }

    boolean d() {
        a aVar = this.f2677c;
        if (e()) {
            return aVar.f2678a;
        }
        Location b5 = b();
        if (b5 != null) {
            f(b5);
            return aVar.f2678a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i5 = Calendar.getInstance().get(11);
        return i5 < 6 || i5 >= 22;
    }
}
