package androidx.core.view;

import android.view.MotionEvent;

/* loaded from: classes.dex */
class Z {

    /* renamed from: a, reason: collision with root package name */
    private final float[] f4509a = new float[20];

    /* renamed from: b, reason: collision with root package name */
    private final long[] f4510b = new long[20];

    /* renamed from: c, reason: collision with root package name */
    private float f4511c = 0.0f;

    /* renamed from: d, reason: collision with root package name */
    private int f4512d = 0;

    /* renamed from: e, reason: collision with root package name */
    private int f4513e = 0;

    Z() {
    }

    private void b() {
        this.f4512d = 0;
        this.f4511c = 0.0f;
    }

    private float e() {
        long[] jArr;
        long j5;
        int i5 = this.f4512d;
        if (i5 < 2) {
            return 0.0f;
        }
        int i6 = this.f4513e;
        int i7 = ((i6 + 20) - (i5 - 1)) % 20;
        long j6 = this.f4510b[i6];
        while (true) {
            jArr = this.f4510b;
            j5 = jArr[i7];
            if (j6 - j5 <= 100) {
                break;
            }
            this.f4512d--;
            i7 = (i7 + 1) % 20;
        }
        int i8 = this.f4512d;
        if (i8 < 2) {
            return 0.0f;
        }
        if (i8 == 2) {
            int i9 = (i7 + 1) % 20;
            if (j5 == jArr[i9]) {
                return 0.0f;
            }
            return this.f4509a[i9] / (r2 - j5);
        }
        float f5 = 0.0f;
        int i10 = 0;
        for (int i11 = 0; i11 < this.f4512d - 1; i11++) {
            int i12 = i11 + i7;
            long[] jArr2 = this.f4510b;
            long j7 = jArr2[i12 % 20];
            int i13 = (i12 + 1) % 20;
            if (jArr2[i13] != j7) {
                i10++;
                float f6 = f(f5);
                float f7 = this.f4509a[i13] / (this.f4510b[i13] - j7);
                f5 += (f7 - f6) * Math.abs(f7);
                if (i10 == 1) {
                    f5 *= 0.5f;
                }
            }
        }
        return f(f5);
    }

    private static float f(float f5) {
        return (f5 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f5) * 2.0f));
    }

    void a(MotionEvent motionEvent) {
        long eventTime = motionEvent.getEventTime();
        if (this.f4512d != 0 && eventTime - this.f4510b[this.f4513e] > 40) {
            b();
        }
        int i5 = (this.f4513e + 1) % 20;
        this.f4513e = i5;
        int i6 = this.f4512d;
        if (i6 != 20) {
            this.f4512d = i6 + 1;
        }
        this.f4509a[i5] = motionEvent.getAxisValue(26);
        this.f4510b[this.f4513e] = eventTime;
    }

    void c(int i5, float f5) {
        float e5 = e() * i5;
        this.f4511c = e5;
        if (e5 < (-Math.abs(f5))) {
            this.f4511c = -Math.abs(f5);
        } else if (this.f4511c > Math.abs(f5)) {
            this.f4511c = Math.abs(f5);
        }
    }

    float d(int i5) {
        if (i5 != 26) {
            return 0.0f;
        }
        return this.f4511c;
    }
}
