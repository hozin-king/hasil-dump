package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

/* loaded from: classes.dex */
public abstract class P implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* renamed from: b, reason: collision with root package name */
    private final float f3415b;

    /* renamed from: c, reason: collision with root package name */
    private final int f3416c;

    /* renamed from: d, reason: collision with root package name */
    private final int f3417d;

    /* renamed from: e, reason: collision with root package name */
    final View f3418e;

    /* renamed from: f, reason: collision with root package name */
    private Runnable f3419f;

    /* renamed from: g, reason: collision with root package name */
    private Runnable f3420g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f3421h;

    /* renamed from: i, reason: collision with root package name */
    private int f3422i;

    /* renamed from: j, reason: collision with root package name */
    private final int[] f3423j = new int[2];

    private class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ViewParent parent = P.this.f3418e.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
    }

    private class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            P.this.e();
        }
    }

    public P(View view) {
        this.f3418e = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f3415b = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.f3416c = tapTimeout;
        this.f3417d = (tapTimeout + ViewConfiguration.getLongPressTimeout()) / 2;
    }

    private void a() {
        Runnable runnable = this.f3420g;
        if (runnable != null) {
            this.f3418e.removeCallbacks(runnable);
        }
        Runnable runnable2 = this.f3419f;
        if (runnable2 != null) {
            this.f3418e.removeCallbacks(runnable2);
        }
    }

    private boolean f(MotionEvent motionEvent) {
        N n5;
        View view = this.f3418e;
        androidx.appcompat.view.menu.p b5 = b();
        if (b5 != null && b5.isShowing() && (n5 = (N) b5.getListView()) != null && n5.isShown()) {
            MotionEvent obtainNoHistory = MotionEvent.obtainNoHistory(motionEvent);
            i(view, obtainNoHistory);
            j(n5, obtainNoHistory);
            boolean e5 = n5.e(obtainNoHistory, this.f3422i);
            obtainNoHistory.recycle();
            int actionMasked = motionEvent.getActionMasked();
            boolean z4 = (actionMasked == 1 || actionMasked == 3) ? false : true;
            if (e5 && z4) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0017, code lost:
    
        if (r1 != 3) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean g(android.view.MotionEvent r6) {
        /*
            r5 = this;
            android.view.View r0 = r5.f3418e
            boolean r1 = r0.isEnabled()
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            int r1 = r6.getActionMasked()
            if (r1 == 0) goto L41
            r3 = 1
            if (r1 == r3) goto L3d
            r4 = 2
            if (r1 == r4) goto L1a
            r6 = 3
            if (r1 == r6) goto L3d
            goto L6d
        L1a:
            int r1 = r5.f3422i
            int r1 = r6.findPointerIndex(r1)
            if (r1 < 0) goto L6d
            float r4 = r6.getX(r1)
            float r6 = r6.getY(r1)
            float r1 = r5.f3415b
            boolean r6 = h(r0, r4, r6, r1)
            if (r6 != 0) goto L6d
            r5.a()
            android.view.ViewParent r6 = r0.getParent()
            r6.requestDisallowInterceptTouchEvent(r3)
            return r3
        L3d:
            r5.a()
            goto L6d
        L41:
            int r6 = r6.getPointerId(r2)
            r5.f3422i = r6
            java.lang.Runnable r6 = r5.f3419f
            if (r6 != 0) goto L52
            androidx.appcompat.widget.P$a r6 = new androidx.appcompat.widget.P$a
            r6.<init>()
            r5.f3419f = r6
        L52:
            java.lang.Runnable r6 = r5.f3419f
            int r1 = r5.f3416c
            long r3 = (long) r1
            r0.postDelayed(r6, r3)
            java.lang.Runnable r6 = r5.f3420g
            if (r6 != 0) goto L65
            androidx.appcompat.widget.P$b r6 = new androidx.appcompat.widget.P$b
            r6.<init>()
            r5.f3420g = r6
        L65:
            java.lang.Runnable r6 = r5.f3420g
            int r1 = r5.f3417d
            long r3 = (long) r1
            r0.postDelayed(r6, r3)
        L6d:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.P.g(android.view.MotionEvent):boolean");
    }

    private static boolean h(View view, float f5, float f6, float f7) {
        float f8 = -f7;
        return f5 >= f8 && f6 >= f8 && f5 < ((float) (view.getRight() - view.getLeft())) + f7 && f6 < ((float) (view.getBottom() - view.getTop())) + f7;
    }

    private boolean i(View view, MotionEvent motionEvent) {
        view.getLocationOnScreen(this.f3423j);
        motionEvent.offsetLocation(r0[0], r0[1]);
        return true;
    }

    private boolean j(View view, MotionEvent motionEvent) {
        view.getLocationOnScreen(this.f3423j);
        motionEvent.offsetLocation(-r0[0], -r0[1]);
        return true;
    }

    public abstract androidx.appcompat.view.menu.p b();

    protected boolean c() {
        androidx.appcompat.view.menu.p b5 = b();
        if (b5 == null || b5.isShowing()) {
            return true;
        }
        b5.show();
        return true;
    }

    protected boolean d() {
        androidx.appcompat.view.menu.p b5 = b();
        if (b5 == null || !b5.isShowing()) {
            return true;
        }
        b5.dismiss();
        return true;
    }

    void e() {
        a();
        View view = this.f3418e;
        if (view.isEnabled() && !view.isLongClickable() && c()) {
            view.getParent().requestDisallowInterceptTouchEvent(true);
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            view.onTouchEvent(obtain);
            obtain.recycle();
            this.f3421h = true;
        }
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z4;
        boolean z5 = this.f3421h;
        if (z5) {
            z4 = f(motionEvent) || !d();
        } else {
            z4 = g(motionEvent) && c();
            if (z4) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                this.f3418e.onTouchEvent(obtain);
                obtain.recycle();
            }
        }
        this.f3421h = z4;
        return z4 || z5;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        this.f3421h = false;
        this.f3422i = -1;
        Runnable runnable = this.f3419f;
        if (runnable != null) {
            this.f3418e.removeCallbacks(runnable);
        }
    }
}
