package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.C1015b0;
import androidx.core.view.C1023f0;

/* loaded from: classes.dex */
class o0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: l, reason: collision with root package name */
    private static o0 f3840l;

    /* renamed from: m, reason: collision with root package name */
    private static o0 f3841m;

    /* renamed from: b, reason: collision with root package name */
    private final View f3842b;

    /* renamed from: c, reason: collision with root package name */
    private final CharSequence f3843c;

    /* renamed from: d, reason: collision with root package name */
    private final int f3844d;

    /* renamed from: e, reason: collision with root package name */
    private final Runnable f3845e = new Runnable() { // from class: androidx.appcompat.widget.m0
        @Override // java.lang.Runnable
        public final void run() {
            o0.this.h(false);
        }
    };

    /* renamed from: f, reason: collision with root package name */
    private final Runnable f3846f = new Runnable() { // from class: androidx.appcompat.widget.n0
        @Override // java.lang.Runnable
        public final void run() {
            o0.this.d();
        }
    };

    /* renamed from: g, reason: collision with root package name */
    private int f3847g;

    /* renamed from: h, reason: collision with root package name */
    private int f3848h;

    /* renamed from: i, reason: collision with root package name */
    private p0 f3849i;

    /* renamed from: j, reason: collision with root package name */
    private boolean f3850j;

    /* renamed from: k, reason: collision with root package name */
    private boolean f3851k;

    private o0(View view, CharSequence charSequence) {
        this.f3842b = view;
        this.f3843c = charSequence;
        this.f3844d = C1023f0.g(ViewConfiguration.get(view.getContext()));
        c();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    private void b() {
        this.f3842b.removeCallbacks(this.f3845e);
    }

    private void c() {
        this.f3851k = true;
    }

    private void e() {
        this.f3842b.postDelayed(this.f3845e, ViewConfiguration.getLongPressTimeout());
    }

    private static void f(o0 o0Var) {
        o0 o0Var2 = f3840l;
        if (o0Var2 != null) {
            o0Var2.b();
        }
        f3840l = o0Var;
        if (o0Var != null) {
            o0Var.e();
        }
    }

    public static void g(View view, CharSequence charSequence) {
        o0 o0Var = f3840l;
        if (o0Var != null && o0Var.f3842b == view) {
            f(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new o0(view, charSequence);
            return;
        }
        o0 o0Var2 = f3841m;
        if (o0Var2 != null && o0Var2.f3842b == view) {
            o0Var2.d();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }

    private boolean i(MotionEvent motionEvent) {
        int x5 = (int) motionEvent.getX();
        int y5 = (int) motionEvent.getY();
        if (!this.f3851k && Math.abs(x5 - this.f3847g) <= this.f3844d && Math.abs(y5 - this.f3848h) <= this.f3844d) {
            return false;
        }
        this.f3847g = x5;
        this.f3848h = y5;
        this.f3851k = false;
        return true;
    }

    void d() {
        if (f3841m == this) {
            f3841m = null;
            p0 p0Var = this.f3849i;
            if (p0Var != null) {
                p0Var.c();
                this.f3849i = null;
                c();
                this.f3842b.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f3840l == this) {
            f(null);
        }
        this.f3842b.removeCallbacks(this.f3846f);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(boolean z4) {
        long longPressTimeout;
        long j5;
        long j6;
        if (this.f3842b.isAttachedToWindow()) {
            f(null);
            o0 o0Var = f3841m;
            if (o0Var != null) {
                o0Var.d();
            }
            f3841m = this;
            this.f3850j = z4;
            p0 p0Var = new p0(this.f3842b.getContext());
            this.f3849i = p0Var;
            p0Var.e(this.f3842b, this.f3847g, this.f3848h, this.f3850j, this.f3843c);
            this.f3842b.addOnAttachStateChangeListener(this);
            if (this.f3850j) {
                j6 = 2500;
            } else {
                if ((C1015b0.F(this.f3842b) & 1) == 1) {
                    longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    j5 = io.bidmachine.media3.common.C.DEFAULT_MAX_SEEK_TO_PREVIOUS_POSITION_MS;
                } else {
                    longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    j5 = 15000;
                }
                j6 = j5 - longPressTimeout;
            }
            this.f3842b.removeCallbacks(this.f3846f);
            this.f3842b.postDelayed(this.f3846f, j6);
        }
    }

    @Override // android.view.View.OnHoverListener
    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.f3849i != null && this.f3850j) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f3842b.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                c();
                d();
            }
        } else if (this.f3842b.isEnabled() && this.f3849i == null && i(motionEvent)) {
            f(this);
        }
        return false;
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View view) {
        this.f3847g = view.getWidth() / 2;
        this.f3848h = view.getHeight() / 2;
        h(true);
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        d();
    }
}
