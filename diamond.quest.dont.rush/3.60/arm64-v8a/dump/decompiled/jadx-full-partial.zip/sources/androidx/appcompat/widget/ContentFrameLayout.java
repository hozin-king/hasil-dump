package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/* loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    private TypedValue f3373b;

    /* renamed from: c, reason: collision with root package name */
    private TypedValue f3374c;

    /* renamed from: d, reason: collision with root package name */
    private TypedValue f3375d;

    /* renamed from: e, reason: collision with root package name */
    private TypedValue f3376e;

    /* renamed from: f, reason: collision with root package name */
    private TypedValue f3377f;

    /* renamed from: g, reason: collision with root package name */
    private TypedValue f3378g;

    /* renamed from: h, reason: collision with root package name */
    private final Rect f3379h;

    /* renamed from: i, reason: collision with root package name */
    private a f3380i;

    public interface a {
        void a();

        void onDetachedFromWindow();
    }

    public ContentFrameLayout(@NonNull Context context) {
        this(context, null);
    }

    public void a(int i5, int i6, int i7, int i8) {
        this.f3379h.set(i5, i6, i7, i8);
        if (isLaidOut()) {
            requestLayout();
        }
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f3377f == null) {
            this.f3377f = new TypedValue();
        }
        return this.f3377f;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f3378g == null) {
            this.f3378g = new TypedValue();
        }
        return this.f3378g;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f3375d == null) {
            this.f3375d = new TypedValue();
        }
        return this.f3375d;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f3376e == null) {
            this.f3376e = new TypedValue();
        }
        return this.f3376e;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f3373b == null) {
            this.f3373b = new TypedValue();
        }
        return this.f3373b;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f3374c == null) {
            this.f3374c = new TypedValue();
        }
        return this.f3374c;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        a aVar = this.f3380i;
        if (aVar != null) {
            aVar.a();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a aVar = this.f3380i;
        if (aVar != null) {
            aVar.onDetachedFromWindow();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00ae  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(a aVar) {
        this.f3380i = aVar;
    }

    public ContentFrameLayout(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        this.f3379h = new Rect();
    }
}
