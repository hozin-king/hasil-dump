package androidx.core.text;

import android.text.SpannableStringBuilder;
import com.google.common.base.Ascii;
import java.util.Locale;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: d, reason: collision with root package name */
    static final t f4428d;

    /* renamed from: e, reason: collision with root package name */
    private static final String f4429e;

    /* renamed from: f, reason: collision with root package name */
    private static final String f4430f;

    /* renamed from: g, reason: collision with root package name */
    static final a f4431g;

    /* renamed from: h, reason: collision with root package name */
    static final a f4432h;

    /* renamed from: a, reason: collision with root package name */
    private final boolean f4433a;

    /* renamed from: b, reason: collision with root package name */
    private final int f4434b;

    /* renamed from: c, reason: collision with root package name */
    private final t f4435c;

    private static class b {

        /* renamed from: f, reason: collision with root package name */
        private static final byte[] f4439f = new byte[1792];

        /* renamed from: a, reason: collision with root package name */
        private final CharSequence f4440a;

        /* renamed from: b, reason: collision with root package name */
        private final boolean f4441b;

        /* renamed from: c, reason: collision with root package name */
        private final int f4442c;

        /* renamed from: d, reason: collision with root package name */
        private int f4443d;

        /* renamed from: e, reason: collision with root package name */
        private char f4444e;

        static {
            for (int i5 = 0; i5 < 1792; i5++) {
                f4439f[i5] = Character.getDirectionality(i5);
            }
        }

        b(CharSequence charSequence, boolean z4) {
            this.f4440a = charSequence;
            this.f4441b = z4;
            this.f4442c = charSequence.length();
        }

        private static byte c(char c5) {
            return c5 < 1792 ? f4439f[c5] : Character.getDirectionality(c5);
        }

        private byte f() {
            char charAt;
            int i5 = this.f4443d;
            do {
                int i6 = this.f4443d;
                if (i6 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f4440a;
                int i7 = i6 - 1;
                this.f4443d = i7;
                charAt = charSequence.charAt(i7);
                this.f4444e = charAt;
                if (charAt == '&') {
                    return Ascii.FF;
                }
            } while (charAt != ';');
            this.f4443d = i5;
            this.f4444e = ';';
            return Ascii.CR;
        }

        private byte g() {
            char charAt;
            do {
                int i5 = this.f4443d;
                if (i5 >= this.f4442c) {
                    return Ascii.FF;
                }
                CharSequence charSequence = this.f4440a;
                this.f4443d = i5 + 1;
                charAt = charSequence.charAt(i5);
                this.f4444e = charAt;
            } while (charAt != ';');
            return Ascii.FF;
        }

        private byte h() {
            char charAt;
            int i5 = this.f4443d;
            while (true) {
                int i6 = this.f4443d;
                if (i6 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f4440a;
                int i7 = i6 - 1;
                this.f4443d = i7;
                char charAt2 = charSequence.charAt(i7);
                this.f4444e = charAt2;
                if (charAt2 == '<') {
                    return Ascii.FF;
                }
                if (charAt2 == '>') {
                    break;
                }
                if (charAt2 == '\"' || charAt2 == '\'') {
                    do {
                        int i8 = this.f4443d;
                        if (i8 > 0) {
                            CharSequence charSequence2 = this.f4440a;
                            int i9 = i8 - 1;
                            this.f4443d = i9;
                            charAt = charSequence2.charAt(i9);
                            this.f4444e = charAt;
                        }
                    } while (charAt != charAt2);
                }
            }
            this.f4443d = i5;
            this.f4444e = '>';
            return Ascii.CR;
        }

        private byte i() {
            char charAt;
            int i5 = this.f4443d;
            while (true) {
                int i6 = this.f4443d;
                if (i6 >= this.f4442c) {
                    this.f4443d = i5;
                    this.f4444e = '<';
                    return Ascii.CR;
                }
                CharSequence charSequence = this.f4440a;
                this.f4443d = i6 + 1;
                char charAt2 = charSequence.charAt(i6);
                this.f4444e = charAt2;
                if (charAt2 == '>') {
                    return Ascii.FF;
                }
                if (charAt2 == '\"' || charAt2 == '\'') {
                    do {
                        int i7 = this.f4443d;
                        if (i7 < this.f4442c) {
                            CharSequence charSequence2 = this.f4440a;
                            this.f4443d = i7 + 1;
                            charAt = charSequence2.charAt(i7);
                            this.f4444e = charAt;
                        }
                    } while (charAt != charAt2);
                }
            }
        }

        byte a() {
            char charAt = this.f4440a.charAt(this.f4443d - 1);
            this.f4444e = charAt;
            if (Character.isLowSurrogate(charAt)) {
                int codePointBefore = Character.codePointBefore(this.f4440a, this.f4443d);
                this.f4443d -= Character.charCount(codePointBefore);
                return Character.getDirectionality(codePointBefore);
            }
            this.f4443d--;
            byte c5 = c(this.f4444e);
            if (!this.f4441b) {
                return c5;
            }
            char c6 = this.f4444e;
            return c6 == '>' ? h() : c6 == ';' ? f() : c5;
        }

        byte b() {
            char charAt = this.f4440a.charAt(this.f4443d);
            this.f4444e = charAt;
            if (Character.isHighSurrogate(charAt)) {
                int codePointAt = Character.codePointAt(this.f4440a, this.f4443d);
                this.f4443d += Character.charCount(codePointAt);
                return Character.getDirectionality(codePointAt);
            }
            this.f4443d++;
            byte c5 = c(this.f4444e);
            if (!this.f4441b) {
                return c5;
            }
            char c6 = this.f4444e;
            return c6 == '<' ? i() : c6 == '&' ? g() : c5;
        }

        int d() {
            this.f4443d = 0;
            int i5 = 0;
            int i6 = 0;
            int i7 = 0;
            while (this.f4443d < this.f4442c && i5 == 0) {
                byte b5 = b();
                if (b5 != 0) {
                    if (b5 == 1 || b5 == 2) {
                        if (i7 == 0) {
                            return 1;
                        }
                    } else if (b5 != 9) {
                        switch (b5) {
                            case 14:
                            case 15:
                                i7++;
                                i6 = -1;
                                continue;
                            case 16:
                            case 17:
                                i7++;
                                i6 = 1;
                                continue;
                            case 18:
                                i7--;
                                i6 = 0;
                                continue;
                        }
                    }
                } else if (i7 == 0) {
                    return -1;
                }
                i5 = i7;
            }
            if (i5 == 0) {
                return 0;
            }
            if (i6 != 0) {
                return i6;
            }
            while (this.f4443d > 0) {
                switch (a()) {
                    case 14:
                    case 15:
                        if (i5 == i7) {
                            return -1;
                        }
                        break;
                    case 16:
                    case 17:
                        if (i5 == i7) {
                            return 1;
                        }
                        break;
                    case 18:
                        i7++;
                        continue;
                }
                i7--;
            }
            return 0;
        }

        int e() {
            this.f4443d = this.f4442c;
            int i5 = 0;
            while (true) {
                int i6 = i5;
                while (this.f4443d > 0) {
                    byte a5 = a();
                    if (a5 != 0) {
                        if (a5 == 1 || a5 == 2) {
                            if (i5 == 0) {
                                return 1;
                            }
                            if (i6 == 0) {
                                break;
                            }
                        } else if (a5 != 9) {
                            switch (a5) {
                                case 14:
                                case 15:
                                    if (i6 == i5) {
                                        return -1;
                                    }
                                    i5--;
                                    break;
                                case 16:
                                case 17:
                                    if (i6 == i5) {
                                        return 1;
                                    }
                                    i5--;
                                    break;
                                case 18:
                                    i5++;
                                    break;
                                default:
                                    if (i6 != 0) {
                                        break;
                                    } else {
                                        break;
                                    }
                            }
                        } else {
                            continue;
                        }
                    } else {
                        if (i5 == 0) {
                            return -1;
                        }
                        if (i6 == 0) {
                            break;
                        }
                    }
                }
                return 0;
            }
        }
    }

    static {
        t tVar = u.f4462c;
        f4428d = tVar;
        f4429e = Character.toString((char) 8206);
        f4430f = Character.toString((char) 8207);
        f4431g = new a(false, 2, tVar);
        f4432h = new a(true, 2, tVar);
    }

    a(boolean z4, int i5, t tVar) {
        this.f4433a = z4;
        this.f4434b = i5;
        this.f4435c = tVar;
    }

    private static int a(CharSequence charSequence) {
        return new b(charSequence, false).d();
    }

    private static int b(CharSequence charSequence) {
        return new b(charSequence, false).e();
    }

    public static a c() {
        return new C0128a().a();
    }

    static boolean e(Locale locale) {
        return v.a(locale) == 1;
    }

    private String f(CharSequence charSequence, t tVar) {
        boolean isRtl = tVar.isRtl(charSequence, 0, charSequence.length());
        return (this.f4433a || !(isRtl || b(charSequence) == 1)) ? this.f4433a ? (!isRtl || b(charSequence) == -1) ? f4430f : "" : "" : f4429e;
    }

    private String g(CharSequence charSequence, t tVar) {
        boolean isRtl = tVar.isRtl(charSequence, 0, charSequence.length());
        return (this.f4433a || !(isRtl || a(charSequence) == 1)) ? this.f4433a ? (!isRtl || a(charSequence) == -1) ? f4430f : "" : "" : f4429e;
    }

    public boolean d() {
        return (this.f4434b & 2) != 0;
    }

    public CharSequence h(CharSequence charSequence) {
        return i(charSequence, this.f4435c, true);
    }

    public CharSequence i(CharSequence charSequence, t tVar, boolean z4) {
        if (charSequence == null) {
            return null;
        }
        boolean isRtl = tVar.isRtl(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (d() && z4) {
            spannableStringBuilder.append((CharSequence) g(charSequence, isRtl ? u.f4461b : u.f4460a));
        }
        if (isRtl != this.f4433a) {
            spannableStringBuilder.append(isRtl ? (char) 8235 : (char) 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append((char) 8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z4) {
            spannableStringBuilder.append((CharSequence) f(charSequence, isRtl ? u.f4461b : u.f4460a));
        }
        return spannableStringBuilder;
    }

    /* renamed from: androidx.core.text.a$a, reason: collision with other inner class name */
    public static final class C0128a {

        /* renamed from: a, reason: collision with root package name */
        private boolean f4436a;

        /* renamed from: b, reason: collision with root package name */
        private int f4437b;

        /* renamed from: c, reason: collision with root package name */
        private t f4438c;

        public C0128a() {
            c(a.e(Locale.getDefault()));
        }

        private static a b(boolean z4) {
            return z4 ? a.f4432h : a.f4431g;
        }

        private void c(boolean z4) {
            this.f4436a = z4;
            this.f4438c = a.f4428d;
            this.f4437b = 2;
        }

        public a a() {
            return (this.f4437b == 2 && this.f4438c == a.f4428d) ? b(this.f4436a) : new a(this.f4436a, this.f4437b, this.f4438c);
        }

        public C0128a(boolean z4) {
            c(z4);
        }

        public C0128a(Locale locale) {
            c(a.e(locale));
        }
    }
}
