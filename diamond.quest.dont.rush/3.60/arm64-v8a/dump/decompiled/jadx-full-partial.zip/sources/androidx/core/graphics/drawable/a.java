package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: androidx.core.graphics.drawable.a$a, reason: collision with other inner class name */
    static class C0126a {
        static void a(Drawable drawable, Resources.Theme theme) {
            drawable.applyTheme(theme);
        }

        static boolean b(Drawable drawable) {
            return drawable.canApplyTheme();
        }

        static ColorFilter c(Drawable drawable) {
            return drawable.getColorFilter();
        }

        static void d(Drawable drawable, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException, IOException {
            drawable.inflate(resources, xmlPullParser, attributeSet, theme);
        }

        static void e(Drawable drawable, float f5, float f6) {
            drawable.setHotspot(f5, f6);
        }

        static void f(Drawable drawable, int i5, int i6, int i7, int i8) {
            drawable.setHotspotBounds(i5, i6, i7, i8);
        }

        static void g(Drawable drawable, int i5) {
            drawable.setTint(i5);
        }

        static void h(Drawable drawable, ColorStateList colorStateList) {
            drawable.setTintList(colorStateList);
        }

        static void i(Drawable drawable, PorterDuff.Mode mode) {
            drawable.setTintMode(mode);
        }
    }

    static class b {
        static int a(Drawable drawable) {
            return drawable.getLayoutDirection();
        }

        static boolean b(Drawable drawable, int i5) {
            return drawable.setLayoutDirection(i5);
        }
    }

    private a() {
    }

    public static void a(Drawable drawable, Resources.Theme theme) {
        C0126a.a(drawable, theme);
    }

    public static boolean b(Drawable drawable) {
        return C0126a.b(drawable);
    }

    public static int c(Drawable drawable) {
        return drawable.getAlpha();
    }

    public static ColorFilter d(Drawable drawable) {
        return C0126a.c(drawable);
    }

    public static int e(Drawable drawable) {
        return b.a(drawable);
    }

    public static void f(Drawable drawable, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        C0126a.d(drawable, resources, xmlPullParser, attributeSet, theme);
    }

    public static boolean g(Drawable drawable) {
        return drawable.isAutoMirrored();
    }

    public static void h(Drawable drawable) {
        drawable.jumpToCurrentState();
    }

    public static void i(Drawable drawable, boolean z4) {
        drawable.setAutoMirrored(z4);
    }

    public static void j(Drawable drawable, float f5, float f6) {
        C0126a.e(drawable, f5, f6);
    }

    public static void k(Drawable drawable, int i5, int i6, int i7, int i8) {
        C0126a.f(drawable, i5, i6, i7, i8);
    }

    public static boolean l(Drawable drawable, int i5) {
        return b.b(drawable, i5);
    }

    public static void m(Drawable drawable, int i5) {
        C0126a.g(drawable, i5);
    }

    public static void n(Drawable drawable, ColorStateList colorStateList) {
        C0126a.h(drawable, colorStateList);
    }

    public static void o(Drawable drawable, PorterDuff.Mode mode) {
        C0126a.i(drawable, mode);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Drawable p(Drawable drawable) {
        return drawable instanceof c ? ((c) drawable).b() : drawable;
    }

    public static Drawable q(Drawable drawable) {
        return drawable;
    }
}
