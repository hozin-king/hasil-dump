package androidx.activity;

import android.view.View;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public abstract class z {
    public static final void a(View view, t fullyDrawnReporterOwner) {
        C7150s.j(view, "<this>");
        C7150s.j(fullyDrawnReporterOwner, "fullyDrawnReporterOwner");
        view.setTag(y.f2540a, fullyDrawnReporterOwner);
    }
}
