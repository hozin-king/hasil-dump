package androidx.core.text;

import java.util.Locale;

/* loaded from: classes.dex */
public final class u {

    /* renamed from: a, reason: collision with root package name */
    public static final t f4460a = new e(null, false);

    /* renamed from: b, reason: collision with root package name */
    public static final t f4461b = new e(null, true);

    /* renamed from: c, reason: collision with root package name */
    public static final t f4462c;

    /* renamed from: d, reason: collision with root package name */
    public static final t f4463d;

    /* renamed from: e, reason: collision with root package name */
    public static final t f4464e;

    /* renamed from: f, reason: collision with root package name */
    public static final t f4465f;

    private static class a implements c {

        /* renamed from: b, reason: collision with root package name */
        static final a f4466b = new a(true);

        /* renamed from: a, reason: collision with root package name */
        private final boolean f4467a;

        private a(boolean z4) {
            this.f4467a = z4;
        }

        @Override // androidx.core.text.u.c
        public int a(CharSequence charSequence, int i5, int i6) {
            int i7 = i6 + i5;
            boolean z4 = false;
            while (i5 < i7) {
                int a5 = u.a(Character.getDirectionality(charSequence.charAt(i5)));
                if (a5 != 0) {
                    if (a5 != 1) {
                        continue;
                        i5++;
                        z4 = z4;
                    } else if (!this.f4467a) {
                        return 1;
                    }
                } else if (this.f4467a) {
                    return 0;
                }
                z4 = true;
                i5++;
                z4 = z4;
            }
            if (z4) {
                return this.f4467a ? 1 : 0;
            }
            return 2;
        }
    }

    private static class b implements c {

        /* renamed from: a, reason: collision with root package name */
        static final b f4468a = new b();

        private b() {
        }

        @Override // androidx.core.text.u.c
        public int a(CharSequence charSequence, int i5, int i6) {
            int i7 = i6 + i5;
            int i8 = 2;
            while (i5 < i7 && i8 == 2) {
                i8 = u.b(Character.getDirectionality(charSequence.charAt(i5)));
                i5++;
            }
            return i8;
        }
    }

    private interface c {
        int a(CharSequence charSequence, int i5, int i6);
    }

    private static abstract class d implements t {

        /* renamed from: a, reason: collision with root package name */
        private final c f4469a;

        d(c cVar) {
            this.f4469a = cVar;
        }

        private boolean b(CharSequence charSequence, int i5, int i6) {
            int a5 = this.f4469a.a(charSequence, i5, i6);
            if (a5 == 0) {
                return true;
            }
            if (a5 != 1) {
                return a();
            }
            return false;
        }

        protected abstract boolean a();

        @Override // androidx.core.text.t
        public boolean isRtl(CharSequence charSequence, int i5, int i6) {
            if (charSequence == null || i5 < 0 || i6 < 0 || charSequence.length() - i6 < i5) {
                throw new IllegalArgumentException();
            }
            return this.f4469a == null ? a() : b(charSequence, i5, i6);
        }
    }

    private static class e extends d {

        /* renamed from: b, reason: collision with root package name */
        private final boolean f4470b;

        e(c cVar, boolean z4) {
            super(cVar);
            this.f4470b = z4;
        }

        @Override // androidx.core.text.u.d
        protected boolean a() {
            return this.f4470b;
        }
    }

    private static class f extends d {

        /* renamed from: b, reason: collision with root package name */
        static final f f4471b = new f();

        f() {
            super(null);
        }

        @Override // androidx.core.text.u.d
        protected boolean a() {
            return v.a(Locale.getDefault()) == 1;
        }
    }

    static {
        b bVar = b.f4468a;
        f4462c = new e(bVar, false);
        f4463d = new e(bVar, true);
        f4464e = new e(a.f4466b, false);
        f4465f = f.f4471b;
    }

    private u() {
    }

    static int a(int i5) {
        if (i5 != 0) {
            return (i5 == 1 || i5 == 2) ? 0 : 2;
        }
        return 1;
    }

    static int b(int i5) {
        if (i5 != 0) {
            if (i5 == 1 || i5 == 2) {
                return 0;
            }
            switch (i5) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
