package androidx.appcompat.app;

import java.util.LinkedHashSet;
import java.util.Locale;

/* loaded from: classes.dex */
abstract class B {
    private static androidx.core.os.j a(androidx.core.os.j jVar, androidx.core.os.j jVar2) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        int i5 = 0;
        while (i5 < jVar.g() + jVar2.g()) {
            Locale d5 = i5 < jVar.g() ? jVar.d(i5) : jVar2.d(i5 - jVar.g());
            if (d5 != null) {
                linkedHashSet.add(d5);
            }
            i5++;
        }
        return androidx.core.os.j.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]));
    }

    static androidx.core.os.j b(androidx.core.os.j jVar, androidx.core.os.j jVar2) {
        return (jVar == null || jVar.f()) ? androidx.core.os.j.e() : a(jVar, jVar2);
    }
}
