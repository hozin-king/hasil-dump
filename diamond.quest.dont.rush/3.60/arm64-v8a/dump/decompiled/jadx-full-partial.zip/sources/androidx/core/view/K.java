package androidx.core.view;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;

/* loaded from: classes.dex */
public class K {

    /* renamed from: a, reason: collision with root package name */
    private int f4487a;

    /* renamed from: b, reason: collision with root package name */
    private int f4488b;

    public K(@NonNull ViewGroup viewGroup) {
    }

    public int a() {
        return this.f4487a | this.f4488b;
    }

    public void b(View view, View view2, int i5) {
        c(view, view2, i5, 0);
    }

    public void c(View view, View view2, int i5, int i6) {
        if (i6 == 1) {
            this.f4488b = i5;
        } else {
            this.f4487a = i5;
        }
    }

    public void d(View view, int i5) {
        if (i5 == 1) {
            this.f4488b = 0;
        } else {
            this.f4487a = 0;
        }
    }
}
