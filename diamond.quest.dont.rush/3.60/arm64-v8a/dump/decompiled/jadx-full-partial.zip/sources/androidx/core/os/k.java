package androidx.core.os;

import com.ironsource.b9;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

/* loaded from: classes.dex */
final class k implements l {

    /* renamed from: c, reason: collision with root package name */
    private static final Locale[] f4416c = new Locale[0];

    /* renamed from: d, reason: collision with root package name */
    private static final Locale f4417d = new Locale("en", "XA");

    /* renamed from: e, reason: collision with root package name */
    private static final Locale f4418e = new Locale("ar", "XB");

    /* renamed from: f, reason: collision with root package name */
    private static final Locale f4419f = j.b("en-Latn");

    /* renamed from: a, reason: collision with root package name */
    private final Locale[] f4420a;

    /* renamed from: b, reason: collision with root package name */
    private final String f4421b;

    k(Locale... localeArr) {
        if (localeArr.length == 0) {
            this.f4420a = f4416c;
            this.f4421b = "";
            return;
        }
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet();
        StringBuilder sb = new StringBuilder();
        for (int i5 = 0; i5 < localeArr.length; i5++) {
            Locale locale = localeArr[i5];
            if (locale == null) {
                throw new NullPointerException("list[" + i5 + "] is null");
            }
            if (!hashSet.contains(locale)) {
                Locale locale2 = (Locale) locale.clone();
                arrayList.add(locale2);
                b(sb, locale2);
                if (i5 < localeArr.length - 1) {
                    sb.append(',');
                }
                hashSet.add(locale2);
            }
        }
        this.f4420a = (Locale[]) arrayList.toArray(new Locale[0]);
        this.f4421b = sb.toString();
    }

    static void b(StringBuilder sb, Locale locale) {
        sb.append(locale.getLanguage());
        String country = locale.getCountry();
        if (country == null || country.isEmpty()) {
            return;
        }
        sb.append('-');
        sb.append(locale.getCountry());
    }

    @Override // androidx.core.os.l
    public String a() {
        return this.f4421b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        Locale[] localeArr = ((k) obj).f4420a;
        if (this.f4420a.length != localeArr.length) {
            return false;
        }
        int i5 = 0;
        while (true) {
            Locale[] localeArr2 = this.f4420a;
            if (i5 >= localeArr2.length) {
                return true;
            }
            if (!localeArr2[i5].equals(localeArr[i5])) {
                return false;
            }
            i5++;
        }
    }

    @Override // androidx.core.os.l
    public Locale get(int i5) {
        if (i5 < 0) {
            return null;
        }
        Locale[] localeArr = this.f4420a;
        if (i5 < localeArr.length) {
            return localeArr[i5];
        }
        return null;
    }

    @Override // androidx.core.os.l
    public Object getLocaleList() {
        return null;
    }

    public int hashCode() {
        int i5 = 1;
        for (Locale locale : this.f4420a) {
            i5 = (i5 * 31) + locale.hashCode();
        }
        return i5;
    }

    @Override // androidx.core.os.l
    public boolean isEmpty() {
        return this.f4420a.length == 0;
    }

    @Override // androidx.core.os.l
    public int size() {
        return this.f4420a.length;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(b9.i.f26268d);
        int i5 = 0;
        while (true) {
            Locale[] localeArr = this.f4420a;
            if (i5 >= localeArr.length) {
                sb.append(b9.i.f26270e);
                return sb.toString();
            }
            sb.append(localeArr[i5]);
            if (i5 < this.f4420a.length - 1) {
                sb.append(',');
            }
            i5++;
        }
    }
}
