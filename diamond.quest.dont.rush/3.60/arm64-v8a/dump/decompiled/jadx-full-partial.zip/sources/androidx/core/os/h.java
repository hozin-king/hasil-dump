package androidx.core.os;

import android.os.Handler;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

/* loaded from: classes.dex */
public final class h {

    private static class a implements Executor {

        /* renamed from: b, reason: collision with root package name */
        private final Handler f4412b;

        a(Handler handler) {
            this.f4412b = (Handler) t.i.g(handler);
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            if (this.f4412b.post((Runnable) t.i.g(runnable))) {
                return;
            }
            throw new RejectedExecutionException(this.f4412b + " is shutting down");
        }
    }

    private h() {
    }

    public static Executor a(Handler handler) {
        return new a(handler);
    }
}
