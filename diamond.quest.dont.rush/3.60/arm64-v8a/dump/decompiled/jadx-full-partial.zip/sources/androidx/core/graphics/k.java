package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import androidx.core.content.res.e;
import com.ironsource.mediationsdk.logger.IronSourceError;
import j$.util.concurrent.ConcurrentHashMap;
import java.io.File;
import java.io.InputStream;
import s.k;

/* loaded from: classes.dex */
abstract class k {

    /* renamed from: a, reason: collision with root package name */
    private ConcurrentHashMap f4398a = new ConcurrentHashMap();

    class a implements b {
        a() {
        }

        @Override // androidx.core.graphics.k.b
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public int a(k.b bVar) {
            return bVar.e();
        }

        @Override // androidx.core.graphics.k.b
        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public boolean b(k.b bVar) {
            return bVar.f();
        }
    }

    private interface b {
        int a(Object obj);

        boolean b(Object obj);
    }

    k() {
    }

    private static Object e(Object[] objArr, int i5, b bVar) {
        return f(objArr, (i5 & 1) == 0 ? 400 : IronSourceError.ERROR_NT_LOAD_AFTER_INIT_FAILED, (i5 & 2) != 0, bVar);
    }

    private static Object f(Object[] objArr, int i5, boolean z4, b bVar) {
        Object obj = null;
        int i6 = Integer.MAX_VALUE;
        for (Object obj2 : objArr) {
            int abs = (Math.abs(bVar.a(obj2) - i5) * 2) + (bVar.b(obj2) == z4 ? 0 : 1);
            if (obj == null || i6 > abs) {
                obj = obj2;
                i6 = abs;
            }
        }
        return obj;
    }

    public abstract Typeface a(Context context, e.c cVar, Resources resources, int i5);

    public abstract Typeface b(Context context, CancellationSignal cancellationSignal, k.b[] bVarArr, int i5);

    protected Typeface c(Context context, InputStream inputStream) {
        File e5 = l.e(context);
        if (e5 == null) {
            return null;
        }
        try {
            if (l.d(e5, inputStream)) {
                return Typeface.createFromFile(e5.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            e5.delete();
        }
    }

    public Typeface d(Context context, Resources resources, int i5, String str, int i6) {
        File e5 = l.e(context);
        if (e5 == null) {
            return null;
        }
        try {
            if (l.c(e5, resources, i5)) {
                return Typeface.createFromFile(e5.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            e5.delete();
        }
    }

    protected k.b g(k.b[] bVarArr, int i5) {
        return (k.b) e(bVarArr, i5, new a());
    }
}
