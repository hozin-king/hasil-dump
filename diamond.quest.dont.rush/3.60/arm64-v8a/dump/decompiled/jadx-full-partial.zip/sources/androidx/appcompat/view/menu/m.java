package androidx.appcompat.view.menu;

import android.content.Context;

/* loaded from: classes.dex */
public interface m {

    public interface a {
        void a(g gVar, boolean z4);

        boolean b(g gVar);
    }

    void a(g gVar, boolean z4);

    boolean b(g gVar, i iVar);

    void c(boolean z4);

    boolean d();

    boolean e(g gVar, i iVar);

    void f(Context context, g gVar);

    void g(a aVar);

    boolean h(r rVar);
}
