package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import f.C4998f;

/* loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    private boolean f3243b;

    /* renamed from: c, reason: collision with root package name */
    private View f3244c;

    /* renamed from: d, reason: collision with root package name */
    private View f3245d;

    /* renamed from: e, reason: collision with root package name */
    private View f3246e;

    /* renamed from: f, reason: collision with root package name */
    Drawable f3247f;

    /* renamed from: g, reason: collision with root package name */
    Drawable f3248g;

    /* renamed from: h, reason: collision with root package name */
    Drawable f3249h;

    /* renamed from: i, reason: collision with root package name */
    boolean f3250i;

    /* renamed from: j, reason: collision with root package name */
    boolean f3251j;

    /* renamed from: k, reason: collision with root package name */
    private int f3252k;

    private static class a {
        public static void a(ActionBarContainer actionBarContainer) {
            actionBarContainer.invalidateOutline();
        }
    }

    public ActionBarContainer(Context context) {
        this(context, null);
    }

    private int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    private boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f3247f;
        if (drawable != null && drawable.isStateful()) {
            this.f3247f.setState(getDrawableState());
        }
        Drawable drawable2 = this.f3248g;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f3248g.setState(getDrawableState());
        }
        Drawable drawable3 = this.f3249h;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f3249h.setState(getDrawableState());
    }

    public View getTabContainer() {
        return this.f3244c;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f3247f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f3248g;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f3249h;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f3245d = findViewById(C4998f.f53808a);
        this.f3246e = findViewById(C4998f.f53813f);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f3243b || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        Drawable drawable;
        super.onLayout(z4, i5, i6, i7, i8);
        View view = this.f3244c;
        boolean z5 = true;
        boolean z6 = false;
        boolean z7 = (view == null || view.getVisibility() == 8) ? false : true;
        if (view != null && view.getVisibility() != 8) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            int measuredHeight2 = measuredHeight - view.getMeasuredHeight();
            int i9 = layoutParams.bottomMargin;
            view.layout(i5, measuredHeight2 - i9, i7, measuredHeight - i9);
        }
        if (this.f3250i) {
            Drawable drawable2 = this.f3249h;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
            z5 = z6;
        } else {
            if (this.f3247f != null) {
                if (this.f3245d.getVisibility() == 0) {
                    this.f3247f.setBounds(this.f3245d.getLeft(), this.f3245d.getTop(), this.f3245d.getRight(), this.f3245d.getBottom());
                } else {
                    View view2 = this.f3246e;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.f3247f.setBounds(0, 0, 0, 0);
                    } else {
                        this.f3247f.setBounds(this.f3246e.getLeft(), this.f3246e.getTop(), this.f3246e.getRight(), this.f3246e.getBottom());
                    }
                }
                z6 = true;
            }
            this.f3251j = z7;
            if (z7 && (drawable = this.f3248g) != null) {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
            z5 = z6;
        }
        if (z5) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i5, int i6) {
        int i7;
        if (this.f3245d == null && View.MeasureSpec.getMode(i6) == Integer.MIN_VALUE && (i7 = this.f3252k) >= 0) {
            i6 = View.MeasureSpec.makeMeasureSpec(Math.min(i7, View.MeasureSpec.getSize(i6)), Integer.MIN_VALUE);
        }
        super.onMeasure(i5, i6);
        if (this.f3245d == null) {
            return;
        }
        int mode = View.MeasureSpec.getMode(i6);
        View view = this.f3244c;
        if (view == null || view.getVisibility() == 8 || mode == 1073741824) {
            return;
        }
        setMeasuredDimension(getMeasuredWidth(), Math.min((!b(this.f3245d) ? a(this.f3245d) : !b(this.f3246e) ? a(this.f3246e) : 0) + a(this.f3244c), mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i6) : Integer.MAX_VALUE));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f3247f;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f3247f);
        }
        this.f3247f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f3245d;
            if (view != null) {
                this.f3247f.setBounds(view.getLeft(), this.f3245d.getTop(), this.f3245d.getRight(), this.f3245d.getBottom());
            }
        }
        boolean z4 = false;
        if (!this.f3250i ? !(this.f3247f != null || this.f3248g != null) : this.f3249h == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        a.a(this);
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f3249h;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f3249h);
        }
        this.f3249h = drawable;
        boolean z4 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f3250i && (drawable2 = this.f3249h) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f3250i ? !(this.f3247f != null || this.f3248g != null) : this.f3249h == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        a.a(this);
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f3248g;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f3248g);
        }
        this.f3248g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f3251j && (drawable2 = this.f3248g) != null) {
                drawable2.setBounds(this.f3244c.getLeft(), this.f3244c.getTop(), this.f3244c.getRight(), this.f3244c.getBottom());
            }
        }
        boolean z4 = false;
        if (!this.f3250i ? !(this.f3247f != null || this.f3248g != null) : this.f3249h == null) {
            z4 = true;
        }
        setWillNotDraw(z4);
        invalidate();
        a.a(this);
    }

    public void setTabContainer(Z z4) {
        View view = this.f3244c;
        if (view != null) {
            removeView(view);
        }
        this.f3244c = z4;
        if (z4 != null) {
            addView(z4);
            ViewGroup.LayoutParams layoutParams = z4.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            z4.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z4) {
        this.f3243b = z4;
        setDescendantFocusability(z4 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i5) {
        super.setVisibility(i5);
        boolean z4 = i5 == 0;
        Drawable drawable = this.f3247f;
        if (drawable != null) {
            drawable.setVisible(z4, false);
        }
        Drawable drawable2 = this.f3248g;
        if (drawable2 != null) {
            drawable2.setVisible(z4, false);
        }
        Drawable drawable3 = this.f3249h;
        if (drawable3 != null) {
            drawable3.setVisible(z4, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        if (drawable == this.f3247f && !this.f3250i) {
            return true;
        }
        if (drawable == this.f3248g && this.f3251j) {
            return true;
        }
        return (drawable == this.f3249h && this.f3250i) || super.verifyDrawable(drawable);
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C0983b(this));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f.j.f53994a);
        this.f3247f = obtainStyledAttributes.getDrawable(f.j.f53999b);
        this.f3248g = obtainStyledAttributes.getDrawable(f.j.f54009d);
        this.f3252k = obtainStyledAttributes.getDimensionPixelSize(f.j.f54039j, -1);
        boolean z4 = true;
        if (getId() == C4998f.f53799H) {
            this.f3250i = true;
            this.f3249h = obtainStyledAttributes.getDrawable(f.j.f54004c);
        }
        obtainStyledAttributes.recycle();
        if (!this.f3250i ? this.f3247f != null || this.f3248g != null : this.f3249h != null) {
            z4 = false;
        }
        setWillNotDraw(z4);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i5) {
        if (i5 != 0) {
            return super.startActionModeForChild(view, callback, i5);
        }
        return null;
    }
}
