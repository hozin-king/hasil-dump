package androidx.core.app;

import android.app.Person;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import com.ironsource.b9;
import j$.util.Objects;

/* loaded from: classes.dex */
public class y {

    /* renamed from: a, reason: collision with root package name */
    CharSequence f4283a;

    /* renamed from: b, reason: collision with root package name */
    IconCompat f4284b;

    /* renamed from: c, reason: collision with root package name */
    String f4285c;

    /* renamed from: d, reason: collision with root package name */
    String f4286d;

    /* renamed from: e, reason: collision with root package name */
    boolean f4287e;

    /* renamed from: f, reason: collision with root package name */
    boolean f4288f;

    static class a {
        static y a(Person person) {
            return new b().f(person.getName()).c(person.getIcon() != null ? IconCompat.f(person.getIcon()) : null).g(person.getUri()).e(person.getKey()).b(person.isBot()).d(person.isImportant()).a();
        }

        static Person b(y yVar) {
            return new Person.Builder().setName(yVar.e()).setIcon(yVar.c() != null ? yVar.c().B() : null).setUri(yVar.f()).setKey(yVar.d()).setBot(yVar.g()).setImportant(yVar.h()).build();
        }
    }

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        CharSequence f4289a;

        /* renamed from: b, reason: collision with root package name */
        IconCompat f4290b;

        /* renamed from: c, reason: collision with root package name */
        String f4291c;

        /* renamed from: d, reason: collision with root package name */
        String f4292d;

        /* renamed from: e, reason: collision with root package name */
        boolean f4293e;

        /* renamed from: f, reason: collision with root package name */
        boolean f4294f;

        public b() {
        }

        public y a() {
            return new y(this);
        }

        public b b(boolean z4) {
            this.f4293e = z4;
            return this;
        }

        public b c(IconCompat iconCompat) {
            this.f4290b = iconCompat;
            return this;
        }

        public b d(boolean z4) {
            this.f4294f = z4;
            return this;
        }

        public b e(String str) {
            this.f4292d = str;
            return this;
        }

        public b f(CharSequence charSequence) {
            this.f4289a = charSequence;
            return this;
        }

        public b g(String str) {
            this.f4291c = str;
            return this;
        }

        b(y yVar) {
            this.f4289a = yVar.f4283a;
            this.f4290b = yVar.f4284b;
            this.f4291c = yVar.f4285c;
            this.f4292d = yVar.f4286d;
            this.f4293e = yVar.f4287e;
            this.f4294f = yVar.f4288f;
        }
    }

    y(b bVar) {
        this.f4283a = bVar.f4289a;
        this.f4284b = bVar.f4290b;
        this.f4285c = bVar.f4291c;
        this.f4286d = bVar.f4292d;
        this.f4287e = bVar.f4293e;
        this.f4288f = bVar.f4294f;
    }

    public static y a(Person person) {
        return a.a(person);
    }

    public static y b(Bundle bundle) {
        Bundle bundle2 = bundle.getBundle("icon");
        return new b().f(bundle.getCharSequence("name")).c(bundle2 != null ? IconCompat.e(bundle2) : null).g(bundle.getString("uri")).e(bundle.getString(b9.h.f26181W)).b(bundle.getBoolean("isBot")).d(bundle.getBoolean("isImportant")).a();
    }

    public IconCompat c() {
        return this.f4284b;
    }

    public String d() {
        return this.f4286d;
    }

    public CharSequence e() {
        return this.f4283a;
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        String d5 = d();
        String d6 = yVar.d();
        return (d5 == null && d6 == null) ? Objects.equals(Objects.toString(e()), Objects.toString(yVar.e())) && Objects.equals(f(), yVar.f()) && Boolean.valueOf(g()).equals(Boolean.valueOf(yVar.g())) && Boolean.valueOf(h()).equals(Boolean.valueOf(yVar.h())) : Objects.equals(d5, d6);
    }

    public String f() {
        return this.f4285c;
    }

    public boolean g() {
        return this.f4287e;
    }

    public boolean h() {
        return this.f4288f;
    }

    public int hashCode() {
        String d5 = d();
        return d5 != null ? d5.hashCode() : Objects.hash(e(), f(), Boolean.valueOf(g()), Boolean.valueOf(h()));
    }

    public String i() {
        String str = this.f4285c;
        if (str != null) {
            return str;
        }
        if (this.f4283a == null) {
            return "";
        }
        return "name:" + ((Object) this.f4283a);
    }

    public Person j() {
        return a.b(this);
    }

    public Bundle k() {
        Bundle bundle = new Bundle();
        bundle.putCharSequence("name", this.f4283a);
        IconCompat iconCompat = this.f4284b;
        bundle.putBundle("icon", iconCompat != null ? iconCompat.A() : null);
        bundle.putString("uri", this.f4285c);
        bundle.putString(b9.h.f26181W, this.f4286d);
        bundle.putBoolean("isBot", this.f4287e);
        bundle.putBoolean("isImportant", this.f4288f);
        return bundle;
    }
}
