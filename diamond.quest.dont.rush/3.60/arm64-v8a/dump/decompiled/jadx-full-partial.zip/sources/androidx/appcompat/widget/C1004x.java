package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.SeekBar;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;

/* renamed from: androidx.appcompat.widget.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C1004x extends SeekBar {

    /* renamed from: b, reason: collision with root package name */
    private final C1005y f3886b;

    public C1004x(@NonNull Context context) {
        this(context, null);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        this.f3886b.h();
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        this.f3886b.i();
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f3886b.g(canvas);
    }

    public C1004x(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53691L);
    }

    public C1004x(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        c0.a(this, getContext());
        C1005y c1005y = new C1005y(this);
        this.f3886b = c1005y;
        c1005y.c(attributeSet, i5);
    }
}
