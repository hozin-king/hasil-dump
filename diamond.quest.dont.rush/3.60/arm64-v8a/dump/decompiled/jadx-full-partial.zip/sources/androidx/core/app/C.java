package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class C implements Iterable {

    /* renamed from: b, reason: collision with root package name */
    private final ArrayList f4101b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    private final Context f4102c;

    public interface a {
        Intent getSupportParentActivityIntent();
    }

    private C(Context context) {
        this.f4102c = context;
    }

    public static C e(Context context) {
        return new C(context);
    }

    public C a(Intent intent) {
        this.f4101b.add(intent);
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public C c(Activity activity) {
        Intent supportParentActivityIntent = activity instanceof a ? ((a) activity).getSupportParentActivityIntent() : null;
        if (supportParentActivityIntent == null) {
            supportParentActivityIntent = l.a(activity);
        }
        if (supportParentActivityIntent != null) {
            ComponentName component = supportParentActivityIntent.getComponent();
            if (component == null) {
                component = supportParentActivityIntent.resolveActivity(this.f4102c.getPackageManager());
            }
            d(component);
            a(supportParentActivityIntent);
        }
        return this;
    }

    public C d(ComponentName componentName) {
        int size = this.f4101b.size();
        try {
            Intent b5 = l.b(this.f4102c, componentName);
            while (b5 != null) {
                this.f4101b.add(size, b5);
                b5 = l.b(this.f4102c, b5.getComponent());
            }
            return this;
        } catch (PackageManager.NameNotFoundException e5) {
            Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
            throw new IllegalArgumentException(e5);
        }
    }

    public void f() {
        g(null);
    }

    public void g(Bundle bundle) {
        if (this.f4101b.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        Intent[] intentArr = (Intent[]) this.f4101b.toArray(new Intent[0]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        if (androidx.core.content.a.startActivities(this.f4102c, intentArr, bundle)) {
            return;
        }
        Intent intent = new Intent(intentArr[intentArr.length - 1]);
        intent.addFlags(268435456);
        this.f4102c.startActivity(intent);
    }

    @Override // java.lang.Iterable
    public Iterator iterator() {
        return this.f4101b.iterator();
    }
}
