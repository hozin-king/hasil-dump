package androidx.core.os;

import android.os.Build;
import android.os.ext.SdkExtensions;
import io.bidmachine.media3.common.PlaybackException;
import java.util.Locale;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final a f4400a = new a();

    /* renamed from: b, reason: collision with root package name */
    public static final int f4401b;

    /* renamed from: c, reason: collision with root package name */
    public static final int f4402c;

    /* renamed from: d, reason: collision with root package name */
    public static final int f4403d;

    /* renamed from: e, reason: collision with root package name */
    public static final int f4404e;

    /* renamed from: androidx.core.os.a$a, reason: collision with other inner class name */
    private static final class C0127a {

        /* renamed from: a, reason: collision with root package name */
        public static final C0127a f4405a = new C0127a();

        private C0127a() {
        }

        public final int a(int i5) {
            return SdkExtensions.getExtensionVersion(i5);
        }
    }

    static {
        int i5 = Build.VERSION.SDK_INT;
        f4401b = i5 >= 30 ? C0127a.f4405a.a(30) : 0;
        f4402c = i5 >= 30 ? C0127a.f4405a.a(31) : 0;
        f4403d = i5 >= 30 ? C0127a.f4405a.a(33) : 0;
        f4404e = i5 >= 30 ? C0127a.f4405a.a(PlaybackException.CUSTOM_ERROR_CODE_BASE) : 0;
    }

    private a() {
    }

    public static final boolean a(String codename, String buildCodename) {
        C7150s.j(codename, "codename");
        C7150s.j(buildCodename, "buildCodename");
        if (C7150s.e("REL", buildCodename)) {
            return false;
        }
        Locale locale = Locale.ROOT;
        String upperCase = buildCodename.toUpperCase(locale);
        C7150s.i(upperCase, "this as java.lang.String).toUpperCase(Locale.ROOT)");
        String upperCase2 = codename.toUpperCase(locale);
        C7150s.i(upperCase2, "this as java.lang.String).toUpperCase(Locale.ROOT)");
        return upperCase.compareTo(upperCase2) >= 0;
    }

    public static final boolean b() {
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 31) {
            return true;
        }
        if (i5 < 30) {
            return false;
        }
        String CODENAME = Build.VERSION.CODENAME;
        C7150s.i(CODENAME, "CODENAME");
        return a("S", CODENAME);
    }

    public static final boolean c() {
        if (Build.VERSION.SDK_INT < 34) {
            return false;
        }
        String CODENAME = Build.VERSION.CODENAME;
        C7150s.i(CODENAME, "CODENAME");
        return a("VanillaIceCream", CODENAME);
    }
}
