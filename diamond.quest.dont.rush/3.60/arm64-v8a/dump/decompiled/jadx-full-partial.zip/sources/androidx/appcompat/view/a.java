package androidx.appcompat.view;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import f.C4993a;
import f.C4994b;
import f.C4996d;
import f.j;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private Context f2923a;

    private a(Context context) {
        this.f2923a = context;
    }

    public static a b(Context context) {
        return new a(context);
    }

    public boolean a() {
        return this.f2923a.getApplicationInfo().targetSdkVersion < 14;
    }

    public int c() {
        return this.f2923a.getResources().getDisplayMetrics().widthPixels / 2;
    }

    public int d() {
        Configuration configuration = this.f2923a.getResources().getConfiguration();
        int i5 = configuration.screenWidthDp;
        int i6 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i5 > 600) {
            return 5;
        }
        if (i5 > 960 && i6 > 720) {
            return 5;
        }
        if (i5 > 720 && i6 > 960) {
            return 5;
        }
        if (i5 >= 500) {
            return 4;
        }
        if (i5 > 640 && i6 > 480) {
            return 4;
        }
        if (i5 <= 480 || i6 <= 640) {
            return i5 >= 360 ? 3 : 2;
        }
        return 4;
    }

    public int e() {
        return this.f2923a.getResources().getDimensionPixelSize(C4996d.f53733b);
    }

    public int f() {
        TypedArray obtainStyledAttributes = this.f2923a.obtainStyledAttributes(null, j.f53994a, C4993a.f53699c, 0);
        int layoutDimension = obtainStyledAttributes.getLayoutDimension(j.f54039j, 0);
        Resources resources = this.f2923a.getResources();
        if (!g()) {
            layoutDimension = Math.min(layoutDimension, resources.getDimensionPixelSize(C4996d.f53732a));
        }
        obtainStyledAttributes.recycle();
        return layoutDimension;
    }

    public boolean g() {
        return this.f2923a.getResources().getBoolean(C4994b.f53723a);
    }

    public boolean h() {
        return true;
    }
}
