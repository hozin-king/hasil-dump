package androidx.core.app;

import android.app.LocaleManager;
import android.content.Context;
import android.os.Build;
import android.os.LocaleList;
import io.appmetrica.analytics.networktasks.internal.CommonUrlParts;

/* loaded from: classes.dex */
public final class j {

    static class a {
        static LocaleList a(Object obj) {
            return ((LocaleManager) obj).getApplicationLocales();
        }

        static LocaleList b(Object obj) {
            return ((LocaleManager) obj).getSystemLocales();
        }
    }

    private j() {
    }

    public static androidx.core.os.j a(Context context) {
        if (Build.VERSION.SDK_INT < 33) {
            return androidx.core.os.j.c(f.b(context));
        }
        Object b5 = b(context);
        return b5 != null ? androidx.core.os.j.j(a.a(b5)) : androidx.core.os.j.e();
    }

    private static Object b(Context context) {
        return context.getSystemService(CommonUrlParts.LOCALE);
    }
}
