package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import f.C4993a;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class S implements androidx.appcompat.view.menu.p {
    private static Method sGetMaxAvailableHeightMethod;
    private static Method sSetClipToWindowEnabledMethod;
    private static Method sSetEpicenterBoundsMethod;
    private ListAdapter mAdapter;
    private Context mContext;
    private boolean mDropDownAlwaysVisible;
    private View mDropDownAnchorView;
    private int mDropDownGravity;
    private int mDropDownHeight;
    private int mDropDownHorizontalOffset;
    N mDropDownList;
    private Drawable mDropDownListHighlight;
    private int mDropDownVerticalOffset;
    private boolean mDropDownVerticalOffsetSet;
    private int mDropDownWidth;
    private int mDropDownWindowLayoutType;
    private Rect mEpicenterBounds;
    private boolean mForceIgnoreOutsideTouch;
    final Handler mHandler;
    private final e mHideSelector;
    private AdapterView.OnItemClickListener mItemClickListener;
    private AdapterView.OnItemSelectedListener mItemSelectedListener;
    int mListItemExpandMaximum;
    private boolean mModal;
    private DataSetObserver mObserver;
    private boolean mOverlapAnchor;
    private boolean mOverlapAnchorSet;
    PopupWindow mPopup;
    private int mPromptPosition;
    private View mPromptView;
    final i mResizePopupRunnable;
    private final g mScrollListener;
    private Runnable mShowDropDownRunnable;
    private final Rect mTempRect;
    private final h mTouchInterceptor;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            View anchorView = S.this.getAnchorView();
            if (anchorView == null || anchorView.getWindowToken() == null) {
                return;
            }
            S.this.show();
        }
    }

    class b implements AdapterView.OnItemSelectedListener {
        b() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView adapterView, View view, int i5, long j5) {
            N n5;
            if (i5 == -1 || (n5 = S.this.mDropDownList) == null) {
                return;
            }
            n5.setListSelectionHidden(false);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView adapterView) {
        }
    }

    static class c {
        static int a(PopupWindow popupWindow, View view, int i5, boolean z4) {
            return popupWindow.getMaxAvailableHeight(view, i5, z4);
        }
    }

    static class d {
        static void a(PopupWindow popupWindow, Rect rect) {
            popupWindow.setEpicenterBounds(rect);
        }

        static void b(PopupWindow popupWindow, boolean z4) {
            popupWindow.setIsClippedToScreen(z4);
        }
    }

    private class e implements Runnable {
        e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            S.this.clearListSelection();
        }
    }

    private class f extends DataSetObserver {
        f() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (S.this.isShowing()) {
                S.this.show();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            S.this.dismiss();
        }
    }

    private class g implements AbsListView.OnScrollListener {
        g() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i5, int i6, int i7) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i5) {
            if (i5 != 1 || S.this.isInputMethodNotNeeded() || S.this.mPopup.getContentView() == null) {
                return;
            }
            S s5 = S.this;
            s5.mHandler.removeCallbacks(s5.mResizePopupRunnable);
            S.this.mResizePopupRunnable.run();
        }
    }

    private class h implements View.OnTouchListener {
        h() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x5 = (int) motionEvent.getX();
            int y5 = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = S.this.mPopup) != null && popupWindow.isShowing() && x5 >= 0 && x5 < S.this.mPopup.getWidth() && y5 >= 0 && y5 < S.this.mPopup.getHeight()) {
                S s5 = S.this;
                s5.mHandler.postDelayed(s5.mResizePopupRunnable, 250L);
                return false;
            }
            if (action != 1) {
                return false;
            }
            S s6 = S.this;
            s6.mHandler.removeCallbacks(s6.mResizePopupRunnable);
            return false;
        }
    }

    private class i implements Runnable {
        i() {
        }

        @Override // java.lang.Runnable
        public void run() {
            N n5 = S.this.mDropDownList;
            if (n5 == null || !n5.isAttachedToWindow() || S.this.mDropDownList.getCount() <= S.this.mDropDownList.getChildCount()) {
                return;
            }
            int childCount = S.this.mDropDownList.getChildCount();
            S s5 = S.this;
            if (childCount <= s5.mListItemExpandMaximum) {
                s5.mPopup.setInputMethodMode(2);
                S.this.show();
            }
        }
    }

    static {
        int i5 = Build.VERSION.SDK_INT;
        Class cls = Boolean.TYPE;
        if (i5 <= 28) {
            try {
                sSetClipToWindowEnabledMethod = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", cls);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                sSetEpicenterBoundsMethod = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                sGetMaxAvailableHeightMethod = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", View.class, Integer.TYPE, cls);
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public S(@NonNull Context context) {
        this(context, null, C4993a.f53685F);
    }

    private int g() {
        int i5;
        int i6;
        int makeMeasureSpec;
        int i7;
        if (this.mDropDownList == null) {
            Context context = this.mContext;
            this.mShowDropDownRunnable = new a();
            N createDropDownListView = createDropDownListView(context, !this.mModal);
            this.mDropDownList = createDropDownListView;
            Drawable drawable = this.mDropDownListHighlight;
            if (drawable != null) {
                createDropDownListView.setSelector(drawable);
            }
            this.mDropDownList.setAdapter(this.mAdapter);
            this.mDropDownList.setOnItemClickListener(this.mItemClickListener);
            this.mDropDownList.setFocusable(true);
            this.mDropDownList.setFocusableInTouchMode(true);
            this.mDropDownList.setOnItemSelectedListener(new b());
            this.mDropDownList.setOnScrollListener(this.mScrollListener);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.mItemSelectedListener;
            if (onItemSelectedListener != null) {
                this.mDropDownList.setOnItemSelectedListener(onItemSelectedListener);
            }
            View view = this.mDropDownList;
            View view2 = this.mPromptView;
            if (view2 != null) {
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                ViewGroup.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
                int i8 = this.mPromptPosition;
                if (i8 == 0) {
                    linearLayout.addView(view2);
                    linearLayout.addView(view, layoutParams);
                } else if (i8 != 1) {
                    Log.e("ListPopupWindow", "Invalid hint position " + this.mPromptPosition);
                } else {
                    linearLayout.addView(view, layoutParams);
                    linearLayout.addView(view2);
                }
                int i9 = this.mDropDownWidth;
                if (i9 >= 0) {
                    i7 = Integer.MIN_VALUE;
                } else {
                    i9 = 0;
                    i7 = 0;
                }
                view2.measure(View.MeasureSpec.makeMeasureSpec(i9, i7), 0);
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) view2.getLayoutParams();
                i5 = view2.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
                view = linearLayout;
            } else {
                i5 = 0;
            }
            this.mPopup.setContentView(view);
        } else {
            View view3 = this.mPromptView;
            if (view3 != null) {
                LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) view3.getLayoutParams();
                i5 = view3.getMeasuredHeight() + layoutParams3.topMargin + layoutParams3.bottomMargin;
            } else {
                i5 = 0;
            }
        }
        Drawable background = this.mPopup.getBackground();
        if (background != null) {
            background.getPadding(this.mTempRect);
            Rect rect = this.mTempRect;
            int i10 = rect.top;
            i6 = rect.bottom + i10;
            if (!this.mDropDownVerticalOffsetSet) {
                this.mDropDownVerticalOffset = -i10;
            }
        } else {
            this.mTempRect.setEmpty();
            i6 = 0;
        }
        int h5 = h(getAnchorView(), this.mDropDownVerticalOffset, this.mPopup.getInputMethodMode() == 2);
        if (this.mDropDownAlwaysVisible || this.mDropDownHeight == -1) {
            return h5 + i6;
        }
        int i11 = this.mDropDownWidth;
        if (i11 == -2) {
            int i12 = this.mContext.getResources().getDisplayMetrics().widthPixels;
            Rect rect2 = this.mTempRect;
            makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i12 - (rect2.left + rect2.right), Integer.MIN_VALUE);
        } else if (i11 != -1) {
            makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
        } else {
            int i13 = this.mContext.getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = this.mTempRect;
            makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i13 - (rect3.left + rect3.right), 1073741824);
        }
        int d5 = this.mDropDownList.d(makeMeasureSpec, 0, -1, h5 - i5, -1);
        if (d5 > 0) {
            i5 += i6 + this.mDropDownList.getPaddingTop() + this.mDropDownList.getPaddingBottom();
        }
        return d5 + i5;
    }

    private int h(View view, int i5, boolean z4) {
        if (Build.VERSION.SDK_INT > 23) {
            return c.a(this.mPopup, view, i5, z4);
        }
        Method method = sGetMaxAvailableHeightMethod;
        if (method != null) {
            try {
                return ((Integer) method.invoke(this.mPopup, view, Integer.valueOf(i5), Boolean.valueOf(z4))).intValue();
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
            }
        }
        return this.mPopup.getMaxAvailableHeight(view, i5);
    }

    private void i() {
        View view = this.mPromptView;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.mPromptView);
            }
        }
    }

    private void j(boolean z4) {
        if (Build.VERSION.SDK_INT > 28) {
            d.b(this.mPopup, z4);
            return;
        }
        Method method = sSetClipToWindowEnabledMethod;
        if (method != null) {
            try {
                method.invoke(this.mPopup, Boolean.valueOf(z4));
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
        }
    }

    public void clearListSelection() {
        N n5 = this.mDropDownList;
        if (n5 != null) {
            n5.setListSelectionHidden(true);
            n5.requestLayout();
        }
    }

    @NonNull
    N createDropDownListView(Context context, boolean z4) {
        return new N(context, z4);
    }

    @Override // androidx.appcompat.view.menu.p
    public void dismiss() {
        this.mPopup.dismiss();
        i();
        this.mPopup.setContentView(null);
        this.mDropDownList = null;
        this.mHandler.removeCallbacks(this.mResizePopupRunnable);
    }

    @Nullable
    public View getAnchorView() {
        return this.mDropDownAnchorView;
    }

    @Nullable
    public Drawable getBackground() {
        return this.mPopup.getBackground();
    }

    public int getHorizontalOffset() {
        return this.mDropDownHorizontalOffset;
    }

    @Override // androidx.appcompat.view.menu.p
    @Nullable
    public ListView getListView() {
        return this.mDropDownList;
    }

    public int getVerticalOffset() {
        if (this.mDropDownVerticalOffsetSet) {
            return this.mDropDownVerticalOffset;
        }
        return 0;
    }

    public int getWidth() {
        return this.mDropDownWidth;
    }

    public boolean isInputMethodNotNeeded() {
        return this.mPopup.getInputMethodMode() == 2;
    }

    public boolean isModal() {
        return this.mModal;
    }

    @Override // androidx.appcompat.view.menu.p
    public boolean isShowing() {
        return this.mPopup.isShowing();
    }

    public void setAdapter(@Nullable ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.mObserver;
        if (dataSetObserver == null) {
            this.mObserver = new f();
        } else {
            ListAdapter listAdapter2 = this.mAdapter;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.mAdapter = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.mObserver);
        }
        N n5 = this.mDropDownList;
        if (n5 != null) {
            n5.setAdapter(this.mAdapter);
        }
    }

    public void setAnchorView(@Nullable View view) {
        this.mDropDownAnchorView = view;
    }

    public void setAnimationStyle(int i5) {
        this.mPopup.setAnimationStyle(i5);
    }

    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        this.mPopup.setBackgroundDrawable(drawable);
    }

    public void setContentWidth(int i5) {
        Drawable background = this.mPopup.getBackground();
        if (background == null) {
            setWidth(i5);
            return;
        }
        background.getPadding(this.mTempRect);
        Rect rect = this.mTempRect;
        this.mDropDownWidth = rect.left + rect.right + i5;
    }

    public void setDropDownGravity(int i5) {
        this.mDropDownGravity = i5;
    }

    public void setEpicenterBounds(@Nullable Rect rect) {
        this.mEpicenterBounds = rect != null ? new Rect(rect) : null;
    }

    public void setHorizontalOffset(int i5) {
        this.mDropDownHorizontalOffset = i5;
    }

    public void setInputMethodMode(int i5) {
        this.mPopup.setInputMethodMode(i5);
    }

    public void setModal(boolean z4) {
        this.mModal = z4;
        this.mPopup.setFocusable(z4);
    }

    public void setOnDismissListener(@Nullable PopupWindow.OnDismissListener onDismissListener) {
        this.mPopup.setOnDismissListener(onDismissListener);
    }

    public void setOnItemClickListener(@Nullable AdapterView.OnItemClickListener onItemClickListener) {
        this.mItemClickListener = onItemClickListener;
    }

    public void setOverlapAnchor(boolean z4) {
        this.mOverlapAnchorSet = true;
        this.mOverlapAnchor = z4;
    }

    public void setPromptPosition(int i5) {
        this.mPromptPosition = i5;
    }

    public void setSelection(int i5) {
        N n5 = this.mDropDownList;
        if (!isShowing() || n5 == null) {
            return;
        }
        n5.setListSelectionHidden(false);
        n5.setSelection(i5);
        if (n5.getChoiceMode() != 0) {
            n5.setItemChecked(i5, true);
        }
    }

    public void setVerticalOffset(int i5) {
        this.mDropDownVerticalOffset = i5;
        this.mDropDownVerticalOffsetSet = true;
    }

    public void setWidth(int i5) {
        this.mDropDownWidth = i5;
    }

    @Override // androidx.appcompat.view.menu.p
    public void show() {
        int g5 = g();
        boolean isInputMethodNotNeeded = isInputMethodNotNeeded();
        androidx.core.widget.i.b(this.mPopup, this.mDropDownWindowLayoutType);
        if (this.mPopup.isShowing()) {
            if (getAnchorView().isAttachedToWindow()) {
                int i5 = this.mDropDownWidth;
                if (i5 == -1) {
                    i5 = -1;
                } else if (i5 == -2) {
                    i5 = getAnchorView().getWidth();
                }
                int i6 = this.mDropDownHeight;
                if (i6 == -1) {
                    if (!isInputMethodNotNeeded) {
                        g5 = -1;
                    }
                    if (isInputMethodNotNeeded) {
                        this.mPopup.setWidth(this.mDropDownWidth == -1 ? -1 : 0);
                        this.mPopup.setHeight(0);
                    } else {
                        this.mPopup.setWidth(this.mDropDownWidth == -1 ? -1 : 0);
                        this.mPopup.setHeight(-1);
                    }
                } else if (i6 != -2) {
                    g5 = i6;
                }
                this.mPopup.setOutsideTouchable((this.mForceIgnoreOutsideTouch || this.mDropDownAlwaysVisible) ? false : true);
                this.mPopup.update(getAnchorView(), this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset, i5 < 0 ? -1 : i5, g5 < 0 ? -1 : g5);
                return;
            }
            return;
        }
        int i7 = this.mDropDownWidth;
        if (i7 == -1) {
            i7 = -1;
        } else if (i7 == -2) {
            i7 = getAnchorView().getWidth();
        }
        int i8 = this.mDropDownHeight;
        if (i8 == -1) {
            g5 = -1;
        } else if (i8 != -2) {
            g5 = i8;
        }
        this.mPopup.setWidth(i7);
        this.mPopup.setHeight(g5);
        j(true);
        this.mPopup.setOutsideTouchable((this.mForceIgnoreOutsideTouch || this.mDropDownAlwaysVisible) ? false : true);
        this.mPopup.setTouchInterceptor(this.mTouchInterceptor);
        if (this.mOverlapAnchorSet) {
            androidx.core.widget.i.a(this.mPopup, this.mOverlapAnchor);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = sSetEpicenterBoundsMethod;
            if (method != null) {
                try {
                    method.invoke(this.mPopup, this.mEpicenterBounds);
                } catch (Exception e5) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e5);
                }
            }
        } else {
            d.a(this.mPopup, this.mEpicenterBounds);
        }
        androidx.core.widget.i.c(this.mPopup, getAnchorView(), this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset, this.mDropDownGravity);
        this.mDropDownList.setSelection(-1);
        if (!this.mModal || this.mDropDownList.isInTouchMode()) {
            clearListSelection();
        }
        if (this.mModal) {
            return;
        }
        this.mHandler.post(this.mHideSelector);
    }

    public S(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, C4993a.f53685F);
    }

    public S(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        this(context, attributeSet, i5, 0);
    }

    public S(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5, int i6) {
        this.mDropDownHeight = -2;
        this.mDropDownWidth = -2;
        this.mDropDownWindowLayoutType = 1002;
        this.mDropDownGravity = 0;
        this.mDropDownAlwaysVisible = false;
        this.mForceIgnoreOutsideTouch = false;
        this.mListItemExpandMaximum = Integer.MAX_VALUE;
        this.mPromptPosition = 0;
        this.mResizePopupRunnable = new i();
        this.mTouchInterceptor = new h();
        this.mScrollListener = new g();
        this.mHideSelector = new e();
        this.mTempRect = new Rect();
        this.mContext = context;
        this.mHandler = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f.j.f54051l1, i5, i6);
        this.mDropDownHorizontalOffset = obtainStyledAttributes.getDimensionPixelOffset(f.j.f54056m1, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(f.j.f54061n1, 0);
        this.mDropDownVerticalOffset = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.mDropDownVerticalOffsetSet = true;
        }
        obtainStyledAttributes.recycle();
        C0999s c0999s = new C0999s(context, attributeSet, i5, i6);
        this.mPopup = c0999s;
        c0999s.setInputMethodMode(1);
    }
}
