package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import f.C4996d;
import f.C4998f;
import f.C4999g;

/* loaded from: classes.dex */
class p0 {

    /* renamed from: a, reason: collision with root package name */
    private final Context f3855a;

    /* renamed from: b, reason: collision with root package name */
    private final View f3856b;

    /* renamed from: c, reason: collision with root package name */
    private final TextView f3857c;

    /* renamed from: d, reason: collision with root package name */
    private final WindowManager.LayoutParams f3858d;

    /* renamed from: e, reason: collision with root package name */
    private final Rect f3859e;

    /* renamed from: f, reason: collision with root package name */
    private final int[] f3860f;

    /* renamed from: g, reason: collision with root package name */
    private final int[] f3861g;

    p0(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f3858d = layoutParams;
        this.f3859e = new Rect();
        this.f3860f = new int[2];
        this.f3861g = new int[2];
        this.f3855a = context;
        View inflate = LayoutInflater.from(context).inflate(C4999g.f53852s, (ViewGroup) null);
        this.f3856b = inflate;
        this.f3857c = (TextView) inflate.findViewById(C4998f.f53826s);
        layoutParams.setTitle(getClass().getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = f.i.f53868a;
        layoutParams.flags = 24;
    }

    private void a(View view, int i5, int i6, boolean z4, WindowManager.LayoutParams layoutParams) {
        int height;
        int i7;
        layoutParams.token = view.getApplicationWindowToken();
        int dimensionPixelOffset = this.f3855a.getResources().getDimensionPixelOffset(C4996d.f53744m);
        if (view.getWidth() < dimensionPixelOffset) {
            i5 = view.getWidth() / 2;
        }
        if (view.getHeight() >= dimensionPixelOffset) {
            int dimensionPixelOffset2 = this.f3855a.getResources().getDimensionPixelOffset(C4996d.f53743l);
            height = i6 + dimensionPixelOffset2;
            i7 = i6 - dimensionPixelOffset2;
        } else {
            height = view.getHeight();
            i7 = 0;
        }
        layoutParams.gravity = 49;
        int dimensionPixelOffset3 = this.f3855a.getResources().getDimensionPixelOffset(z4 ? C4996d.f53746o : C4996d.f53745n);
        View b5 = b(view);
        if (b5 == null) {
            Log.e("TooltipPopup", "Cannot find app view");
            return;
        }
        b5.getWindowVisibleDisplayFrame(this.f3859e);
        Rect rect = this.f3859e;
        if (rect.left < 0 && rect.top < 0) {
            Resources resources = this.f3855a.getResources();
            int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
            int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            this.f3859e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
        }
        b5.getLocationOnScreen(this.f3861g);
        view.getLocationOnScreen(this.f3860f);
        int[] iArr = this.f3860f;
        int i8 = iArr[0];
        int[] iArr2 = this.f3861g;
        int i9 = i8 - iArr2[0];
        iArr[0] = i9;
        iArr[1] = iArr[1] - iArr2[1];
        layoutParams.x = (i9 + i5) - (b5.getWidth() / 2);
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.f3856b.measure(makeMeasureSpec, makeMeasureSpec);
        int measuredHeight = this.f3856b.getMeasuredHeight();
        int i10 = this.f3860f[1];
        int i11 = ((i7 + i10) - dimensionPixelOffset3) - measuredHeight;
        int i12 = i10 + height + dimensionPixelOffset3;
        if (z4) {
            if (i11 >= 0) {
                layoutParams.y = i11;
                return;
            } else {
                layoutParams.y = i12;
                return;
            }
        }
        if (measuredHeight + i12 <= this.f3859e.height()) {
            layoutParams.y = i12;
        } else {
            layoutParams.y = i11;
        }
    }

    private static View b(View view) {
        View rootView = view.getRootView();
        ViewGroup.LayoutParams layoutParams = rootView.getLayoutParams();
        if (!(layoutParams instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams).type != 2) {
            for (Context context = view.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
                if (context instanceof Activity) {
                    return ((Activity) context).getWindow().getDecorView();
                }
            }
        }
        return rootView;
    }

    void c() {
        if (d()) {
            ((WindowManager) this.f3855a.getSystemService("window")).removeView(this.f3856b);
        }
    }

    boolean d() {
        return this.f3856b.getParent() != null;
    }

    void e(View view, int i5, int i6, boolean z4, CharSequence charSequence) {
        if (d()) {
            c();
        }
        this.f3857c.setText(charSequence);
        a(view, i5, i6, z4, this.f3858d);
        ((WindowManager) this.f3855a.getSystemService("window")).addView(this.f3856b, this.f3858d);
    }
}
