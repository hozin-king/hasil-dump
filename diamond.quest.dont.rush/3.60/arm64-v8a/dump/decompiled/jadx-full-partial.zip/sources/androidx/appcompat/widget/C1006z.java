package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.annotation.NonNull;

/* renamed from: androidx.appcompat.widget.z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
final class C1006z {

    /* renamed from: a, reason: collision with root package name */
    private TextView f3893a;

    /* renamed from: b, reason: collision with root package name */
    private TextClassifier f3894b;

    /* renamed from: androidx.appcompat.widget.z$a */
    private static final class a {
        @NonNull
        static TextClassifier a(@NonNull TextView textView) {
            TextClassificationManager textClassificationManager = (TextClassificationManager) textView.getContext().getSystemService(TextClassificationManager.class);
            return textClassificationManager != null ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
        }
    }

    C1006z(TextView textView) {
        this.f3893a = (TextView) t.i.g(textView);
    }

    public TextClassifier a() {
        TextClassifier textClassifier = this.f3894b;
        return textClassifier == null ? a.a(this.f3893a) : textClassifier;
    }

    public void b(TextClassifier textClassifier) {
        this.f3894b = textClassifier;
    }
}
