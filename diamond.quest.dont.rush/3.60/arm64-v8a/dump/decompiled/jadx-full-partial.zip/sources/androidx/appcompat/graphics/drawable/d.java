package androidx.appcompat.graphics.drawable;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.StateSet;
import androidx.annotation.Nullable;
import androidx.appcompat.graphics.drawable.b;

/* loaded from: classes.dex */
public class d extends b {

    /* renamed from: n, reason: collision with root package name */
    private a f2920n;

    /* renamed from: o, reason: collision with root package name */
    private boolean f2921o;

    static class a extends b.d {

        /* renamed from: J, reason: collision with root package name */
        int[][] f2922J;

        a(a aVar, d dVar, Resources resources) {
            super(aVar, dVar, resources);
            if (aVar != null) {
                this.f2922J = aVar.f2922J;
            } else {
                this.f2922J = new int[f()][];
            }
        }

        int A(int[] iArr, Drawable drawable) {
            int a5 = a(drawable);
            this.f2922J[a5] = iArr;
            return a5;
        }

        int B(int[] iArr) {
            int[][] iArr2 = this.f2922J;
            int h5 = h();
            for (int i5 = 0; i5 < h5; i5++) {
                if (StateSet.stateSetMatches(iArr2[i5], iArr)) {
                    return i5;
                }
            }
            return -1;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new d(this, null);
        }

        @Override // androidx.appcompat.graphics.drawable.b.d
        public void o(int i5, int i6) {
            super.o(i5, i6);
            int[][] iArr = new int[i6][];
            System.arraycopy(this.f2922J, 0, iArr, 0, i5);
            this.f2922J = iArr;
        }

        @Override // androidx.appcompat.graphics.drawable.b.d
        void s() {
            int[][] iArr = this.f2922J;
            int[][] iArr2 = new int[iArr.length][];
            for (int length = iArr.length - 1; length >= 0; length--) {
                int[] iArr3 = this.f2922J[length];
                iArr2[length] = iArr3 != null ? (int[]) iArr3.clone() : null;
            }
            this.f2922J = iArr2;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new d(this, resources);
        }
    }

    public d() {
        this(null, null);
    }

    @Override // androidx.appcompat.graphics.drawable.b, android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        super.applyTheme(theme);
        onStateChange(getState());
    }

    @Override // androidx.appcompat.graphics.drawable.b
    void h(b.d dVar) {
        super.h(dVar);
        if (dVar instanceof a) {
            this.f2920n = (a) dVar;
        }
    }

    @Override // androidx.appcompat.graphics.drawable.b, android.graphics.drawable.Drawable
    public boolean isStateful() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // androidx.appcompat.graphics.drawable.b
    /* renamed from: j, reason: merged with bridge method [inline-methods] */
    public a b() {
        return new a(this.f2920n, this, null);
    }

    int[] k(AttributeSet attributeSet) {
        int attributeCount = attributeSet.getAttributeCount();
        int[] iArr = new int[attributeCount];
        int i5 = 0;
        for (int i6 = 0; i6 < attributeCount; i6++) {
            int attributeNameResource = attributeSet.getAttributeNameResource(i6);
            if (attributeNameResource != 0 && attributeNameResource != 16842960 && attributeNameResource != 16843161) {
                int i7 = i5 + 1;
                if (!attributeSet.getAttributeBooleanValue(i6, false)) {
                    attributeNameResource = -attributeNameResource;
                }
                iArr[i5] = attributeNameResource;
                i5 = i7;
            }
        }
        return StateSet.trimStateSet(iArr, i5);
    }

    @Override // androidx.appcompat.graphics.drawable.b, android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.f2921o && super.mutate() == this) {
            this.f2920n.s();
            this.f2921o = true;
        }
        return this;
    }

    @Override // androidx.appcompat.graphics.drawable.b, android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        boolean onStateChange = super.onStateChange(iArr);
        int B4 = this.f2920n.B(iArr);
        if (B4 < 0) {
            B4 = this.f2920n.B(StateSet.WILD_CARD);
        }
        return g(B4) || onStateChange;
    }

    d(a aVar, Resources resources) {
        h(new a(aVar, this, resources));
        onStateChange(getState());
    }

    d(@Nullable a aVar) {
        if (aVar != null) {
            h(aVar);
        }
    }
}
