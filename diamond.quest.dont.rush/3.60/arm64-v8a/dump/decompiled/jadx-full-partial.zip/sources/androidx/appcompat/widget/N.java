package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.view.C1035l0;
import f.C4993a;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
class N extends ListView {

    /* renamed from: b, reason: collision with root package name */
    private final Rect f3395b;

    /* renamed from: c, reason: collision with root package name */
    private int f3396c;

    /* renamed from: d, reason: collision with root package name */
    private int f3397d;

    /* renamed from: e, reason: collision with root package name */
    private int f3398e;

    /* renamed from: f, reason: collision with root package name */
    private int f3399f;

    /* renamed from: g, reason: collision with root package name */
    private int f3400g;

    /* renamed from: h, reason: collision with root package name */
    private d f3401h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f3402i;

    /* renamed from: j, reason: collision with root package name */
    private boolean f3403j;

    /* renamed from: k, reason: collision with root package name */
    private boolean f3404k;

    /* renamed from: l, reason: collision with root package name */
    private C1035l0 f3405l;

    /* renamed from: m, reason: collision with root package name */
    private androidx.core.widget.h f3406m;

    /* renamed from: n, reason: collision with root package name */
    f f3407n;

    static class a {
        static void a(View view, float f5, float f6) {
            view.drawableHotspotChanged(f5, f6);
        }
    }

    static class b {

        /* renamed from: a, reason: collision with root package name */
        private static Method f3408a;

        /* renamed from: b, reason: collision with root package name */
        private static Method f3409b;

        /* renamed from: c, reason: collision with root package name */
        private static Method f3410c;

        /* renamed from: d, reason: collision with root package name */
        private static boolean f3411d;

        static {
            try {
                Class cls = Integer.TYPE;
                Class cls2 = Float.TYPE;
                Method declaredMethod = AbsListView.class.getDeclaredMethod("positionSelector", cls, View.class, Boolean.TYPE, cls2, cls2);
                f3408a = declaredMethod;
                declaredMethod.setAccessible(true);
                Method declaredMethod2 = AdapterView.class.getDeclaredMethod("setSelectedPositionInt", cls);
                f3409b = declaredMethod2;
                declaredMethod2.setAccessible(true);
                Method declaredMethod3 = AdapterView.class.getDeclaredMethod("setNextSelectedPositionInt", cls);
                f3410c = declaredMethod3;
                declaredMethod3.setAccessible(true);
                f3411d = true;
            } catch (NoSuchMethodException e5) {
                e5.printStackTrace();
            }
        }

        static boolean a() {
            return f3411d;
        }

        static void b(N n5, int i5, View view) {
            try {
                f3408a.invoke(n5, Integer.valueOf(i5), view, Boolean.FALSE, -1, -1);
                f3409b.invoke(n5, Integer.valueOf(i5));
                f3410c.invoke(n5, Integer.valueOf(i5));
            } catch (IllegalAccessException e5) {
                e5.printStackTrace();
            } catch (InvocationTargetException e6) {
                e6.printStackTrace();
            }
        }
    }

    static class c {
        static boolean a(AbsListView absListView) {
            return absListView.isSelectedChildViewEnabled();
        }

        static void b(AbsListView absListView, boolean z4) {
            absListView.setSelectedChildViewEnabled(z4);
        }
    }

    private static class d extends androidx.appcompat.graphics.drawable.c {

        /* renamed from: c, reason: collision with root package name */
        private boolean f3412c;

        d(Drawable drawable) {
            super(drawable);
            this.f3412c = true;
        }

        void b(boolean z4) {
            this.f3412c = z4;
        }

        @Override // androidx.appcompat.graphics.drawable.c, android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            if (this.f3412c) {
                super.draw(canvas);
            }
        }

        @Override // androidx.appcompat.graphics.drawable.c, android.graphics.drawable.Drawable
        public void setHotspot(float f5, float f6) {
            if (this.f3412c) {
                super.setHotspot(f5, f6);
            }
        }

        @Override // androidx.appcompat.graphics.drawable.c, android.graphics.drawable.Drawable
        public void setHotspotBounds(int i5, int i6, int i7, int i8) {
            if (this.f3412c) {
                super.setHotspotBounds(i5, i6, i7, i8);
            }
        }

        @Override // androidx.appcompat.graphics.drawable.c, android.graphics.drawable.Drawable
        public boolean setState(int[] iArr) {
            if (this.f3412c) {
                return super.setState(iArr);
            }
            return false;
        }

        @Override // androidx.appcompat.graphics.drawable.c, android.graphics.drawable.Drawable
        public boolean setVisible(boolean z4, boolean z5) {
            if (this.f3412c) {
                return super.setVisible(z4, z5);
            }
            return false;
        }
    }

    static class e {

        /* renamed from: a, reason: collision with root package name */
        private static final Field f3413a;

        static {
            Field field = null;
            try {
                field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
                field.setAccessible(true);
            } catch (NoSuchFieldException e5) {
                e5.printStackTrace();
            }
            f3413a = field;
        }

        static boolean a(AbsListView absListView) {
            Field field = f3413a;
            if (field == null) {
                return false;
            }
            try {
                return field.getBoolean(absListView);
            } catch (IllegalAccessException e5) {
                e5.printStackTrace();
                return false;
            }
        }

        static void b(AbsListView absListView, boolean z4) {
            Field field = f3413a;
            if (field != null) {
                try {
                    field.set(absListView, Boolean.valueOf(z4));
                } catch (IllegalAccessException e5) {
                    e5.printStackTrace();
                }
            }
        }
    }

    private class f implements Runnable {
        f() {
        }

        public void a() {
            N n5 = N.this;
            n5.f3407n = null;
            n5.removeCallbacks(this);
        }

        public void b() {
            N.this.post(this);
        }

        @Override // java.lang.Runnable
        public void run() {
            N n5 = N.this;
            n5.f3407n = null;
            n5.drawableStateChanged();
        }
    }

    N(Context context, boolean z4) {
        super(context, null, C4993a.f53681B);
        this.f3395b = new Rect();
        this.f3396c = 0;
        this.f3397d = 0;
        this.f3398e = 0;
        this.f3399f = 0;
        this.f3403j = z4;
        setCacheColorHint(0);
    }

    private void a() {
        this.f3404k = false;
        setPressed(false);
        drawableStateChanged();
        View childAt = getChildAt(this.f3400g - getFirstVisiblePosition());
        if (childAt != null) {
            childAt.setPressed(false);
        }
        C1035l0 c1035l0 = this.f3405l;
        if (c1035l0 != null) {
            c1035l0.c();
            this.f3405l = null;
        }
    }

    private void b(View view, int i5) {
        performItemClick(view, i5, getItemIdAtPosition(i5));
    }

    private void c(Canvas canvas) {
        Drawable selector;
        if (this.f3395b.isEmpty() || (selector = getSelector()) == null) {
            return;
        }
        selector.setBounds(this.f3395b);
        selector.draw(canvas);
    }

    private void f(int i5, View view) {
        Rect rect = this.f3395b;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        rect.left -= this.f3396c;
        rect.top -= this.f3397d;
        rect.right += this.f3398e;
        rect.bottom += this.f3399f;
        boolean k5 = k();
        if (view.isEnabled() != k5) {
            l(!k5);
            if (i5 != -1) {
                refreshDrawableState();
            }
        }
    }

    private void g(int i5, View view) {
        Drawable selector = getSelector();
        boolean z4 = (selector == null || i5 == -1) ? false : true;
        if (z4) {
            selector.setVisible(false, false);
        }
        f(i5, view);
        if (z4) {
            Rect rect = this.f3395b;
            float exactCenterX = rect.exactCenterX();
            float exactCenterY = rect.exactCenterY();
            selector.setVisible(getVisibility() == 0, false);
            androidx.core.graphics.drawable.a.j(selector, exactCenterX, exactCenterY);
        }
    }

    private void h(int i5, View view, float f5, float f6) {
        g(i5, view);
        Drawable selector = getSelector();
        if (selector == null || i5 == -1) {
            return;
        }
        androidx.core.graphics.drawable.a.j(selector, f5, f6);
    }

    private void i(View view, int i5, float f5, float f6) {
        View childAt;
        this.f3404k = true;
        a.a(this, f5, f6);
        if (!isPressed()) {
            setPressed(true);
        }
        layoutChildren();
        int i6 = this.f3400g;
        if (i6 != -1 && (childAt = getChildAt(i6 - getFirstVisiblePosition())) != null && childAt != view && childAt.isPressed()) {
            childAt.setPressed(false);
        }
        this.f3400g = i5;
        a.a(view, f5 - view.getLeft(), f6 - view.getTop());
        if (!view.isPressed()) {
            view.setPressed(true);
        }
        h(i5, view, f5, f6);
        j(false);
        refreshDrawableState();
    }

    private void j(boolean z4) {
        d dVar = this.f3401h;
        if (dVar != null) {
            dVar.b(z4);
        }
    }

    private boolean k() {
        return Build.VERSION.SDK_INT >= 33 ? c.a(this) : e.a(this);
    }

    private void l(boolean z4) {
        if (Build.VERSION.SDK_INT >= 33) {
            c.b(this, z4);
        } else {
            e.b(this, z4);
        }
    }

    private boolean m() {
        return this.f3404k;
    }

    private void n() {
        Drawable selector = getSelector();
        if (selector != null && m() && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    public int d(int i5, int i6, int i7, int i8, int i9) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        if (adapter == null) {
            return listPaddingTop + listPaddingBottom;
        }
        int i10 = listPaddingTop + listPaddingBottom;
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        View view = null;
        while (i11 < count) {
            int itemViewType = adapter.getItemViewType(i11);
            if (itemViewType != i12) {
                view = null;
                i12 = itemViewType;
            }
            view = adapter.getView(i11, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i14 = layoutParams.height;
            view.measure(i5, i14 > 0 ? View.MeasureSpec.makeMeasureSpec(i14, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i11 > 0) {
                i10 += dividerHeight;
            }
            i10 += view.getMeasuredHeight();
            if (i10 >= i8) {
                return (i9 < 0 || i11 <= i9 || i13 <= 0 || i10 == i8) ? i8 : i13;
            }
            if (i9 >= 0 && i11 >= i9) {
                i13 = i10;
            }
            i11++;
        }
        return i10;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        c(canvas);
        super.dispatchDraw(canvas);
    }

    @Override // android.widget.AbsListView, android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        if (this.f3407n != null) {
            return;
        }
        super.drawableStateChanged();
        j(true);
        n();
    }

    /* JADX WARN: Code restructure failed: missing block: B:6:0x000c, code lost:
    
        if (r0 != 3) goto L8;
     */
    /* JADX WARN: Removed duplicated region for block: B:11:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0048 A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean e(android.view.MotionEvent r8, int r9) {
        /*
            r7 = this;
            int r0 = r8.getActionMasked()
            r1 = 1
            r2 = 0
            if (r0 == r1) goto L16
            r3 = 2
            if (r0 == r3) goto L14
            r9 = 3
            if (r0 == r9) goto L11
        Le:
            r3 = r1
            r9 = r2
            goto L46
        L11:
            r9 = r2
            r3 = r9
            goto L46
        L14:
            r3 = r1
            goto L17
        L16:
            r3 = r2
        L17:
            int r9 = r8.findPointerIndex(r9)
            if (r9 >= 0) goto L1e
            goto L11
        L1e:
            float r4 = r8.getX(r9)
            int r4 = (int) r4
            float r9 = r8.getY(r9)
            int r9 = (int) r9
            int r5 = r7.pointToPosition(r4, r9)
            r6 = -1
            if (r5 != r6) goto L31
            r9 = r1
            goto L46
        L31:
            int r3 = r7.getFirstVisiblePosition()
            int r3 = r5 - r3
            android.view.View r3 = r7.getChildAt(r3)
            float r4 = (float) r4
            float r9 = (float) r9
            r7.i(r3, r5, r4, r9)
            if (r0 != r1) goto Le
            r7.b(r3, r5)
            goto Le
        L46:
            if (r3 == 0) goto L4a
            if (r9 == 0) goto L4d
        L4a:
            r7.a()
        L4d:
            if (r3 == 0) goto L65
            androidx.core.widget.h r9 = r7.f3406m
            if (r9 != 0) goto L5a
            androidx.core.widget.h r9 = new androidx.core.widget.h
            r9.<init>(r7)
            r7.f3406m = r9
        L5a:
            androidx.core.widget.h r9 = r7.f3406m
            r9.m(r1)
            androidx.core.widget.h r9 = r7.f3406m
            r9.onTouch(r7, r8)
            return r3
        L65:
            androidx.core.widget.h r8 = r7.f3406m
            if (r8 == 0) goto L6c
            r8.m(r2)
        L6c:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.N.e(android.view.MotionEvent, int):boolean");
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean hasFocus() {
        return this.f3403j || super.hasFocus();
    }

    @Override // android.view.View
    public boolean hasWindowFocus() {
        return this.f3403j || super.hasWindowFocus();
    }

    @Override // android.view.View
    public boolean isFocused() {
        return this.f3403j || super.isFocused();
    }

    @Override // android.view.View
    public boolean isInTouchMode() {
        return (this.f3403j && this.f3402i) || super.isInTouchMode();
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        this.f3407n = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int i5 = Build.VERSION.SDK_INT;
        if (i5 < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f3407n == null) {
            f fVar = new f();
            this.f3407n = fVar;
            fVar.b();
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked != 9 && actionMasked != 7) {
            setSelection(-1);
            return onHoverEvent;
        }
        int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        if (pointToPosition != -1 && pointToPosition != getSelectedItemPosition()) {
            View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
            if (childAt.isEnabled()) {
                requestFocus();
                if (i5 < 30 || !b.a()) {
                    setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                } else {
                    b.b(this, pointToPosition, childAt);
                }
            }
            n();
        }
        return onHoverEvent;
    }

    @Override // android.widget.AbsListView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f3400g = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        f fVar = this.f3407n;
        if (fVar != null) {
            fVar.a();
        }
        return super.onTouchEvent(motionEvent);
    }

    void setListSelectionHidden(boolean z4) {
        this.f3402i = z4;
    }

    @Override // android.widget.AbsListView
    public void setSelector(Drawable drawable) {
        d dVar = drawable != null ? new d(drawable) : null;
        this.f3401h = dVar;
        super.setSelector(dVar);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f3396c = rect.left;
        this.f3397d = rect.top;
        this.f3398e = rect.right;
        this.f3399f = rect.bottom;
    }
}
