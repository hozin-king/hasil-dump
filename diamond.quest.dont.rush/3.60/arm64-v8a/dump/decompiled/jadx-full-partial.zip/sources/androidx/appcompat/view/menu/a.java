package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.core.view.AbstractC1014b;
import p.InterfaceMenuItemC7302b;

/* loaded from: classes.dex */
public class a implements InterfaceMenuItemC7302b {

    /* renamed from: a, reason: collision with root package name */
    private final int f3022a;

    /* renamed from: b, reason: collision with root package name */
    private final int f3023b;

    /* renamed from: c, reason: collision with root package name */
    private final int f3024c;

    /* renamed from: d, reason: collision with root package name */
    private CharSequence f3025d;

    /* renamed from: e, reason: collision with root package name */
    private CharSequence f3026e;

    /* renamed from: f, reason: collision with root package name */
    private Intent f3027f;

    /* renamed from: g, reason: collision with root package name */
    private char f3028g;

    /* renamed from: i, reason: collision with root package name */
    private char f3030i;

    /* renamed from: k, reason: collision with root package name */
    private Drawable f3032k;

    /* renamed from: l, reason: collision with root package name */
    private Context f3033l;

    /* renamed from: m, reason: collision with root package name */
    private MenuItem.OnMenuItemClickListener f3034m;

    /* renamed from: n, reason: collision with root package name */
    private CharSequence f3035n;

    /* renamed from: o, reason: collision with root package name */
    private CharSequence f3036o;

    /* renamed from: h, reason: collision with root package name */
    private int f3029h = 4096;

    /* renamed from: j, reason: collision with root package name */
    private int f3031j = 4096;

    /* renamed from: p, reason: collision with root package name */
    private ColorStateList f3037p = null;

    /* renamed from: q, reason: collision with root package name */
    private PorterDuff.Mode f3038q = null;

    /* renamed from: r, reason: collision with root package name */
    private boolean f3039r = false;

    /* renamed from: s, reason: collision with root package name */
    private boolean f3040s = false;

    /* renamed from: t, reason: collision with root package name */
    private int f3041t = 16;

    public a(Context context, int i5, int i6, int i7, int i8, CharSequence charSequence) {
        this.f3033l = context;
        this.f3022a = i6;
        this.f3023b = i5;
        this.f3024c = i8;
        this.f3025d = charSequence;
    }

    private void c() {
        Drawable drawable = this.f3032k;
        if (drawable != null) {
            if (this.f3039r || this.f3040s) {
                Drawable q5 = androidx.core.graphics.drawable.a.q(drawable);
                this.f3032k = q5;
                Drawable mutate = q5.mutate();
                this.f3032k = mutate;
                if (this.f3039r) {
                    androidx.core.graphics.drawable.a.n(mutate, this.f3037p);
                }
                if (this.f3040s) {
                    androidx.core.graphics.drawable.a.o(this.f3032k, this.f3038q);
                }
            }
        }
    }

    @Override // p.InterfaceMenuItemC7302b
    public AbstractC1014b a() {
        return null;
    }

    @Override // p.InterfaceMenuItemC7302b
    public InterfaceMenuItemC7302b b(AbstractC1014b abstractC1014b) {
        throw new UnsupportedOperationException();
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean collapseActionView() {
        return false;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setActionView(int i5) {
        throw new UnsupportedOperationException();
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: e, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean expandActionView() {
        return false;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    /* renamed from: f, reason: merged with bridge method [inline-methods] */
    public InterfaceMenuItemC7302b setShowAsActionFlags(int i5) {
        setShowAsAction(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public View getActionView() {
        return null;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f3031j;
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f3030i;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f3035n;
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f3023b;
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        return this.f3032k;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f3037p;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f3038q;
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f3027f;
    }

    @Override // android.view.MenuItem
    public int getItemId() {
        return this.f3022a;
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public int getNumericModifiers() {
        return this.f3029h;
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f3028g;
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f3024c;
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return null;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitle() {
        return this.f3025d;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f3026e;
        return charSequence != null ? charSequence : this.f3025d;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f3036o;
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return false;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public boolean isActionViewExpanded() {
        return false;
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return (this.f3041t & 1) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return (this.f3041t & 2) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return (this.f3041t & 16) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        return (this.f3041t & 8) == 0;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5) {
        this.f3030i = Character.toLowerCase(c5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z4) {
        this.f3041t = (z4 ? 1 : 0) | (this.f3041t & (-2));
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z4) {
        this.f3041t = (z4 ? 2 : 0) | (this.f3041t & (-3));
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z4) {
        this.f3041t = (z4 ? 16 : 0) | (this.f3041t & (-17));
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f3032k = drawable;
        c();
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f3037p = colorStateList;
        this.f3039r = true;
        c();
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f3038q = mode;
        this.f3040s = true;
        c();
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f3027f = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c5) {
        this.f3028g = c5;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f3034m = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6) {
        this.f3028g = c5;
        this.f3030i = Character.toLowerCase(c6);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public void setShowAsAction(int i5) {
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f3025d = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f3026e = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z4) {
        this.f3041t = (this.f3041t & 8) | (z4 ? 0 : 8);
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c5, int i5) {
        this.f3030i = Character.toLowerCase(c5);
        this.f3031j = KeyEvent.normalizeMetaState(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public InterfaceMenuItemC7302b setContentDescription(CharSequence charSequence) {
        this.f3035n = charSequence;
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setNumericShortcut(char c5, int i5) {
        this.f3028g = c5;
        this.f3029h = KeyEvent.normalizeMetaState(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i5) {
        this.f3025d = this.f3033l.getResources().getString(i5);
        return this;
    }

    @Override // android.view.MenuItem
    public InterfaceMenuItemC7302b setTooltipText(CharSequence charSequence) {
        this.f3036o = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i5) {
        this.f3032k = androidx.core.content.a.getDrawable(this.f3033l, i5);
        c();
        return this;
    }

    @Override // p.InterfaceMenuItemC7302b, android.view.MenuItem
    public MenuItem setShortcut(char c5, char c6, int i5, int i6) {
        this.f3028g = c5;
        this.f3029h = KeyEvent.normalizeMetaState(i5);
        this.f3030i = Character.toLowerCase(c6);
        this.f3031j = KeyEvent.normalizeMetaState(i6);
        return this;
    }
}
