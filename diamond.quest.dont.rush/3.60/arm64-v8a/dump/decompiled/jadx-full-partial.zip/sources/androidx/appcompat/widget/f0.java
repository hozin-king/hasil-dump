package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
class f0 extends X {

    /* renamed from: b, reason: collision with root package name */
    private final WeakReference f3775b;

    public f0(Context context, Resources resources) {
        super(resources);
        this.f3775b = new WeakReference(context);
    }

    @Override // android.content.res.Resources
    public Drawable getDrawable(int i5) {
        Drawable a5 = a(i5);
        Context context = (Context) this.f3775b.get();
        if (a5 != null && context != null) {
            W.h().x(context, i5, a5);
        }
        return a5;
    }
}
