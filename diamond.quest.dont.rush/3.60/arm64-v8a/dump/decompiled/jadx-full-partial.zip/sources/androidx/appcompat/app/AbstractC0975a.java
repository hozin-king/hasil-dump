package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.appcompat.view.b;

/* renamed from: androidx.appcompat.app.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0975a {

    /* renamed from: androidx.appcompat.app.a$b */
    public static abstract class b {
        public abstract CharSequence a();

        public abstract View b();

        public abstract Drawable c();

        public abstract CharSequence d();

        public abstract void e();
    }

    public boolean f() {
        return false;
    }

    public boolean g() {
        return false;
    }

    public void h(boolean z4) {
    }

    public abstract int i();

    public Context j() {
        return null;
    }

    public boolean k() {
        return false;
    }

    public void l(Configuration configuration) {
    }

    void m() {
    }

    public boolean n(int i5, KeyEvent keyEvent) {
        return false;
    }

    public boolean o(KeyEvent keyEvent) {
        return false;
    }

    public boolean p() {
        return false;
    }

    public void q(boolean z4) {
    }

    public void r(boolean z4) {
    }

    public void s(CharSequence charSequence) {
    }

    public androidx.appcompat.view.b t(b.a aVar) {
        return null;
    }

    /* renamed from: androidx.appcompat.app.a$a, reason: collision with other inner class name */
    public static class C0106a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public int f2720a;

        public C0106a(@NonNull Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2720a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f.j.f54089t);
            this.f2720a = obtainStyledAttributes.getInt(f.j.f54094u, 0);
            obtainStyledAttributes.recycle();
        }

        public C0106a(int i5, int i6) {
            super(i5, i6);
            this.f2720a = 8388627;
        }

        public C0106a(int i5, int i6, int i7) {
            super(i5, i6);
            this.f2720a = i7;
        }

        public C0106a(int i5) {
            this(-2, -1, i5);
        }

        public C0106a(C0106a c0106a) {
            super((ViewGroup.MarginLayoutParams) c0106a);
            this.f2720a = 0;
            this.f2720a = c0106a.f2720a;
        }

        public C0106a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2720a = 0;
        }
    }
}
