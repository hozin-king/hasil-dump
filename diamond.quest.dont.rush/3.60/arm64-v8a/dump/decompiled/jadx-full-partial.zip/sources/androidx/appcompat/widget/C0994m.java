package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;

/* renamed from: androidx.appcompat.widget.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0994m {

    /* renamed from: a, reason: collision with root package name */
    private final EditText f3834a;

    /* renamed from: b, reason: collision with root package name */
    private final F.a f3835b;

    C0994m(EditText editText) {
        this.f3834a = editText;
        this.f3835b = new F.a(editText, false);
    }

    KeyListener a(KeyListener keyListener) {
        return b(keyListener) ? this.f3835b.a(keyListener) : keyListener;
    }

    boolean b(KeyListener keyListener) {
        return !(keyListener instanceof NumberKeyListener);
    }

    void c(AttributeSet attributeSet, int i5) {
        TypedArray obtainStyledAttributes = this.f3834a.getContext().obtainStyledAttributes(attributeSet, f.j.f54025g0, i5, 0);
        try {
            boolean z4 = obtainStyledAttributes.hasValue(f.j.f54095u0) ? obtainStyledAttributes.getBoolean(f.j.f54095u0, true) : true;
            obtainStyledAttributes.recycle();
            e(z4);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    InputConnection d(InputConnection inputConnection, EditorInfo editorInfo) {
        return this.f3835b.b(inputConnection, editorInfo);
    }

    void e(boolean z4) {
        this.f3835b.c(z4);
    }
}
