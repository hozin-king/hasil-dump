package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

/* renamed from: androidx.appcompat.widget.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0999s extends PopupWindow {

    /* renamed from: b, reason: collision with root package name */
    private static final boolean f3876b = false;

    /* renamed from: a, reason: collision with root package name */
    private boolean f3877a;

    public C0999s(Context context, AttributeSet attributeSet, int i5, int i6) {
        super(context, attributeSet, i5, i6);
        a(context, attributeSet, i5, i6);
    }

    private void a(Context context, AttributeSet attributeSet, int i5, int i6) {
        g0 u5 = g0.u(context, attributeSet, f.j.f53988Y1, i5, i6);
        if (u5.r(f.j.f53997a2)) {
            b(u5.a(f.j.f53997a2, false));
        }
        setBackgroundDrawable(u5.f(f.j.f53992Z1));
        u5.w();
    }

    private void b(boolean z4) {
        if (f3876b) {
            this.f3877a = z4;
        } else {
            androidx.core.widget.i.a(this, z4);
        }
    }

    @Override // android.widget.PopupWindow
    public void showAsDropDown(View view, int i5, int i6) {
        if (f3876b && this.f3877a) {
            i6 -= view.getHeight();
        }
        super.showAsDropDown(view, i5, i6);
    }

    @Override // android.widget.PopupWindow
    public void update(View view, int i5, int i6, int i7, int i8) {
        if (f3876b && this.f3877a) {
            i6 -= view.getHeight();
        }
        super.update(view, i5, i6, i7, i8);
    }

    @Override // android.widget.PopupWindow
    public void showAsDropDown(View view, int i5, int i6, int i7) {
        if (f3876b && this.f3877a) {
            i6 -= view.getHeight();
        }
        super.showAsDropDown(view, i5, i6, i7);
    }
}
