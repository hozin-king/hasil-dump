package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.text.h;
import g.C5008a;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/* loaded from: classes.dex */
public class B extends TextView implements androidx.core.widget.l {
    private final C0986e mBackgroundTintHelper;

    @NonNull
    private C0995n mEmojiTextViewHelper;
    private boolean mIsSetTypefaceProcessing;

    @Nullable
    private Future<androidx.core.text.h> mPrecomputedTextFuture;

    @Nullable
    private a mSuperCaller;
    private final C1006z mTextClassifierHelper;
    private final A mTextHelper;

    private interface a {
        int a();

        TextClassifier b();

        int c();

        void d(int i5, int i6, int i7, int i8);

        void e(int i5);

        int f();

        void g(int i5);

        void h(int[] iArr, int i5);

        void i(int i5);

        int j();

        void k(int i5, float f5);

        int[] l();

        void m(TextClassifier textClassifier);
    }

    class b implements a {
        b() {
        }

        @Override // androidx.appcompat.widget.B.a
        public int a() {
            return B.super.getAutoSizeMinTextSize();
        }

        @Override // androidx.appcompat.widget.B.a
        public TextClassifier b() {
            return B.super.getTextClassifier();
        }

        @Override // androidx.appcompat.widget.B.a
        public int c() {
            return B.super.getAutoSizeMaxTextSize();
        }

        @Override // androidx.appcompat.widget.B.a
        public void d(int i5, int i6, int i7, int i8) {
            B.super.setAutoSizeTextTypeUniformWithConfiguration(i5, i6, i7, i8);
        }

        @Override // androidx.appcompat.widget.B.a
        public void e(int i5) {
        }

        @Override // androidx.appcompat.widget.B.a
        public int f() {
            return B.super.getAutoSizeStepGranularity();
        }

        @Override // androidx.appcompat.widget.B.a
        public void g(int i5) {
            B.super.setAutoSizeTextTypeWithDefaults(i5);
        }

        @Override // androidx.appcompat.widget.B.a
        public void h(int[] iArr, int i5) {
            B.super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i5);
        }

        @Override // androidx.appcompat.widget.B.a
        public void i(int i5) {
        }

        @Override // androidx.appcompat.widget.B.a
        public int j() {
            return B.super.getAutoSizeTextType();
        }

        @Override // androidx.appcompat.widget.B.a
        public void k(int i5, float f5) {
        }

        @Override // androidx.appcompat.widget.B.a
        public int[] l() {
            return B.super.getAutoSizeTextAvailableSizes();
        }

        @Override // androidx.appcompat.widget.B.a
        public void m(TextClassifier textClassifier) {
            B.super.setTextClassifier(textClassifier);
        }
    }

    class c extends b {
        c() {
            super();
        }

        @Override // androidx.appcompat.widget.B.b, androidx.appcompat.widget.B.a
        public void e(int i5) {
            B.super.setFirstBaselineToTopHeight(i5);
        }

        @Override // androidx.appcompat.widget.B.b, androidx.appcompat.widget.B.a
        public void i(int i5) {
            B.super.setLastBaselineToBottomHeight(i5);
        }
    }

    class d extends c {
        d() {
            super();
        }

        @Override // androidx.appcompat.widget.B.b, androidx.appcompat.widget.B.a
        public void k(int i5, float f5) {
            B.super.setLineHeight(i5, f5);
        }
    }

    public B(@NonNull Context context) {
        this(context, null);
    }

    private void e() {
        Future<androidx.core.text.h> future = this.mPrecomputedTextFuture;
        if (future != null) {
            try {
                this.mPrecomputedTextFuture = null;
                androidx.core.widget.j.l(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    @NonNull
    private C0995n getEmojiTextViewHelper() {
        if (this.mEmojiTextViewHelper == null) {
            this.mEmojiTextViewHelper = new C0995n(this);
        }
        return this.mEmojiTextViewHelper;
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.b();
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (r0.f3875c) {
            return getSuperCaller().c();
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            return a5.e();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (r0.f3875c) {
            return getSuperCaller().a();
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            return a5.f();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (r0.f3875c) {
            return getSuperCaller().f();
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            return a5.g();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (r0.f3875c) {
            return getSuperCaller().l();
        }
        A a5 = this.mTextHelper;
        return a5 != null ? a5.h() : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (r0.f3875c) {
            return getSuperCaller().j() == 1 ? 1 : 0;
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            return a5.i();
        }
        return 0;
    }

    @Override // android.widget.TextView
    @Nullable
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return androidx.core.widget.j.n(super.getCustomSelectionActionModeCallback());
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return androidx.core.widget.j.a(this);
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return androidx.core.widget.j.b(this);
    }

    a getSuperCaller() {
        if (this.mSuperCaller == null) {
            int i5 = Build.VERSION.SDK_INT;
            if (i5 >= 34) {
                this.mSuperCaller = new d();
            } else if (i5 >= 28) {
                this.mSuperCaller = new c();
            } else if (i5 >= 26) {
                this.mSuperCaller = new b();
            }
        }
        return this.mSuperCaller;
    }

    @Nullable
    public ColorStateList getSupportBackgroundTintList() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.c();
        }
        return null;
    }

    @Nullable
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            return c0986e.d();
        }
        return null;
    }

    @Nullable
    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.mTextHelper.j();
    }

    @Nullable
    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.mTextHelper.k();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        e();
        return super.getText();
    }

    @Override // android.widget.TextView
    @NonNull
    public TextClassifier getTextClassifier() {
        C1006z c1006z;
        return (Build.VERSION.SDK_INT >= 28 || (c1006z = this.mTextClassifierHelper) == null) ? getSuperCaller().b() : c1006z.a();
    }

    @NonNull
    public h.b getTextMetricsParamsCompat() {
        return androidx.core.widget.j.e(this);
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.mTextHelper.r(this, onCreateInputConnection, editorInfo);
        return AbstractC0996o.a(onCreateInputConnection, editorInfo, this);
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i5 = Build.VERSION.SDK_INT;
        if (i5 < 30 || i5 >= 33 || !onCheckIsTextEditor()) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z4, int i5, int i6, int i7, int i8) {
        super.onLayout(z4, i5, i6, i7, i8);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.o(z4, i5, i6, i7, i8);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onMeasure(int i5, int i6) {
        e();
        super.onMeasure(i5, i6);
    }

    @Override // android.widget.TextView
    protected void onTextChanged(CharSequence charSequence, int i5, int i6, int i7) {
        super.onTextChanged(charSequence, i5, i6, i7);
        A a5 = this.mTextHelper;
        if (a5 == null || r0.f3875c || !a5.l()) {
            return;
        }
        this.mTextHelper.c();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z4) {
        super.setAllCaps(z4);
        getEmojiTextViewHelper().d(z4);
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i5, int i6, int i7, int i8) throws IllegalArgumentException {
        if (r0.f3875c) {
            getSuperCaller().d(i5, i6, i7, i8);
            return;
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.t(i5, i6, i7, i8);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] iArr, int i5) throws IllegalArgumentException {
        if (r0.f3875c) {
            getSuperCaller().h(iArr, i5);
            return;
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.u(iArr, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i5) {
        if (r0.f3875c) {
            getSuperCaller().g(i5);
            return;
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.v(i5);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(@Nullable Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i5) {
        super.setBackgroundResource(i5);
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.g(i5);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(@Nullable Drawable drawable, @Nullable Drawable drawable2, @Nullable Drawable drawable3, @Nullable Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(@Nullable ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(androidx.core.widget.j.o(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z4) {
        getEmojiTextViewHelper().e(z4);
    }

    @Override // android.widget.TextView
    public void setFilters(@NonNull InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i5) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().e(i5);
        } else {
            androidx.core.widget.j.h(this, i5);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i5) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().i(i5);
        } else {
            androidx.core.widget.j.i(this, i5);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i5) {
        androidx.core.widget.j.j(this, i5);
    }

    public void setPrecomputedText(@NonNull androidx.core.text.h hVar) {
        androidx.core.widget.j.l(this, hVar);
    }

    public void setSupportBackgroundTintList(@Nullable ColorStateList colorStateList) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(@Nullable PorterDuff.Mode mode) {
        C0986e c0986e = this.mBackgroundTintHelper;
        if (c0986e != null) {
            c0986e.j(mode);
        }
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintList(@Nullable ColorStateList colorStateList) {
        this.mTextHelper.w(colorStateList);
        this.mTextHelper.b();
    }

    @Override // androidx.core.widget.l
    public void setSupportCompoundDrawablesTintMode(@Nullable PorterDuff.Mode mode) {
        this.mTextHelper.x(mode);
        this.mTextHelper.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i5) {
        super.setTextAppearance(context, i5);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.q(context, i5);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(@Nullable TextClassifier textClassifier) {
        C1006z c1006z;
        if (Build.VERSION.SDK_INT >= 28 || (c1006z = this.mTextClassifierHelper) == null) {
            getSuperCaller().m(textClassifier);
        } else {
            c1006z.b(textClassifier);
        }
    }

    public void setTextFuture(@Nullable Future<androidx.core.text.h> future) {
        this.mPrecomputedTextFuture = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(@NonNull h.b bVar) {
        androidx.core.widget.j.m(this, bVar);
    }

    @Override // android.widget.TextView
    public void setTextSize(int i5, float f5) {
        if (r0.f3875c) {
            super.setTextSize(i5, f5);
            return;
        }
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.A(i5, f5);
        }
    }

    @Override // android.widget.TextView
    public void setTypeface(@Nullable Typeface typeface, int i5) {
        if (this.mIsSetTypefaceProcessing) {
            return;
        }
        Typeface a5 = (typeface == null || i5 <= 0) ? null : androidx.core.graphics.e.a(getContext(), typeface, i5);
        this.mIsSetTypefaceProcessing = true;
        if (a5 != null) {
            typeface = a5;
        }
        try {
            super.setTypeface(typeface, i5);
        } finally {
            this.mIsSetTypefaceProcessing = false;
        }
    }

    public B(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i5, float f5) {
        if (Build.VERSION.SDK_INT >= 34) {
            getSuperCaller().k(i5, f5);
        } else {
            androidx.core.widget.j.k(this, i5, f5);
        }
    }

    public B(@NonNull Context context, @Nullable AttributeSet attributeSet, int i5) {
        super(d0.b(context), attributeSet, i5);
        this.mIsSetTypefaceProcessing = false;
        this.mSuperCaller = null;
        c0.a(this, getContext());
        C0986e c0986e = new C0986e(this);
        this.mBackgroundTintHelper = c0986e;
        c0986e.e(attributeSet, i5);
        A a5 = new A(this);
        this.mTextHelper = a5;
        a5.m(attributeSet, i5);
        a5.b();
        this.mTextClassifierHelper = new C1006z(this);
        getEmojiTextViewHelper().c(attributeSet, i5);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i5, int i6, int i7, int i8) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i5 != 0 ? C5008a.b(context, i5) : null, i6 != 0 ? C5008a.b(context, i6) : null, i7 != 0 ? C5008a.b(context, i7) : null, i8 != 0 ? C5008a.b(context, i8) : null);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i5, int i6, int i7, int i8) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i5 != 0 ? C5008a.b(context, i5) : null, i6 != 0 ? C5008a.b(context, i6) : null, i7 != 0 ? C5008a.b(context, i7) : null, i8 != 0 ? C5008a.b(context, i8) : null);
        A a5 = this.mTextHelper;
        if (a5 != null) {
            a5.p();
        }
    }
}
