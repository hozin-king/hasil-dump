package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;

/* loaded from: classes.dex */
public final class O implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: b, reason: collision with root package name */
    private final View f4489b;

    /* renamed from: c, reason: collision with root package name */
    private ViewTreeObserver f4490c;

    /* renamed from: d, reason: collision with root package name */
    private final Runnable f4491d;

    private O(View view, Runnable runnable) {
        this.f4489b = view;
        this.f4490c = view.getViewTreeObserver();
        this.f4491d = runnable;
    }

    public static O a(View view, Runnable runnable) {
        if (view == null) {
            throw new NullPointerException("view == null");
        }
        if (runnable == null) {
            throw new NullPointerException("runnable == null");
        }
        O o5 = new O(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(o5);
        view.addOnAttachStateChangeListener(o5);
        return o5;
    }

    public void b() {
        if (this.f4490c.isAlive()) {
            this.f4490c.removeOnPreDrawListener(this);
        } else {
            this.f4489b.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        this.f4489b.removeOnAttachStateChangeListener(this);
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public boolean onPreDraw() {
        b();
        this.f4491d.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
        this.f4490c = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        b();
    }
}
