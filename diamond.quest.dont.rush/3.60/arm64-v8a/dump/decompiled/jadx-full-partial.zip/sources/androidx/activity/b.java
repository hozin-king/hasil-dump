package androidx.activity;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: e, reason: collision with root package name */
    public static final a f2469e = new a(null);

    /* renamed from: a, reason: collision with root package name */
    private final float f2470a;

    /* renamed from: b, reason: collision with root package name */
    private final float f2471b;

    /* renamed from: c, reason: collision with root package name */
    private final float f2472c;

    /* renamed from: d, reason: collision with root package name */
    private final int f2473d;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public b(float f5, float f6, float f7, int i5) {
        this.f2470a = f5;
        this.f2471b = f6;
        this.f2472c = f7;
        this.f2473d = i5;
    }

    public String toString() {
        return "BackEventCompat{touchX=" + this.f2470a + ", touchY=" + this.f2471b + ", progress=" + this.f2472c + ", swipeEdge=" + this.f2473d + '}';
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public b(android.window.BackEvent r5) {
        /*
            r4 = this;
            java.lang.String r0 = "backEvent"
            kotlin.jvm.internal.C7150s.j(r5, r0)
            androidx.activity.a r0 = androidx.activity.C0974a.f2468a
            float r1 = r0.d(r5)
            float r2 = r0.e(r5)
            float r3 = r0.b(r5)
            int r5 = r0.c(r5)
            r4.<init>(r1, r2, r3, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.b.<init>(android.window.BackEvent):void");
    }
}
