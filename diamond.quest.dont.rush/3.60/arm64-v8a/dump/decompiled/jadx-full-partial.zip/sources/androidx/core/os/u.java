package androidx.core.os;

import android.os.OutcomeReceiver;

/* loaded from: classes.dex */
public abstract class u {
    public static final OutcomeReceiver a(O3.d dVar) {
        return t.a(new g(dVar));
    }
}
