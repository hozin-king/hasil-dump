package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: classes.dex */
public class e0 {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f3768a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f3769b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f3770c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f3771d;

    void a() {
        this.f3768a = null;
        this.f3771d = false;
        this.f3769b = null;
        this.f3770c = false;
    }
}
