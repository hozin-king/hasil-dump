package androidx.activity.result;

/* loaded from: classes.dex */
public abstract class b {
    public void a(Object obj) {
        b(obj, null);
    }

    public abstract void b(Object obj, androidx.core.app.d dVar);

    public abstract void c();
}
