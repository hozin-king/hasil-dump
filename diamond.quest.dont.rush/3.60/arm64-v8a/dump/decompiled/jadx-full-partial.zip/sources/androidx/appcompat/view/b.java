package androidx.appcompat.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: b, reason: collision with root package name */
    private Object f2924b;

    /* renamed from: c, reason: collision with root package name */
    private boolean f2925c;

    public interface a {
        boolean a(b bVar, Menu menu);

        boolean b(b bVar, MenuItem menuItem);

        boolean c(b bVar, Menu menu);

        void d(b bVar);
    }

    public abstract void c();

    public abstract View d();

    public abstract Menu e();

    public abstract MenuInflater f();

    public abstract CharSequence g();

    public Object h() {
        return this.f2924b;
    }

    public abstract CharSequence i();

    public boolean j() {
        return this.f2925c;
    }

    public abstract void k();

    public boolean l() {
        return false;
    }

    public abstract void m(View view);

    public abstract void n(int i5);

    public abstract void o(CharSequence charSequence);

    public void p(Object obj) {
        this.f2924b = obj;
    }

    public abstract void q(int i5);

    public abstract void r(CharSequence charSequence);

    public void s(boolean z4) {
        this.f2925c = z4;
    }
}
