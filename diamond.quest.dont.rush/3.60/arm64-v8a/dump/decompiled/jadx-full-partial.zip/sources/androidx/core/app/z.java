package androidx.core.app;

import android.content.res.Configuration;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    private final boolean f4295a;

    /* renamed from: b, reason: collision with root package name */
    private Configuration f4296b;

    public z(boolean z4) {
        this.f4295a = z4;
    }

    public final boolean a() {
        return this.f4295a;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public z(boolean z4, Configuration newConfig) {
        this(z4);
        C7150s.j(newConfig, "newConfig");
        this.f4296b = newConfig;
    }
}
