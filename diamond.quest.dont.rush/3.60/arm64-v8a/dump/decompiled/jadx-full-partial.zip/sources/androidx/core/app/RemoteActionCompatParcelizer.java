package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(androidx.versionedparcelable.b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f4217a = (IconCompat) bVar.v(remoteActionCompat.f4217a, 1);
        remoteActionCompat.f4218b = bVar.l(remoteActionCompat.f4218b, 2);
        remoteActionCompat.f4219c = bVar.l(remoteActionCompat.f4219c, 3);
        remoteActionCompat.f4220d = (PendingIntent) bVar.r(remoteActionCompat.f4220d, 4);
        remoteActionCompat.f4221e = bVar.h(remoteActionCompat.f4221e, 5);
        remoteActionCompat.f4222f = bVar.h(remoteActionCompat.f4222f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, androidx.versionedparcelable.b bVar) {
        bVar.x(false, false);
        bVar.M(remoteActionCompat.f4217a, 1);
        bVar.D(remoteActionCompat.f4218b, 2);
        bVar.D(remoteActionCompat.f4219c, 3);
        bVar.H(remoteActionCompat.f4220d, 4);
        bVar.z(remoteActionCompat.f4221e, 5);
        bVar.z(remoteActionCompat.f4222f, 6);
    }
}
