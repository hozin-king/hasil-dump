package androidx.core.os;

import android.os.Build;
import android.os.Trace;
import android.util.Log;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public final class v {

    /* renamed from: a, reason: collision with root package name */
    private static long f4423a;

    /* renamed from: b, reason: collision with root package name */
    private static Method f4424b;

    /* renamed from: c, reason: collision with root package name */
    private static Method f4425c;

    /* renamed from: d, reason: collision with root package name */
    private static Method f4426d;

    /* renamed from: e, reason: collision with root package name */
    private static Method f4427e;

    static class a {
        static void a(String str, int i5) {
            Trace.beginAsyncSection(str, i5);
        }

        static void b(String str, int i5) {
            Trace.endAsyncSection(str, i5);
        }

        static boolean c() {
            return Trace.isEnabled();
        }

        static void d(String str, long j5) {
            Trace.setCounter(str, j5);
        }
    }

    static {
        if (Build.VERSION.SDK_INT < 29) {
            try {
                f4423a = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                Class cls = Long.TYPE;
                f4424b = Trace.class.getMethod("isTagEnabled", cls);
                Class cls2 = Integer.TYPE;
                f4425c = Trace.class.getMethod("asyncTraceBegin", cls, String.class, cls2);
                f4426d = Trace.class.getMethod("asyncTraceEnd", cls, String.class, cls2);
                f4427e = Trace.class.getMethod("traceCounter", cls, String.class, cls2);
            } catch (Exception e5) {
                Log.i("TraceCompat", "Unable to initialize via reflection.", e5);
            }
        }
    }

    private v() {
    }

    public static void a(String str) {
        Trace.beginSection(str);
    }

    public static void b() {
        Trace.endSection();
    }

    public static boolean c() {
        if (Build.VERSION.SDK_INT >= 29) {
            return a.c();
        }
        try {
            return ((Boolean) f4424b.invoke(null, Long.valueOf(f4423a))).booleanValue();
        } catch (Exception unused) {
            Log.v("TraceCompat", "Unable to invoke isTagEnabled() via reflection.");
            return false;
        }
    }
}
