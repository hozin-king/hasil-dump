package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class ActivityResult implements Parcelable {

    /* renamed from: b, reason: collision with root package name */
    private final int f2497b;

    /* renamed from: c, reason: collision with root package name */
    private final Intent f2498c;

    /* renamed from: d, reason: collision with root package name */
    public static final b f2496d = new b(null);
    public static final Parcelable.Creator<ActivityResult> CREATOR = new a();

    public static final class a implements Parcelable.Creator {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public ActivityResult createFromParcel(Parcel parcel) {
            C7150s.j(parcel, "parcel");
            return new ActivityResult(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public ActivityResult[] newArray(int i5) {
            return new ActivityResult[i5];
        }
    }

    public static final class b {
        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final String a(int i5) {
            return i5 != -1 ? i5 != 0 ? String.valueOf(i5) : "RESULT_CANCELED" : "RESULT_OK";
        }

        private b() {
        }
    }

    public ActivityResult(int i5, Intent intent) {
        this.f2497b = i5;
        this.f2498c = intent;
    }

    public final Intent c() {
        return this.f2498c;
    }

    public final int d() {
        return this.f2497b;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "ActivityResult{resultCode=" + f2496d.a(this.f2497b) + ", data=" + this.f2498c + '}';
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i5) {
        C7150s.j(dest, "dest");
        dest.writeInt(this.f2497b);
        dest.writeInt(this.f2498c == null ? 0 : 1);
        Intent intent = this.f2498c;
        if (intent != null) {
            intent.writeToParcel(dest, i5);
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ActivityResult(Parcel parcel) {
        this(parcel.readInt(), parcel.readInt() == 0 ? null : (Intent) Intent.CREATOR.createFromParcel(parcel));
        C7150s.j(parcel, "parcel");
    }
}
