package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class d0 extends ContextWrapper {

    /* renamed from: c, reason: collision with root package name */
    private static final Object f3758c = new Object();

    /* renamed from: d, reason: collision with root package name */
    private static ArrayList f3759d;

    /* renamed from: a, reason: collision with root package name */
    private final Resources f3760a;

    /* renamed from: b, reason: collision with root package name */
    private final Resources.Theme f3761b;

    private d0(@NonNull Context context) {
        super(context);
        if (!q0.c()) {
            this.f3760a = new f0(this, context.getResources());
            this.f3761b = null;
            return;
        }
        q0 q0Var = new q0(this, context.getResources());
        this.f3760a = q0Var;
        Resources.Theme newTheme = q0Var.newTheme();
        this.f3761b = newTheme;
        newTheme.setTo(context.getTheme());
    }

    private static boolean a(Context context) {
        return ((context instanceof d0) || (context.getResources() instanceof f0) || (context.getResources() instanceof q0) || !q0.c()) ? false : true;
    }

    public static Context b(Context context) {
        if (!a(context)) {
            return context;
        }
        synchronized (f3758c) {
            try {
                ArrayList arrayList = f3759d;
                if (arrayList == null) {
                    f3759d = new ArrayList();
                } else {
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        WeakReference weakReference = (WeakReference) f3759d.get(size);
                        if (weakReference == null || weakReference.get() == null) {
                            f3759d.remove(size);
                        }
                    }
                    for (int size2 = f3759d.size() - 1; size2 >= 0; size2--) {
                        WeakReference weakReference2 = (WeakReference) f3759d.get(size2);
                        d0 d0Var = weakReference2 != null ? (d0) weakReference2.get() : null;
                        if (d0Var != null && d0Var.getBaseContext() == context) {
                            return d0Var;
                        }
                    }
                }
                d0 d0Var2 = new d0(context);
                f3759d.add(new WeakReference(d0Var2));
                return d0Var2;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return this.f3760a.getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        return this.f3760a;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f3761b;
        return theme == null ? super.getTheme() : theme;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i5) {
        Resources.Theme theme = this.f3761b;
        if (theme == null) {
            super.setTheme(i5);
        } else {
            theme.applyStyle(i5, true);
        }
    }
}
