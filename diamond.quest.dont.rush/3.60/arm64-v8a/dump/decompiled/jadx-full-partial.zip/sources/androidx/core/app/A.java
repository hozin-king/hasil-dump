package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class A {

    /* renamed from: a, reason: collision with root package name */
    private final String f4086a;

    /* renamed from: b, reason: collision with root package name */
    private final CharSequence f4087b;

    /* renamed from: c, reason: collision with root package name */
    private final CharSequence[] f4088c;

    /* renamed from: d, reason: collision with root package name */
    private final boolean f4089d;

    /* renamed from: e, reason: collision with root package name */
    private final int f4090e;

    /* renamed from: f, reason: collision with root package name */
    private final Bundle f4091f;

    /* renamed from: g, reason: collision with root package name */
    private final Set f4092g;

    static class a {
        static void a(Object obj, Intent intent, Bundle bundle) {
            RemoteInput.addResultsToIntent((RemoteInput[]) obj, intent, bundle);
        }

        public static RemoteInput b(A a5) {
            Set e5;
            RemoteInput.Builder addExtras = new RemoteInput.Builder(a5.j()).setLabel(a5.i()).setChoices(a5.f()).setAllowFreeFormInput(a5.d()).addExtras(a5.h());
            if (Build.VERSION.SDK_INT >= 26 && (e5 = a5.e()) != null) {
                Iterator it = e5.iterator();
                while (it.hasNext()) {
                    b.d(addExtras, (String) it.next(), true);
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                c.b(addExtras, a5.g());
            }
            return addExtras.build();
        }

        static A c(Object obj) {
            Set<String> b5;
            RemoteInput remoteInput = (RemoteInput) obj;
            d a5 = new d(remoteInput.getResultKey()).g(remoteInput.getLabel()).e(remoteInput.getChoices()).d(remoteInput.getAllowFreeFormInput()).a(remoteInput.getExtras());
            if (Build.VERSION.SDK_INT >= 26 && (b5 = b.b(remoteInput)) != null) {
                Iterator<String> it = b5.iterator();
                while (it.hasNext()) {
                    a5.c(it.next(), true);
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                a5.f(c.a(remoteInput));
            }
            return a5.b();
        }

        static Bundle d(Intent intent) {
            return RemoteInput.getResultsFromIntent(intent);
        }
    }

    static class b {
        static void a(A a5, Intent intent, Map<String, Uri> map) {
            RemoteInput.addDataResultToIntent(A.a(a5), intent, map);
        }

        static Set<String> b(Object obj) {
            return ((RemoteInput) obj).getAllowedDataTypes();
        }

        static Map<String, Uri> c(Intent intent, String str) {
            return RemoteInput.getDataResultsFromIntent(intent, str);
        }

        static RemoteInput.Builder d(RemoteInput.Builder builder, String str, boolean z4) {
            return builder.setAllowDataType(str, z4);
        }
    }

    static class c {
        static int a(Object obj) {
            return ((RemoteInput) obj).getEditChoicesBeforeSending();
        }

        static RemoteInput.Builder b(RemoteInput.Builder builder, int i5) {
            return builder.setEditChoicesBeforeSending(i5);
        }
    }

    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        private final String f4093a;

        /* renamed from: d, reason: collision with root package name */
        private CharSequence f4096d;

        /* renamed from: e, reason: collision with root package name */
        private CharSequence[] f4097e;

        /* renamed from: b, reason: collision with root package name */
        private final Set f4094b = new HashSet();

        /* renamed from: c, reason: collision with root package name */
        private final Bundle f4095c = new Bundle();

        /* renamed from: f, reason: collision with root package name */
        private boolean f4098f = true;

        /* renamed from: g, reason: collision with root package name */
        private int f4099g = 0;

        public d(@NonNull String str) {
            if (str == null) {
                throw new IllegalArgumentException("Result key can't be null");
            }
            this.f4093a = str;
        }

        public d a(Bundle bundle) {
            if (bundle != null) {
                this.f4095c.putAll(bundle);
            }
            return this;
        }

        public A b() {
            return new A(this.f4093a, this.f4096d, this.f4097e, this.f4098f, this.f4099g, this.f4095c, this.f4094b);
        }

        public d c(String str, boolean z4) {
            if (z4) {
                this.f4094b.add(str);
                return this;
            }
            this.f4094b.remove(str);
            return this;
        }

        public d d(boolean z4) {
            this.f4098f = z4;
            return this;
        }

        public d e(CharSequence[] charSequenceArr) {
            this.f4097e = charSequenceArr;
            return this;
        }

        public d f(int i5) {
            this.f4099g = i5;
            return this;
        }

        public d g(CharSequence charSequence) {
            this.f4096d = charSequence;
            return this;
        }
    }

    A(String str, CharSequence charSequence, CharSequence[] charSequenceArr, boolean z4, int i5, Bundle bundle, Set<String> set) {
        this.f4086a = str;
        this.f4087b = charSequence;
        this.f4088c = charSequenceArr;
        this.f4089d = z4;
        this.f4090e = i5;
        this.f4091f = bundle;
        this.f4092g = set;
        if (g() == 2 && !d()) {
            throw new IllegalArgumentException("setEditChoicesBeforeSending requires setAllowFreeFormInput");
        }
    }

    static RemoteInput a(A a5) {
        return a.b(a5);
    }

    static RemoteInput[] b(A[] aArr) {
        if (aArr == null) {
            return null;
        }
        RemoteInput[] remoteInputArr = new RemoteInput[aArr.length];
        for (int i5 = 0; i5 < aArr.length; i5++) {
            remoteInputArr[i5] = a(aArr[i5]);
        }
        return remoteInputArr;
    }

    static A c(RemoteInput remoteInput) {
        return a.c(remoteInput);
    }

    public boolean d() {
        return this.f4089d;
    }

    public Set e() {
        return this.f4092g;
    }

    public CharSequence[] f() {
        return this.f4088c;
    }

    public int g() {
        return this.f4090e;
    }

    public Bundle h() {
        return this.f4091f;
    }

    public CharSequence i() {
        return this.f4087b;
    }

    public String j() {
        return this.f4086a;
    }

    public boolean k() {
        if (d()) {
            return false;
        }
        return ((f() != null && f().length != 0) || e() == null || e().isEmpty()) ? false : true;
    }
}
