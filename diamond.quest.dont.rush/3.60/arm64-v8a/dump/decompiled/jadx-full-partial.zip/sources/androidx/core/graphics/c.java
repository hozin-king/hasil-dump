package androidx.core.graphics;

import android.graphics.Paint;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    private static final ThreadLocal f4363a = new ThreadLocal();

    static class a {
        static boolean a(Paint paint, String str) {
            return paint.hasGlyph(str);
        }
    }

    private c() {
    }

    public static boolean a(Paint paint, String str) {
        return a.a(paint, str);
    }
}
