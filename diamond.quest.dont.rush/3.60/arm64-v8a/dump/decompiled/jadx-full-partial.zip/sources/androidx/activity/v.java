package androidx.activity;

/* loaded from: classes.dex */
public abstract /* synthetic */ class v {
    public static /* synthetic */ boolean a(Object obj) {
        return obj != null;
    }
}
