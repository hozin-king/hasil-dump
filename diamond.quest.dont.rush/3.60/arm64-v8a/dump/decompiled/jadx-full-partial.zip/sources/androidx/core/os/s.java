package androidx.core.os;

import android.os.LocaleList;
import java.util.Locale;

/* loaded from: classes.dex */
final class s implements l {

    /* renamed from: a, reason: collision with root package name */
    private final LocaleList f4422a;

    s(Object obj) {
        this.f4422a = r.a(obj);
    }

    @Override // androidx.core.os.l
    public String a() {
        String languageTags;
        languageTags = this.f4422a.toLanguageTags();
        return languageTags;
    }

    public boolean equals(Object obj) {
        boolean equals;
        equals = this.f4422a.equals(((l) obj).getLocaleList());
        return equals;
    }

    @Override // androidx.core.os.l
    public Locale get(int i5) {
        Locale locale;
        locale = this.f4422a.get(i5);
        return locale;
    }

    @Override // androidx.core.os.l
    public Object getLocaleList() {
        return this.f4422a;
    }

    public int hashCode() {
        int hashCode;
        hashCode = this.f4422a.hashCode();
        return hashCode;
    }

    @Override // androidx.core.os.l
    public boolean isEmpty() {
        boolean isEmpty;
        isEmpty = this.f4422a.isEmpty();
        return isEmpty;
    }

    @Override // androidx.core.os.l
    public int size() {
        int size;
        size = this.f4422a.size();
        return size;
    }

    public String toString() {
        String localeList;
        localeList = this.f4422a.toString();
        return localeList;
    }
}
