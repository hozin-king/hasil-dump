package androidx.activity;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public static int f2540a = 2131362674;

    /* renamed from: b, reason: collision with root package name */
    public static int f2541b = 2131362790;

    private y() {
    }
}
