package androidx.appcompat.widget;

/* loaded from: classes.dex */
class Y {

    /* renamed from: a, reason: collision with root package name */
    private int f3604a = 0;

    /* renamed from: b, reason: collision with root package name */
    private int f3605b = 0;

    /* renamed from: c, reason: collision with root package name */
    private int f3606c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    private int f3607d = Integer.MIN_VALUE;

    /* renamed from: e, reason: collision with root package name */
    private int f3608e = 0;

    /* renamed from: f, reason: collision with root package name */
    private int f3609f = 0;

    /* renamed from: g, reason: collision with root package name */
    private boolean f3610g = false;

    /* renamed from: h, reason: collision with root package name */
    private boolean f3611h = false;

    Y() {
    }

    public int a() {
        return this.f3610g ? this.f3604a : this.f3605b;
    }

    public int b() {
        return this.f3604a;
    }

    public int c() {
        return this.f3605b;
    }

    public int d() {
        return this.f3610g ? this.f3605b : this.f3604a;
    }

    public void e(int i5, int i6) {
        this.f3611h = false;
        if (i5 != Integer.MIN_VALUE) {
            this.f3608e = i5;
            this.f3604a = i5;
        }
        if (i6 != Integer.MIN_VALUE) {
            this.f3609f = i6;
            this.f3605b = i6;
        }
    }

    public void f(boolean z4) {
        if (z4 == this.f3610g) {
            return;
        }
        this.f3610g = z4;
        if (!this.f3611h) {
            this.f3604a = this.f3608e;
            this.f3605b = this.f3609f;
            return;
        }
        if (z4) {
            int i5 = this.f3607d;
            if (i5 == Integer.MIN_VALUE) {
                i5 = this.f3608e;
            }
            this.f3604a = i5;
            int i6 = this.f3606c;
            if (i6 == Integer.MIN_VALUE) {
                i6 = this.f3609f;
            }
            this.f3605b = i6;
            return;
        }
        int i7 = this.f3606c;
        if (i7 == Integer.MIN_VALUE) {
            i7 = this.f3608e;
        }
        this.f3604a = i7;
        int i8 = this.f3607d;
        if (i8 == Integer.MIN_VALUE) {
            i8 = this.f3609f;
        }
        this.f3605b = i8;
    }

    public void g(int i5, int i6) {
        this.f3606c = i5;
        this.f3607d = i6;
        this.f3611h = true;
        if (this.f3610g) {
            if (i6 != Integer.MIN_VALUE) {
                this.f3604a = i6;
            }
            if (i5 != Integer.MIN_VALUE) {
                this.f3605b = i5;
                return;
            }
            return;
        }
        if (i5 != Integer.MIN_VALUE) {
            this.f3604a = i5;
        }
        if (i6 != Integer.MIN_VALUE) {
            this.f3605b = i6;
        }
    }
}
