package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import androidx.core.view.C1015b0;

/* renamed from: androidx.appcompat.widget.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C1005y extends C1000t {

    /* renamed from: d, reason: collision with root package name */
    private final SeekBar f3887d;

    /* renamed from: e, reason: collision with root package name */
    private Drawable f3888e;

    /* renamed from: f, reason: collision with root package name */
    private ColorStateList f3889f;

    /* renamed from: g, reason: collision with root package name */
    private PorterDuff.Mode f3890g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f3891h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f3892i;

    C1005y(SeekBar seekBar) {
        super(seekBar);
        this.f3889f = null;
        this.f3890g = null;
        this.f3891h = false;
        this.f3892i = false;
        this.f3887d = seekBar;
    }

    private void f() {
        Drawable drawable = this.f3888e;
        if (drawable != null) {
            if (this.f3891h || this.f3892i) {
                Drawable q5 = androidx.core.graphics.drawable.a.q(drawable.mutate());
                this.f3888e = q5;
                if (this.f3891h) {
                    androidx.core.graphics.drawable.a.n(q5, this.f3889f);
                }
                if (this.f3892i) {
                    androidx.core.graphics.drawable.a.o(this.f3888e, this.f3890g);
                }
                if (this.f3888e.isStateful()) {
                    this.f3888e.setState(this.f3887d.getDrawableState());
                }
            }
        }
    }

    @Override // androidx.appcompat.widget.C1000t
    void c(AttributeSet attributeSet, int i5) {
        super.c(attributeSet, i5);
        g0 u5 = g0.u(this.f3887d.getContext(), attributeSet, f.j.f53966T, i5, 0);
        SeekBar seekBar = this.f3887d;
        C1015b0.b0(seekBar, seekBar.getContext(), f.j.f53966T, attributeSet, u5.q(), i5, 0);
        Drawable g5 = u5.g(f.j.f53970U);
        if (g5 != null) {
            this.f3887d.setThumb(g5);
        }
        j(u5.f(f.j.f53974V));
        if (u5.r(f.j.f53982X)) {
            this.f3890g = M.d(u5.j(f.j.f53982X, -1), this.f3890g);
            this.f3892i = true;
        }
        if (u5.r(f.j.f53978W)) {
            this.f3889f = u5.c(f.j.f53978W);
            this.f3891h = true;
        }
        u5.w();
        f();
    }

    void g(Canvas canvas) {
        if (this.f3888e != null) {
            int max = this.f3887d.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f3888e.getIntrinsicWidth();
                int intrinsicHeight = this.f3888e.getIntrinsicHeight();
                int i5 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i6 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f3888e.setBounds(-i5, -i6, i5, i6);
                float width = ((this.f3887d.getWidth() - this.f3887d.getPaddingLeft()) - this.f3887d.getPaddingRight()) / max;
                int save = canvas.save();
                canvas.translate(this.f3887d.getPaddingLeft(), this.f3887d.getHeight() / 2);
                for (int i7 = 0; i7 <= max; i7++) {
                    this.f3888e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }

    void h() {
        Drawable drawable = this.f3888e;
        if (drawable != null && drawable.isStateful() && drawable.setState(this.f3887d.getDrawableState())) {
            this.f3887d.invalidateDrawable(drawable);
        }
    }

    void i() {
        Drawable drawable = this.f3888e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    void j(Drawable drawable) {
        Drawable drawable2 = this.f3888e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f3888e = drawable;
        if (drawable != null) {
            drawable.setCallback(this.f3887d);
            androidx.core.graphics.drawable.a.l(drawable, this.f3887d.getLayoutDirection());
            if (drawable.isStateful()) {
                drawable.setState(this.f3887d.getDrawableState());
            }
            f();
        }
        this.f3887d.invalidate();
    }
}
