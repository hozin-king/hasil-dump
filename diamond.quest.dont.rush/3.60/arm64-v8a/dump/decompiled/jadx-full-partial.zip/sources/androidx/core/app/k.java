package androidx.core.app;

import android.content.res.Configuration;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    private final boolean f4247a;

    /* renamed from: b, reason: collision with root package name */
    private Configuration f4248b;

    public k(boolean z4) {
        this.f4247a = z4;
    }

    public final boolean a() {
        return this.f4247a;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public k(boolean z4, Configuration newConfig) {
        this(z4);
        C7150s.j(newConfig, "newConfig");
        this.f4248b = newConfig;
    }
}
