package Q2;

/* loaded from: classes6.dex */
public interface a {
}
