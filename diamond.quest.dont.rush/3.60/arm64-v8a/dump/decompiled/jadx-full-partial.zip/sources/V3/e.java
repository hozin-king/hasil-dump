package V3;

/* loaded from: classes8.dex */
public interface e extends a {
}
