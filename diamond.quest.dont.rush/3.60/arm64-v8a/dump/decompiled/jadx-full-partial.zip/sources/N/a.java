package N;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: f, reason: collision with root package name */
    private static final Object f1562f = new Object();

    /* renamed from: g, reason: collision with root package name */
    private static a f1563g;

    /* renamed from: a, reason: collision with root package name */
    private final Context f1564a;

    /* renamed from: b, reason: collision with root package name */
    private final HashMap f1565b = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    private final HashMap f1566c = new HashMap();

    /* renamed from: d, reason: collision with root package name */
    private final ArrayList f1567d = new ArrayList();

    /* renamed from: e, reason: collision with root package name */
    private final Handler f1568e;

    /* renamed from: N.a$a, reason: collision with other inner class name */
    class HandlerC0061a extends Handler {
        HandlerC0061a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                super.handleMessage(message);
            } else {
                a.this.a();
            }
        }
    }

    private static final class b {

        /* renamed from: a, reason: collision with root package name */
        final Intent f1570a;

        /* renamed from: b, reason: collision with root package name */
        final ArrayList f1571b;

        b(Intent intent, ArrayList arrayList) {
            this.f1570a = intent;
            this.f1571b = arrayList;
        }
    }

    private static final class c {

        /* renamed from: a, reason: collision with root package name */
        final IntentFilter f1572a;

        /* renamed from: b, reason: collision with root package name */
        final BroadcastReceiver f1573b;

        /* renamed from: c, reason: collision with root package name */
        boolean f1574c;

        /* renamed from: d, reason: collision with root package name */
        boolean f1575d;

        c(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.f1572a = intentFilter;
            this.f1573b = broadcastReceiver;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("Receiver{");
            sb.append(this.f1573b);
            sb.append(" filter=");
            sb.append(this.f1572a);
            if (this.f1575d) {
                sb.append(" DEAD");
            }
            sb.append("}");
            return sb.toString();
        }
    }

    private a(Context context) {
        this.f1564a = context;
        this.f1568e = new HandlerC0061a(context.getMainLooper());
    }

    public static a b(Context context) {
        a aVar;
        synchronized (f1562f) {
            try {
                if (f1563g == null) {
                    f1563g = new a(context.getApplicationContext());
                }
                aVar = f1563g;
            } catch (Throwable th) {
                throw th;
            }
        }
        return aVar;
    }

    void a() {
        int size;
        b[] bVarArr;
        while (true) {
            synchronized (this.f1565b) {
                try {
                    size = this.f1567d.size();
                    if (size <= 0) {
                        return;
                    }
                    bVarArr = new b[size];
                    this.f1567d.toArray(bVarArr);
                    this.f1567d.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
            for (int i5 = 0; i5 < size; i5++) {
                b bVar = bVarArr[i5];
                int size2 = bVar.f1571b.size();
                for (int i6 = 0; i6 < size2; i6++) {
                    c cVar = (c) bVar.f1571b.get(i6);
                    if (!cVar.f1575d) {
                        cVar.f1573b.onReceive(this.f1564a, bVar.f1570a);
                    }
                }
            }
        }
    }

    public void c(BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        synchronized (this.f1565b) {
            try {
                c cVar = new c(intentFilter, broadcastReceiver);
                ArrayList arrayList = (ArrayList) this.f1565b.get(broadcastReceiver);
                if (arrayList == null) {
                    arrayList = new ArrayList(1);
                    this.f1565b.put(broadcastReceiver, arrayList);
                }
                arrayList.add(cVar);
                for (int i5 = 0; i5 < intentFilter.countActions(); i5++) {
                    String action = intentFilter.getAction(i5);
                    ArrayList arrayList2 = (ArrayList) this.f1566c.get(action);
                    if (arrayList2 == null) {
                        arrayList2 = new ArrayList(1);
                        this.f1566c.put(action, arrayList2);
                    }
                    arrayList2.add(cVar);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean d(Intent intent) {
        String str;
        synchronized (this.f1565b) {
            try {
                String action = intent.getAction();
                String resolveTypeIfNeeded = intent.resolveTypeIfNeeded(this.f1564a.getContentResolver());
                Uri data = intent.getData();
                String scheme = intent.getScheme();
                Set<String> categories = intent.getCategories();
                boolean z4 = (intent.getFlags() & 8) != 0;
                if (z4) {
                    Log.v("LocalBroadcastManager", "Resolving type " + resolveTypeIfNeeded + " scheme " + scheme + " of intent " + intent);
                }
                ArrayList arrayList = (ArrayList) this.f1566c.get(intent.getAction());
                if (arrayList != null) {
                    if (z4) {
                        Log.v("LocalBroadcastManager", "Action list: " + arrayList);
                    }
                    ArrayList arrayList2 = null;
                    int i5 = 0;
                    while (i5 < arrayList.size()) {
                        c cVar = (c) arrayList.get(i5);
                        if (z4) {
                            Log.v("LocalBroadcastManager", "Matching against filter " + cVar.f1572a);
                        }
                        if (cVar.f1574c) {
                            if (z4) {
                                Log.v("LocalBroadcastManager", "  Filter's target already added");
                            }
                            str = action;
                        } else {
                            int match = cVar.f1572a.match(action, resolveTypeIfNeeded, scheme, data, categories, "LocalBroadcastManager");
                            if (match >= 0) {
                                if (z4) {
                                    StringBuilder sb = new StringBuilder();
                                    str = action;
                                    sb.append("  Filter matched!  match=0x");
                                    sb.append(Integer.toHexString(match));
                                    Log.v("LocalBroadcastManager", sb.toString());
                                } else {
                                    str = action;
                                }
                                if (arrayList2 == null) {
                                    arrayList2 = new ArrayList();
                                }
                                arrayList2.add(cVar);
                                cVar.f1574c = true;
                            } else {
                                str = action;
                                if (z4) {
                                    Log.v("LocalBroadcastManager", "  Filter did not match: " + (match != -4 ? match != -3 ? match != -2 ? match != -1 ? "unknown reason" : "type" : "data" : "action" : "category"));
                                }
                            }
                        }
                        i5++;
                        action = str;
                    }
                    if (arrayList2 != null) {
                        for (int i6 = 0; i6 < arrayList2.size(); i6++) {
                            ((c) arrayList2.get(i6)).f1574c = false;
                        }
                        this.f1567d.add(new b(intent, arrayList2));
                        if (!this.f1568e.hasMessages(1)) {
                            this.f1568e.sendEmptyMessage(1);
                        }
                        return true;
                    }
                }
                return false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void e(BroadcastReceiver broadcastReceiver) {
        synchronized (this.f1565b) {
            try {
                ArrayList arrayList = (ArrayList) this.f1565b.remove(broadcastReceiver);
                if (arrayList == null) {
                    return;
                }
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    c cVar = (c) arrayList.get(size);
                    cVar.f1575d = true;
                    for (int i5 = 0; i5 < cVar.f1572a.countActions(); i5++) {
                        String action = cVar.f1572a.getAction(i5);
                        ArrayList arrayList2 = (ArrayList) this.f1566c.get(action);
                        if (arrayList2 != null) {
                            for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
                                c cVar2 = (c) arrayList2.get(size2);
                                if (cVar2.f1573b == broadcastReceiver) {
                                    cVar2.f1575d = true;
                                    arrayList2.remove(size2);
                                }
                            }
                            if (arrayList2.size() <= 0) {
                                this.f1566c.remove(action);
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
