package K3;

import kotlin.jvm.internal.C7150s;

/* renamed from: K3.a, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public final class C0941a {

    /* renamed from: a, reason: collision with root package name */
    private final U3.q f1377a;

    public C0941a(U3.q block) {
        C7150s.j(block, "block");
        this.f1377a = block;
    }

    public final U3.q a() {
        return this.f1377a;
    }
}
