package K3;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class E implements Comparable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1369c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final short f1370b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    private /* synthetic */ E(short s5) {
        this.f1370b = s5;
    }

    public static final /* synthetic */ E a(short s5) {
        return new E(s5);
    }

    public static boolean c(short s5, Object obj) {
        return (obj instanceof E) && s5 == ((E) obj).g();
    }

    public static String f(short s5) {
        return String.valueOf(s5 & 65535);
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return C7150s.k(g() & 65535, ((E) obj).g() & 65535);
    }

    public boolean equals(Object obj) {
        return c(this.f1370b, obj);
    }

    public final /* synthetic */ short g() {
        return this.f1370b;
    }

    public int hashCode() {
        return e(this.f1370b);
    }

    public String toString() {
        return f(this.f1370b);
    }

    public static short b(short s5) {
        return s5;
    }

    public static int e(short s5) {
        return s5;
    }
}
