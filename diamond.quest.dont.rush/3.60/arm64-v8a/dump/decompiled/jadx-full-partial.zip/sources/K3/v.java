package K3;

import java.io.Serializable;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class v implements Serializable {

    /* renamed from: b, reason: collision with root package name */
    private final Object f1402b;

    /* renamed from: c, reason: collision with root package name */
    private final Object f1403c;

    /* renamed from: d, reason: collision with root package name */
    private final Object f1404d;

    public v(Object obj, Object obj2, Object obj3) {
        this.f1402b = obj;
        this.f1403c = obj2;
        this.f1404d = obj3;
    }

    public final Object a() {
        return this.f1402b;
    }

    public final Object b() {
        return this.f1403c;
    }

    public final Object c() {
        return this.f1404d;
    }

    public final Object d() {
        return this.f1402b;
    }

    public final Object e() {
        return this.f1403c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof v)) {
            return false;
        }
        v vVar = (v) obj;
        return C7150s.e(this.f1402b, vVar.f1402b) && C7150s.e(this.f1403c, vVar.f1403c) && C7150s.e(this.f1404d, vVar.f1404d);
    }

    public final Object f() {
        return this.f1404d;
    }

    public int hashCode() {
        Object obj = this.f1402b;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f1403c;
        int hashCode2 = (hashCode + (obj2 == null ? 0 : obj2.hashCode())) * 31;
        Object obj3 = this.f1404d;
        return hashCode2 + (obj3 != null ? obj3.hashCode() : 0);
    }

    public String toString() {
        return '(' + this.f1402b + ", " + this.f1403c + ", " + this.f1404d + ')';
    }
}
