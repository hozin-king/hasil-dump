package K3;

import java.io.Serializable;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
final class u implements InterfaceC0950j, Serializable {

    /* renamed from: b, reason: collision with root package name */
    private U3.a f1399b;

    /* renamed from: c, reason: collision with root package name */
    private volatile Object f1400c;

    /* renamed from: d, reason: collision with root package name */
    private final Object f1401d;

    public u(U3.a initializer, Object obj) {
        C7150s.j(initializer, "initializer");
        this.f1399b = initializer;
        this.f1400c = D.f1368a;
        this.f1401d = obj == null ? this : obj;
    }

    private final Object writeReplace() {
        return new C0948h(getValue());
    }

    @Override // K3.InterfaceC0950j
    public Object getValue() {
        Object obj;
        Object obj2 = this.f1400c;
        D d5 = D.f1368a;
        if (obj2 != d5) {
            return obj2;
        }
        synchronized (this.f1401d) {
            obj = this.f1400c;
            if (obj == d5) {
                U3.a aVar = this.f1399b;
                C7150s.g(aVar);
                obj = aVar.invoke();
                this.f1400c = obj;
                this.f1399b = null;
            }
        }
        return obj;
    }

    @Override // K3.InterfaceC0950j
    public boolean isInitialized() {
        return this.f1400c != D.f1368a;
    }

    public String toString() {
        return isInitialized() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }

    public /* synthetic */ u(U3.a aVar, Object obj, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this(aVar, (i5 & 2) != 0 ? null : obj);
    }
}
