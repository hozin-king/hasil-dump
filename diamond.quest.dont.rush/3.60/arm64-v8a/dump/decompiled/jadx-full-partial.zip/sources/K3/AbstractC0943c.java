package K3;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* renamed from: K3.c, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public abstract class AbstractC0943c {
    public /* synthetic */ AbstractC0943c(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    public abstract Object a(Object obj, O3.d dVar);

    private AbstractC0943c() {
    }
}
