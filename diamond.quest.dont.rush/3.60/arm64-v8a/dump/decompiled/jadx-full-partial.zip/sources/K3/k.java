package K3;

/* loaded from: classes8.dex */
public final class k extends m {
    private k() {
    }
}
