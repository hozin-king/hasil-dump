package K3;

/* loaded from: classes8.dex */
public final class H {

    /* renamed from: a, reason: collision with root package name */
    public static final H f1374a = new H();

    private H() {
    }

    public String toString() {
        return "kotlin.Unit";
    }
}
