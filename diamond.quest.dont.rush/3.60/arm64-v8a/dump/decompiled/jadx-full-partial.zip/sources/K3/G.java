package K3;

/* loaded from: classes8.dex */
public final class G extends RuntimeException {
    public G() {
    }

    public G(String str) {
        super(str);
    }

    public G(String str, Throwable th) {
        super(str, th);
    }

    public G(Throwable th) {
        super(th);
    }
}
