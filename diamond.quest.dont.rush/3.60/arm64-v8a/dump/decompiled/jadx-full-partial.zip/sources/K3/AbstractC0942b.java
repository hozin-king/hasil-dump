package K3;

import K3.r;
import kotlin.jvm.internal.C7150s;

/* renamed from: K3.b, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public abstract class AbstractC0942b {

    /* renamed from: a, reason: collision with root package name */
    private static final Object f1378a;

    static {
        r.a aVar = r.f1391c;
        f1378a = r.b(kotlin.coroutines.intrinsics.b.f());
    }

    public static final Object b(C0941a c0941a, Object obj) {
        C7150s.j(c0941a, "<this>");
        return new C0944d(c0941a.a(), obj).b();
    }
}
