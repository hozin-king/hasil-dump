package K3;

import java.io.Serializable;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class r implements Serializable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1391c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final Object f1392b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public static final class b implements Serializable {

        /* renamed from: b, reason: collision with root package name */
        public final Throwable f1393b;

        public b(Throwable exception) {
            C7150s.j(exception, "exception");
            this.f1393b = exception;
        }

        public boolean equals(Object obj) {
            return (obj instanceof b) && C7150s.e(this.f1393b, ((b) obj).f1393b);
        }

        public int hashCode() {
            return this.f1393b.hashCode();
        }

        public String toString() {
            return "Failure(" + this.f1393b + ')';
        }
    }

    private /* synthetic */ r(Object obj) {
        this.f1392b = obj;
    }

    public static final /* synthetic */ r a(Object obj) {
        return new r(obj);
    }

    public static boolean c(Object obj, Object obj2) {
        return (obj2 instanceof r) && C7150s.e(obj, ((r) obj2).j());
    }

    public static final boolean d(Object obj, Object obj2) {
        return C7150s.e(obj, obj2);
    }

    public static final Throwable e(Object obj) {
        if (obj instanceof b) {
            return ((b) obj).f1393b;
        }
        return null;
    }

    public static int f(Object obj) {
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public static final boolean g(Object obj) {
        return obj instanceof b;
    }

    public static final boolean h(Object obj) {
        return !(obj instanceof b);
    }

    public static String i(Object obj) {
        if (obj instanceof b) {
            return ((b) obj).toString();
        }
        return "Success(" + obj + ')';
    }

    public boolean equals(Object obj) {
        return c(this.f1392b, obj);
    }

    public int hashCode() {
        return f(this.f1392b);
    }

    public final /* synthetic */ Object j() {
        return this.f1392b;
    }

    public String toString() {
        return i(this.f1392b);
    }

    public static Object b(Object obj) {
        return obj;
    }
}
