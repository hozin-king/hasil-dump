package K3;

/* renamed from: K3.e, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public final class C0945e extends AbstractC0946f {
    private C0945e() {
    }
}
