package K3;

import java.io.Serializable;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class I implements InterfaceC0950j, Serializable {

    /* renamed from: b, reason: collision with root package name */
    private U3.a f1375b;

    /* renamed from: c, reason: collision with root package name */
    private Object f1376c;

    public I(U3.a initializer) {
        C7150s.j(initializer, "initializer");
        this.f1375b = initializer;
        this.f1376c = D.f1368a;
    }

    private final Object writeReplace() {
        return new C0948h(getValue());
    }

    @Override // K3.InterfaceC0950j
    public Object getValue() {
        if (this.f1376c == D.f1368a) {
            U3.a aVar = this.f1375b;
            C7150s.g(aVar);
            this.f1376c = aVar.invoke();
            this.f1375b = null;
        }
        return this.f1376c;
    }

    @Override // K3.InterfaceC0950j
    public boolean isInitialized() {
        return this.f1376c != D.f1368a;
    }

    public String toString() {
        return isInitialized() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
