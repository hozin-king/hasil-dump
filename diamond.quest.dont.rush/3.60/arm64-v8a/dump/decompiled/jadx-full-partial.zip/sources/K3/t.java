package K3;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
final class t implements InterfaceC0950j, Serializable {

    /* renamed from: e, reason: collision with root package name */
    public static final a f1394e = new a(null);

    /* renamed from: f, reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f1395f = AtomicReferenceFieldUpdater.newUpdater(t.class, Object.class, "c");

    /* renamed from: b, reason: collision with root package name */
    private volatile U3.a f1396b;

    /* renamed from: c, reason: collision with root package name */
    private volatile Object f1397c;

    /* renamed from: d, reason: collision with root package name */
    private final Object f1398d;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public t(U3.a initializer) {
        C7150s.j(initializer, "initializer");
        this.f1396b = initializer;
        D d5 = D.f1368a;
        this.f1397c = d5;
        this.f1398d = d5;
    }

    private final Object writeReplace() {
        return new C0948h(getValue());
    }

    @Override // K3.InterfaceC0950j
    public Object getValue() {
        Object obj = this.f1397c;
        D d5 = D.f1368a;
        if (obj != d5) {
            return obj;
        }
        U3.a aVar = this.f1396b;
        if (aVar != null) {
            Object invoke = aVar.invoke();
            if (androidx.concurrent.futures.b.a(f1395f, this, d5, invoke)) {
                this.f1396b = null;
                return invoke;
            }
        }
        return this.f1397c;
    }

    @Override // K3.InterfaceC0950j
    public boolean isInitialized() {
        return this.f1397c != D.f1368a;
    }

    public String toString() {
        return isInitialized() ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}
