package K3;

import java.io.PrintWriter;
import java.io.StringWriter;
import kotlin.jvm.internal.C7150s;

/* JADX INFO: Access modifiers changed from: package-private */
/* renamed from: K3.f, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public abstract class AbstractC0946f {
    public static void a(Throwable th, Throwable exception) {
        C7150s.j(th, "<this>");
        C7150s.j(exception, "exception");
        if (th != exception) {
            Q3.b.f1693a.a(th, exception);
        }
    }

    public static String b(Throwable th) {
        C7150s.j(th, "<this>");
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        printWriter.flush();
        String stringWriter2 = stringWriter.toString();
        C7150s.i(stringWriter2, "toString(...)");
        return stringWriter2;
    }
}
