package K3;

/* loaded from: classes8.dex */
public abstract class w {
    public static final q a(Object obj, Object obj2) {
        return new q(obj, obj2);
    }
}
