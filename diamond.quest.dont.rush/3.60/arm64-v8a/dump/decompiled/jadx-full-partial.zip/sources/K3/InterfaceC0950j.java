package K3;

/* renamed from: K3.j, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public interface InterfaceC0950j {
    Object getValue();

    boolean isInitialized();
}
