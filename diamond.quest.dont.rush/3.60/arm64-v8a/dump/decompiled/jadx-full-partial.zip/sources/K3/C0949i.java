package K3;

/* renamed from: K3.i, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public final class C0949i extends RuntimeException {
    public C0949i() {
    }

    public C0949i(String str) {
        super(str);
    }

    public C0949i(String str, Throwable th) {
        super(str, th);
    }

    public C0949i(Throwable th) {
        super(th);
    }
}
