package K3;

/* loaded from: classes8.dex */
public final class D {

    /* renamed from: a, reason: collision with root package name */
    public static final D f1368a = new D();

    private D() {
    }
}
