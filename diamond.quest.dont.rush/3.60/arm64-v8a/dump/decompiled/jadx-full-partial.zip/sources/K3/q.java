package K3;

import java.io.Serializable;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public final class q implements Serializable {

    /* renamed from: b, reason: collision with root package name */
    private final Object f1389b;

    /* renamed from: c, reason: collision with root package name */
    private final Object f1390c;

    public q(Object obj, Object obj2) {
        this.f1389b = obj;
        this.f1390c = obj2;
    }

    public final Object a() {
        return this.f1389b;
    }

    public final Object b() {
        return this.f1390c;
    }

    public final Object c() {
        return this.f1389b;
    }

    public final Object d() {
        return this.f1390c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return C7150s.e(this.f1389b, qVar.f1389b) && C7150s.e(this.f1390c, qVar.f1390c);
    }

    public int hashCode() {
        Object obj = this.f1389b;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f1390c;
        return hashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public String toString() {
        return '(' + this.f1389b + ", " + this.f1390c + ')';
    }
}
