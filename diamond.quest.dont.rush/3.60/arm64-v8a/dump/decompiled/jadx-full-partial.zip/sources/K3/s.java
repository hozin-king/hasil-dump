package K3;

import K3.r;
import kotlin.jvm.internal.C7150s;

/* loaded from: classes8.dex */
public abstract class s {
    public static final Object a(Throwable exception) {
        C7150s.j(exception, "exception");
        return new r.b(exception);
    }

    public static final void b(Object obj) {
        if (obj instanceof r.b) {
            throw ((r.b) obj).f1393b;
        }
    }
}
