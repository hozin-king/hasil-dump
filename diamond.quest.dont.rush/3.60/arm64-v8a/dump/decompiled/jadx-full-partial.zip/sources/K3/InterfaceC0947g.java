package K3;

/* renamed from: K3.g, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public interface InterfaceC0947g {
}
