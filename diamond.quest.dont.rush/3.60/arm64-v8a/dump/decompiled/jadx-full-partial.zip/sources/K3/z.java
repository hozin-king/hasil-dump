package K3;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class z implements Comparable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1410c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final int f1411b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    private /* synthetic */ z(int i5) {
        this.f1411b = i5;
    }

    public static final /* synthetic */ z a(int i5) {
        return new z(i5);
    }

    public static boolean c(int i5, Object obj) {
        return (obj instanceof z) && i5 == ((z) obj).g();
    }

    public static String f(int i5) {
        return String.valueOf(i5 & 4294967295L);
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return J.a(g(), ((z) obj).g());
    }

    public boolean equals(Object obj) {
        return c(this.f1411b, obj);
    }

    public final /* synthetic */ int g() {
        return this.f1411b;
    }

    public int hashCode() {
        return e(this.f1411b);
    }

    public String toString() {
        return f(this.f1411b);
    }

    public static int b(int i5) {
        return i5;
    }

    public static int e(int i5) {
        return i5;
    }
}
