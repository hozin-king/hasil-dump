package K3;

/* loaded from: classes8.dex */
public class o extends RuntimeException {
    public o() {
    }

    public o(String str) {
        super(str);
    }

    public o(String str, Throwable th) {
        super(str, th);
    }

    public o(Throwable th) {
        super(th);
    }
}
