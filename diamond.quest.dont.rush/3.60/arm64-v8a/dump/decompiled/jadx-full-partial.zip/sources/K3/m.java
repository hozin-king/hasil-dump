package K3;

/* loaded from: classes8.dex */
abstract class m extends l {
}
