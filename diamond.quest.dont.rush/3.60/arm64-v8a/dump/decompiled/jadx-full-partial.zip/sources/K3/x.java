package K3;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class x implements Comparable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1405c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final byte f1406b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    private /* synthetic */ x(byte b5) {
        this.f1406b = b5;
    }

    public static final /* synthetic */ x a(byte b5) {
        return new x(b5);
    }

    public static boolean c(byte b5, Object obj) {
        return (obj instanceof x) && b5 == ((x) obj).g();
    }

    public static String f(byte b5) {
        return String.valueOf(b5 & 255);
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return C7150s.k(g() & 255, ((x) obj).g() & 255);
    }

    public boolean equals(Object obj) {
        return c(this.f1406b, obj);
    }

    public final /* synthetic */ byte g() {
        return this.f1406b;
    }

    public int hashCode() {
        return e(this.f1406b);
    }

    public String toString() {
        return f(this.f1406b);
    }

    public static byte b(byte b5) {
        return b5;
    }

    public static int e(byte b5) {
        return b5;
    }
}
