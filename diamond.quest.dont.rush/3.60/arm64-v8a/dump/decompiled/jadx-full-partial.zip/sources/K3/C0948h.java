package K3;

import java.io.Serializable;

/* renamed from: K3.h, reason: case insensitive filesystem */
/* loaded from: classes8.dex */
public final class C0948h implements InterfaceC0950j, Serializable {

    /* renamed from: b, reason: collision with root package name */
    private final Object f1383b;

    public C0948h(Object obj) {
        this.f1383b = obj;
    }

    @Override // K3.InterfaceC0950j
    public Object getValue() {
        return this.f1383b;
    }

    @Override // K3.InterfaceC0950j
    public boolean isInitialized() {
        return true;
    }

    public String toString() {
        return String.valueOf(getValue());
    }
}
