package K3;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes8.dex */
public final class n {

    /* renamed from: b, reason: collision with root package name */
    public static final n f1384b = new n("SYNCHRONIZED", 0);

    /* renamed from: c, reason: collision with root package name */
    public static final n f1385c = new n("PUBLICATION", 1);

    /* renamed from: d, reason: collision with root package name */
    public static final n f1386d = new n("NONE", 2);

    /* renamed from: e, reason: collision with root package name */
    private static final /* synthetic */ n[] f1387e;

    /* renamed from: f, reason: collision with root package name */
    private static final /* synthetic */ P3.a f1388f;

    static {
        n[] a5 = a();
        f1387e = a5;
        f1388f = P3.b.a(a5);
    }

    private n(String str, int i5) {
    }

    private static final /* synthetic */ n[] a() {
        return new n[]{f1384b, f1385c, f1386d};
    }

    public static n valueOf(String str) {
        return (n) Enum.valueOf(n.class, str);
    }

    public static n[] values() {
        return (n[]) f1387e.clone();
    }
}
