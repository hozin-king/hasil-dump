package K3;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes8.dex */
public final class B implements Comparable {

    /* renamed from: c, reason: collision with root package name */
    public static final a f1363c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final long f1364b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    private /* synthetic */ B(long j5) {
        this.f1364b = j5;
    }

    public static final /* synthetic */ B a(long j5) {
        return new B(j5);
    }

    public static boolean c(long j5, Object obj) {
        return (obj instanceof B) && j5 == ((B) obj).g();
    }

    public static int e(long j5) {
        return androidx.privacysandbox.ads.adservices.topics.j.a(j5);
    }

    public static String f(long j5) {
        return J.c(j5);
    }

    @Override // java.lang.Comparable
    public /* bridge */ /* synthetic */ int compareTo(Object obj) {
        return J.b(g(), ((B) obj).g());
    }

    public boolean equals(Object obj) {
        return c(this.f1364b, obj);
    }

    public final /* synthetic */ long g() {
        return this.f1364b;
    }

    public int hashCode() {
        return e(this.f1364b);
    }

    public String toString() {
        return f(this.f1364b);
    }

    public static long b(long j5) {
        return j5;
    }
}
