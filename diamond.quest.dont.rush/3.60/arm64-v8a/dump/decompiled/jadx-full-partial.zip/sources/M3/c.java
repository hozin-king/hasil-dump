package M3;

import K3.A;
import K3.C;
import K3.F;
import K3.y;
import com.ironsource.b9;
import kotlin.collections.C7123p;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes8.dex */
public abstract class c extends b {
    public static String a(byte[] bArr) {
        String n02;
        return (bArr == null || (n02 = C7123p.n0(y.a(bArr), ", ", b9.i.f26268d, b9.i.f26270e, 0, null, null, 56, null)) == null) ? "null" : n02;
    }

    public static String b(int[] iArr) {
        String n02;
        return (iArr == null || (n02 = C7123p.n0(A.a(iArr), ", ", b9.i.f26268d, b9.i.f26270e, 0, null, null, 56, null)) == null) ? "null" : n02;
    }

    public static String c(short[] sArr) {
        String n02;
        return (sArr == null || (n02 = C7123p.n0(F.a(sArr), ", ", b9.i.f26268d, b9.i.f26270e, 0, null, null, 56, null)) == null) ? "null" : n02;
    }

    public static String d(long[] jArr) {
        String n02;
        return (jArr == null || (n02 = C7123p.n0(C.a(jArr), ", ", b9.i.f26268d, b9.i.f26270e, 0, null, null, 56, null)) == null) ? "null" : n02;
    }
}
