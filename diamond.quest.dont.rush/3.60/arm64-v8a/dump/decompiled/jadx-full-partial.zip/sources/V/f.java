package V;

import android.database.Cursor;
import androidx.annotation.NonNull;
import com.google.firebase.messaging.Constants;
import com.ironsource.cc;
import j$.util.DesugarCollections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/* loaded from: classes.dex */
public class f {

    /* renamed from: a, reason: collision with root package name */
    public final String f1871a;

    /* renamed from: b, reason: collision with root package name */
    public final Map f1872b;

    /* renamed from: c, reason: collision with root package name */
    public final Set f1873c;

    /* renamed from: d, reason: collision with root package name */
    public final Set f1874d;

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final String f1875a;

        /* renamed from: b, reason: collision with root package name */
        public final String f1876b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1877c;

        /* renamed from: d, reason: collision with root package name */
        public final boolean f1878d;

        /* renamed from: e, reason: collision with root package name */
        public final int f1879e;

        /* renamed from: f, reason: collision with root package name */
        public final String f1880f;

        /* renamed from: g, reason: collision with root package name */
        private final int f1881g;

        @Deprecated
        public a(String str, String str2, boolean z4, int i5) {
            this(str, str2, z4, i5, null, 0);
        }

        private static int a(String str) {
            if (str == null) {
                return 5;
            }
            String upperCase = str.toUpperCase(Locale.US);
            if (upperCase.contains("INT")) {
                return 3;
            }
            if (upperCase.contains("CHAR") || upperCase.contains("CLOB") || upperCase.contains("TEXT")) {
                return 2;
            }
            if (upperCase.contains("BLOB")) {
                return 5;
            }
            return (upperCase.contains("REAL") || upperCase.contains("FLOA") || upperCase.contains("DOUB")) ? 4 : 1;
        }

        public boolean equals(Object obj) {
            String str;
            String str2;
            String str3;
            if (this == obj) {
                return true;
            }
            if (obj != null && getClass() == obj.getClass()) {
                a aVar = (a) obj;
                if (this.f1879e != aVar.f1879e || !this.f1875a.equals(aVar.f1875a) || this.f1878d != aVar.f1878d) {
                    return false;
                }
                if (this.f1881g == 1 && aVar.f1881g == 2 && (str3 = this.f1880f) != null && !str3.equals(aVar.f1880f)) {
                    return false;
                }
                if (this.f1881g == 2 && aVar.f1881g == 1 && (str2 = aVar.f1880f) != null && !str2.equals(this.f1880f)) {
                    return false;
                }
                int i5 = this.f1881g;
                if ((i5 == 0 || i5 != aVar.f1881g || ((str = this.f1880f) == null ? aVar.f1880f == null : str.equals(aVar.f1880f))) && this.f1877c == aVar.f1877c) {
                    return true;
                }
            }
            return false;
        }

        public int hashCode() {
            return (((((this.f1875a.hashCode() * 31) + this.f1877c) * 31) + (this.f1878d ? 1231 : 1237)) * 31) + this.f1879e;
        }

        public String toString() {
            return "Column{name='" + this.f1875a + "', type='" + this.f1876b + "', affinity='" + this.f1877c + "', notNull=" + this.f1878d + ", primaryKeyPosition=" + this.f1879e + ", defaultValue='" + this.f1880f + "'}";
        }

        public a(String str, String str2, boolean z4, int i5, String str3, int i6) {
            this.f1875a = str;
            this.f1876b = str2;
            this.f1878d = z4;
            this.f1879e = i5;
            this.f1877c = a(str2);
            this.f1880f = str3;
            this.f1881g = i6;
        }
    }

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public final String f1882a;

        /* renamed from: b, reason: collision with root package name */
        public final String f1883b;

        /* renamed from: c, reason: collision with root package name */
        public final String f1884c;

        /* renamed from: d, reason: collision with root package name */
        public final List f1885d;

        /* renamed from: e, reason: collision with root package name */
        public final List f1886e;

        public b(@NonNull String str, @NonNull String str2, @NonNull String str3, @NonNull List<String> list, @NonNull List<String> list2) {
            this.f1882a = str;
            this.f1883b = str2;
            this.f1884c = str3;
            this.f1885d = DesugarCollections.unmodifiableList(list);
            this.f1886e = DesugarCollections.unmodifiableList(list2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            if (this.f1882a.equals(bVar.f1882a) && this.f1883b.equals(bVar.f1883b) && this.f1884c.equals(bVar.f1884c) && this.f1885d.equals(bVar.f1885d)) {
                return this.f1886e.equals(bVar.f1886e);
            }
            return false;
        }

        public int hashCode() {
            return (((((((this.f1882a.hashCode() * 31) + this.f1883b.hashCode()) * 31) + this.f1884c.hashCode()) * 31) + this.f1885d.hashCode()) * 31) + this.f1886e.hashCode();
        }

        public String toString() {
            return "ForeignKey{referenceTable='" + this.f1882a + "', onDelete='" + this.f1883b + "', onUpdate='" + this.f1884c + "', columnNames=" + this.f1885d + ", referenceColumnNames=" + this.f1886e + '}';
        }
    }

    static class c implements Comparable {

        /* renamed from: b, reason: collision with root package name */
        final int f1887b;

        /* renamed from: c, reason: collision with root package name */
        final int f1888c;

        /* renamed from: d, reason: collision with root package name */
        final String f1889d;

        /* renamed from: e, reason: collision with root package name */
        final String f1890e;

        c(int i5, int i6, String str, String str2) {
            this.f1887b = i5;
            this.f1888c = i6;
            this.f1889d = str;
            this.f1890e = str2;
        }

        @Override // java.lang.Comparable
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compareTo(c cVar) {
            int i5 = this.f1887b - cVar.f1887b;
            return i5 == 0 ? this.f1888c - cVar.f1888c : i5;
        }
    }

    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public final String f1891a;

        /* renamed from: b, reason: collision with root package name */
        public final boolean f1892b;

        /* renamed from: c, reason: collision with root package name */
        public final List f1893c;

        public d(String str, boolean z4, List<String> list) {
            this.f1891a = str;
            this.f1892b = z4;
            this.f1893c = list;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            d dVar = (d) obj;
            if (this.f1892b == dVar.f1892b && this.f1893c.equals(dVar.f1893c)) {
                return this.f1891a.startsWith("index_") ? dVar.f1891a.startsWith("index_") : this.f1891a.equals(dVar.f1891a);
            }
            return false;
        }

        public int hashCode() {
            return ((((this.f1891a.startsWith("index_") ? -1184239155 : this.f1891a.hashCode()) * 31) + (this.f1892b ? 1 : 0)) * 31) + this.f1893c.hashCode();
        }

        public String toString() {
            return "Index{name='" + this.f1891a + "', unique=" + this.f1892b + ", columns=" + this.f1893c + '}';
        }
    }

    public f(String str, Map<String, a> map, Set<b> set, Set<d> set2) {
        this.f1871a = str;
        this.f1872b = DesugarCollections.unmodifiableMap(map);
        this.f1873c = DesugarCollections.unmodifiableSet(set);
        this.f1874d = set2 == null ? null : DesugarCollections.unmodifiableSet(set2);
    }

    public static f a(androidx.sqlite.db.b bVar, String str) {
        return new f(str, b(bVar, str), d(bVar, str), f(bVar, str));
    }

    private static Map b(androidx.sqlite.db.b bVar, String str) {
        Cursor g02 = bVar.g0("PRAGMA table_info(`" + str + "`)");
        HashMap hashMap = new HashMap();
        try {
            if (g02.getColumnCount() > 0) {
                int columnIndex = g02.getColumnIndex("name");
                int columnIndex2 = g02.getColumnIndex("type");
                int columnIndex3 = g02.getColumnIndex("notnull");
                int columnIndex4 = g02.getColumnIndex("pk");
                int columnIndex5 = g02.getColumnIndex("dflt_value");
                while (g02.moveToNext()) {
                    String string = g02.getString(columnIndex);
                    hashMap.put(string, new a(string, g02.getString(columnIndex2), g02.getInt(columnIndex3) != 0, g02.getInt(columnIndex4), g02.getString(columnIndex5), 2));
                }
            }
            return hashMap;
        } finally {
            g02.close();
        }
    }

    private static List c(Cursor cursor) {
        int columnIndex = cursor.getColumnIndex("id");
        int columnIndex2 = cursor.getColumnIndex("seq");
        int columnIndex3 = cursor.getColumnIndex(Constants.MessagePayloadKeys.FROM);
        int columnIndex4 = cursor.getColumnIndex("to");
        int count = cursor.getCount();
        ArrayList arrayList = new ArrayList();
        for (int i5 = 0; i5 < count; i5++) {
            cursor.moveToPosition(i5);
            arrayList.add(new c(cursor.getInt(columnIndex), cursor.getInt(columnIndex2), cursor.getString(columnIndex3), cursor.getString(columnIndex4)));
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    private static Set d(androidx.sqlite.db.b bVar, String str) {
        HashSet hashSet = new HashSet();
        Cursor g02 = bVar.g0("PRAGMA foreign_key_list(`" + str + "`)");
        try {
            int columnIndex = g02.getColumnIndex("id");
            int columnIndex2 = g02.getColumnIndex("seq");
            int columnIndex3 = g02.getColumnIndex(cc.f26436Q);
            int columnIndex4 = g02.getColumnIndex("on_delete");
            int columnIndex5 = g02.getColumnIndex("on_update");
            List<c> c5 = c(g02);
            int count = g02.getCount();
            for (int i5 = 0; i5 < count; i5++) {
                g02.moveToPosition(i5);
                if (g02.getInt(columnIndex2) == 0) {
                    int i6 = g02.getInt(columnIndex);
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (c cVar : c5) {
                        if (cVar.f1887b == i6) {
                            arrayList.add(cVar.f1889d);
                            arrayList2.add(cVar.f1890e);
                        }
                    }
                    hashSet.add(new b(g02.getString(columnIndex3), g02.getString(columnIndex4), g02.getString(columnIndex5), arrayList, arrayList2));
                }
            }
            g02.close();
            return hashSet;
        } catch (Throwable th) {
            g02.close();
            throw th;
        }
    }

    /* JADX WARN: Finally extract failed */
    private static d e(androidx.sqlite.db.b bVar, String str, boolean z4) {
        Cursor g02 = bVar.g0("PRAGMA index_xinfo(`" + str + "`)");
        try {
            int columnIndex = g02.getColumnIndex("seqno");
            int columnIndex2 = g02.getColumnIndex("cid");
            int columnIndex3 = g02.getColumnIndex("name");
            if (columnIndex != -1 && columnIndex2 != -1 && columnIndex3 != -1) {
                TreeMap treeMap = new TreeMap();
                while (g02.moveToNext()) {
                    if (g02.getInt(columnIndex2) >= 0) {
                        treeMap.put(Integer.valueOf(g02.getInt(columnIndex)), g02.getString(columnIndex3));
                    }
                }
                ArrayList arrayList = new ArrayList(treeMap.size());
                arrayList.addAll(treeMap.values());
                d dVar = new d(str, z4, arrayList);
                g02.close();
                return dVar;
            }
            g02.close();
            return null;
        } catch (Throwable th) {
            g02.close();
            throw th;
        }
    }

    private static Set f(androidx.sqlite.db.b bVar, String str) {
        Cursor g02 = bVar.g0("PRAGMA index_list(`" + str + "`)");
        try {
            int columnIndex = g02.getColumnIndex("name");
            int columnIndex2 = g02.getColumnIndex("origin");
            int columnIndex3 = g02.getColumnIndex("unique");
            if (columnIndex != -1 && columnIndex2 != -1 && columnIndex3 != -1) {
                HashSet hashSet = new HashSet();
                while (g02.moveToNext()) {
                    if ("c".equals(g02.getString(columnIndex2))) {
                        String string = g02.getString(columnIndex);
                        boolean z4 = true;
                        if (g02.getInt(columnIndex3) != 1) {
                            z4 = false;
                        }
                        d e5 = e(bVar, string, z4);
                        if (e5 == null) {
                            return null;
                        }
                        hashSet.add(e5);
                    }
                }
                return hashSet;
            }
            return null;
        } finally {
            g02.close();
        }
    }

    public boolean equals(Object obj) {
        Set set;
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        f fVar = (f) obj;
        String str = this.f1871a;
        if (str == null ? fVar.f1871a != null : !str.equals(fVar.f1871a)) {
            return false;
        }
        Map map = this.f1872b;
        if (map == null ? fVar.f1872b != null : !map.equals(fVar.f1872b)) {
            return false;
        }
        Set set2 = this.f1873c;
        if (set2 == null ? fVar.f1873c != null : !set2.equals(fVar.f1873c)) {
            return false;
        }
        Set set3 = this.f1874d;
        if (set3 == null || (set = fVar.f1874d) == null) {
            return true;
        }
        return set3.equals(set);
    }

    public int hashCode() {
        String str = this.f1871a;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Map map = this.f1872b;
        int hashCode2 = (hashCode + (map != null ? map.hashCode() : 0)) * 31;
        Set set = this.f1873c;
        return hashCode2 + (set != null ? set.hashCode() : 0);
    }

    public String toString() {
        return "TableInfo{name='" + this.f1871a + "', columns=" + this.f1872b + ", foreignKeys=" + this.f1873c + ", indices=" + this.f1874d + '}';
    }

    public f(String str, Map<String, a> map, Set<b> set) {
        this(str, map, set, Collections.EMPTY_SET);
    }
}
