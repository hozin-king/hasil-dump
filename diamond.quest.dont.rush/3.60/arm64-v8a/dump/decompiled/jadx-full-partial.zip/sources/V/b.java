package V;

import android.database.Cursor;
import android.database.MatrixCursor;

/* loaded from: classes.dex */
public class b {
    private b() {
    }

    public static Cursor a(Cursor cursor) {
        try {
            MatrixCursor matrixCursor = new MatrixCursor(cursor.getColumnNames(), cursor.getCount());
            while (cursor.moveToNext()) {
                Object[] objArr = new Object[cursor.getColumnCount()];
                for (int i5 = 0; i5 < cursor.getColumnCount(); i5++) {
                    int type = cursor.getType(i5);
                    if (type == 0) {
                        objArr[i5] = null;
                    } else if (type == 1) {
                        objArr[i5] = Long.valueOf(cursor.getLong(i5));
                    } else if (type == 2) {
                        objArr[i5] = Double.valueOf(cursor.getDouble(i5));
                    } else if (type == 3) {
                        objArr[i5] = cursor.getString(i5);
                    } else {
                        if (type != 4) {
                            throw new IllegalStateException();
                        }
                        objArr[i5] = cursor.getBlob(i5);
                    }
                }
                matrixCursor.addRow(objArr);
            }
            cursor.close();
            return matrixCursor;
        } catch (Throwable th) {
            cursor.close();
            throw th;
        }
    }

    public static int b(Cursor cursor, String str) {
        int columnIndex = cursor.getColumnIndex(str);
        if (columnIndex >= 0) {
            return columnIndex;
        }
        return cursor.getColumnIndexOrThrow("`" + str + "`");
    }
}
