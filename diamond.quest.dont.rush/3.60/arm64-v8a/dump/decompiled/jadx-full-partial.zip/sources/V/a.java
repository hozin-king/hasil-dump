package V;

import androidx.annotation.NonNull;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public class a {

    /* renamed from: e, reason: collision with root package name */
    private static final Map f1865e = new HashMap();

    /* renamed from: a, reason: collision with root package name */
    private final File f1866a;

    /* renamed from: b, reason: collision with root package name */
    private final Lock f1867b;

    /* renamed from: c, reason: collision with root package name */
    private final boolean f1868c;

    /* renamed from: d, reason: collision with root package name */
    private FileChannel f1869d;

    public a(@NonNull String str, @NonNull File file, boolean z4) {
        File file2 = new File(file, str + ".lck");
        this.f1866a = file2;
        this.f1867b = a(file2.getAbsolutePath());
        this.f1868c = z4;
    }

    private static Lock a(String str) {
        Lock lock;
        Map map = f1865e;
        synchronized (map) {
            try {
                lock = (Lock) map.get(str);
                if (lock == null) {
                    lock = new ReentrantLock();
                    map.put(str, lock);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return lock;
    }

    public void b() {
        this.f1867b.lock();
        if (this.f1868c) {
            try {
                FileChannel channel = new FileOutputStream(this.f1866a).getChannel();
                this.f1869d = channel;
                channel.lock();
            } catch (IOException e5) {
                throw new IllegalStateException("Unable to grab copy lock.", e5);
            }
        }
    }

    public void c() {
        FileChannel fileChannel = this.f1869d;
        if (fileChannel != null) {
            try {
                fileChannel.close();
            } catch (IOException unused) {
            }
        }
        this.f1867b.unlock();
    }
}
