package V;

import io.appmetrica.analytics.coreutils.internal.StringUtils;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    public static final String[] f1870a = new String[0];

    private e() {
    }

    public static void a(StringBuilder sb, int i5) {
        for (int i6 = 0; i6 < i5; i6++) {
            sb.append("?");
            if (i6 < i5 - 1) {
                sb.append(StringUtils.COMMA);
            }
        }
    }

    public static StringBuilder b() {
        return new StringBuilder();
    }
}
