package Y0;

import com.ironsource.b9;
import java.io.Serializable;

/* loaded from: classes3.dex */
public final class a implements Serializable {
    private static final long serialVersionUID = 1;

    /* renamed from: b, reason: collision with root package name */
    protected final Class f2001b;

    /* renamed from: c, reason: collision with root package name */
    protected final int f2002c;

    /* renamed from: d, reason: collision with root package name */
    protected String f2003d;

    public a(Class<?> cls) {
        this(cls, null);
    }

    public String a() {
        return this.f2003d;
    }

    public Class b() {
        return this.f2001b;
    }

    public boolean c() {
        return this.f2003d != null;
    }

    public void d(String str) {
        if (str == null || str.length() == 0) {
            str = null;
        }
        this.f2003d = str;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return obj != null && obj.getClass() == a.class && this.f2001b == ((a) obj).f2001b;
    }

    public int hashCode() {
        return this.f2002c;
    }

    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append("[NamedType, class ");
        sb.append(this.f2001b.getName());
        sb.append(", name: ");
        if (this.f2003d == null) {
            str = "null";
        } else {
            str = "'" + this.f2003d + "'";
        }
        sb.append(str);
        sb.append(b9.i.f26270e);
        return sb.toString();
    }

    public a(Class<?> cls, String str) {
        this.f2001b = cls;
        this.f2002c = cls.getName().hashCode();
        d(str);
    }
}
