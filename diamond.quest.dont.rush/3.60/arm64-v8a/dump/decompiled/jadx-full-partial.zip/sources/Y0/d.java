package Y0;

import com.fasterxml.jackson.databind.j;

/* loaded from: classes3.dex */
public interface d {
    String a(Object obj);

    String b();

    j c(com.fasterxml.jackson.databind.e eVar, String str);

    void d(j jVar);

    String e(Object obj, Class cls);

    String f();
}
