package U0;

import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes3.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private final a f1803a;

    /* renamed from: b, reason: collision with root package name */
    private final AtomicReference f1804b;

    /* renamed from: c, reason: collision with root package name */
    private final int f1805c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f1806d;

    /* renamed from: e, reason: collision with root package name */
    private final boolean f1807e;

    /* renamed from: f, reason: collision with root package name */
    private int[] f1808f;

    /* renamed from: g, reason: collision with root package name */
    private int f1809g;

    /* renamed from: h, reason: collision with root package name */
    private int f1810h;

    /* renamed from: i, reason: collision with root package name */
    private int f1811i;

    /* renamed from: j, reason: collision with root package name */
    private int f1812j;

    /* renamed from: k, reason: collision with root package name */
    private int f1813k;

    /* renamed from: l, reason: collision with root package name */
    private String[] f1814l;

    /* renamed from: m, reason: collision with root package name */
    private int f1815m;

    /* renamed from: n, reason: collision with root package name */
    private int f1816n;

    /* renamed from: o, reason: collision with root package name */
    private transient boolean f1817o;

    /* renamed from: p, reason: collision with root package name */
    private boolean f1818p;

    /* renamed from: U0.a$a, reason: collision with other inner class name */
    private static final class C0082a {

        /* renamed from: a, reason: collision with root package name */
        public final int f1819a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1820b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1821c;

        /* renamed from: d, reason: collision with root package name */
        public final int[] f1822d;

        /* renamed from: e, reason: collision with root package name */
        public final String[] f1823e;

        /* renamed from: f, reason: collision with root package name */
        public final int f1824f;

        /* renamed from: g, reason: collision with root package name */
        public final int f1825g;

        public C0082a(int i5, int i6, int i7, int[] iArr, String[] strArr, int i8, int i9) {
            this.f1819a = i5;
            this.f1820b = i6;
            this.f1821c = i7;
            this.f1822d = iArr;
            this.f1823e = strArr;
            this.f1824f = i8;
            this.f1825g = i9;
        }

        public static C0082a a(int i5) {
            int i6 = i5 << 3;
            return new C0082a(i5, 0, a.a(i5), new int[i6], new String[i5 << 1], i6 - i5, i6);
        }
    }

    private a(int i5, boolean z4, int i6, boolean z5) {
        this.f1803a = null;
        this.f1805c = i6;
        this.f1806d = z4;
        this.f1807e = z5;
        int i7 = 16;
        if (i5 >= 16) {
            if (((i5 - 1) & i5) != 0) {
                while (i7 < i5) {
                    i7 += i7;
                }
            }
            this.f1804b = new AtomicReference(C0082a.a(i5));
        }
        i5 = i7;
        this.f1804b = new AtomicReference(C0082a.a(i5));
    }

    static int a(int i5) {
        int i6 = i5 >> 2;
        if (i6 < 64) {
            return 4;
        }
        if (i6 <= 256) {
            return 5;
        }
        return i6 <= 1024 ? 6 : 7;
    }

    private final int b() {
        int i5 = this.f1809g;
        return (i5 << 3) - i5;
    }

    public static a c() {
        long currentTimeMillis = System.currentTimeMillis();
        return d((((int) currentTimeMillis) + ((int) (currentTimeMillis >>> 32))) | 1);
    }

    protected static a d(int i5) {
        return new a(64, true, i5, true);
    }

    public int e() {
        int i5 = this.f1810h;
        int i6 = 0;
        for (int i7 = 3; i7 < i5; i7 += 4) {
            if (this.f1808f[i7] != 0) {
                i6++;
            }
        }
        return i6;
    }

    public int f() {
        int i5 = this.f1811i;
        int i6 = 0;
        for (int i7 = this.f1810h + 3; i7 < i5; i7 += 4) {
            if (this.f1808f[i7] != 0) {
                i6++;
            }
        }
        return i6;
    }

    public int g() {
        return (this.f1815m - b()) >> 2;
    }

    public int h() {
        int i5 = this.f1811i + 3;
        int i6 = this.f1809g + i5;
        int i7 = 0;
        while (i5 < i6) {
            if (this.f1808f[i5] != 0) {
                i7++;
            }
            i5 += 4;
        }
        return i7;
    }

    public int i() {
        int i5 = this.f1809g << 3;
        int i6 = 0;
        for (int i7 = 3; i7 < i5; i7 += 4) {
            if (this.f1808f[i7] != 0) {
                i6++;
            }
        }
        return i6;
    }

    public String toString() {
        int e5 = e();
        int f5 = f();
        int h5 = h();
        int g5 = g();
        return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", a.class.getName(), Integer.valueOf(this.f1813k), Integer.valueOf(this.f1809g), Integer.valueOf(e5), Integer.valueOf(f5), Integer.valueOf(h5), Integer.valueOf(g5), Integer.valueOf(e5 + f5 + h5 + g5), Integer.valueOf(i()));
    }

    private a(a aVar, boolean z4, int i5, boolean z5, C0082a c0082a) {
        this.f1803a = aVar;
        this.f1805c = i5;
        this.f1806d = z4;
        this.f1807e = z5;
        this.f1804b = null;
        this.f1813k = c0082a.f1820b;
        int i6 = c0082a.f1819a;
        this.f1809g = i6;
        int i7 = i6 << 2;
        this.f1810h = i7;
        this.f1811i = i7 + (i7 >> 1);
        this.f1812j = c0082a.f1821c;
        this.f1808f = c0082a.f1822d;
        this.f1814l = c0082a.f1823e;
        this.f1815m = c0082a.f1824f;
        this.f1816n = c0082a.f1825g;
        this.f1817o = false;
        this.f1818p = true;
    }
}
