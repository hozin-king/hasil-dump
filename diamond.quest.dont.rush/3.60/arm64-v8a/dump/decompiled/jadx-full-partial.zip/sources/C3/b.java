package C3;

/* loaded from: classes8.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public String f451a;

    /* renamed from: b, reason: collision with root package name */
    public Object f452b;

    public b(String str) {
        this(str, null);
    }

    public b(String str, Object obj) {
        this.f451a = str;
        this.f452b = obj;
    }
}
