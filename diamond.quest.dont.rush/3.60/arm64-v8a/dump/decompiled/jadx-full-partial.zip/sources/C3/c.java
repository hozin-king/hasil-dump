package C3;

import H3.a;
import com.bytedance.sdk.component.pglcrypt.PglCryptUtils;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes8.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private static final int f453a = String.valueOf(Integer.MAX_VALUE).length();

    /* renamed from: b, reason: collision with root package name */
    private static final Map f454b;

    /* renamed from: c, reason: collision with root package name */
    private static final Map f455c;

    /* renamed from: d, reason: collision with root package name */
    private static C3.b f456d;

    /* renamed from: e, reason: collision with root package name */
    private static a.C0041a f457e;

    class a extends HashMap {
        a() {
            put("open", 0);
            put("close", 1);
            put("ping", 2);
            put("pong", 3);
            put(PglCryptUtils.KEY_MESSAGE, 4);
            put("upgrade", 5);
            put("noop", 6);
        }
    }

    class b implements f {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ StringBuilder f458a;

        b(StringBuilder sb) {
            this.f458a = sb;
        }

        @Override // C3.c.f
        public void call(Object obj) {
            this.f458a.append(c.o((String) obj));
        }
    }

    /* renamed from: C3.c$c, reason: collision with other inner class name */
    class C0018c implements f {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ArrayList f459a;

        C0018c(ArrayList arrayList) {
            this.f459a = arrayList;
        }

        @Override // C3.c.f
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public void call(byte[] bArr) {
            this.f459a.add(bArr);
        }
    }

    class d implements f {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ f f460a;

        d(f fVar) {
            this.f460a = fVar;
        }

        @Override // C3.c.f
        public void call(Object obj) {
            if (obj instanceof String) {
                String str = (String) obj;
                String valueOf = String.valueOf(str.length());
                int length = valueOf.length();
                byte[] bArr = new byte[length + 2];
                bArr[0] = 0;
                int i5 = 0;
                while (i5 < valueOf.length()) {
                    int i6 = i5 + 1;
                    bArr[i6] = (byte) Character.getNumericValue(valueOf.charAt(i5));
                    i5 = i6;
                }
                bArr[length + 1] = -1;
                this.f460a.call(C3.a.a(new byte[][]{bArr, c.p(str)}));
                return;
            }
            byte[] bArr2 = (byte[]) obj;
            String valueOf2 = String.valueOf(bArr2.length);
            int length2 = valueOf2.length();
            byte[] bArr3 = new byte[length2 + 2];
            bArr3[0] = 1;
            int i7 = 0;
            while (i7 < valueOf2.length()) {
                int i8 = i7 + 1;
                bArr3[i8] = (byte) Character.getNumericValue(valueOf2.charAt(i7));
                i7 = i8;
            }
            bArr3[length2 + 1] = -1;
            this.f460a.call(C3.a.a(new byte[][]{bArr3, bArr2}));
        }
    }

    public interface e {
        boolean a(C3.b bVar, int i5, int i6);
    }

    public interface f {
        void call(Object obj);
    }

    static {
        a aVar = new a();
        f454b = aVar;
        f455c = new HashMap();
        Iterator it = aVar.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            f455c.put(entry.getValue(), entry.getKey());
        }
        f456d = new C3.b("error", "parser error");
        a.C0041a c0041a = new a.C0041a();
        f457e = c0041a;
        c0041a.f1008a = false;
    }

    private c() {
    }

    private static String c(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b5 : bArr) {
            sb.appendCodePoint(b5 & 255);
        }
        return sb.toString();
    }

    public static C3.b d(String str) {
        return e(str, false);
    }

    public static C3.b e(String str, boolean z4) {
        int i5;
        if (str == null) {
            return f456d;
        }
        try {
            i5 = Character.getNumericValue(str.charAt(0));
        } catch (IndexOutOfBoundsException unused) {
            i5 = -1;
        }
        if (z4) {
            try {
                str = H3.a.c(str, f457e);
            } catch (H3.b unused2) {
                return f456d;
            }
        }
        if (i5 >= 0) {
            Map map = f455c;
            if (i5 < map.size()) {
                return str.length() > 1 ? new C3.b((String) map.get(Integer.valueOf(i5)), str.substring(1)) : new C3.b((String) map.get(Integer.valueOf(i5)));
            }
        }
        return f456d;
    }

    public static C3.b f(byte[] bArr) {
        byte b5 = bArr[0];
        int length = bArr.length - 1;
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 1, bArr2, 0, length);
        return new C3.b((String) f455c.get(Integer.valueOf(b5)), bArr2);
    }

    public static void g(String str, e eVar) {
        if (str == null || str.length() == 0) {
            eVar.a(f456d, 0, 1);
            return;
        }
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        int i5 = 0;
        while (i5 < length) {
            char charAt = str.charAt(i5);
            if (':' != charAt) {
                sb.append(charAt);
            } else {
                try {
                    int parseInt = Integer.parseInt(sb.toString());
                    int i6 = i5 + 1;
                    try {
                        String substring = str.substring(i6, i6 + parseInt);
                        if (substring.length() != 0) {
                            C3.b e5 = e(substring, false);
                            if (f456d.f451a.equals(e5.f451a) && ((String) f456d.f452b).equals(e5.f452b)) {
                                eVar.a(f456d, 0, 1);
                                return;
                            } else if (!eVar.a(e5, i5 + parseInt, length)) {
                                return;
                            }
                        }
                        i5 += parseInt;
                        sb = new StringBuilder();
                    } catch (IndexOutOfBoundsException unused) {
                        eVar.a(f456d, 0, 1);
                        return;
                    }
                } catch (NumberFormatException unused2) {
                    eVar.a(f456d, 0, 1);
                    return;
                }
            }
            i5++;
        }
        if (sb.length() > 0) {
            eVar.a(f456d, 0, 1);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x002a, code lost:
    
        r2 = (java.nio.ByteBuffer) r10.position(r1.length() + 1);
        r10 = r10.slice();
        r1 = java.lang.Integer.parseInt(r1.toString());
        r2 = (java.nio.ByteBuffer) r10.position(1);
        r1 = r1 + 1;
        r2 = (java.nio.ByteBuffer) r10.limit(r1);
        r2 = new byte[r10.remaining()];
        r10.get(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0057, code lost:
    
        if (r4 == false) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0059, code lost:
    
        r0.add(c(r2));
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0061, code lost:
    
        r0.add(r2);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void h(byte[] r10, C3.c.e r11) {
        /*
            java.nio.ByteBuffer r10 = java.nio.ByteBuffer.wrap(r10)
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
        L9:
            int r1 = r10.capacity()
            r2 = 0
            r3 = 1
            if (r1 <= 0) goto L89
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            byte r4 = r10.get(r2)
            r5 = 255(0xff, float:3.57E-43)
            r4 = r4 & r5
            if (r4 != 0) goto L21
            r4 = r3
            goto L22
        L21:
            r4 = r2
        L22:
            r6 = r3
        L23:
            byte r7 = r10.get(r6)
            r7 = r7 & r5
            if (r7 != r5) goto L75
            int r2 = r1.length()
            int r2 = r2 + r3
            java.nio.Buffer r2 = r10.position(r2)
            java.nio.ByteBuffer r2 = (java.nio.ByteBuffer) r2
            java.nio.ByteBuffer r10 = r10.slice()
            java.lang.String r1 = r1.toString()
            int r1 = java.lang.Integer.parseInt(r1)
            java.nio.Buffer r2 = r10.position(r3)
            java.nio.ByteBuffer r2 = (java.nio.ByteBuffer) r2
            int r1 = r1 + r3
            java.nio.Buffer r2 = r10.limit(r1)
            java.nio.ByteBuffer r2 = (java.nio.ByteBuffer) r2
            int r2 = r10.remaining()
            byte[] r2 = new byte[r2]
            r10.get(r2)
            if (r4 == 0) goto L61
            java.lang.String r2 = c(r2)
            r0.add(r2)
            goto L64
        L61:
            r0.add(r2)
        L64:
            java.nio.Buffer r2 = r10.clear()
            java.nio.ByteBuffer r2 = (java.nio.ByteBuffer) r2
            java.nio.Buffer r1 = r10.position(r1)
            java.nio.ByteBuffer r1 = (java.nio.ByteBuffer) r1
            java.nio.ByteBuffer r10 = r10.slice()
            goto L9
        L75:
            int r8 = r1.length()
            int r9 = C3.c.f453a
            if (r8 <= r9) goto L83
            C3.b r10 = C3.c.f456d
            r11.a(r10, r2, r3)
            return
        L83:
            r1.append(r7)
            int r6 = r6 + 1
            goto L23
        L89:
            int r10 = r0.size()
        L8d:
            if (r2 >= r10) goto Lb1
            java.lang.Object r1 = r0.get(r2)
            boolean r4 = r1 instanceof java.lang.String
            if (r4 == 0) goto La1
            java.lang.String r1 = (java.lang.String) r1
            C3.b r1 = e(r1, r3)
            r11.a(r1, r2, r10)
            goto Lae
        La1:
            boolean r4 = r1 instanceof byte[]
            if (r4 == 0) goto Lae
            byte[] r1 = (byte[]) r1
            C3.b r1 = f(r1)
            r11.a(r1, r2, r10)
        Lae:
            int r2 = r2 + 1
            goto L8d
        Lb1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: C3.c.h(byte[], C3.c$e):void");
    }

    private static void i(C3.b bVar, f fVar) {
        byte[] bArr = (byte[]) bVar.f452b;
        byte[] bArr2 = new byte[bArr.length + 1];
        bArr2[0] = ((Integer) f454b.get(bVar.f451a)).byteValue();
        System.arraycopy(bArr, 0, bArr2, 1, bArr.length);
        fVar.call(bArr2);
    }

    private static void j(C3.b bVar, f fVar) {
        l(bVar, true, new d(fVar));
    }

    public static void k(C3.b bVar, f fVar) {
        l(bVar, false, fVar);
    }

    public static void l(C3.b bVar, boolean z4, f fVar) {
        if (bVar.f452b instanceof byte[]) {
            i(bVar, fVar);
            return;
        }
        String valueOf = String.valueOf(f454b.get(bVar.f451a));
        if (bVar.f452b != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(valueOf);
            String valueOf2 = String.valueOf(bVar.f452b);
            if (z4) {
                valueOf2 = H3.a.e(valueOf2, f457e);
            }
            sb.append(valueOf2);
            valueOf = sb.toString();
        }
        fVar.call(valueOf);
    }

    public static void m(C3.b[] bVarArr, f fVar) {
        for (C3.b bVar : bVarArr) {
            if (bVar.f452b instanceof byte[]) {
                n(bVarArr, fVar);
                return;
            }
        }
        if (bVarArr.length == 0) {
            fVar.call("0:");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (C3.b bVar2 : bVarArr) {
            l(bVar2, false, new b(sb));
        }
        fVar.call(sb.toString());
    }

    private static void n(C3.b[] bVarArr, f fVar) {
        if (bVarArr.length == 0) {
            fVar.call(new byte[0]);
            return;
        }
        ArrayList arrayList = new ArrayList(bVarArr.length);
        for (C3.b bVar : bVarArr) {
            j(bVar, new C0018c(arrayList));
        }
        fVar.call(C3.a.a((byte[][]) arrayList.toArray(new byte[arrayList.size()][])));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String o(String str) {
        return str.length() + StringUtils.PROCESS_POSTFIX_DELIMITER + str;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static byte[] p(String str) {
        int length = str.length();
        byte[] bArr = new byte[length];
        for (int i5 = 0; i5 < length; i5++) {
            bArr[i5] = (byte) Character.codePointAt(str, i5);
        }
        return bArr;
    }
}
