package C3;

import java.nio.ByteBuffer;

/* loaded from: classes8.dex */
abstract class a {
    public static byte[] a(byte[][] bArr) {
        int i5 = 0;
        for (byte[] bArr2 : bArr) {
            i5 += bArr2.length;
        }
        return b(bArr, i5);
    }

    public static byte[] b(byte[][] bArr, int i5) {
        if (bArr.length == 0) {
            return new byte[0];
        }
        if (bArr.length == 1) {
            return bArr[0];
        }
        ByteBuffer allocate = ByteBuffer.allocate(i5);
        for (byte[] bArr2 : bArr) {
            allocate.put(bArr2);
        }
        return allocate.array();
    }
}
