package a;

/* renamed from: a.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0968a {
    public final StackTraceElement a() {
        StackTraceElement b5;
        b5 = b.b(new Exception(), c.class.getSimpleName());
        return b5;
    }
}
