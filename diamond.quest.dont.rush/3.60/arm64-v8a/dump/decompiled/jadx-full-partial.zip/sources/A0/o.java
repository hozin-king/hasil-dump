package A0;

import com.ironsource.cc;

/* loaded from: classes3.dex */
public enum o {
    URL(cc.f26458r),
    ENABLED("is_enabled"),
    DATASETID("dataset_id"),
    ACCESSKEY("access_key");


    /* renamed from: b, reason: collision with root package name */
    private final String f168b;

    o(String str) {
        this.f168b = str;
    }

    public final String b() {
        return this.f168b;
    }
}
