package A0;

import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes3.dex */
public enum a {
    MOBILE_APP_INSTALL,
    CUSTOM,
    OTHER;


    /* renamed from: b, reason: collision with root package name */
    public static final C0000a f16b = new C0000a(null);

    /* renamed from: A0.a$a, reason: collision with other inner class name */
    public static final class C0000a {
        public /* synthetic */ C0000a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final a a(String rawValue) {
            C7150s.j(rawValue, "rawValue");
            return C7150s.e(rawValue, "MOBILE_APP_INSTALL") ? a.MOBILE_APP_INSTALL : C7150s.e(rawValue, "CUSTOM_APP_EVENTS") ? a.CUSTOM : a.OTHER;
        }

        private C0000a() {
        }
    }
}
