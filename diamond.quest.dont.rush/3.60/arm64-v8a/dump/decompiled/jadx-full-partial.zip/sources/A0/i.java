package A0;

import com.google.firebase.analytics.FirebaseAnalytics;
import io.bidmachine.unified.UnifiedMediationParams;

/* loaded from: classes3.dex */
public enum i {
    VALUE_TO_SUM("value"),
    EVENT_TIME("event_time"),
    EVENT_NAME("event_name"),
    CONTENT_IDS("content_ids"),
    CONTENTS("contents"),
    CONTENT_TYPE(FirebaseAnalytics.Param.CONTENT_TYPE),
    DESCRIPTION(UnifiedMediationParams.KEY_DESCRIPTION),
    LEVEL("level"),
    MAX_RATING_VALUE("max_rating_value"),
    NUM_ITEMS("num_items"),
    PAYMENT_INFO_AVAILABLE("payment_info_available"),
    REGISTRATION_METHOD("registration_method"),
    SEARCH_STRING("search_string"),
    SUCCESS("success"),
    ORDER_ID("order_id"),
    AD_TYPE("ad_type"),
    CURRENCY("currency");


    /* renamed from: b, reason: collision with root package name */
    private final String f94b;

    i(String str) {
        this.f94b = str;
    }

    public final String b() {
        return this.f94b;
    }
}
