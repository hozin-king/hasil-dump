package A0;

import com.mbridge.msdk.MBridgeConstans;

/* loaded from: classes3.dex */
public enum n {
    EVENT("event"),
    ACTION_SOURCE("action_source"),
    APP(MBridgeConstans.DYNAMIC_VIEW_WX_APP),
    MOBILE_APP_INSTALL("MobileAppInstall"),
    INSTALL_EVENT_TIME("install_timestamp");


    /* renamed from: b, reason: collision with root package name */
    private final String f162b;

    n(String str) {
        this.f162b = str;
    }

    public final String b() {
        return this.f162b;
    }
}
