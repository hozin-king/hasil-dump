package A0;

/* loaded from: classes3.dex */
public enum k {
    USER_DATA("user_data"),
    APP_DATA("app_data"),
    CUSTOM_DATA("custom_data"),
    CUSTOM_EVENTS("custom_events");


    /* renamed from: b, reason: collision with root package name */
    private final String f116b;

    k(String str) {
        this.f116b = str;
    }

    public final String b() {
        return this.f116b;
    }
}
