package A0;

import com.adjust.sdk.Constants;
import com.applovin.sdk.AppLovinEventParameters;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* loaded from: classes3.dex */
public enum b {
    ANON_ID("anon_id"),
    APP_USER_ID("app_user_id"),
    ADVERTISER_ID("advertiser_id"),
    PAGE_ID("page_id"),
    PAGE_SCOPED_USER_ID("page_scoped_user_id"),
    USER_DATA("ud"),
    ADV_TE("advertiser_tracking_enabled"),
    APP_TE("application_tracking_enabled"),
    CONSIDER_VIEWS("consider_views"),
    DEVICE_TOKEN("device_token"),
    EXT_INFO("extInfo"),
    INCLUDE_DWELL_DATA("include_dwell_data"),
    INCLUDE_VIDEO_DATA("include_video_data"),
    INSTALL_REFERRER(Constants.INSTALL_REFERRER),
    INSTALLER_PACKAGE("installer_package"),
    RECEIPT_DATA(AppLovinEventParameters.IN_APP_PURCHASE_DATA),
    URL_SCHEMES("url_schemes");


    /* renamed from: c, reason: collision with root package name */
    public static final a f21c = new a(null);

    /* renamed from: b, reason: collision with root package name */
    private final String f40b;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final b a(String rawValue) {
            C7150s.j(rawValue, "rawValue");
            for (b bVar : b.values()) {
                if (C7150s.e(bVar.b(), rawValue)) {
                    return bVar;
                }
            }
            return null;
        }

        private a() {
        }
    }

    b(String str) {
        this.f40b = str;
    }

    public final String b() {
        return this.f40b;
    }
}
