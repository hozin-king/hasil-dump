package T3;

import Z3.c;
import com.adjust.sdk.Constants;
import kotlin.jvm.internal.C7150s;
import kotlin.jvm.internal.InterfaceC7140h;
import kotlin.jvm.internal.L;

/* loaded from: classes8.dex */
public abstract class a {
    public static final Class a(c cVar) {
        C7150s.j(cVar, "<this>");
        Class a5 = ((InterfaceC7140h) cVar).a();
        C7150s.h(a5, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
        return a5;
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue
    java.lang.NullPointerException: Cannot invoke "java.util.List.iterator()" because the return value of "jadx.core.dex.visitors.regions.SwitchOverStringVisitor$SwitchData.getNewCases()" is null
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.restoreSwitchOverString(SwitchOverStringVisitor.java:109)
    	at jadx.core.dex.visitors.regions.SwitchOverStringVisitor.visitRegion(SwitchOverStringVisitor.java:66)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:77)
    	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseIterativeStepInternal(DepthRegionTraversal.java:82)
     */
    public static final Class b(c cVar) {
        C7150s.j(cVar, "<this>");
        Class a5 = ((InterfaceC7140h) cVar).a();
        if (!a5.isPrimitive()) {
            C7150s.h(a5, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
            return a5;
        }
        String name = a5.getName();
        switch (name.hashCode()) {
            case -1325958191:
                if (name.equals("double")) {
                    a5 = Double.class;
                    break;
                }
                break;
            case 104431:
                if (name.equals("int")) {
                    a5 = Integer.class;
                    break;
                }
                break;
            case 3039496:
                if (name.equals("byte")) {
                    a5 = Byte.class;
                    break;
                }
                break;
            case 3052374:
                if (name.equals("char")) {
                    a5 = Character.class;
                    break;
                }
                break;
            case 3327612:
                if (name.equals(Constants.LONG)) {
                    a5 = Long.class;
                    break;
                }
                break;
            case 3625364:
                if (name.equals("void")) {
                    a5 = Void.class;
                    break;
                }
                break;
            case 64711720:
                if (name.equals("boolean")) {
                    a5 = Boolean.class;
                    break;
                }
                break;
            case 97526364:
                if (name.equals("float")) {
                    a5 = Float.class;
                    break;
                }
                break;
            case 109413500:
                if (name.equals("short")) {
                    a5 = Short.class;
                    break;
                }
                break;
        }
        C7150s.h(a5, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
        return a5;
    }

    public static final c c(Class cls) {
        C7150s.j(cls, "<this>");
        return L.b(cls);
    }
}
