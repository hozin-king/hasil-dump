package G;

import android.R;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: b, reason: collision with root package name */
    public static int f850b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static int f851c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static int f852d = 2;

    /* renamed from: f, reason: collision with root package name */
    public static int f854f = 0;

    /* renamed from: g, reason: collision with root package name */
    public static int f855g = 1;

    /* renamed from: a, reason: collision with root package name */
    public static int[] f849a = {R.attr.name, R.attr.id, R.attr.tag};

    /* renamed from: e, reason: collision with root package name */
    public static int[] f853e = {R.attr.name, R.attr.tag};

    private c() {
    }
}
