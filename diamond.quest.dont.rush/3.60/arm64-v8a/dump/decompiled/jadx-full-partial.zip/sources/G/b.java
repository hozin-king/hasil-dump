package G;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static int f846a = 2131362114;

    /* renamed from: b, reason: collision with root package name */
    public static int f847b = 2131362710;

    /* renamed from: c, reason: collision with root package name */
    public static int f848c = 2131362793;

    private b() {
    }
}
