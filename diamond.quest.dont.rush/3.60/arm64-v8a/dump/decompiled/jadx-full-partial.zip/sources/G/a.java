package G;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static int f840a = 2130837504;

    /* renamed from: b, reason: collision with root package name */
    public static int f841b = 2130837505;

    /* renamed from: c, reason: collision with root package name */
    public static int f842c = 2130837506;

    /* renamed from: d, reason: collision with root package name */
    public static int f843d = 2130837507;

    /* renamed from: e, reason: collision with root package name */
    public static int f844e = 2130837508;

    /* renamed from: f, reason: collision with root package name */
    public static int f845f = 2130837509;

    private a() {
    }
}
