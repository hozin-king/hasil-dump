package Z;

import android.content.Context;
import android.graphics.Path;
import android.util.AttributeSet;
import androidx.annotation.NonNull;

/* renamed from: Z.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0957g {
    public AbstractC0957g() {
    }

    public abstract Path a(float f5, float f6, float f7, float f8);

    public AbstractC0957g(@NonNull Context context, @NonNull AttributeSet attributeSet) {
    }
}
