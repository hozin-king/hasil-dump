package Z;

/* renamed from: Z.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0959i {

    /* renamed from: a, reason: collision with root package name */
    public static int f2129a = 2131362684;

    /* renamed from: b, reason: collision with root package name */
    public static int f2130b = 2131362767;

    private C0959i() {
    }
}
