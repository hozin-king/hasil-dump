package Z;

import android.view.View;

/* loaded from: classes.dex */
abstract class E extends N {

    /* renamed from: c, reason: collision with root package name */
    private static boolean f2057c = true;

    E() {
    }

    @Override // Z.N
    public float b(View view) {
        float transitionAlpha;
        if (f2057c) {
            try {
                transitionAlpha = view.getTransitionAlpha();
                return transitionAlpha;
            } catch (NoSuchMethodError unused) {
                f2057c = false;
            }
        }
        return view.getAlpha();
    }

    @Override // Z.N
    public void e(View view, float f5) {
        if (f2057c) {
            try {
                view.setTransitionAlpha(f5);
                return;
            } catch (NoSuchMethodError unused) {
                f2057c = false;
            }
        }
        view.setAlpha(f5);
    }

    @Override // Z.N
    public void a(View view) {
    }

    @Override // Z.N
    public void c(View view) {
    }
}
