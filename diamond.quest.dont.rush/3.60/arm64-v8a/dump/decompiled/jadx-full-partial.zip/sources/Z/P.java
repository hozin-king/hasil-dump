package Z;

import android.view.View;
import android.view.WindowId;

/* loaded from: classes.dex */
class P implements Q {

    /* renamed from: a, reason: collision with root package name */
    private final WindowId f2080a;

    P(View view) {
        this.f2080a = view.getWindowId();
    }

    public boolean equals(Object obj) {
        return (obj instanceof P) && ((P) obj).f2080a.equals(this.f2080a);
    }

    public int hashCode() {
        return this.f2080a.hashCode();
    }
}
