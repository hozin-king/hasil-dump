package Z;

import android.graphics.Matrix;
import android.view.View;

/* loaded from: classes.dex */
abstract class H extends E {

    /* renamed from: d, reason: collision with root package name */
    private static boolean f2058d = true;

    /* renamed from: e, reason: collision with root package name */
    private static boolean f2059e = true;

    H() {
    }

    @Override // Z.N
    public void g(View view, Matrix matrix) {
        if (f2058d) {
            try {
                view.transformMatrixToGlobal(matrix);
            } catch (NoSuchMethodError unused) {
                f2058d = false;
            }
        }
    }

    @Override // Z.N
    public void h(View view, Matrix matrix) {
        if (f2059e) {
            try {
                view.transformMatrixToLocal(matrix);
            } catch (NoSuchMethodError unused) {
                f2059e = false;
            }
        }
    }
}
