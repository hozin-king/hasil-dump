package Z;

import android.os.Build;
import android.view.ViewGroup;

/* loaded from: classes.dex */
abstract class y {

    /* renamed from: a, reason: collision with root package name */
    private static boolean f2185a = true;

    static w a(ViewGroup viewGroup) {
        return new v(viewGroup);
    }

    private static void b(ViewGroup viewGroup, boolean z4) {
        if (f2185a) {
            try {
                viewGroup.suppressLayout(z4);
            } catch (NoSuchMethodError unused) {
                f2185a = false;
            }
        }
    }

    static void c(ViewGroup viewGroup, boolean z4) {
        if (Build.VERSION.SDK_INT >= 29) {
            viewGroup.suppressLayout(z4);
        } else {
            b(viewGroup, z4);
        }
    }
}
