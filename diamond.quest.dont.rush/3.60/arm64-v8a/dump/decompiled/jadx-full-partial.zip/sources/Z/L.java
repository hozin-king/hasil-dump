package Z;

import android.os.Build;
import android.view.View;

/* loaded from: classes.dex */
class L extends J {

    /* renamed from: g, reason: collision with root package name */
    private static boolean f2061g = true;

    L() {
    }

    @Override // Z.N
    public void f(View view, int i5) {
        if (Build.VERSION.SDK_INT == 28) {
            super.f(view, i5);
        } else if (f2061g) {
            try {
                view.setTransitionVisibility(i5);
            } catch (NoSuchMethodError unused) {
                f2061g = false;
            }
        }
    }
}
