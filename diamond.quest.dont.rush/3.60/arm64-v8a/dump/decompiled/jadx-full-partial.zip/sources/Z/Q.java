package Z;

/* loaded from: classes.dex */
interface Q {
}
