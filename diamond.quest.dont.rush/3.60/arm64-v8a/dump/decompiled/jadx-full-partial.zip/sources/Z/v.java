package Z;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

/* loaded from: classes.dex */
class v implements w {

    /* renamed from: a, reason: collision with root package name */
    private final ViewGroupOverlay f2184a;

    v(ViewGroup viewGroup) {
        this.f2184a = viewGroup.getOverlay();
    }

    @Override // Z.A
    public void a(Drawable drawable) {
        this.f2184a.remove(drawable);
    }

    @Override // Z.A
    public void b(Drawable drawable) {
        this.f2184a.add(drawable);
    }

    @Override // Z.w
    public void c(View view) {
        this.f2184a.add(view);
    }

    @Override // Z.w
    public void d(View view) {
        this.f2184a.remove(view);
    }
}
