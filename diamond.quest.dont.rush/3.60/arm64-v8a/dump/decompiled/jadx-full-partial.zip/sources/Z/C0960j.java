package Z;

import android.animation.TypeEvaluator;
import android.graphics.Rect;

/* renamed from: Z.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
class C0960j implements TypeEvaluator {

    /* renamed from: a, reason: collision with root package name */
    private Rect f2131a;

    C0960j() {
    }

    @Override // android.animation.TypeEvaluator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public Rect evaluate(float f5, Rect rect, Rect rect2) {
        int i5 = rect.left + ((int) ((rect2.left - r0) * f5));
        int i6 = rect.top + ((int) ((rect2.top - r1) * f5));
        int i7 = rect.right + ((int) ((rect2.right - r2) * f5));
        int i8 = rect.bottom + ((int) ((rect2.bottom - r6) * f5));
        Rect rect3 = this.f2131a;
        if (rect3 == null) {
            return new Rect(i5, i6, i7, i8);
        }
        rect3.set(i5, i6, i7, i8);
        return this.f2131a;
    }
}
