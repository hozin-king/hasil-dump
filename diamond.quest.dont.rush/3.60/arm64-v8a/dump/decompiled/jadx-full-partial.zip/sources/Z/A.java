package Z;

import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
interface A {
    void a(Drawable drawable);

    void b(Drawable drawable);
}
