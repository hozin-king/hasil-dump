package Z;

import android.view.View;

/* loaded from: classes.dex */
abstract class J extends H {

    /* renamed from: f, reason: collision with root package name */
    private static boolean f2060f = true;

    J() {
    }

    @Override // Z.N
    public void d(View view, int i5, int i6, int i7, int i8) {
        if (f2060f) {
            try {
                view.setLeftTopRightBottom(i5, i6, i7, i8);
            } catch (NoSuchMethodError unused) {
                f2060f = false;
            }
        }
    }
}
