package Z;

import android.view.View;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class t {

    /* renamed from: b, reason: collision with root package name */
    public View f2178b;

    /* renamed from: a, reason: collision with root package name */
    public final Map f2177a = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    final ArrayList f2179c = new ArrayList();

    @Deprecated
    public t() {
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof t)) {
            return false;
        }
        t tVar = (t) obj;
        return this.f2178b == tVar.f2178b && this.f2177a.equals(tVar.f2177a);
    }

    public int hashCode() {
        return (this.f2178b.hashCode() * 31) + this.f2177a.hashCode();
    }

    public String toString() {
        String str = (("TransitionValues@" + Integer.toHexString(hashCode()) + ":\n") + "    view = " + this.f2178b + "\n") + "    values:";
        for (String str2 : this.f2177a.keySet()) {
            str = str + "    " + str2 + ": " + this.f2177a.get(str2) + "\n";
        }
        return str;
    }

    public t(@NonNull View view) {
        this.f2178b = view;
    }
}
