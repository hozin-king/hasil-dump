package Z;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.InflateException;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.C1015b0;
import com.ironsource.C4306m5;
import com.ironsource.mediationsdk.utils.IronSourceConstants;
import io.appmetrica.analytics.coreutils.internal.StringUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/* renamed from: Z.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0963m implements Cloneable {
    private static final int[] DEFAULT_MATCH_ORDER = {2, 1, 3, 4};
    private static final AbstractC0957g STRAIGHT_PATH_MOTION = new a();
    private static ThreadLocal<androidx.collection.a> sRunningAnimators = new ThreadLocal<>();
    private ArrayList<t> mEndValuesList;
    private e mEpicenterCallback;
    private androidx.collection.a mNameOverrides;
    AbstractC0966p mPropagation;
    private ArrayList<t> mStartValuesList;
    private String mName = getClass().getName();
    private long mStartDelay = -1;
    long mDuration = -1;
    private TimeInterpolator mInterpolator = null;
    ArrayList<Integer> mTargetIds = new ArrayList<>();
    ArrayList<View> mTargets = new ArrayList<>();
    private ArrayList<String> mTargetNames = null;
    private ArrayList<Class<?>> mTargetTypes = null;
    private ArrayList<Integer> mTargetIdExcludes = null;
    private ArrayList<View> mTargetExcludes = null;
    private ArrayList<Class<?>> mTargetTypeExcludes = null;
    private ArrayList<String> mTargetNameExcludes = null;
    private ArrayList<Integer> mTargetIdChildExcludes = null;
    private ArrayList<View> mTargetChildExcludes = null;
    private ArrayList<Class<?>> mTargetTypeChildExcludes = null;
    private u mStartValues = new u();
    private u mEndValues = new u();
    C0967q mParent = null;
    private int[] mMatchOrder = DEFAULT_MATCH_ORDER;
    boolean mCanRemoveViews = false;
    ArrayList<Animator> mCurrentAnimators = new ArrayList<>();
    private int mNumInstances = 0;
    private boolean mPaused = false;
    private boolean mEnded = false;
    private ArrayList<f> mListeners = null;
    private ArrayList<Animator> mAnimators = new ArrayList<>();
    private AbstractC0957g mPathMotion = STRAIGHT_PATH_MOTION;

    /* renamed from: Z.m$a */
    class a extends AbstractC0957g {
        a() {
        }

        @Override // Z.AbstractC0957g
        public Path a(float f5, float f6, float f7, float f8) {
            Path path = new Path();
            path.moveTo(f5, f6);
            path.lineTo(f7, f8);
            return path;
        }
    }

    /* renamed from: Z.m$b */
    class b extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ androidx.collection.a f2149a;

        b(androidx.collection.a aVar) {
            this.f2149a = aVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2149a.remove(animator);
            AbstractC0963m.this.mCurrentAnimators.remove(animator);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            AbstractC0963m.this.mCurrentAnimators.add(animator);
        }
    }

    /* renamed from: Z.m$c */
    class c extends AnimatorListenerAdapter {
        c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            AbstractC0963m.this.end();
            animator.removeListener(this);
        }
    }

    /* renamed from: Z.m$d */
    private static class d {

        /* renamed from: a, reason: collision with root package name */
        View f2152a;

        /* renamed from: b, reason: collision with root package name */
        String f2153b;

        /* renamed from: c, reason: collision with root package name */
        t f2154c;

        /* renamed from: d, reason: collision with root package name */
        Q f2155d;

        /* renamed from: e, reason: collision with root package name */
        AbstractC0963m f2156e;

        d(View view, String str, AbstractC0963m abstractC0963m, Q q5, t tVar) {
            this.f2152a = view;
            this.f2153b = str;
            this.f2154c = tVar;
            this.f2155d = q5;
            this.f2156e = abstractC0963m;
        }
    }

    /* renamed from: Z.m$e */
    public static abstract class e {
    }

    /* renamed from: Z.m$f */
    public interface f {
        void onTransitionCancel(AbstractC0963m abstractC0963m);

        void onTransitionEnd(AbstractC0963m abstractC0963m);

        void onTransitionPause(AbstractC0963m abstractC0963m);

        void onTransitionResume(AbstractC0963m abstractC0963m);

        void onTransitionStart(AbstractC0963m abstractC0963m);
    }

    public AbstractC0963m() {
    }

    private void a(androidx.collection.a aVar, androidx.collection.a aVar2) {
        for (int i5 = 0; i5 < aVar.size(); i5++) {
            t tVar = (t) aVar.l(i5);
            if (isValidTarget(tVar.f2178b)) {
                this.mStartValuesList.add(tVar);
                this.mEndValuesList.add(null);
            }
        }
        for (int i6 = 0; i6 < aVar2.size(); i6++) {
            t tVar2 = (t) aVar2.l(i6);
            if (isValidTarget(tVar2.f2178b)) {
                this.mEndValuesList.add(tVar2);
                this.mStartValuesList.add(null);
            }
        }
    }

    private static void b(u uVar, View view, t tVar) {
        uVar.f2180a.put(view, tVar);
        int id = view.getId();
        if (id >= 0) {
            if (uVar.f2181b.indexOfKey(id) >= 0) {
                uVar.f2181b.put(id, null);
            } else {
                uVar.f2181b.put(id, view);
            }
        }
        String E4 = C1015b0.E(view);
        if (E4 != null) {
            if (uVar.f2183d.containsKey(E4)) {
                uVar.f2183d.put(E4, null);
            } else {
                uVar.f2183d.put(E4, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            ListView listView = (ListView) view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                if (uVar.f2182c.h(itemIdAtPosition) < 0) {
                    C1015b0.l0(view, true);
                    uVar.f2182c.k(itemIdAtPosition, view);
                    return;
                }
                View view2 = (View) uVar.f2182c.f(itemIdAtPosition);
                if (view2 != null) {
                    C1015b0.l0(view2, false);
                    uVar.f2182c.k(itemIdAtPosition, null);
                }
            }
        }
    }

    private static boolean c(int[] iArr, int i5) {
        int i6 = iArr[i5];
        for (int i7 = 0; i7 < i5; i7++) {
            if (iArr[i7] == i6) {
                return true;
            }
        }
        return false;
    }

    private void e(View view, boolean z4) {
        if (view == null) {
            return;
        }
        int id = view.getId();
        ArrayList<Integer> arrayList = this.mTargetIdExcludes;
        if (arrayList == null || !arrayList.contains(Integer.valueOf(id))) {
            ArrayList<View> arrayList2 = this.mTargetExcludes;
            if (arrayList2 == null || !arrayList2.contains(view)) {
                ArrayList<Class<?>> arrayList3 = this.mTargetTypeExcludes;
                if (arrayList3 != null) {
                    int size = arrayList3.size();
                    for (int i5 = 0; i5 < size; i5++) {
                        if (this.mTargetTypeExcludes.get(i5).isInstance(view)) {
                            return;
                        }
                    }
                }
                if (view.getParent() instanceof ViewGroup) {
                    t tVar = new t(view);
                    if (z4) {
                        captureStartValues(tVar);
                    } else {
                        captureEndValues(tVar);
                    }
                    tVar.f2179c.add(this);
                    capturePropagationValues(tVar);
                    if (z4) {
                        b(this.mStartValues, view, tVar);
                    } else {
                        b(this.mEndValues, view, tVar);
                    }
                }
                if (view instanceof ViewGroup) {
                    ArrayList<Integer> arrayList4 = this.mTargetIdChildExcludes;
                    if (arrayList4 == null || !arrayList4.contains(Integer.valueOf(id))) {
                        ArrayList<View> arrayList5 = this.mTargetChildExcludes;
                        if (arrayList5 == null || !arrayList5.contains(view)) {
                            ArrayList<Class<?>> arrayList6 = this.mTargetTypeChildExcludes;
                            if (arrayList6 != null) {
                                int size2 = arrayList6.size();
                                for (int i6 = 0; i6 < size2; i6++) {
                                    if (this.mTargetTypeChildExcludes.get(i6).isInstance(view)) {
                                        return;
                                    }
                                }
                            }
                            ViewGroup viewGroup = (ViewGroup) view;
                            for (int i7 = 0; i7 < viewGroup.getChildCount(); i7++) {
                                e(viewGroup.getChildAt(i7), z4);
                            }
                        }
                    }
                }
            }
        }
    }

    private static androidx.collection.a f() {
        androidx.collection.a aVar = sRunningAnimators.get();
        if (aVar != null) {
            return aVar;
        }
        androidx.collection.a aVar2 = new androidx.collection.a();
        sRunningAnimators.set(aVar2);
        return aVar2;
    }

    private static boolean g(int i5) {
        return i5 >= 1 && i5 <= 4;
    }

    private static boolean h(t tVar, t tVar2, String str) {
        Object obj = tVar.f2177a.get(str);
        Object obj2 = tVar2.f2177a.get(str);
        if (obj == null && obj2 == null) {
            return false;
        }
        if (obj == null || obj2 == null) {
            return true;
        }
        return !obj.equals(obj2);
    }

    private void i(androidx.collection.a aVar, androidx.collection.a aVar2, SparseArray sparseArray, SparseArray sparseArray2) {
        View view;
        int size = sparseArray.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view2 = (View) sparseArray.valueAt(i5);
            if (view2 != null && isValidTarget(view2) && (view = (View) sparseArray2.get(sparseArray.keyAt(i5))) != null && isValidTarget(view)) {
                t tVar = (t) aVar.get(view2);
                t tVar2 = (t) aVar2.get(view);
                if (tVar != null && tVar2 != null) {
                    this.mStartValuesList.add(tVar);
                    this.mEndValuesList.add(tVar2);
                    aVar.remove(view2);
                    aVar2.remove(view);
                }
            }
        }
    }

    private void j(androidx.collection.a aVar, androidx.collection.a aVar2) {
        t tVar;
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View view = (View) aVar.g(size);
            if (view != null && isValidTarget(view) && (tVar = (t) aVar2.remove(view)) != null && isValidTarget(tVar.f2178b)) {
                this.mStartValuesList.add((t) aVar.i(size));
                this.mEndValuesList.add(tVar);
            }
        }
    }

    private void k(androidx.collection.a aVar, androidx.collection.a aVar2, androidx.collection.h hVar, androidx.collection.h hVar2) {
        View view;
        int n5 = hVar.n();
        for (int i5 = 0; i5 < n5; i5++) {
            View view2 = (View) hVar.o(i5);
            if (view2 != null && isValidTarget(view2) && (view = (View) hVar2.f(hVar.j(i5))) != null && isValidTarget(view)) {
                t tVar = (t) aVar.get(view2);
                t tVar2 = (t) aVar2.get(view);
                if (tVar != null && tVar2 != null) {
                    this.mStartValuesList.add(tVar);
                    this.mEndValuesList.add(tVar2);
                    aVar.remove(view2);
                    aVar2.remove(view);
                }
            }
        }
    }

    private void l(androidx.collection.a aVar, androidx.collection.a aVar2, androidx.collection.a aVar3, androidx.collection.a aVar4) {
        View view;
        int size = aVar3.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view2 = (View) aVar3.l(i5);
            if (view2 != null && isValidTarget(view2) && (view = (View) aVar4.get(aVar3.g(i5))) != null && isValidTarget(view)) {
                t tVar = (t) aVar.get(view2);
                t tVar2 = (t) aVar2.get(view);
                if (tVar != null && tVar2 != null) {
                    this.mStartValuesList.add(tVar);
                    this.mEndValuesList.add(tVar2);
                    aVar.remove(view2);
                    aVar2.remove(view);
                }
            }
        }
    }

    private void m(u uVar, u uVar2) {
        androidx.collection.a aVar = new androidx.collection.a(uVar.f2180a);
        androidx.collection.a aVar2 = new androidx.collection.a(uVar2.f2180a);
        int i5 = 0;
        while (true) {
            int[] iArr = this.mMatchOrder;
            if (i5 >= iArr.length) {
                a(aVar, aVar2);
                return;
            }
            int i6 = iArr[i5];
            if (i6 == 1) {
                j(aVar, aVar2);
            } else if (i6 == 2) {
                l(aVar, aVar2, uVar.f2183d, uVar2.f2183d);
            } else if (i6 == 3) {
                i(aVar, aVar2, uVar.f2181b, uVar2.f2181b);
            } else if (i6 == 4) {
                k(aVar, aVar2, uVar.f2182c, uVar2.f2182c);
            }
            i5++;
        }
    }

    private static int[] n(String str) {
        StringTokenizer stringTokenizer = new StringTokenizer(str, StringUtils.COMMA);
        int[] iArr = new int[stringTokenizer.countTokens()];
        int i5 = 0;
        while (stringTokenizer.hasMoreTokens()) {
            String trim = stringTokenizer.nextToken().trim();
            if ("id".equalsIgnoreCase(trim)) {
                iArr[i5] = 3;
            } else if (C4306m5.f28034p.equalsIgnoreCase(trim)) {
                iArr[i5] = 1;
            } else if ("name".equalsIgnoreCase(trim)) {
                iArr[i5] = 2;
            } else if ("itemId".equalsIgnoreCase(trim)) {
                iArr[i5] = 4;
            } else {
                if (!trim.isEmpty()) {
                    throw new InflateException("Unknown match type in matchOrder: '" + trim + "'");
                }
                int[] iArr2 = new int[iArr.length - 1];
                System.arraycopy(iArr, 0, iArr2, 0, i5);
                i5--;
                iArr = iArr2;
            }
            i5++;
        }
        return iArr;
    }

    private void o(Animator animator, androidx.collection.a aVar) {
        if (animator != null) {
            animator.addListener(new b(aVar));
            animate(animator);
        }
    }

    @NonNull
    public AbstractC0963m addListener(@NonNull f fVar) {
        if (this.mListeners == null) {
            this.mListeners = new ArrayList<>();
        }
        this.mListeners.add(fVar);
        return this;
    }

    @NonNull
    public AbstractC0963m addTarget(@NonNull View view) {
        this.mTargets.add(view);
        return this;
    }

    protected void animate(Animator animator) {
        if (animator == null) {
            end();
            return;
        }
        if (getDuration() >= 0) {
            animator.setDuration(getDuration());
        }
        if (getStartDelay() >= 0) {
            animator.setStartDelay(getStartDelay() + animator.getStartDelay());
        }
        if (getInterpolator() != null) {
            animator.setInterpolator(getInterpolator());
        }
        animator.addListener(new c());
        animator.start();
    }

    protected void cancel() {
        for (int size = this.mCurrentAnimators.size() - 1; size >= 0; size--) {
            this.mCurrentAnimators.get(size).cancel();
        }
        ArrayList<f> arrayList = this.mListeners;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        ArrayList arrayList2 = (ArrayList) this.mListeners.clone();
        int size2 = arrayList2.size();
        for (int i5 = 0; i5 < size2; i5++) {
            ((f) arrayList2.get(i5)).onTransitionCancel(this);
        }
    }

    public abstract void captureEndValues(t tVar);

    void capturePropagationValues(t tVar) {
        String[] b5;
        if (this.mPropagation == null || tVar.f2177a.isEmpty() || (b5 = this.mPropagation.b()) == null) {
            return;
        }
        for (String str : b5) {
            if (!tVar.f2177a.containsKey(str)) {
                this.mPropagation.a(tVar);
                return;
            }
        }
    }

    public abstract void captureStartValues(t tVar);

    void captureValues(ViewGroup viewGroup, boolean z4) {
        ArrayList<String> arrayList;
        ArrayList<Class<?>> arrayList2;
        androidx.collection.a aVar;
        clearValues(z4);
        if ((this.mTargetIds.size() > 0 || this.mTargets.size() > 0) && (((arrayList = this.mTargetNames) == null || arrayList.isEmpty()) && ((arrayList2 = this.mTargetTypes) == null || arrayList2.isEmpty()))) {
            for (int i5 = 0; i5 < this.mTargetIds.size(); i5++) {
                View findViewById = viewGroup.findViewById(this.mTargetIds.get(i5).intValue());
                if (findViewById != null) {
                    t tVar = new t(findViewById);
                    if (z4) {
                        captureStartValues(tVar);
                    } else {
                        captureEndValues(tVar);
                    }
                    tVar.f2179c.add(this);
                    capturePropagationValues(tVar);
                    if (z4) {
                        b(this.mStartValues, findViewById, tVar);
                    } else {
                        b(this.mEndValues, findViewById, tVar);
                    }
                }
            }
            for (int i6 = 0; i6 < this.mTargets.size(); i6++) {
                View view = this.mTargets.get(i6);
                t tVar2 = new t(view);
                if (z4) {
                    captureStartValues(tVar2);
                } else {
                    captureEndValues(tVar2);
                }
                tVar2.f2179c.add(this);
                capturePropagationValues(tVar2);
                if (z4) {
                    b(this.mStartValues, view, tVar2);
                } else {
                    b(this.mEndValues, view, tVar2);
                }
            }
        } else {
            e(viewGroup, z4);
        }
        if (z4 || (aVar = this.mNameOverrides) == null) {
            return;
        }
        int size = aVar.size();
        ArrayList arrayList3 = new ArrayList(size);
        for (int i7 = 0; i7 < size; i7++) {
            arrayList3.add(this.mStartValues.f2183d.remove((String) this.mNameOverrides.g(i7)));
        }
        for (int i8 = 0; i8 < size; i8++) {
            View view2 = (View) arrayList3.get(i8);
            if (view2 != null) {
                this.mStartValues.f2183d.put((String) this.mNameOverrides.l(i8), view2);
            }
        }
    }

    void clearValues(boolean z4) {
        if (z4) {
            this.mStartValues.f2180a.clear();
            this.mStartValues.f2181b.clear();
            this.mStartValues.f2182c.b();
        } else {
            this.mEndValues.f2180a.clear();
            this.mEndValues.f2181b.clear();
            this.mEndValues.f2182c.b();
        }
    }

    public Animator createAnimator(ViewGroup viewGroup, t tVar, t tVar2) {
        return null;
    }

    protected void createAnimators(ViewGroup viewGroup, u uVar, u uVar2, ArrayList<t> arrayList, ArrayList<t> arrayList2) {
        Animator createAnimator;
        int i5;
        int i6;
        View view;
        t tVar;
        Animator animator;
        t tVar2;
        int i7;
        androidx.collection.a f5 = f();
        SparseIntArray sparseIntArray = new SparseIntArray();
        int size = arrayList.size();
        long j5 = Long.MAX_VALUE;
        int i8 = 0;
        while (i8 < size) {
            t tVar3 = arrayList.get(i8);
            t tVar4 = arrayList2.get(i8);
            if (tVar3 != null && !tVar3.f2179c.contains(this)) {
                tVar3 = null;
            }
            if (tVar4 != null && !tVar4.f2179c.contains(this)) {
                tVar4 = null;
            }
            if (!(tVar3 == null && tVar4 == null) && ((tVar3 == null || tVar4 == null || isTransitionRequired(tVar3, tVar4)) && (createAnimator = createAnimator(viewGroup, tVar3, tVar4)) != null)) {
                if (tVar4 != null) {
                    view = tVar4.f2178b;
                    String[] transitionProperties = getTransitionProperties();
                    if (transitionProperties != null && transitionProperties.length > 0) {
                        tVar2 = new t(view);
                        i5 = size;
                        i6 = i8;
                        t tVar5 = (t) uVar2.f2180a.get(view);
                        if (tVar5 != null) {
                            int i9 = 0;
                            while (i9 < transitionProperties.length) {
                                Map map = tVar2.f2177a;
                                String[] strArr = transitionProperties;
                                String str = strArr[i9];
                                map.put(str, tVar5.f2177a.get(str));
                                i9++;
                                transitionProperties = strArr;
                            }
                        }
                        int size2 = f5.size();
                        int i10 = 0;
                        while (true) {
                            if (i10 >= size2) {
                                animator = createAnimator;
                                break;
                            }
                            d dVar = (d) f5.get((Animator) f5.g(i10));
                            if (dVar.f2154c != null && dVar.f2152a == view) {
                                i7 = size2;
                                if (dVar.f2153b.equals(getName()) && dVar.f2154c.equals(tVar2)) {
                                    animator = null;
                                    break;
                                }
                            } else {
                                i7 = size2;
                            }
                            i10++;
                            size2 = i7;
                        }
                    } else {
                        i5 = size;
                        i6 = i8;
                        animator = createAnimator;
                        tVar2 = null;
                    }
                    createAnimator = animator;
                    tVar = tVar2;
                } else {
                    i5 = size;
                    i6 = i8;
                    view = tVar3.f2178b;
                    tVar = null;
                }
                if (createAnimator != null) {
                    AbstractC0966p abstractC0966p = this.mPropagation;
                    if (abstractC0966p != null) {
                        long c5 = abstractC0966p.c(viewGroup, this, tVar3, tVar4);
                        sparseIntArray.put(this.mAnimators.size(), (int) c5);
                        j5 = Math.min(c5, j5);
                    }
                    f5.put(createAnimator, new d(view, getName(), this, B.d(viewGroup), tVar));
                    this.mAnimators.add(createAnimator);
                    j5 = j5;
                }
            } else {
                i5 = size;
                i6 = i8;
            }
            i8 = i6 + 1;
            size = i5;
        }
        if (sparseIntArray.size() != 0) {
            for (int i11 = 0; i11 < sparseIntArray.size(); i11++) {
                Animator animator2 = this.mAnimators.get(sparseIntArray.keyAt(i11));
                animator2.setStartDelay((sparseIntArray.valueAt(i11) - j5) + animator2.getStartDelay());
            }
        }
    }

    protected void end() {
        int i5 = this.mNumInstances - 1;
        this.mNumInstances = i5;
        if (i5 == 0) {
            ArrayList<f> arrayList = this.mListeners;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.mListeners.clone();
                int size = arrayList2.size();
                for (int i6 = 0; i6 < size; i6++) {
                    ((f) arrayList2.get(i6)).onTransitionEnd(this);
                }
            }
            for (int i7 = 0; i7 < this.mStartValues.f2182c.n(); i7++) {
                View view = (View) this.mStartValues.f2182c.o(i7);
                if (view != null) {
                    C1015b0.l0(view, false);
                }
            }
            for (int i8 = 0; i8 < this.mEndValues.f2182c.n(); i8++) {
                View view2 = (View) this.mEndValues.f2182c.o(i8);
                if (view2 != null) {
                    C1015b0.l0(view2, false);
                }
            }
            this.mEnded = true;
        }
    }

    void forceToEnd(ViewGroup viewGroup) {
        androidx.collection.a f5 = f();
        int size = f5.size();
        if (viewGroup == null || size == 0) {
            return;
        }
        Q d5 = B.d(viewGroup);
        androidx.collection.a aVar = new androidx.collection.a(f5);
        f5.clear();
        for (int i5 = size - 1; i5 >= 0; i5--) {
            d dVar = (d) aVar.l(i5);
            if (dVar.f2152a != null && d5 != null && d5.equals(dVar.f2155d)) {
                ((Animator) aVar.g(i5)).end();
            }
        }
    }

    public long getDuration() {
        return this.mDuration;
    }

    @Nullable
    public e getEpicenterCallback() {
        return this.mEpicenterCallback;
    }

    @Nullable
    public TimeInterpolator getInterpolator() {
        return this.mInterpolator;
    }

    t getMatchedTransitionValues(View view, boolean z4) {
        C0967q c0967q = this.mParent;
        if (c0967q != null) {
            return c0967q.getMatchedTransitionValues(view, z4);
        }
        ArrayList<t> arrayList = z4 ? this.mStartValuesList : this.mEndValuesList;
        if (arrayList == null) {
            return null;
        }
        int size = arrayList.size();
        int i5 = 0;
        while (true) {
            if (i5 >= size) {
                i5 = -1;
                break;
            }
            t tVar = arrayList.get(i5);
            if (tVar == null) {
                return null;
            }
            if (tVar.f2178b == view) {
                break;
            }
            i5++;
        }
        if (i5 >= 0) {
            return (z4 ? this.mEndValuesList : this.mStartValuesList).get(i5);
        }
        return null;
    }

    @NonNull
    public String getName() {
        return this.mName;
    }

    @NonNull
    public AbstractC0957g getPathMotion() {
        return this.mPathMotion;
    }

    @Nullable
    public AbstractC0966p getPropagation() {
        return this.mPropagation;
    }

    public long getStartDelay() {
        return this.mStartDelay;
    }

    @NonNull
    public List<Integer> getTargetIds() {
        return this.mTargetIds;
    }

    @Nullable
    public List<String> getTargetNames() {
        return this.mTargetNames;
    }

    @Nullable
    public List<Class<?>> getTargetTypes() {
        return this.mTargetTypes;
    }

    @NonNull
    public List<View> getTargets() {
        return this.mTargets;
    }

    public String[] getTransitionProperties() {
        return null;
    }

    @Nullable
    public t getTransitionValues(@NonNull View view, boolean z4) {
        C0967q c0967q = this.mParent;
        if (c0967q != null) {
            return c0967q.getTransitionValues(view, z4);
        }
        return (t) (z4 ? this.mStartValues : this.mEndValues).f2180a.get(view);
    }

    public boolean isTransitionRequired(@Nullable t tVar, @Nullable t tVar2) {
        if (tVar != null && tVar2 != null) {
            String[] transitionProperties = getTransitionProperties();
            if (transitionProperties != null) {
                for (String str : transitionProperties) {
                    if (h(tVar, tVar2, str)) {
                        return true;
                    }
                }
            } else {
                Iterator it = tVar.f2177a.keySet().iterator();
                while (it.hasNext()) {
                    if (h(tVar, tVar2, (String) it.next())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    boolean isValidTarget(View view) {
        ArrayList<Class<?>> arrayList;
        ArrayList<String> arrayList2;
        int id = view.getId();
        ArrayList<Integer> arrayList3 = this.mTargetIdExcludes;
        if (arrayList3 != null && arrayList3.contains(Integer.valueOf(id))) {
            return false;
        }
        ArrayList<View> arrayList4 = this.mTargetExcludes;
        if (arrayList4 != null && arrayList4.contains(view)) {
            return false;
        }
        ArrayList<Class<?>> arrayList5 = this.mTargetTypeExcludes;
        if (arrayList5 != null) {
            int size = arrayList5.size();
            for (int i5 = 0; i5 < size; i5++) {
                if (this.mTargetTypeExcludes.get(i5).isInstance(view)) {
                    return false;
                }
            }
        }
        if (this.mTargetNameExcludes != null && C1015b0.E(view) != null && this.mTargetNameExcludes.contains(C1015b0.E(view))) {
            return false;
        }
        if ((this.mTargetIds.size() == 0 && this.mTargets.size() == 0 && (((arrayList = this.mTargetTypes) == null || arrayList.isEmpty()) && ((arrayList2 = this.mTargetNames) == null || arrayList2.isEmpty()))) || this.mTargetIds.contains(Integer.valueOf(id)) || this.mTargets.contains(view)) {
            return true;
        }
        ArrayList<String> arrayList6 = this.mTargetNames;
        if (arrayList6 != null && arrayList6.contains(C1015b0.E(view))) {
            return true;
        }
        if (this.mTargetTypes != null) {
            for (int i6 = 0; i6 < this.mTargetTypes.size(); i6++) {
                if (this.mTargetTypes.get(i6).isInstance(view)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void pause(View view) {
        if (this.mEnded) {
            return;
        }
        for (int size = this.mCurrentAnimators.size() - 1; size >= 0; size--) {
            AbstractC0951a.b(this.mCurrentAnimators.get(size));
        }
        ArrayList<f> arrayList = this.mListeners;
        if (arrayList != null && arrayList.size() > 0) {
            ArrayList arrayList2 = (ArrayList) this.mListeners.clone();
            int size2 = arrayList2.size();
            for (int i5 = 0; i5 < size2; i5++) {
                ((f) arrayList2.get(i5)).onTransitionPause(this);
            }
        }
        this.mPaused = true;
    }

    void playTransition(ViewGroup viewGroup) {
        d dVar;
        this.mStartValuesList = new ArrayList<>();
        this.mEndValuesList = new ArrayList<>();
        m(this.mStartValues, this.mEndValues);
        androidx.collection.a f5 = f();
        int size = f5.size();
        Q d5 = B.d(viewGroup);
        for (int i5 = size - 1; i5 >= 0; i5--) {
            Animator animator = (Animator) f5.g(i5);
            if (animator != null && (dVar = (d) f5.get(animator)) != null && dVar.f2152a != null && d5.equals(dVar.f2155d)) {
                t tVar = dVar.f2154c;
                View view = dVar.f2152a;
                t transitionValues = getTransitionValues(view, true);
                t matchedTransitionValues = getMatchedTransitionValues(view, true);
                if (transitionValues == null && matchedTransitionValues == null) {
                    matchedTransitionValues = (t) this.mEndValues.f2180a.get(view);
                }
                if ((transitionValues != null || matchedTransitionValues != null) && dVar.f2156e.isTransitionRequired(tVar, matchedTransitionValues)) {
                    if (animator.isRunning() || animator.isStarted()) {
                        animator.cancel();
                    } else {
                        f5.remove(animator);
                    }
                }
            }
        }
        createAnimators(viewGroup, this.mStartValues, this.mEndValues, this.mStartValuesList, this.mEndValuesList);
        runAnimators();
    }

    @NonNull
    public AbstractC0963m removeListener(@NonNull f fVar) {
        ArrayList<f> arrayList = this.mListeners;
        if (arrayList != null) {
            arrayList.remove(fVar);
            if (this.mListeners.size() == 0) {
                this.mListeners = null;
            }
        }
        return this;
    }

    @NonNull
    public AbstractC0963m removeTarget(@NonNull View view) {
        this.mTargets.remove(view);
        return this;
    }

    public void resume(View view) {
        if (this.mPaused) {
            if (!this.mEnded) {
                for (int size = this.mCurrentAnimators.size() - 1; size >= 0; size--) {
                    AbstractC0951a.c(this.mCurrentAnimators.get(size));
                }
                ArrayList<f> arrayList = this.mListeners;
                if (arrayList != null && arrayList.size() > 0) {
                    ArrayList arrayList2 = (ArrayList) this.mListeners.clone();
                    int size2 = arrayList2.size();
                    for (int i5 = 0; i5 < size2; i5++) {
                        ((f) arrayList2.get(i5)).onTransitionResume(this);
                    }
                }
            }
            this.mPaused = false;
        }
    }

    protected void runAnimators() {
        start();
        androidx.collection.a f5 = f();
        ArrayList<Animator> arrayList = this.mAnimators;
        int size = arrayList.size();
        int i5 = 0;
        while (i5 < size) {
            Animator animator = arrayList.get(i5);
            i5++;
            Animator animator2 = animator;
            if (f5.containsKey(animator2)) {
                start();
                o(animator2, f5);
            }
        }
        this.mAnimators.clear();
        end();
    }

    void setCanRemoveViews(boolean z4) {
        this.mCanRemoveViews = z4;
    }

    @NonNull
    public AbstractC0963m setDuration(long j5) {
        this.mDuration = j5;
        return this;
    }

    public void setEpicenterCallback(@Nullable e eVar) {
        this.mEpicenterCallback = eVar;
    }

    @NonNull
    public AbstractC0963m setInterpolator(@Nullable TimeInterpolator timeInterpolator) {
        this.mInterpolator = timeInterpolator;
        return this;
    }

    public void setMatchOrder(int... iArr) {
        if (iArr == null || iArr.length == 0) {
            this.mMatchOrder = DEFAULT_MATCH_ORDER;
            return;
        }
        for (int i5 = 0; i5 < iArr.length; i5++) {
            if (!g(iArr[i5])) {
                throw new IllegalArgumentException("matches contains invalid value");
            }
            if (c(iArr, i5)) {
                throw new IllegalArgumentException("matches contains a duplicate value");
            }
        }
        this.mMatchOrder = (int[]) iArr.clone();
    }

    public void setPathMotion(@Nullable AbstractC0957g abstractC0957g) {
        if (abstractC0957g == null) {
            this.mPathMotion = STRAIGHT_PATH_MOTION;
        } else {
            this.mPathMotion = abstractC0957g;
        }
    }

    public void setPropagation(@Nullable AbstractC0966p abstractC0966p) {
        this.mPropagation = abstractC0966p;
    }

    @NonNull
    public AbstractC0963m setStartDelay(long j5) {
        this.mStartDelay = j5;
        return this;
    }

    protected void start() {
        if (this.mNumInstances == 0) {
            ArrayList<f> arrayList = this.mListeners;
            if (arrayList != null && arrayList.size() > 0) {
                ArrayList arrayList2 = (ArrayList) this.mListeners.clone();
                int size = arrayList2.size();
                for (int i5 = 0; i5 < size; i5++) {
                    ((f) arrayList2.get(i5)).onTransitionStart(this);
                }
            }
            this.mEnded = false;
        }
        this.mNumInstances++;
    }

    public String toString() {
        return toString("");
    }

    @NonNull
    public AbstractC0963m addTarget(int i5) {
        if (i5 != 0) {
            this.mTargetIds.add(Integer.valueOf(i5));
        }
        return this;
    }

    @Override // 
    /* renamed from: clone */
    public AbstractC0963m mo1clone() {
        try {
            AbstractC0963m abstractC0963m = (AbstractC0963m) super.clone();
            abstractC0963m.mAnimators = new ArrayList<>();
            abstractC0963m.mStartValues = new u();
            abstractC0963m.mEndValues = new u();
            abstractC0963m.mStartValuesList = null;
            abstractC0963m.mEndValuesList = null;
            return abstractC0963m;
        } catch (CloneNotSupportedException unused) {
            return null;
        }
    }

    String toString(String str) {
        String str2 = str + getClass().getSimpleName() + "@" + Integer.toHexString(hashCode()) + ": ";
        if (this.mDuration != -1) {
            str2 = str2 + "dur(" + this.mDuration + ") ";
        }
        if (this.mStartDelay != -1) {
            str2 = str2 + "dly(" + this.mStartDelay + ") ";
        }
        if (this.mInterpolator != null) {
            str2 = str2 + "interp(" + this.mInterpolator + ") ";
        }
        if (this.mTargetIds.size() <= 0 && this.mTargets.size() <= 0) {
            return str2;
        }
        String str3 = str2 + "tgts(";
        if (this.mTargetIds.size() > 0) {
            for (int i5 = 0; i5 < this.mTargetIds.size(); i5++) {
                if (i5 > 0) {
                    str3 = str3 + ", ";
                }
                str3 = str3 + this.mTargetIds.get(i5);
            }
        }
        if (this.mTargets.size() > 0) {
            for (int i6 = 0; i6 < this.mTargets.size(); i6++) {
                if (i6 > 0) {
                    str3 = str3 + ", ";
                }
                str3 = str3 + this.mTargets.get(i6);
            }
        }
        return str3 + ")";
    }

    @SuppressLint({"RestrictedApi"})
    public AbstractC0963m(@NonNull Context context, @NonNull AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0962l.f2140c);
        XmlResourceParser xmlResourceParser = (XmlResourceParser) attributeSet;
        long g5 = androidx.core.content.res.k.g(obtainStyledAttributes, xmlResourceParser, IronSourceConstants.EVENTS_DURATION, 1, -1);
        if (g5 >= 0) {
            setDuration(g5);
        }
        long g6 = androidx.core.content.res.k.g(obtainStyledAttributes, xmlResourceParser, "startDelay", 2, -1);
        if (g6 > 0) {
            setStartDelay(g6);
        }
        int h5 = androidx.core.content.res.k.h(obtainStyledAttributes, xmlResourceParser, "interpolator", 0, 0);
        if (h5 > 0) {
            setInterpolator(AnimationUtils.loadInterpolator(context, h5));
        }
        String i5 = androidx.core.content.res.k.i(obtainStyledAttributes, xmlResourceParser, "matchOrder", 3);
        if (i5 != null) {
            setMatchOrder(n(i5));
        }
        obtainStyledAttributes.recycle();
    }
}
