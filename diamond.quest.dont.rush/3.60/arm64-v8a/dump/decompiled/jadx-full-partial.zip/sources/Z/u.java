package Z;

import android.util.SparseArray;

/* loaded from: classes.dex */
class u {

    /* renamed from: a, reason: collision with root package name */
    final androidx.collection.a f2180a = new androidx.collection.a();

    /* renamed from: b, reason: collision with root package name */
    final SparseArray f2181b = new SparseArray();

    /* renamed from: c, reason: collision with root package name */
    final androidx.collection.h f2182c = new androidx.collection.h();

    /* renamed from: d, reason: collision with root package name */
    final androidx.collection.a f2183d = new androidx.collection.a();

    u() {
    }
}
