package Z;

import android.graphics.Matrix;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
abstract class N {

    /* renamed from: a, reason: collision with root package name */
    private static Field f2062a;

    /* renamed from: b, reason: collision with root package name */
    private static boolean f2063b;

    N() {
    }

    public abstract void a(View view);

    public abstract float b(View view);

    public abstract void c(View view);

    public abstract void d(View view, int i5, int i6, int i7, int i8);

    public abstract void e(View view, float f5);

    public void f(View view, int i5) {
        if (!f2063b) {
            try {
                Field declaredField = View.class.getDeclaredField("mViewFlags");
                f2062a = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException unused) {
                Log.i("ViewUtilsBase", "fetchViewFlagsField: ");
            }
            f2063b = true;
        }
        Field field = f2062a;
        if (field != null) {
            try {
                f2062a.setInt(view, i5 | (field.getInt(view) & (-13)));
            } catch (IllegalAccessException unused2) {
            }
        }
    }

    public abstract void g(View view, Matrix matrix);

    public abstract void h(View view, Matrix matrix);
}
