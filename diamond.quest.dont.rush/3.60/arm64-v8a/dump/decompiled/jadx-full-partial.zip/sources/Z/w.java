package Z;

import android.view.View;

/* loaded from: classes.dex */
interface w extends A {
    void c(View view);

    void d(View view);
}
