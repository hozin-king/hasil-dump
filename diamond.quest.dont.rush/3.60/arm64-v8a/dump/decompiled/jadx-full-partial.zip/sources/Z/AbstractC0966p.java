package Z;

import android.view.ViewGroup;

/* renamed from: Z.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0966p {
    public abstract void a(t tVar);

    public abstract String[] b();

    public abstract long c(ViewGroup viewGroup, AbstractC0963m abstractC0963m, t tVar, t tVar2);
}
