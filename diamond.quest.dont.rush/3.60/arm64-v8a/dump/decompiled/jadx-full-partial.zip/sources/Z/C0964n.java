package Z;

import Z.AbstractC0963m;
import androidx.annotation.NonNull;

/* renamed from: Z.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0964n implements AbstractC0963m.f {
    @Override // Z.AbstractC0963m.f
    public void onTransitionCancel(@NonNull AbstractC0963m abstractC0963m) {
    }

    @Override // Z.AbstractC0963m.f
    public void onTransitionEnd(AbstractC0963m abstractC0963m) {
    }

    @Override // Z.AbstractC0963m.f
    public void onTransitionPause(@NonNull AbstractC0963m abstractC0963m) {
    }

    @Override // Z.AbstractC0963m.f
    public void onTransitionResume(@NonNull AbstractC0963m abstractC0963m) {
    }

    @Override // Z.AbstractC0963m.f
    public void onTransitionStart(@NonNull AbstractC0963m abstractC0963m) {
    }
}
