package Z;

import android.R;

/* renamed from: Z.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
abstract class AbstractC0962l {

    /* renamed from: a, reason: collision with root package name */
    static final int[] f2138a = {R.attr.targetClass, R.attr.targetId, R.attr.excludeId, R.attr.excludeClass, R.attr.targetName, R.attr.excludeName};

    /* renamed from: b, reason: collision with root package name */
    static final int[] f2139b = {R.attr.fromScene, R.attr.toScene, R.attr.transition};

    /* renamed from: c, reason: collision with root package name */
    static final int[] f2140c = {R.attr.interpolator, R.attr.duration, R.attr.startDelay, R.attr.matchOrder};

    /* renamed from: d, reason: collision with root package name */
    static final int[] f2141d = {R.attr.resizeClip};

    /* renamed from: e, reason: collision with root package name */
    static final int[] f2142e = {R.attr.transitionVisibilityMode};

    /* renamed from: f, reason: collision with root package name */
    static final int[] f2143f = {R.attr.fadingMode};

    /* renamed from: g, reason: collision with root package name */
    static final int[] f2144g = {R.attr.reparent, R.attr.reparentWithOverlay};

    /* renamed from: h, reason: collision with root package name */
    static final int[] f2145h = {R.attr.slideEdge};

    /* renamed from: i, reason: collision with root package name */
    static final int[] f2146i = {R.attr.transitionOrdering};

    /* renamed from: j, reason: collision with root package name */
    static final int[] f2147j = {R.attr.minimumHorizontalAngle, R.attr.minimumVerticalAngle, R.attr.maximumAngle};

    /* renamed from: k, reason: collision with root package name */
    static final int[] f2148k = {R.attr.patternPathData};
}
