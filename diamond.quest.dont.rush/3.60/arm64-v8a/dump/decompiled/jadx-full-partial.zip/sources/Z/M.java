package Z;

import android.graphics.Matrix;
import android.view.View;

/* loaded from: classes.dex */
class M extends L {
    M() {
    }

    @Override // Z.E, Z.N
    public float b(View view) {
        float transitionAlpha;
        transitionAlpha = view.getTransitionAlpha();
        return transitionAlpha;
    }

    @Override // Z.J, Z.N
    public void d(View view, int i5, int i6, int i7, int i8) {
        view.setLeftTopRightBottom(i5, i6, i7, i8);
    }

    @Override // Z.E, Z.N
    public void e(View view, float f5) {
        view.setTransitionAlpha(f5);
    }

    @Override // Z.L, Z.N
    public void f(View view, int i5) {
        view.setTransitionVisibility(i5);
    }

    @Override // Z.H, Z.N
    public void g(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }

    @Override // Z.H, Z.N
    public void h(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }
}
