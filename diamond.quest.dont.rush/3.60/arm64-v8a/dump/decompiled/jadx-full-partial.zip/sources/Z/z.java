package Z;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOverlay;

/* loaded from: classes.dex */
class z implements A {

    /* renamed from: a, reason: collision with root package name */
    private final ViewOverlay f2186a;

    z(View view) {
        this.f2186a = view.getOverlay();
    }

    @Override // Z.A
    public void a(Drawable drawable) {
        this.f2186a.remove(drawable);
    }

    @Override // Z.A
    public void b(Drawable drawable) {
        this.f2186a.add(drawable);
    }
}
