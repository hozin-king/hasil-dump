package Z;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Build;
import android.util.Property;
import android.view.View;
import androidx.core.view.C1015b0;

/* loaded from: classes.dex */
abstract class B {

    /* renamed from: a, reason: collision with root package name */
    private static final N f2054a;

    /* renamed from: b, reason: collision with root package name */
    static final Property f2055b;

    /* renamed from: c, reason: collision with root package name */
    static final Property f2056c;

    class a extends Property {
        a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(B.c(view));
        }

        @Override // android.util.Property
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f5) {
            B.g(view, f5.floatValue());
        }
    }

    class b extends Property {
        b(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Rect get(View view) {
            return C1015b0.t(view);
        }

        @Override // android.util.Property
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Rect rect) {
            C1015b0.j0(view, rect);
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 29) {
            f2054a = new M();
        } else {
            f2054a = new L();
        }
        f2055b = new a(Float.class, "translationAlpha");
        f2056c = new b(Rect.class, "clipBounds");
    }

    static void a(View view) {
        f2054a.a(view);
    }

    static A b(View view) {
        return new z(view);
    }

    static float c(View view) {
        return f2054a.b(view);
    }

    static Q d(View view) {
        return new P(view);
    }

    static void e(View view) {
        f2054a.c(view);
    }

    static void f(View view, int i5, int i6, int i7, int i8) {
        f2054a.d(view, i5, i6, i7, i8);
    }

    static void g(View view, float f5) {
        f2054a.e(view, f5);
    }

    static void h(View view, int i5) {
        f2054a.f(view, i5);
    }

    static void i(View view, Matrix matrix) {
        f2054a.g(view, matrix);
    }

    static void j(View view, Matrix matrix) {
        f2054a.h(view, matrix);
    }
}
