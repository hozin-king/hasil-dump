package Z;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;

/* renamed from: Z.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0961k {

    /* renamed from: a, reason: collision with root package name */
    private Context f2132a;

    /* renamed from: b, reason: collision with root package name */
    private int f2133b;

    /* renamed from: c, reason: collision with root package name */
    private ViewGroup f2134c;

    /* renamed from: d, reason: collision with root package name */
    private View f2135d;

    /* renamed from: e, reason: collision with root package name */
    private Runnable f2136e;

    /* renamed from: f, reason: collision with root package name */
    private Runnable f2137f;

    public C0961k(@NonNull ViewGroup viewGroup) {
        this.f2133b = -1;
        this.f2134c = viewGroup;
    }

    public static C0961k c(ViewGroup viewGroup) {
        return (C0961k) viewGroup.getTag(C0959i.f2130b);
    }

    static void f(ViewGroup viewGroup, C0961k c0961k) {
        viewGroup.setTag(C0959i.f2130b, c0961k);
    }

    public void a() {
        if (this.f2133b > 0 || this.f2135d != null) {
            d().removeAllViews();
            if (this.f2133b > 0) {
                LayoutInflater.from(this.f2132a).inflate(this.f2133b, this.f2134c);
            } else {
                this.f2134c.addView(this.f2135d);
            }
        }
        Runnable runnable = this.f2136e;
        if (runnable != null) {
            runnable.run();
        }
        f(this.f2134c, this);
    }

    public void b() {
        Runnable runnable;
        if (c(this.f2134c) != this || (runnable = this.f2137f) == null) {
            return;
        }
        runnable.run();
    }

    public ViewGroup d() {
        return this.f2134c;
    }

    boolean e() {
        return this.f2133b > 0;
    }

    public void g(Runnable runnable) {
        this.f2137f = runnable;
    }

    private C0961k(ViewGroup viewGroup, int i5, Context context) {
        this.f2132a = context;
        this.f2134c = viewGroup;
        this.f2133b = i5;
    }

    public C0961k(@NonNull ViewGroup viewGroup, @NonNull View view) {
        this.f2133b = -1;
        this.f2134c = viewGroup;
        this.f2135d = view;
    }
}
