package Q3;

import java.lang.reflect.Method;
import kotlin.collections.C7116i;
import kotlin.jvm.internal.C7150s;
import kotlin.random.d;

/* loaded from: classes8.dex */
public class a {

    /* renamed from: Q3.a$a, reason: collision with other inner class name */
    private static final class C0072a {

        /* renamed from: a, reason: collision with root package name */
        public static final C0072a f1690a = new C0072a();

        /* renamed from: b, reason: collision with root package name */
        public static final Method f1691b;

        /* renamed from: c, reason: collision with root package name */
        public static final Method f1692c;

        static {
            Method method;
            Method method2;
            Method[] methods = Throwable.class.getMethods();
            C7150s.g(methods);
            int length = methods.length;
            int i5 = 0;
            int i6 = 0;
            while (true) {
                method = null;
                if (i6 >= length) {
                    method2 = null;
                    break;
                }
                method2 = methods[i6];
                if (C7150s.e(method2.getName(), "addSuppressed")) {
                    Class<?>[] parameterTypes = method2.getParameterTypes();
                    C7150s.i(parameterTypes, "getParameterTypes(...)");
                    if (C7150s.e(C7116i.i0(parameterTypes), Throwable.class)) {
                        break;
                    }
                }
                i6++;
            }
            f1691b = method2;
            int length2 = methods.length;
            while (true) {
                if (i5 >= length2) {
                    break;
                }
                Method method3 = methods[i5];
                if (C7150s.e(method3.getName(), "getSuppressed")) {
                    method = method3;
                    break;
                }
                i5++;
            }
            f1692c = method;
        }

        private C0072a() {
        }
    }

    public void a(Throwable cause, Throwable exception) {
        C7150s.j(cause, "cause");
        C7150s.j(exception, "exception");
        Method method = C0072a.f1691b;
        if (method != null) {
            method.invoke(cause, exception);
        }
    }

    public d b() {
        return new kotlin.random.b();
    }
}
