package a2;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/* renamed from: a2.a, reason: case insensitive filesystem */
/* loaded from: classes4.dex */
public class C0972a implements d {

    /* renamed from: b, reason: collision with root package name */
    private d f2236b;

    /* renamed from: c, reason: collision with root package name */
    private PBEParameterSpec f2237c;

    /* renamed from: d, reason: collision with root package name */
    private PBEKeySpec f2238d;

    /* renamed from: e, reason: collision with root package name */
    private SecretKey f2239e;

    private void d(char[] cArr) {
        this.f2237c = new PBEParameterSpec(new byte[]{-57, 115, 33, -116, 126, -56, -18, -103}, 20);
        this.f2238d = new PBEKeySpec(cArr);
        try {
            this.f2239e = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(this.f2238d);
        } catch (Exception e5) {
            e5.printStackTrace();
        }
    }

    public Cipher a() {
        try {
            Cipher cipher = Cipher.getInstance("PBEWithMD5AndDES");
            cipher.init(2, this.f2239e, this.f2237c);
            return cipher;
        } catch (Exception unused) {
            return null;
        }
    }

    public Cipher b() {
        try {
            Cipher cipher = Cipher.getInstance("PBEWithMD5AndDES");
            cipher.init(1, this.f2239e, this.f2237c);
            return cipher;
        } catch (Exception unused) {
            return null;
        }
    }

    public void c() {
        String hash = getHash();
        if (hash != null) {
            Object h5 = h();
            if (h5 != null && h5.getClass().getName().indexOf(".") < 0) {
                hash = hash.substring(1);
            }
            d(hash.toCharArray());
        }
    }

    public void e(d dVar) {
        this.f2236b = dVar;
    }

    @Override // a2.d
    public String getHash() {
        d dVar = this.f2236b;
        if (dVar != null) {
            return dVar.getHash();
        }
        return null;
    }

    @Override // a2.d
    public Object h() {
        d dVar = this.f2236b;
        if (dVar != null) {
            return dVar.h();
        }
        return null;
    }
}
