package a2;

/* loaded from: classes4.dex */
public interface d {
    String getHash();

    Object h();
}
