package V2;

/* loaded from: classes6.dex */
public abstract /* synthetic */ class d {
}
