package E2;

/* loaded from: classes6.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private String f585a;

    /* renamed from: b, reason: collision with root package name */
    private String f586b;

    /* renamed from: c, reason: collision with root package name */
    private String f587c;

    /* renamed from: d, reason: collision with root package name */
    private String f588d;

    /* renamed from: e, reason: collision with root package name */
    private Integer f589e;

    public c(String str, String str2) {
        this(str, str2, null, null, null);
    }

    public String a() {
        return this.f588d;
    }

    public String b() {
        return this.f587c;
    }

    public String c() {
        return this.f585a;
    }

    public String d() {
        return this.f586b;
    }

    public Integer e() {
        return this.f589e;
    }

    public c(String str, String str2, String str3, String str4, Integer num) {
        this.f585a = str;
        this.f586b = str2;
        this.f587c = str3;
        this.f588d = str4;
        this.f589e = num;
    }
}
