package E2;

import android.app.Activity;

/* loaded from: classes6.dex */
public interface a {
    void show(Activity activity);
}
