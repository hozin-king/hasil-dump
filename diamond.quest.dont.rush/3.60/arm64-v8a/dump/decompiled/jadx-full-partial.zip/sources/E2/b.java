package E2;

/* loaded from: classes6.dex */
public interface b {
    void onAdLoaded();
}
