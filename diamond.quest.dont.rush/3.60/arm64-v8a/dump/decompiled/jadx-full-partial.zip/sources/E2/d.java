package E2;

/* loaded from: classes6.dex */
public enum d {
    INTERSTITIAL,
    REWARDED,
    BANNER
}
