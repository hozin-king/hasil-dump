package Y1;

/* loaded from: classes4.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public final String f2006a;

    public a(String str) {
        this.f2006a = str;
    }
}
