package Y1;

/* loaded from: classes4.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public final String f2007a;

    public b(String str) {
        this.f2007a = str;
    }
}
