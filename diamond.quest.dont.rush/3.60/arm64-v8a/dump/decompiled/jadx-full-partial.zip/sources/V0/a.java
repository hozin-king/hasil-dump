package V0;

/* loaded from: classes3.dex */
public abstract class a {
    public abstract a b();

    public boolean d() {
        return b() != null;
    }

    public abstract String e();
}
