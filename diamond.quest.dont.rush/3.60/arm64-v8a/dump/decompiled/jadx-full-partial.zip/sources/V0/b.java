package V0;

import com.fasterxml.jackson.core.k;

/* loaded from: classes3.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public Object f1894a;

    /* renamed from: b, reason: collision with root package name */
    public Class f1895b;

    /* renamed from: c, reason: collision with root package name */
    public Object f1896c;

    /* renamed from: d, reason: collision with root package name */
    public String f1897d;

    /* renamed from: e, reason: collision with root package name */
    public a f1898e;

    /* renamed from: f, reason: collision with root package name */
    public k f1899f;

    /* renamed from: g, reason: collision with root package name */
    public boolean f1900g;

    public enum a {
        WRAPPER_ARRAY,
        WRAPPER_OBJECT,
        METADATA_PROPERTY,
        PAYLOAD_PROPERTY,
        PARENT_PROPERTY;

        public boolean a() {
            return this == METADATA_PROPERTY || this == PAYLOAD_PROPERTY;
        }
    }

    public b() {
    }

    public b(Object obj, k kVar) {
        this(obj, kVar, (Object) null);
    }

    public b(Object obj, Class<?> cls, k kVar) {
        this(obj, kVar, (Object) null);
        this.f1895b = cls;
    }

    public b(Object obj, k kVar, Object obj2) {
        this.f1894a = obj;
        this.f1896c = obj2;
        this.f1899f = kVar;
    }
}
