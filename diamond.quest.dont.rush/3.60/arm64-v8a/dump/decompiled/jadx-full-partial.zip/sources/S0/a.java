package S0;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes3.dex */
public interface a extends IInterface {

    public static class b {
        /* JADX INFO: Access modifiers changed from: private */
        public static Object c(Parcel parcel, Parcelable.Creator creator) {
            if (parcel.readInt() != 0) {
                return creator.createFromParcel(parcel);
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static void d(Parcel parcel, Parcelable parcelable, int i5) {
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                parcel.writeInt(1);
                parcelable.writeToParcel(parcel, i5);
            }
        }
    }

    int m(Bundle bundle);

    /* renamed from: S0.a$a, reason: collision with other inner class name */
    public static abstract class AbstractBinderC0076a extends Binder implements a {

        /* renamed from: S0.a$a$a, reason: collision with other inner class name */
        private static class C0077a implements a {

            /* renamed from: b, reason: collision with root package name */
            private IBinder f1736b;

            C0077a(IBinder iBinder) {
                this.f1736b = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f1736b;
            }

            @Override // S0.a
            public int m(Bundle bundle) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.facebook.ppml.receiver.IReceiverService");
                    b.d(obtain, bundle, 0);
                    this.f1736b.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public AbstractBinderC0076a() {
            attachInterface(this, "com.facebook.ppml.receiver.IReceiverService");
        }

        public static a C0(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.facebook.ppml.receiver.IReceiverService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof a)) ? new C0077a(iBinder) : (a) queryLocalInterface;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i5, Parcel parcel, Parcel parcel2, int i6) {
            if (i5 >= 1 && i5 <= 16777215) {
                parcel.enforceInterface("com.facebook.ppml.receiver.IReceiverService");
            }
            if (i5 == 1598968902) {
                parcel2.writeString("com.facebook.ppml.receiver.IReceiverService");
                return true;
            }
            if (i5 != 1) {
                return super.onTransact(i5, parcel, parcel2, i6);
            }
            int m5 = m((Bundle) b.c(parcel, Bundle.CREATOR));
            parcel2.writeNoException();
            parcel2.writeInt(m5);
            return true;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }
    }
}
