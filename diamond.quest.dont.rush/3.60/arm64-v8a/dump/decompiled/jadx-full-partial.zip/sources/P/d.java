package P;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.zip.CRC32;
import java.util.zip.ZipException;

/* loaded from: classes.dex */
abstract class d {

    static class a {

        /* renamed from: a, reason: collision with root package name */
        long f1630a;

        /* renamed from: b, reason: collision with root package name */
        long f1631b;

        a() {
        }
    }

    static long a(RandomAccessFile randomAccessFile, a aVar) {
        CRC32 crc32 = new CRC32();
        long j5 = aVar.f1631b;
        randomAccessFile.seek(aVar.f1630a);
        byte[] bArr = new byte[16384];
        int read = randomAccessFile.read(bArr, 0, (int) Math.min(16384L, j5));
        while (read != -1) {
            crc32.update(bArr, 0, read);
            j5 -= read;
            if (j5 == 0) {
                break;
            }
            read = randomAccessFile.read(bArr, 0, (int) Math.min(16384L, j5));
        }
        return crc32.getValue();
    }

    static a b(RandomAccessFile randomAccessFile) {
        long length = randomAccessFile.length();
        long j5 = length - 22;
        if (j5 < 0) {
            throw new ZipException("File too short to be a zip file: " + randomAccessFile.length());
        }
        long j6 = length - 65558;
        long j7 = j6 >= 0 ? j6 : 0L;
        int reverseBytes = Integer.reverseBytes(101010256);
        do {
            randomAccessFile.seek(j5);
            if (randomAccessFile.readInt() == reverseBytes) {
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                a aVar = new a();
                aVar.f1631b = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                aVar.f1630a = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                return aVar;
            }
            j5--;
        } while (j5 >= j7);
        throw new ZipException("End Of Central Directory signature not found");
    }

    static long c(File file) {
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        try {
            return a(randomAccessFile, b(randomAccessFile));
        } finally {
            randomAccessFile.close();
        }
    }
}
