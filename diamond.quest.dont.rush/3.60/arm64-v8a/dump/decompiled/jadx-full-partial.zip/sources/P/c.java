package P;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.ironsource.b9;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/* loaded from: classes.dex */
final class c implements Closeable {

    /* renamed from: b, reason: collision with root package name */
    private final File f1622b;

    /* renamed from: c, reason: collision with root package name */
    private final long f1623c;

    /* renamed from: d, reason: collision with root package name */
    private final File f1624d;

    /* renamed from: e, reason: collision with root package name */
    private final RandomAccessFile f1625e;

    /* renamed from: f, reason: collision with root package name */
    private final FileChannel f1626f;

    /* renamed from: g, reason: collision with root package name */
    private final FileLock f1627g;

    class a implements FileFilter {
        a() {
        }

        @Override // java.io.FileFilter
        public boolean accept(File file) {
            return !file.getName().equals("MultiDex.lock");
        }
    }

    private static class b extends File {

        /* renamed from: b, reason: collision with root package name */
        public long f1629b;

        public b(File file, String str) {
            super(file, str);
            this.f1629b = -1L;
        }
    }

    c(File file, File file2) {
        Log.i("MultiDex", "MultiDexExtractor(" + file.getPath() + ", " + file2.getPath() + ")");
        this.f1622b = file;
        this.f1624d = file2;
        this.f1623c = k(file);
        File file3 = new File(file2, "MultiDex.lock");
        RandomAccessFile randomAccessFile = new RandomAccessFile(file3, "rw");
        this.f1625e = randomAccessFile;
        try {
            FileChannel channel = randomAccessFile.getChannel();
            this.f1626f = channel;
            try {
                Log.i("MultiDex", "Blocking on lock " + file3.getPath());
                this.f1627g = channel.lock();
                Log.i("MultiDex", file3.getPath() + " locked");
            } catch (IOException e5) {
                e = e5;
                e(this.f1626f);
                throw e;
            } catch (Error e6) {
                e = e6;
                e(this.f1626f);
                throw e;
            } catch (RuntimeException e7) {
                e = e7;
                e(this.f1626f);
                throw e;
            }
        } catch (IOException e8) {
            e = e8;
            e(this.f1625e);
            throw e;
        } catch (Error e9) {
            e = e9;
            e(this.f1625e);
            throw e;
        } catch (RuntimeException e10) {
            e = e10;
            e(this.f1625e);
            throw e;
        }
    }

    private void d() {
        File[] listFiles = this.f1624d.listFiles(new a());
        if (listFiles == null) {
            Log.w("MultiDex", "Failed to list secondary dex dir content (" + this.f1624d.getPath() + ").");
            return;
        }
        for (File file : listFiles) {
            Log.i("MultiDex", "Trying to delete old file " + file.getPath() + " of size " + file.length());
            if (file.delete()) {
                Log.i("MultiDex", "Deleted old file " + file.getPath());
            } else {
                Log.w("MultiDex", "Failed to delete old file " + file.getPath());
            }
        }
    }

    private static void e(Closeable closeable) {
        try {
            closeable.close();
        } catch (IOException e5) {
            Log.w("MultiDex", "Failed to close resource", e5);
        }
    }

    private static void g(ZipFile zipFile, ZipEntry zipEntry, File file, String str) {
        InputStream inputStream = zipFile.getInputStream(zipEntry);
        File createTempFile = File.createTempFile("tmp-" + str, ".zip", file.getParentFile());
        Log.i("MultiDex", "Extracting " + createTempFile.getPath());
        try {
            ZipOutputStream zipOutputStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(createTempFile)));
            try {
                ZipEntry zipEntry2 = new ZipEntry("classes.dex");
                zipEntry2.setTime(zipEntry.getTime());
                zipOutputStream.putNextEntry(zipEntry2);
                byte[] bArr = new byte[16384];
                for (int read = inputStream.read(bArr); read != -1; read = inputStream.read(bArr)) {
                    zipOutputStream.write(bArr, 0, read);
                }
                zipOutputStream.closeEntry();
                zipOutputStream.close();
                if (!createTempFile.setReadOnly()) {
                    throw new IOException("Failed to mark readonly \"" + createTempFile.getAbsolutePath() + "\" (tmp of \"" + file.getAbsolutePath() + "\")");
                }
                Log.i("MultiDex", "Renaming to " + file.getPath());
                if (createTempFile.renameTo(file)) {
                    e(inputStream);
                    createTempFile.delete();
                    return;
                }
                throw new IOException("Failed to rename \"" + createTempFile.getAbsolutePath() + "\" to \"" + file.getAbsolutePath() + "\"");
            } catch (Throwable th) {
                zipOutputStream.close();
                throw th;
            }
        } catch (Throwable th2) {
            e(inputStream);
            createTempFile.delete();
            throw th2;
        }
    }

    private static SharedPreferences h(Context context) {
        return context.getSharedPreferences("multidex.version", 4);
    }

    private static long i(File file) {
        long lastModified = file.lastModified();
        return lastModified == -1 ? lastModified - 1 : lastModified;
    }

    private static long k(File file) {
        long c5 = d.c(file);
        return c5 == -1 ? c5 - 1 : c5;
    }

    private static boolean m(Context context, File file, long j5, String str) {
        SharedPreferences h5 = h(context);
        if (h5.getLong(str + "timestamp", -1L) != i(file)) {
            return true;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("crc");
        return h5.getLong(sb.toString(), -1L) != j5;
    }

    private List s(Context context, String str) {
        Log.i("MultiDex", "loading existing secondary dex files");
        String str2 = this.f1622b.getName() + ".classes";
        SharedPreferences h5 = h(context);
        int i5 = h5.getInt(str + "dex.number", 1);
        ArrayList arrayList = new ArrayList(i5 + (-1));
        int i6 = 2;
        while (i6 <= i5) {
            b bVar = new b(this.f1624d, str2 + i6 + ".zip");
            if (!bVar.isFile()) {
                throw new IOException("Missing extracted secondary dex file '" + bVar.getPath() + "'");
            }
            bVar.f1629b = k(bVar);
            long j5 = h5.getLong(str + "dex.crc." + i6, -1L);
            long j6 = h5.getLong(str + "dex.time." + i6, -1L);
            long lastModified = bVar.lastModified();
            if (j6 == lastModified) {
                String str3 = str2;
                SharedPreferences sharedPreferences = h5;
                if (j5 == bVar.f1629b) {
                    arrayList.add(bVar);
                    i6++;
                    h5 = sharedPreferences;
                    str2 = str3;
                }
            }
            throw new IOException("Invalid extracted dex: " + bVar + " (key \"" + str + "\"), expected modification time: " + j6 + ", modification time: " + lastModified + ", expected crc: " + j5 + ", file crc: " + bVar.f1629b);
        }
        return arrayList;
    }

    private List u() {
        boolean z4;
        String str = this.f1622b.getName() + ".classes";
        d();
        ArrayList arrayList = new ArrayList();
        ZipFile zipFile = new ZipFile(this.f1622b);
        try {
            int i5 = 2;
            ZipEntry entry = zipFile.getEntry("classes2.dex");
            while (entry != null) {
                b bVar = new b(this.f1624d, str + i5 + ".zip");
                arrayList.add(bVar);
                Log.i("MultiDex", "Extraction is needed for file " + bVar);
                int i6 = 0;
                boolean z5 = false;
                while (i6 < 3 && !z5) {
                    int i7 = i6 + 1;
                    g(zipFile, entry, bVar, str);
                    try {
                        bVar.f1629b = k(bVar);
                        z4 = true;
                    } catch (IOException e5) {
                        Log.w("MultiDex", "Failed to read crc from " + bVar.getAbsolutePath(), e5);
                        z4 = false;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append("Extraction ");
                    sb.append(z4 ? "succeeded" : b9.h.f26222t);
                    sb.append(" '");
                    sb.append(bVar.getAbsolutePath());
                    sb.append("': length ");
                    sb.append(bVar.length());
                    sb.append(" - crc: ");
                    sb.append(bVar.f1629b);
                    Log.i("MultiDex", sb.toString());
                    if (!z4) {
                        bVar.delete();
                        if (bVar.exists()) {
                            Log.w("MultiDex", "Failed to delete corrupted secondary dex '" + bVar.getPath() + "'");
                        }
                    }
                    z5 = z4;
                    i6 = i7;
                }
                if (!z5) {
                    throw new IOException("Could not create zip file " + bVar.getAbsolutePath() + " for secondary dex (" + i5 + ")");
                }
                i5++;
                entry = zipFile.getEntry("classes" + i5 + ".dex");
            }
            try {
                zipFile.close();
            } catch (IOException e6) {
                Log.w("MultiDex", "Failed to close resource", e6);
            }
            return arrayList;
        } finally {
        }
    }

    private static void v(Context context, String str, long j5, long j6, List list) {
        SharedPreferences.Editor edit = h(context).edit();
        edit.putLong(str + "timestamp", j5);
        edit.putLong(str + "crc", j6);
        edit.putInt(str + "dex.number", list.size() + 1);
        Iterator it = list.iterator();
        int i5 = 2;
        while (it.hasNext()) {
            b bVar = (b) it.next();
            edit.putLong(str + "dex.crc." + i5, bVar.f1629b);
            edit.putLong(str + "dex.time." + i5, bVar.lastModified());
            i5++;
        }
        edit.commit();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f1627g.release();
        this.f1626f.close();
        this.f1625e.close();
    }

    List n(Context context, String str, boolean z4) {
        List u5;
        List list;
        Log.i("MultiDex", "MultiDexExtractor.load(" + this.f1622b.getPath() + ", " + z4 + ", " + str + ")");
        if (!this.f1627g.isValid()) {
            throw new IllegalStateException("MultiDexExtractor was closed");
        }
        if (!z4 && !m(context, this.f1622b, this.f1623c, str)) {
            try {
                list = s(context, str);
            } catch (IOException e5) {
                Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", e5);
                u5 = u();
                v(context, str, i(this.f1622b), this.f1623c, u5);
            }
            Log.i("MultiDex", "load found " + list.size() + " secondary dex files");
            return list;
        }
        if (z4) {
            Log.i("MultiDex", "Forced extraction must be performed.");
        } else {
            Log.i("MultiDex", "Detected that extraction must be performed.");
        }
        u5 = u();
        v(context, str, i(this.f1622b), this.f1623c, u5);
        list = u5;
        Log.i("MultiDex", "load found " + list.size() + " secondary dex files");
        return list;
    }
}
